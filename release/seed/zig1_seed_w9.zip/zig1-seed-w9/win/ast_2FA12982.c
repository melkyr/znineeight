#include "ast_2FA12982.h"
zT_8143F551_AstKind zG_8143F551_AstKind;
zT_6B0A7D14_AstStore zG_6B0A7D14_AstStore;
static unsigned char* const zG_CC2D7D2E_zzz_astnode_sz = (unsigned char*)"ZZZ_ASTNODE_24B_OFFSETS_kind0_flags1_pad2_spanlen4_spanstart8_child0_12_child1_16_child2_20";
unsigned int const zG_8CAC6FAE_AST_BLOCK_SHIFT = (unsigned int)(12);
unsigned int const zG_AD5F12EB_AST_BLOCK_NODES = (unsigned int)(4096);
unsigned int const zG_90577FCA_AST_BLOCK_NODE_BYTE = (unsigned int)(98304);
unsigned int const zG_6A9DB958_AST_BLOCK_PAYLOAD_B = (unsigned int)(16384);
unsigned int const zG_34E102E4_AST_BLOCK_REC_SIZE = (unsigned int)(114688);
unsigned int const zG_FBAC49CE_AST_SPILL_MAX_BLOCK = (unsigned int)(18724);
unsigned int const zG_E58760FE_AST_BLOCK_MASK = (unsigned int)(4095);
unsigned int const zG_EFD0414E_AST_WINDOW_SLOTS = (unsigned int)(8);
unsigned int const zG_A890E80F_AST_HEAD_SLOT = (unsigned int)(0);
unsigned int const zG_6700141F_VALUE_POOL_BLOCK_BY = (unsigned int)(4096);
unsigned int const zG_21A8D55B_VALUE_POOL_SLOTS = (unsigned int)(8);
/* u32ArrayListAppendInner */
void zF_8B163A32_u32ArrayListAppen_1(unsigned int** items, unsigned int* len, unsigned int* capacity, zT_3E40CD83_Sand* arena, unsigned int value) {
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    unsigned int zT_26;
    int zT_27;
    zT_3E40CD83_Sand* zT_30;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int* zT_35;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned char zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned char zT_47;
    zT_DD2B0E80_Opt_263 zT_49;
    unsigned char zT_50;
    unsigned int* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned char zT_59;
    zT_3E40CD83_Sand* zT_61;
    unsigned int zT_62;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    unsigned char zT_68;
    zT_FDFD82FD_EU_362 zT_70;
    unsigned char zT_71;
    unsigned char* zT_72;
    unsigned int* zT_75;
    unsigned int* zT_76;
    unsigned int zT_77;
    int zT_78;
    unsigned int* zT_79;
    unsigned int zT_80;
    unsigned char zT_81;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_82;
    unsigned int* zT_83;
    unsigned int zT_84;
    unsigned int zT_89;
    unsigned int* zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    int zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    unsigned char zT_98;
    zig_poison_fill((void*)&zT_49, (unsigned int)sizeof zT_49);
    zig_poison_fill((void*)&zT_70, (unsigned int)sizeof zT_70);
    unsigned int new_cap;
    zT_DD2B0E80_Opt_263 grown;
    unsigned char* raw;
    unsigned int* new_items_p;
    unsigned int item;
    unsigned int i;
    zT_5 = *len;
    zT_6 = *capacity;
    if ((unsigned char)(zT_5 >= zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = *capacity;
    new_cap = zT_9;
    if ((unsigned char)(new_cap < (unsigned int)(8))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_90 = *items;
    zT_91 = *len;
    zT_90[zT_91] = value;
    zT_92 = *len;
    zT_93 = 1;
    zT_94 = (unsigned int)zT_93;
    zT_95 = zig_wrap_add_u(((zu64)(zT_92)), ((zu64)(zT_94)), 32u);
    zT_96 = zig_overflow_flag_add_u(((zu64)(zT_92)), ((zu64)(zT_94)), 32u);
    zT_98 = zT_96 == (unsigned int)(0);
    if (!(zT_98)) { pal_trap(); }
    *len = zT_95;
    return;
    z_bb_3:
    zT_12 = 8;
    new_cap = zT_12;
    goto z_bb_4;
    z_bb_4:
    zT_13 = *len;
    zT_14 = 2;
    zT_15 = zig_wrap_mul_u(((zu64)(zT_13)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_mul_u(((zu64)(zT_13)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_15)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = *len;
    zT_21 = 2;
    zT_22 = zig_wrap_mul_u(((zu64)(zT_20)), ((zu64)(zT_21)), 32u);
    zT_23 = zig_overflow_flag_mul_u(((zu64)(zT_20)), ((zu64)(zT_21)), 32u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    new_cap = zT_22;
    goto z_bb_6;
    z_bb_6:
    zT_26 = *capacity;
    zT_27 = 0;
    if ((unsigned char)(zT_26 > (unsigned int)zT_27)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_30 = arena;
    zT_35 = *items;
    zT_37 = *capacity;
    zT_38 = 4;
    zT_39 = zig_wrap_mul_u(((zu64)(zT_37)), ((zu64)(zT_38)), 32u);
    zT_40 = zig_overflow_flag_mul_u(((zu64)(zT_37)), ((zu64)(zT_38)), 32u);
    zT_42 = zT_40 == (unsigned int)(0);
    if (!(zT_42)) { pal_trap(); }
    zT_32 = zT_39;
    zT_43 = 4;
    zT_44 = zig_wrap_mul_u(((zu64)(new_cap)), ((zu64)(zT_43)), 32u);
    zT_45 = zig_overflow_flag_mul_u(((zu64)(new_cap)), ((zu64)(zT_43)), 32u);
    zT_47 = zT_45 == (unsigned int)(0);
    if (!(zT_47)) { pal_trap(); }
    zT_33 = zT_44;
    zT_49 = zF_33A3D4F8_sandTryReallocInPla(zT_30, (unsigned char*)((unsigned char*)zT_35), zT_32, zT_33, (unsigned int)(4));
    grown = zT_49;
    zT_50 = grown.has_value;
    if (zT_50) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_61 = arena;
    zT_64 = 4;
    zT_65 = zig_wrap_mul_u(((zu64)(zT_64)), ((zu64)(new_cap)), 32u);
    zT_66 = zig_overflow_flag_mul_u(((zu64)(zT_64)), ((zu64)(new_cap)), 32u);
    zT_68 = zT_66 == (unsigned int)(0);
    if (!(zT_68)) { pal_trap(); }
    zT_62 = zT_65;
    zT_70 = zF_1395EB68_sandAlloc(zT_61, zT_62, (unsigned int)(4));
    zT_71 = zT_70.is_error;
    if (zT_71) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    *capacity = new_cap;
    zT_51 = *items;
    zT_52 = *len;
    zT_51[zT_52] = value;
    zT_53 = *len;
    zT_54 = 1;
    zT_55 = (unsigned int)zT_54;
    zT_56 = zig_wrap_add_u(((zu64)(zT_53)), ((zu64)(zT_55)), 32u);
    zT_57 = zig_overflow_flag_add_u(((zu64)(zT_53)), ((zu64)(zT_55)), 32u);
    zT_59 = zT_57 == (unsigned int)(0);
    if (!(zT_59)) { pal_trap(); }
    *len = zT_56;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_72 = zT_70.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_72;
    zT_75 = (unsigned int*)raw;
    new_items_p = zT_75;
    zT_76 = *items;
    zT_77 = *len;
    zT_78 = 0;
    zT_79 = zT_76 + zT_78;
    zT_80 = zT_77 - zT_78;
    zT_81 = (unsigned int)zT_78 <= zT_77;
    if (!(zT_81)) { pal_trap(); }
    zT_82.ptr = (unsigned int*)zT_79;
    zT_82.len = zT_80;
    zT_83 = zT_82.ptr;
    zT_84 = zT_82.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(i < zT_84)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_83[i];
    new_items_p[i] = item;
    goto z_bb_17;
    z_bb_16:
    *items = new_items_p;
    *capacity = new_cap;
    goto z_bb_2;
    z_bb_17:
    zT_89 = i + (unsigned int)(1);
    i = zT_89;
    goto z_bb_14;
}

/* u64ArrayListAppendInner */
void zF_FA105BA5_u64ArrayListAppendI(zT_79FAE712_u64** items, unsigned int* len, unsigned int* capacity, zT_3E40CD83_Sand* arena, zT_79FAE712_u64 value) {
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    unsigned int zT_26;
    int zT_27;
    zT_3E40CD83_Sand* zT_30;
    unsigned int zT_32;
    unsigned int zT_33;
    zT_79FAE712_u64* zT_35;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned char zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned char zT_47;
    zT_DD2B0E80_Opt_263 zT_49;
    unsigned char zT_50;
    zT_79FAE712_u64* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned char zT_59;
    zT_3E40CD83_Sand* zT_61;
    unsigned int zT_62;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    unsigned char zT_68;
    zT_FDFD82FD_EU_362 zT_70;
    unsigned char zT_71;
    unsigned char* zT_72;
    zT_79FAE712_u64* zT_75;
    zT_79FAE712_u64* zT_76;
    unsigned int zT_77;
    int zT_78;
    zT_79FAE712_u64* zT_79;
    unsigned int zT_80;
    unsigned char zT_81;
    zT_A62C5D8D_Slice_zT_79FAE712_u zT_82;
    zT_79FAE712_u64* zT_83;
    unsigned int zT_84;
    unsigned int zT_89;
    zT_79FAE712_u64* zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    int zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    unsigned char zT_98;
    zig_poison_fill((void*)&zT_49, (unsigned int)sizeof zT_49);
    zig_poison_fill((void*)&zT_70, (unsigned int)sizeof zT_70);
    unsigned int new_cap;
    zT_DD2B0E80_Opt_263 grown;
    unsigned char* raw;
    zT_79FAE712_u64* new_items_p;
    zT_79FAE712_u64 item;
    unsigned int i;
    zT_5 = *len;
    zT_6 = *capacity;
    if ((unsigned char)(zT_5 >= zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = *capacity;
    new_cap = zT_9;
    if ((unsigned char)(new_cap < (unsigned int)(8))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_90 = *items;
    zT_91 = *len;
    zT_90[zT_91] = value;
    zT_92 = *len;
    zT_93 = 1;
    zT_94 = (unsigned int)zT_93;
    zT_95 = zig_wrap_add_u(((zu64)(zT_92)), ((zu64)(zT_94)), 32u);
    zT_96 = zig_overflow_flag_add_u(((zu64)(zT_92)), ((zu64)(zT_94)), 32u);
    zT_98 = zT_96 == (unsigned int)(0);
    if (!(zT_98)) { pal_trap(); }
    *len = zT_95;
    return;
    z_bb_3:
    zT_12 = 8;
    new_cap = zT_12;
    goto z_bb_4;
    z_bb_4:
    zT_13 = *len;
    zT_14 = 2;
    zT_15 = zig_wrap_mul_u(((zu64)(zT_13)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_mul_u(((zu64)(zT_13)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_15)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = *len;
    zT_21 = 2;
    zT_22 = zig_wrap_mul_u(((zu64)(zT_20)), ((zu64)(zT_21)), 32u);
    zT_23 = zig_overflow_flag_mul_u(((zu64)(zT_20)), ((zu64)(zT_21)), 32u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    new_cap = zT_22;
    goto z_bb_6;
    z_bb_6:
    zT_26 = *capacity;
    zT_27 = 0;
    if ((unsigned char)(zT_26 > (unsigned int)zT_27)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_30 = arena;
    zT_35 = *items;
    zT_37 = *capacity;
    zT_38 = 8;
    zT_39 = zig_wrap_mul_u(((zu64)(zT_37)), ((zu64)(zT_38)), 32u);
    zT_40 = zig_overflow_flag_mul_u(((zu64)(zT_37)), ((zu64)(zT_38)), 32u);
    zT_42 = zT_40 == (unsigned int)(0);
    if (!(zT_42)) { pal_trap(); }
    zT_32 = zT_39;
    zT_43 = 8;
    zT_44 = zig_wrap_mul_u(((zu64)(new_cap)), ((zu64)(zT_43)), 32u);
    zT_45 = zig_overflow_flag_mul_u(((zu64)(new_cap)), ((zu64)(zT_43)), 32u);
    zT_47 = zT_45 == (unsigned int)(0);
    if (!(zT_47)) { pal_trap(); }
    zT_33 = zT_44;
    zT_49 = zF_33A3D4F8_sandTryReallocInPla(zT_30, (unsigned char*)((unsigned char*)zT_35), zT_32, zT_33, (unsigned int)(4));
    grown = zT_49;
    zT_50 = grown.has_value;
    if (zT_50) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_61 = arena;
    zT_64 = 8;
    zT_65 = zig_wrap_mul_u(((zu64)(zT_64)), ((zu64)(new_cap)), 32u);
    zT_66 = zig_overflow_flag_mul_u(((zu64)(zT_64)), ((zu64)(new_cap)), 32u);
    zT_68 = zT_66 == (unsigned int)(0);
    if (!(zT_68)) { pal_trap(); }
    zT_62 = zT_65;
    zT_70 = zF_1395EB68_sandAlloc(zT_61, zT_62, (unsigned int)(4));
    zT_71 = zT_70.is_error;
    if (zT_71) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    *capacity = new_cap;
    zT_51 = *items;
    zT_52 = *len;
    zT_51[zT_52] = value;
    zT_53 = *len;
    zT_54 = 1;
    zT_55 = (unsigned int)zT_54;
    zT_56 = zig_wrap_add_u(((zu64)(zT_53)), ((zu64)(zT_55)), 32u);
    zT_57 = zig_overflow_flag_add_u(((zu64)(zT_53)), ((zu64)(zT_55)), 32u);
    zT_59 = zT_57 == (unsigned int)(0);
    if (!(zT_59)) { pal_trap(); }
    *len = zT_56;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_72 = zT_70.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_72;
    zT_75 = (zT_79FAE712_u64*)raw;
    new_items_p = zT_75;
    zT_76 = *items;
    zT_77 = *len;
    zT_78 = 0;
    zT_79 = zT_76 + zT_78;
    zT_80 = zT_77 - zT_78;
    zT_81 = (unsigned int)zT_78 <= zT_77;
    if (!(zT_81)) { pal_trap(); }
    zT_82.ptr = (zT_79FAE712_u64*)zT_79;
    zT_82.len = zT_80;
    zT_83 = zT_82.ptr;
    zT_84 = zT_82.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(i < zT_84)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_83[i];
    new_items_p[i] = item;
    goto z_bb_17;
    z_bb_16:
    *items = new_items_p;
    *capacity = new_cap;
    goto z_bb_2;
    z_bb_17:
    zT_89 = i + (unsigned int)(1);
    i = zT_89;
    goto z_bb_14;
}

/* f64ArrayListAppendInner */
void zF_51A5BB50_f64ArrayListAppendI(zT_00435AEB_f64** items, unsigned int* len, unsigned int* capacity, zT_3E40CD83_Sand* arena, zT_00435AEB_f64 value) {
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    unsigned int zT_26;
    int zT_27;
    zT_3E40CD83_Sand* zT_30;
    unsigned int zT_32;
    unsigned int zT_33;
    zT_00435AEB_f64* zT_35;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned char zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned char zT_47;
    zT_DD2B0E80_Opt_263 zT_49;
    unsigned char zT_50;
    zT_00435AEB_f64* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned char zT_59;
    zT_3E40CD83_Sand* zT_61;
    unsigned int zT_62;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    unsigned char zT_68;
    zT_FDFD82FD_EU_362 zT_70;
    unsigned char zT_71;
    unsigned char* zT_72;
    zT_00435AEB_f64* zT_75;
    zT_00435AEB_f64* zT_76;
    unsigned int zT_77;
    int zT_78;
    zT_00435AEB_f64* zT_79;
    unsigned int zT_80;
    unsigned char zT_81;
    zT_ACF60AF6_Slice_zT_00435AEB_f zT_82;
    zT_00435AEB_f64* zT_83;
    unsigned int zT_84;
    unsigned int zT_89;
    zT_00435AEB_f64* zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    int zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    unsigned char zT_98;
    zig_poison_fill((void*)&zT_49, (unsigned int)sizeof zT_49);
    zig_poison_fill((void*)&zT_70, (unsigned int)sizeof zT_70);
    unsigned int new_cap;
    zT_DD2B0E80_Opt_263 grown;
    unsigned char* raw;
    zT_00435AEB_f64* new_items_p;
    zT_00435AEB_f64 item;
    unsigned int i;
    zT_5 = *len;
    zT_6 = *capacity;
    if ((unsigned char)(zT_5 >= zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = *capacity;
    new_cap = zT_9;
    if ((unsigned char)(new_cap < (unsigned int)(8))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_90 = *items;
    zT_91 = *len;
    zT_90[zT_91] = value;
    zT_92 = *len;
    zT_93 = 1;
    zT_94 = (unsigned int)zT_93;
    zT_95 = zig_wrap_add_u(((zu64)(zT_92)), ((zu64)(zT_94)), 32u);
    zT_96 = zig_overflow_flag_add_u(((zu64)(zT_92)), ((zu64)(zT_94)), 32u);
    zT_98 = zT_96 == (unsigned int)(0);
    if (!(zT_98)) { pal_trap(); }
    *len = zT_95;
    return;
    z_bb_3:
    zT_12 = 8;
    new_cap = zT_12;
    goto z_bb_4;
    z_bb_4:
    zT_13 = *len;
    zT_14 = 2;
    zT_15 = zig_wrap_mul_u(((zu64)(zT_13)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_mul_u(((zu64)(zT_13)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_15)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = *len;
    zT_21 = 2;
    zT_22 = zig_wrap_mul_u(((zu64)(zT_20)), ((zu64)(zT_21)), 32u);
    zT_23 = zig_overflow_flag_mul_u(((zu64)(zT_20)), ((zu64)(zT_21)), 32u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    new_cap = zT_22;
    goto z_bb_6;
    z_bb_6:
    zT_26 = *capacity;
    zT_27 = 0;
    if ((unsigned char)(zT_26 > (unsigned int)zT_27)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_30 = arena;
    zT_35 = *items;
    zT_37 = *capacity;
    zT_38 = 8;
    zT_39 = zig_wrap_mul_u(((zu64)(zT_37)), ((zu64)(zT_38)), 32u);
    zT_40 = zig_overflow_flag_mul_u(((zu64)(zT_37)), ((zu64)(zT_38)), 32u);
    zT_42 = zT_40 == (unsigned int)(0);
    if (!(zT_42)) { pal_trap(); }
    zT_32 = zT_39;
    zT_43 = 8;
    zT_44 = zig_wrap_mul_u(((zu64)(new_cap)), ((zu64)(zT_43)), 32u);
    zT_45 = zig_overflow_flag_mul_u(((zu64)(new_cap)), ((zu64)(zT_43)), 32u);
    zT_47 = zT_45 == (unsigned int)(0);
    if (!(zT_47)) { pal_trap(); }
    zT_33 = zT_44;
    zT_49 = zF_33A3D4F8_sandTryReallocInPla(zT_30, (unsigned char*)((unsigned char*)zT_35), zT_32, zT_33, (unsigned int)(4));
    grown = zT_49;
    zT_50 = grown.has_value;
    if (zT_50) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_61 = arena;
    zT_64 = 8;
    zT_65 = zig_wrap_mul_u(((zu64)(zT_64)), ((zu64)(new_cap)), 32u);
    zT_66 = zig_overflow_flag_mul_u(((zu64)(zT_64)), ((zu64)(new_cap)), 32u);
    zT_68 = zT_66 == (unsigned int)(0);
    if (!(zT_68)) { pal_trap(); }
    zT_62 = zT_65;
    zT_70 = zF_1395EB68_sandAlloc(zT_61, zT_62, (unsigned int)(4));
    zT_71 = zT_70.is_error;
    if (zT_71) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    *capacity = new_cap;
    zT_51 = *items;
    zT_52 = *len;
    zT_51[zT_52] = value;
    zT_53 = *len;
    zT_54 = 1;
    zT_55 = (unsigned int)zT_54;
    zT_56 = zig_wrap_add_u(((zu64)(zT_53)), ((zu64)(zT_55)), 32u);
    zT_57 = zig_overflow_flag_add_u(((zu64)(zT_53)), ((zu64)(zT_55)), 32u);
    zT_59 = zT_57 == (unsigned int)(0);
    if (!(zT_59)) { pal_trap(); }
    *len = zT_56;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_72 = zT_70.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_72;
    zT_75 = (zT_00435AEB_f64*)raw;
    new_items_p = zT_75;
    zT_76 = *items;
    zT_77 = *len;
    zT_78 = 0;
    zT_79 = zT_76 + zT_78;
    zT_80 = zT_77 - zT_78;
    zT_81 = (unsigned int)zT_78 <= zT_77;
    if (!(zT_81)) { pal_trap(); }
    zT_82.ptr = (zT_00435AEB_f64*)zT_79;
    zT_82.len = zT_80;
    zT_83 = zT_82.ptr;
    zT_84 = zT_82.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(i < zT_84)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_83[i];
    new_items_p[i] = item;
    goto z_bb_17;
    z_bb_16:
    *items = new_items_p;
    *capacity = new_cap;
    goto z_bb_2;
    z_bb_17:
    zT_89 = i + (unsigned int)(1);
    i = zT_89;
    goto z_bb_14;
}

/* fnProtoArrayListAppendInner */
void zF_F22CE022_fnProtoArrayListApp(zT_243D6A41_FnProto** items, unsigned int* len, unsigned int* capacity, zT_3E40CD83_Sand* arena, zT_243D6A41_FnProto value) {
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    unsigned int zT_26;
    int zT_27;
    zT_3E40CD83_Sand* zT_30;
    unsigned int zT_32;
    unsigned int zT_33;
    zT_243D6A41_FnProto* zT_35;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned char zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned char zT_47;
    zT_DD2B0E80_Opt_263 zT_49;
    unsigned char zT_50;
    zT_243D6A41_FnProto* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned char zT_59;
    zT_3E40CD83_Sand* zT_61;
    unsigned int zT_62;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    unsigned char zT_68;
    zT_FDFD82FD_EU_362 zT_70;
    unsigned char zT_71;
    unsigned char* zT_72;
    zT_243D6A41_FnProto* zT_75;
    zT_243D6A41_FnProto* zT_76;
    unsigned int zT_77;
    int zT_78;
    zT_243D6A41_FnProto* zT_79;
    unsigned int zT_80;
    unsigned char zT_81;
    zT_91F8F99F_Slice_zT_243D6A41_F zT_82;
    zT_243D6A41_FnProto* zT_83;
    unsigned int zT_84;
    unsigned int zT_89;
    zT_243D6A41_FnProto* zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    int zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    unsigned char zT_98;
    zig_poison_fill((void*)&zT_49, (unsigned int)sizeof zT_49);
    zig_poison_fill((void*)&zT_70, (unsigned int)sizeof zT_70);
    unsigned int new_cap;
    zT_DD2B0E80_Opt_263 grown;
    unsigned char* raw;
    zT_243D6A41_FnProto* new_items_p;
    zT_243D6A41_FnProto item;
    unsigned int i;
    zT_5 = *len;
    zT_6 = *capacity;
    if ((unsigned char)(zT_5 >= zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = *capacity;
    new_cap = zT_9;
    if ((unsigned char)(new_cap < (unsigned int)(8))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_90 = *items;
    zT_91 = *len;
    zT_90[zT_91] = value;
    zT_92 = *len;
    zT_93 = 1;
    zT_94 = (unsigned int)zT_93;
    zT_95 = zig_wrap_add_u(((zu64)(zT_92)), ((zu64)(zT_94)), 32u);
    zT_96 = zig_overflow_flag_add_u(((zu64)(zT_92)), ((zu64)(zT_94)), 32u);
    zT_98 = zT_96 == (unsigned int)(0);
    if (!(zT_98)) { pal_trap(); }
    *len = zT_95;
    return;
    z_bb_3:
    zT_12 = 8;
    new_cap = zT_12;
    goto z_bb_4;
    z_bb_4:
    zT_13 = *len;
    zT_14 = 2;
    zT_15 = zig_wrap_mul_u(((zu64)(zT_13)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_mul_u(((zu64)(zT_13)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    if ((unsigned char)(new_cap < zT_15)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = *len;
    zT_21 = 2;
    zT_22 = zig_wrap_mul_u(((zu64)(zT_20)), ((zu64)(zT_21)), 32u);
    zT_23 = zig_overflow_flag_mul_u(((zu64)(zT_20)), ((zu64)(zT_21)), 32u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    new_cap = zT_22;
    goto z_bb_6;
    z_bb_6:
    zT_26 = *capacity;
    zT_27 = 0;
    if ((unsigned char)(zT_26 > (unsigned int)zT_27)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_30 = arena;
    zT_35 = *items;
    zT_37 = *capacity;
    zT_38 = 16;
    zT_39 = zig_wrap_mul_u(((zu64)(zT_37)), ((zu64)(zT_38)), 32u);
    zT_40 = zig_overflow_flag_mul_u(((zu64)(zT_37)), ((zu64)(zT_38)), 32u);
    zT_42 = zT_40 == (unsigned int)(0);
    if (!(zT_42)) { pal_trap(); }
    zT_32 = zT_39;
    zT_43 = 16;
    zT_44 = zig_wrap_mul_u(((zu64)(new_cap)), ((zu64)(zT_43)), 32u);
    zT_45 = zig_overflow_flag_mul_u(((zu64)(new_cap)), ((zu64)(zT_43)), 32u);
    zT_47 = zT_45 == (unsigned int)(0);
    if (!(zT_47)) { pal_trap(); }
    zT_33 = zT_44;
    zT_49 = zF_33A3D4F8_sandTryReallocInPla(zT_30, (unsigned char*)((unsigned char*)zT_35), zT_32, zT_33, (unsigned int)(4));
    grown = zT_49;
    zT_50 = grown.has_value;
    if (zT_50) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_61 = arena;
    zT_64 = 16;
    zT_65 = zig_wrap_mul_u(((zu64)(zT_64)), ((zu64)(new_cap)), 32u);
    zT_66 = zig_overflow_flag_mul_u(((zu64)(zT_64)), ((zu64)(new_cap)), 32u);
    zT_68 = zT_66 == (unsigned int)(0);
    if (!(zT_68)) { pal_trap(); }
    zT_62 = zT_65;
    zT_70 = zF_1395EB68_sandAlloc(zT_61, zT_62, (unsigned int)(4));
    zT_71 = zT_70.is_error;
    if (zT_71) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    *capacity = new_cap;
    zT_51 = *items;
    zT_52 = *len;
    zT_51[zT_52] = value;
    zT_53 = *len;
    zT_54 = 1;
    zT_55 = (unsigned int)zT_54;
    zT_56 = zig_wrap_add_u(((zu64)(zT_53)), ((zu64)(zT_55)), 32u);
    zT_57 = zig_overflow_flag_add_u(((zu64)(zT_53)), ((zu64)(zT_55)), 32u);
    zT_59 = zT_57 == (unsigned int)(0);
    if (!(zT_59)) { pal_trap(); }
    *len = zT_56;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_72 = zT_70.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_72;
    zT_75 = (zT_243D6A41_FnProto*)raw;
    new_items_p = zT_75;
    zT_76 = *items;
    zT_77 = *len;
    zT_78 = 0;
    zT_79 = zT_76 + zT_78;
    zT_80 = zT_77 - zT_78;
    zT_81 = (unsigned int)zT_78 <= zT_77;
    if (!(zT_81)) { pal_trap(); }
    zT_82.ptr = (zT_243D6A41_FnProto*)zT_79;
    zT_82.len = zT_80;
    zT_83 = zT_82.ptr;
    zT_84 = zT_82.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(i < zT_84)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_83[i];
    new_items_p[i] = item;
    goto z_bb_17;
    z_bb_16:
    *items = new_items_p;
    *capacity = new_cap;
    goto z_bb_2;
    z_bb_17:
    zT_89 = i + (unsigned int)(1);
    i = zT_89;
    goto z_bb_14;
}

/* astStoreInit */
zT_6B0A7D14_AstStore zF_D9F91436_astStoreInit(zT_3E40CD83_Sand* arena) {
    zT_22A7C88B_AstNode zT_2;
    zT_8143F551_AstKind zT_3;
    unsigned char zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_6B0A7D14_AstStore zT_11;
    zT_61A320D8_anon_323976 zT_12;
    unsigned int zT_13;
    zT_01BE9D46_AstValuePool zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned char zT_25;
    unsigned int zT_26;
    zT_D21A8776_SpillStore zT_27;
    unsigned int zT_28;
    unsigned char zT_29;
    zT_01BE9D46_AstValuePool zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    int zT_40;
    unsigned char zT_41;
    unsigned int zT_42;
    zT_D21A8776_SpillStore zT_43;
    unsigned int zT_44;
    unsigned char zT_45;
    zT_01BE9D46_AstValuePool zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    int zT_56;
    unsigned char zT_57;
    unsigned int zT_58;
    zT_D21A8776_SpillStore zT_59;
    unsigned int zT_60;
    unsigned char zT_61;
    zT_E494E487_anon_323991 zT_62;
    int zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    zT_5838FCFA_anon_324009 zT_66;
    int zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    zT_5138F1F5_anon_324000 zT_70;
    int zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_4E36AEA5_anon_324013 zT_74;
    unsigned int zT_75;
    zT_01BE9D46_AstValuePool zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    int zT_86;
    unsigned char zT_87;
    unsigned int zT_88;
    zT_D21A8776_SpillStore zT_89;
    unsigned int zT_90;
    unsigned char zT_91;
    zT_DA3E46CE_anon_324027 zT_92;
    int zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    zT_D21A8776_SpillStore zT_99;
    unsigned int zT_100;
    zT_6B0A7D14_AstStore* zT_101;
    int zT_104;
    unsigned int zT_105;
    zT_6DD0D007_AstSlot zT_108;
    int zT_109;
    unsigned int zT_110;
    int zT_111;
    unsigned int zT_112;
    unsigned char zT_113;
    zT_6DD0D007_AstSlot* zT_114;
    unsigned char zT_116;
    unsigned int zT_117;
    unsigned int* zT_118;
    unsigned char zT_120;
    int zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    unsigned char zT_126;
    zT_6DD0D007_AstSlot* zT_128;
    unsigned char zT_131;
    zT_6DD0D007_AstSlot* zT_132;
    zT_6B0A7D14_AstStore* zT_133;
    zT_E2FE8472_NodeBlockInfo zT_137;
    unsigned int zT_138;
    unsigned char zT_139;
    unsigned int zT_140;
    zT_DA3E46CE_anon_324027 zT_141;
    zT_E2FE8472_NodeBlockInfo* zT_142;
    int zT_143;
    unsigned int zT_144;
    unsigned int* zT_145;
    unsigned int zT_146;
    unsigned char zT_148;
    unsigned char* zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned int zT_152;
    int zT_154;
    unsigned int zT_155;
    unsigned int zT_157;
    unsigned char* zT_159;
    unsigned int zT_160;
    unsigned char zT_161;
    unsigned char zT_162;
    unsigned char* zT_163;
    unsigned char zT_165;
    int zT_166;
    unsigned int zT_167;
    unsigned int zT_168;
    unsigned int zT_169;
    unsigned char zT_171;
    unsigned int zT_173;
    unsigned char* zT_175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_176;
    unsigned int zT_177;
    int zT_179;
    unsigned int zT_180;
    unsigned int zT_182;
    unsigned char* zT_184;
    unsigned int zT_185;
    unsigned char zT_186;
    unsigned char zT_187;
    zT_01BE9D46_AstValuePool zT_188;
    unsigned char* zT_189;
    unsigned char zT_191;
    int zT_192;
    unsigned int zT_193;
    unsigned int zT_194;
    unsigned int zT_195;
    unsigned char zT_197;
    unsigned int zT_199;
    zT_6B0A7D14_AstStore* zT_200;
    zT_01BE9D46_AstValuePool* zT_201;
    unsigned char* zT_203;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_204;
    unsigned int zT_205;
    int zT_207;
    unsigned int zT_208;
    unsigned int zT_210;
    unsigned char* zT_212;
    unsigned int zT_213;
    unsigned char zT_214;
    unsigned char zT_215;
    zT_01BE9D46_AstValuePool zT_216;
    unsigned char* zT_217;
    unsigned char zT_219;
    int zT_220;
    unsigned int zT_221;
    unsigned int zT_222;
    unsigned int zT_223;
    unsigned char zT_225;
    unsigned int zT_227;
    zT_6B0A7D14_AstStore* zT_228;
    zT_01BE9D46_AstValuePool* zT_229;
    unsigned char* zT_231;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_232;
    unsigned int zT_233;
    int zT_235;
    unsigned int zT_236;
    unsigned int zT_238;
    unsigned char* zT_240;
    unsigned int zT_241;
    unsigned char zT_242;
    unsigned char zT_243;
    zT_01BE9D46_AstValuePool zT_244;
    unsigned char* zT_245;
    unsigned char zT_247;
    int zT_248;
    unsigned int zT_249;
    unsigned int zT_250;
    unsigned int zT_251;
    unsigned char zT_253;
    unsigned int zT_255;
    zT_6B0A7D14_AstStore* zT_256;
    zT_01BE9D46_AstValuePool* zT_257;
    unsigned char* zT_259;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_260;
    unsigned int zT_261;
    int zT_263;
    unsigned int zT_264;
    unsigned int zT_266;
    unsigned char* zT_268;
    unsigned int zT_269;
    unsigned char zT_270;
    unsigned char zT_271;
    zT_01BE9D46_AstValuePool zT_272;
    unsigned char* zT_273;
    unsigned char zT_275;
    int zT_276;
    unsigned int zT_277;
    unsigned int zT_278;
    unsigned int zT_279;
    unsigned char zT_281;
    unsigned int zT_283;
    zT_6B0A7D14_AstStore* zT_284;
    zT_01BE9D46_AstValuePool* zT_285;
    zT_6B0A7D14_AstStore* zT_286;
    zT_22A7C88B_AstNode zT_287;
    zT_6B0A7D14_AstStore* zT_291;
    zT_01BE9D46_AstValuePool* zT_292;
    zT_6B0A7D14_AstStore* zT_295;
    unsigned int zT_298;
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zig_poison_fill((void*)&zT_43, (unsigned int)sizeof zT_43);
    zig_poison_fill((void*)&zT_59, (unsigned int)sizeof zT_59);
    zig_poison_fill((void*)&zT_89, (unsigned int)sizeof zT_89);
    zig_poison_fill((void*)&zT_99, (unsigned int)sizeof zT_99);
    zig_poison_fill((void*)&zT_298, (unsigned int)sizeof zT_298);
    zT_22A7C88B_AstNode null_node;
    zT_6B0A7D14_AstStore store;
    unsigned int si;
    zT_8F083A69_Slice_zT_0B42B2F8_u default_path;
    unsigned int pi;
    zT_8F083A69_Slice_zT_0B42B2F8_u d_id;
    unsigned int di;
    zT_8F083A69_Slice_zT_0B42B2F8_u d_iv;
    unsigned int dvi;
    zT_8F083A69_Slice_zT_0B42B2F8_u d_ec;
    unsigned int deci;
    zT_8F083A69_Slice_zT_0B42B2F8_u d_er;
    unsigned int deri;
    zT_3 = zT_8143F551_AstKind_err;
    zT_2.kind = zT_3;
    zT_4 = 0;
    zT_2.flags = zT_4;
    zT_5 = 0;
    zT_2.span_start = zT_5;
    zT_6 = 0;
    zT_2.span_len = zT_6;
    zT_7 = 0;
    zT_2.child_0 = zT_7;
    zT_8 = 0;
    zT_2.child_1 = zT_8;
    zT_9 = 0;
    zT_2.child_2 = zT_9;
    null_node = zT_2;
    zT_13 = 0;
    zT_12.len = zT_13;
    zT_11.nodes = zT_12;
    zT_15 = 0;
    zT_14.len = zT_15;
    zT_16 = 0;
    zT_14.elem_bytes = zT_16;
    zT_17 = 0;
    zT_14.elems_per_block = zT_17;
    zT_18 = 0;
    zT_14.block_shift = zT_18;
    zT_19 = 0;
    zT_14.block_mask = zT_19;
    zig_poison_fill((void*)&zT_20, (unsigned int)sizeof zT_20);
    zT_14.head_buf = (unsigned char*)zT_20;
    zT_21 = 0;
    zT_14.head_cap = zT_21;
    zT_22 = 0;
    zT_14.head_elems = zT_22;
    zT_23 = 0;
    zT_14.cur_block = zT_23;
    zig_poison_fill((void*)&zT_24, (unsigned int)sizeof zT_24);
    zT_14.cache_buf = (unsigned char*)zT_24;
    zT_25 = 0;
    zT_14.cache_allocated = zT_25;
    zT_26 = 0;
    zT_14.ring_next = zT_26;
    zT_27 = zF_22C79E6C_spillStoreInit();
    zT_14.spill = zT_27;
    zT_28 = 0;
    zT_14.spill_path_len = zT_28;
    zT_29 = 1;
    zT_14.is_extra = zT_29;
    zT_11.extra_children = zT_14;
    zT_31 = 0;
    zT_30.len = zT_31;
    zT_32 = 0;
    zT_30.elem_bytes = zT_32;
    zT_33 = 0;
    zT_30.elems_per_block = zT_33;
    zT_34 = 0;
    zT_30.block_shift = zT_34;
    zT_35 = 0;
    zT_30.block_mask = zT_35;
    zig_poison_fill((void*)&zT_36, (unsigned int)sizeof zT_36);
    zT_30.head_buf = (unsigned char*)zT_36;
    zT_37 = 0;
    zT_30.head_cap = zT_37;
    zT_38 = 0;
    zT_30.head_elems = zT_38;
    zT_39 = 0;
    zT_30.cur_block = zT_39;
    zig_poison_fill((void*)&zT_40, (unsigned int)sizeof zT_40);
    zT_30.cache_buf = (unsigned char*)zT_40;
    zT_41 = 0;
    zT_30.cache_allocated = zT_41;
    zT_42 = 0;
    zT_30.ring_next = zT_42;
    zT_43 = zF_22C79E6C_spillStoreInit();
    zT_30.spill = zT_43;
    zT_44 = 0;
    zT_30.spill_path_len = zT_44;
    zT_45 = 0;
    zT_30.is_extra = zT_45;
    zT_11.identifiers = zT_30;
    zT_47 = 0;
    zT_46.len = zT_47;
    zT_48 = 0;
    zT_46.elem_bytes = zT_48;
    zT_49 = 0;
    zT_46.elems_per_block = zT_49;
    zT_50 = 0;
    zT_46.block_shift = zT_50;
    zT_51 = 0;
    zT_46.block_mask = zT_51;
    zig_poison_fill((void*)&zT_52, (unsigned int)sizeof zT_52);
    zT_46.head_buf = (unsigned char*)zT_52;
    zT_53 = 0;
    zT_46.head_cap = zT_53;
    zT_54 = 0;
    zT_46.head_elems = zT_54;
    zT_55 = 0;
    zT_46.cur_block = zT_55;
    zig_poison_fill((void*)&zT_56, (unsigned int)sizeof zT_56);
    zT_46.cache_buf = (unsigned char*)zT_56;
    zT_57 = 0;
    zT_46.cache_allocated = zT_57;
    zT_58 = 0;
    zT_46.ring_next = zT_58;
    zT_59 = zF_22C79E6C_spillStoreInit();
    zT_46.spill = zT_59;
    zT_60 = 0;
    zT_46.spill_path_len = zT_60;
    zT_61 = 0;
    zT_46.is_extra = zT_61;
    zT_11.int_values = zT_46;
    zig_poison_fill((void*)&zT_63, (unsigned int)sizeof zT_63);
    zT_62.items = (zT_00435AEB_f64*)zT_63;
    zT_64 = 0;
    zT_62.len = zT_64;
    zT_65 = 0;
    zT_62.capacity = zT_65;
    zT_11.float_values = zT_62;
    zig_poison_fill((void*)&zT_67, (unsigned int)sizeof zT_67);
    zT_66.items = (zT_243D6A41_FnProto*)zT_67;
    zT_68 = 0;
    zT_66.len = zT_68;
    zT_69 = 0;
    zT_66.capacity = zT_69;
    zT_11.fn_protos = zT_66;
    zig_poison_fill((void*)&zT_71, (unsigned int)sizeof zT_71);
    zT_70.items = (unsigned int*)zT_71;
    zT_72 = 0;
    zT_70.len = zT_72;
    zT_73 = 0;
    zT_70.capacity = zT_73;
    zT_11.string_values = zT_70;
    zT_75 = 0;
    zT_74.len = zT_75;
    zT_11.payload = zT_74;
    zT_77 = 0;
    zT_76.len = zT_77;
    zT_78 = 0;
    zT_76.elem_bytes = zT_78;
    zT_79 = 0;
    zT_76.elems_per_block = zT_79;
    zT_80 = 0;
    zT_76.block_shift = zT_80;
    zT_81 = 0;
    zT_76.block_mask = zT_81;
    zig_poison_fill((void*)&zT_82, (unsigned int)sizeof zT_82);
    zT_76.head_buf = (unsigned char*)zT_82;
    zT_83 = 0;
    zT_76.head_cap = zT_83;
    zT_84 = 0;
    zT_76.head_elems = zT_84;
    zT_85 = 0;
    zT_76.cur_block = zT_85;
    zig_poison_fill((void*)&zT_86, (unsigned int)sizeof zT_86);
    zT_76.cache_buf = (unsigned char*)zT_86;
    zT_87 = 0;
    zT_76.cache_allocated = zT_87;
    zT_88 = 0;
    zT_76.ring_next = zT_88;
    zT_89 = zF_22C79E6C_spillStoreInit();
    zT_76.spill = zT_89;
    zT_90 = 0;
    zT_76.spill_path_len = zT_90;
    zT_91 = 1;
    zT_76.is_extra = zT_91;
    zT_11.extra_ranges = zT_76;
    zT_11.allocator = arena;
    zig_poison_fill((void*)&zT_93, (unsigned int)sizeof zT_93);
    zT_92.items = (zT_E2FE8472_NodeBlockInfo*)zT_93;
    zT_94 = 0;
    zT_92.len = zT_94;
    zT_95 = 0;
    zT_92.capacity = zT_95;
    zT_11.block_table = zT_92;
    zT_96 = 0;
    zT_11.cur_block = zT_96;
    zT_97 = 0;
    zT_11.cur_block_len = zT_97;
    zT_98 = 1;
    zT_11.ring_next = zT_98;
    zT_99 = zF_22C79E6C_spillStoreInit();
    zT_11.spill = zT_99;
    zT_100 = 0;
    zT_11.spill_path_len = zT_100;
    store = zT_11;
    zT_101 = (zT_6B0A7D14_AstStore*)&store;
    zF_A0C14FAA_astStoreInitValuePo(zT_101);
    zT_104 = 0;
    zT_105 = (unsigned int)zT_104;
    si = zT_105;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(si < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zig_poison_fill((void*)&zT_109, (unsigned int)sizeof zT_109);
    zT_108.node_buf = (zT_22A7C88B_AstNode*)zT_109;
    zT_110 = 0;
    zT_108.node_cap = zT_110;
    zig_poison_fill((void*)&zT_111, (unsigned int)sizeof zT_111);
    zT_108.payload_buf = (unsigned int*)zT_111;
    zT_112 = 0;
    zT_108.payload_cap = zT_112;
    zT_113 = 0;
    zT_108.in_use = zT_113;
    zT_114 = store.slots;
    zT_116 = si < (unsigned int)(8);
    if (!(zT_116)) { pal_trap(); }
    zT_114[si] = zT_108;
    zT_117 = 0;
    zT_118 = store.slot_block;
    zT_120 = si < (unsigned int)(8);
    if (!(zT_120)) { pal_trap(); }
    zT_118[si] = zT_117;
    goto z_bb_4;
    z_bb_3:
    zT_128 = store.slots;
    zT_131 = 1;
    if (!(zT_131)) { pal_trap(); }
    zT_132 = zT_128 + (unsigned int)(0);
    zT_132->in_use = (unsigned char)(1);
    zT_133 = (zT_6B0A7D14_AstStore*)&store;
    zF_1D4F4DCE_astBlockTableEnsure(zT_133, (unsigned int)(1));
    zT_138 = 0;
    zT_137.disk_off = zT_138;
    zT_139 = 1;
    zT_137.resident = zT_139;
    zT_140 = 0;
    zT_137.slot = zT_140;
    zT_141 = store.block_table;
    zT_142 = zT_141.items;
    zT_143 = 0;
    zT_142[zT_143] = zT_137;
    zT_144 = 0;
    zT_145 = store.slot_block;
    zT_146 = 0;
    zT_148 = 1;
    if (!(zT_148)) { pal_trap(); }
    zT_145[zT_146] = zT_144;
    zT_150 = ".zig1_ast.tmp";
    zT_152 = 13;
    zT_151.ptr = (unsigned char*)zT_150;
    zT_151.len = zT_152;
    default_path = zT_151;
    zT_154 = 0;
    zT_155 = (unsigned int)zT_154;
    pi = zT_155;
    goto z_bb_5;
    z_bb_4:
    zT_121 = 1;
    zT_122 = (unsigned int)zT_121;
    zT_123 = zig_wrap_add_u(((zu64)(si)), ((zu64)(zT_122)), 32u);
    zT_124 = zig_overflow_flag_add_u(((zu64)(si)), ((zu64)(zT_122)), 32u);
    zT_126 = zT_124 == (unsigned int)(0);
    if (!(zT_126)) { pal_trap(); }
    si = zT_123;
    goto z_bb_1;
    z_bb_5:
    zT_157 = default_path.len;
    if ((unsigned char)(pi < zT_157)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_159 = default_path.ptr;
    zT_160 = default_path.len;
    zT_161 = pi < zT_160;
    if (!(zT_161)) { pal_trap(); }
    zT_162 = zT_159[pi];
    zT_163 = store.spill_path;
    zT_165 = pi < (unsigned int)(512);
    if (!(zT_165)) { pal_trap(); }
    zT_163[pi] = zT_162;
    goto z_bb_8;
    z_bb_7:
    zT_173 = default_path.len;
    store.spill_path_len = zT_173;
    zT_175 = ".zig1_side.tmp";
    zT_177 = 14;
    zT_176.ptr = (unsigned char*)zT_175;
    zT_176.len = zT_177;
    d_id = zT_176;
    zT_179 = 0;
    zT_180 = (unsigned int)zT_179;
    di = zT_180;
    goto z_bb_9;
    z_bb_8:
    zT_166 = 1;
    zT_167 = (unsigned int)zT_166;
    zT_168 = zig_wrap_add_u(((zu64)(pi)), ((zu64)(zT_167)), 32u);
    zT_169 = zig_overflow_flag_add_u(((zu64)(pi)), ((zu64)(zT_167)), 32u);
    zT_171 = zT_169 == (unsigned int)(0);
    if (!(zT_171)) { pal_trap(); }
    pi = zT_168;
    goto z_bb_5;
    z_bb_9:
    zT_182 = d_id.len;
    if ((unsigned char)(di < zT_182)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_184 = d_id.ptr;
    zT_185 = d_id.len;
    zT_186 = di < zT_185;
    if (!(zT_186)) { pal_trap(); }
    zT_187 = zT_184[di];
    zT_188 = store.identifiers;
    zT_189 = zT_188.spill_path;
    zT_191 = di < (unsigned int)(512);
    if (!(zT_191)) { pal_trap(); }
    zT_189[di] = zT_187;
    goto z_bb_12;
    z_bb_11:
    zT_199 = d_id.len;
    zT_200 = (zT_6B0A7D14_AstStore*)&store;
    zT_201 = &zT_200->identifiers;
    zT_201->spill_path_len = zT_199;
    zT_203 = ".zig1_side_iv.tmp";
    zT_205 = 17;
    zT_204.ptr = (unsigned char*)zT_203;
    zT_204.len = zT_205;
    d_iv = zT_204;
    zT_207 = 0;
    zT_208 = (unsigned int)zT_207;
    dvi = zT_208;
    goto z_bb_13;
    z_bb_12:
    zT_192 = 1;
    zT_193 = (unsigned int)zT_192;
    zT_194 = zig_wrap_add_u(((zu64)(di)), ((zu64)(zT_193)), 32u);
    zT_195 = zig_overflow_flag_add_u(((zu64)(di)), ((zu64)(zT_193)), 32u);
    zT_197 = zT_195 == (unsigned int)(0);
    if (!(zT_197)) { pal_trap(); }
    di = zT_194;
    goto z_bb_9;
    z_bb_13:
    zT_210 = d_iv.len;
    if ((unsigned char)(dvi < zT_210)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_212 = d_iv.ptr;
    zT_213 = d_iv.len;
    zT_214 = dvi < zT_213;
    if (!(zT_214)) { pal_trap(); }
    zT_215 = zT_212[dvi];
    zT_216 = store.int_values;
    zT_217 = zT_216.spill_path;
    zT_219 = dvi < (unsigned int)(512);
    if (!(zT_219)) { pal_trap(); }
    zT_217[dvi] = zT_215;
    goto z_bb_16;
    z_bb_15:
    zT_227 = d_iv.len;
    zT_228 = (zT_6B0A7D14_AstStore*)&store;
    zT_229 = &zT_228->int_values;
    zT_229->spill_path_len = zT_227;
    zT_231 = ".zig1_extra_ec.tmp";
    zT_233 = 18;
    zT_232.ptr = (unsigned char*)zT_231;
    zT_232.len = zT_233;
    d_ec = zT_232;
    zT_235 = 0;
    zT_236 = (unsigned int)zT_235;
    deci = zT_236;
    goto z_bb_17;
    z_bb_16:
    zT_220 = 1;
    zT_221 = (unsigned int)zT_220;
    zT_222 = zig_wrap_add_u(((zu64)(dvi)), ((zu64)(zT_221)), 32u);
    zT_223 = zig_overflow_flag_add_u(((zu64)(dvi)), ((zu64)(zT_221)), 32u);
    zT_225 = zT_223 == (unsigned int)(0);
    if (!(zT_225)) { pal_trap(); }
    dvi = zT_222;
    goto z_bb_13;
    z_bb_17:
    zT_238 = d_ec.len;
    if ((unsigned char)(deci < zT_238)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_240 = d_ec.ptr;
    zT_241 = d_ec.len;
    zT_242 = deci < zT_241;
    if (!(zT_242)) { pal_trap(); }
    zT_243 = zT_240[deci];
    zT_244 = store.extra_children;
    zT_245 = zT_244.spill_path;
    zT_247 = deci < (unsigned int)(512);
    if (!(zT_247)) { pal_trap(); }
    zT_245[deci] = zT_243;
    goto z_bb_20;
    z_bb_19:
    zT_255 = d_ec.len;
    zT_256 = (zT_6B0A7D14_AstStore*)&store;
    zT_257 = &zT_256->extra_children;
    zT_257->spill_path_len = zT_255;
    zT_259 = ".zig1_extra_er.tmp";
    zT_261 = 18;
    zT_260.ptr = (unsigned char*)zT_259;
    zT_260.len = zT_261;
    d_er = zT_260;
    zT_263 = 0;
    zT_264 = (unsigned int)zT_263;
    deri = zT_264;
    goto z_bb_21;
    z_bb_20:
    zT_248 = 1;
    zT_249 = (unsigned int)zT_248;
    zT_250 = zig_wrap_add_u(((zu64)(deci)), ((zu64)(zT_249)), 32u);
    zT_251 = zig_overflow_flag_add_u(((zu64)(deci)), ((zu64)(zT_249)), 32u);
    zT_253 = zT_251 == (unsigned int)(0);
    if (!(zT_253)) { pal_trap(); }
    deci = zT_250;
    goto z_bb_17;
    z_bb_21:
    zT_266 = d_er.len;
    if ((unsigned char)(deri < zT_266)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_268 = d_er.ptr;
    zT_269 = d_er.len;
    zT_270 = deri < zT_269;
    if (!(zT_270)) { pal_trap(); }
    zT_271 = zT_268[deri];
    zT_272 = store.extra_ranges;
    zT_273 = zT_272.spill_path;
    zT_275 = deri < (unsigned int)(512);
    if (!(zT_275)) { pal_trap(); }
    zT_273[deri] = zT_271;
    goto z_bb_24;
    z_bb_23:
    zT_283 = d_er.len;
    zT_284 = (zT_6B0A7D14_AstStore*)&store;
    zT_285 = &zT_284->extra_ranges;
    zT_285->spill_path_len = zT_283;
    zT_286 = (zT_6B0A7D14_AstStore*)&store;
    zT_287 = null_node;
    zF_3A477168_astStoreNodeAppend(zT_286, zT_287, (unsigned int)(0));
    zT_291 = (zT_6B0A7D14_AstStore*)&store;
    zT_295 = (zT_6B0A7D14_AstStore*)&store;
    zT_292 = &zT_295->extra_ranges;
    zT_298 = zF_B73DE9D0_valuePoolAppend(zT_291, zT_292, (zT_79FAE712_u64)(0));
    (void)zT_298;
    return store;
    z_bb_24:
    zT_276 = 1;
    zT_277 = (unsigned int)zT_276;
    zT_278 = zig_wrap_add_u(((zu64)(deri)), ((zu64)(zT_277)), 32u);
    zT_279 = zig_overflow_flag_add_u(((zu64)(deri)), ((zu64)(zT_277)), 32u);
    zT_281 = zT_279 == (unsigned int)(0);
    if (!(zT_281)) { pal_trap(); }
    deri = zT_278;
    goto z_bb_21;
}

/* astStoreInitValuePools */
void zF_A0C14FAA_astStoreInitValuePo(zT_6B0A7D14_AstStore* store) {
    zT_01BE9D46_AstValuePool* zT_1;
    zT_01BE9D46_AstValuePool* zT_5;
    zT_01BE9D46_AstValuePool* zT_9;
    zT_01BE9D46_AstValuePool* zT_13;
    zT_01BE9D46_AstValuePool* zT_18;
    zT_01BE9D46_AstValuePool* zT_20;
    zT_1 = &store->identifiers;
    zF_F58FD6FA_valuePoolInit(zT_1, (unsigned int)(4));
    zT_5 = &store->int_values;
    zF_F58FD6FA_valuePoolInit(zT_5, (unsigned int)(8));
    zT_9 = &store->extra_children;
    zF_F58FD6FA_valuePoolInit(zT_9, (unsigned int)(4));
    zT_13 = &store->extra_ranges;
    zF_F58FD6FA_valuePoolInit(zT_13, (unsigned int)(8));
    zT_18 = &store->extra_children;
    zT_18->is_extra = (unsigned char)(1);
    zT_20 = &store->extra_ranges;
    zT_20->is_extra = (unsigned char)(1);
    return;
}

/* astStoreSetSpillPath */
void zF_2A507339_astStoreSetSpillPat(zT_6B0A7D14_AstStore* store, zT_8F083A69_Slice_zT_0B42B2F8_u path) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned char zT_8;
    unsigned char* zT_11;
    unsigned int zT_12;
    unsigned char zT_13;
    unsigned char zT_14;
    unsigned char* zT_15;
    unsigned char zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned char zT_23;
    unsigned char zT_24;
    unsigned char* zT_25;
    unsigned char zT_27;
    unsigned int i;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = path.len;
    if ((unsigned char)(i < zT_6)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_11 = path.ptr;
    zT_12 = path.len;
    zT_13 = i < zT_12;
    if (!(zT_13)) { pal_trap(); }
    zT_14 = zT_11[i];
    zT_15 = store->spill_path;
    zT_17 = i < (unsigned int)(512);
    if (!(zT_17)) { pal_trap(); }
    zT_15[i] = zT_14;
    goto z_bb_4;
    z_bb_3:
    store->spill_path_len = i;
    zT_24 = 0;
    zT_25 = store->spill_path;
    zT_27 = i < (unsigned int)(512);
    if (!(zT_27)) { pal_trap(); }
    zT_25[i] = zT_24;
    return;
    z_bb_4:
    zT_18 = 1;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_19)), 32u);
    zT_21 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_19)), 32u);
    zT_23 = zT_21 == (unsigned int)(0);
    if (!(zT_23)) { pal_trap(); }
    i = zT_20;
    goto z_bb_1;
    z_bb_5:
    zT_8 = i < (unsigned int)(511);
    goto z_bb_7;
    z_bb_6:
    zT_8 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_8) goto z_bb_2; else goto z_bb_3;
}

/* astStoreCloseSpill */
void zF_21027FAE_astStoreCloseSpill(zT_6B0A7D14_AstStore* store) {
    zT_D21A8776_SpillStore* zT_1;
    zT_6B0A7D14_AstStore* zT_3;
    zT_01BE9D46_AstValuePool* zT_4;
    zT_6B0A7D14_AstStore* zT_6;
    zT_01BE9D46_AstValuePool* zT_7;
    zT_6B0A7D14_AstStore* zT_9;
    zT_01BE9D46_AstValuePool* zT_10;
    zT_6B0A7D14_AstStore* zT_12;
    zT_01BE9D46_AstValuePool* zT_13;
    zT_1 = &store->spill;
    zF_DB2CDC3B_spillClose(zT_1);
    zT_3 = store;
    zT_4 = &store->identifiers;
    zF_131F3CDC_valuePoolClose(zT_3, zT_4);
    zT_6 = store;
    zT_7 = &store->int_values;
    zF_131F3CDC_valuePoolClose(zT_6, zT_7);
    zT_9 = store;
    zT_10 = &store->extra_children;
    zF_131F3CDC_valuePoolClose(zT_9, zT_10);
    zT_12 = store;
    zT_13 = &store->extra_ranges;
    zF_131F3CDC_valuePoolClose(zT_12, zT_13);
    return;
}

/* valuePoolInit */
void zF_F58FD6FA_valuePoolInit(zT_01BE9D46_AstValuePool* p, unsigned int elem_bytes) {
    unsigned char zT_6;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char zT_14;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned char zT_22;
    unsigned int zT_24;
    unsigned char zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    int zT_38;
    unsigned int zT_39;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int* zT_44;
    unsigned char zT_46;
    int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned char zT_52;
    zT_D21A8776_SpillStore zT_54;
    zig_poison_fill((void*)&zT_54, (unsigned int)sizeof zT_54);
    unsigned int shift_tmp;
    unsigned int si;
    p->len = (unsigned int)(0);
    p->elem_bytes = elem_bytes;
    zT_6 = elem_bytes != (unsigned int)(0);
    if (!(zT_6)) { pal_trap(); }
    p->elems_per_block = (unsigned int)((unsigned int)(4096) / elem_bytes);
    p->block_shift = (unsigned int)(0);
    zT_9 = p->elems_per_block;
    zT_10 = 1;
    zT_11 = zig_wrap_sub_u(((zu64)(zT_9)), ((zu64)(zT_10)), 32u);
    zT_12 = zig_overflow_flag_sub_u(((zu64)(zT_9)), ((zu64)(zT_10)), 32u);
    zT_14 = zT_12 == (unsigned int)(0);
    if (!(zT_14)) { pal_trap(); }
    shift_tmp = zT_11;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(shift_tmp != (unsigned int)(0))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_17 = p->block_shift;
    zT_18 = 1;
    zT_19 = zig_wrap_add_u(((zu64)(zT_17)), ((zu64)(zT_18)), 32u);
    zT_20 = zig_overflow_flag_add_u(((zu64)(zT_17)), ((zu64)(zT_18)), 32u);
    zT_22 = zT_20 == (unsigned int)(0);
    if (!(zT_22)) { pal_trap(); }
    p->block_shift = zT_19;
    goto z_bb_4;
    z_bb_3:
    zT_27 = p->elems_per_block;
    zT_28 = 1;
    zT_29 = zig_wrap_sub_u(((zu64)(zT_27)), ((zu64)(zT_28)), 32u);
    zT_30 = zig_overflow_flag_sub_u(((zu64)(zT_27)), ((zu64)(zT_28)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    p->block_mask = zT_29;
    p->head_cap = (unsigned int)(0);
    p->head_elems = (unsigned int)(0);
    p->cur_block = (unsigned int)(0);
    p->cache_allocated = (unsigned char)(0);
    zT_38 = 0;
    zT_39 = (unsigned int)zT_38;
    si = zT_39;
    goto z_bb_5;
    z_bb_4:
    zT_26 = 1;
    if (!(zT_26)) { pal_trap(); }
    zT_24 = shift_tmp >> (unsigned int)(1);
    shift_tmp = zT_24;
    goto z_bb_1;
    z_bb_5:
    if ((unsigned char)(si < (unsigned int)(8))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_42 = 4294967295u;
    zT_43 = (unsigned int)zT_42;
    zT_44 = p->slot_block;
    zT_46 = si < (unsigned int)(8);
    if (!(zT_46)) { pal_trap(); }
    zT_44[si] = zT_43;
    goto z_bb_8;
    z_bb_7:
    p->ring_next = (unsigned int)(0);
    zT_54 = zF_22C79E6C_spillStoreInit();
    p->spill = zT_54;
    p->spill_path_len = (unsigned int)(0);
    p->is_extra = (unsigned char)(0);
    return;
    z_bb_8:
    zT_47 = 1;
    zT_48 = (unsigned int)zT_47;
    zT_49 = zig_wrap_add_u(((zu64)(si)), ((zu64)(zT_48)), 32u);
    zT_50 = zig_overflow_flag_add_u(((zu64)(si)), ((zu64)(zT_48)), 32u);
    zT_52 = zT_50 == (unsigned int)(0);
    if (!(zT_52)) { pal_trap(); }
    si = zT_49;
    goto z_bb_5;
}

/* astStoreSetValuePoolSpillPath */
void zF_35B9B6EC_astStoreSetValuePoo(zT_6B0A7D14_AstStore* store, unsigned int which, zT_8F083A69_Slice_zT_0B42B2F8_u path) {
    zT_01BE9D46_AstValuePool* zT_4;
    zT_01BE9D46_AstValuePool* zT_7;
    zT_01BE9D46_AstValuePool* zT_10;
    zT_01BE9D46_AstValuePool* zT_13;
    zT_01BE9D46_AstValuePool* zT_14;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_19;
    unsigned char zT_21;
    unsigned char* zT_24;
    unsigned int zT_25;
    unsigned char zT_26;
    unsigned char zT_27;
    unsigned char* zT_28;
    unsigned char zT_30;
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned char zT_36;
    unsigned char zT_37;
    unsigned char* zT_38;
    unsigned char zT_40;
    zT_01BE9D46_AstValuePool* p;
    unsigned int i;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    p = zT_4;
    if ((unsigned char)(which == (unsigned int)(0))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_7 = &store->identifiers;
    p = zT_7;
    goto z_bb_2;
    z_bb_2:
    zT_16 = 0;
    zT_17 = (unsigned int)zT_16;
    i = zT_17;
    goto z_bb_10;
    z_bb_3:
    if ((unsigned char)(which == (unsigned int)(1))) goto z_bb_4; else goto z_bb_6;
    z_bb_4:
    zT_10 = &store->int_values;
    p = zT_10;
    goto z_bb_5;
    z_bb_5:
    goto z_bb_2;
    z_bb_6:
    if ((unsigned char)(which == (unsigned int)(2))) goto z_bb_7; else goto z_bb_9;
    z_bb_7:
    zT_13 = &store->extra_children;
    p = zT_13;
    goto z_bb_8;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_14 = &store->extra_ranges;
    p = zT_14;
    goto z_bb_8;
    z_bb_10:
    zT_19 = path.len;
    if ((unsigned char)(i < zT_19)) goto z_bb_14; else goto z_bb_15;
    z_bb_11:
    zT_24 = path.ptr;
    zT_25 = path.len;
    zT_26 = i < zT_25;
    if (!(zT_26)) { pal_trap(); }
    zT_27 = zT_24[i];
    zT_28 = p->spill_path;
    zT_30 = i < (unsigned int)(512);
    if (!(zT_30)) { pal_trap(); }
    zT_28[i] = zT_27;
    goto z_bb_13;
    z_bb_12:
    p->spill_path_len = i;
    zT_37 = 0;
    zT_38 = p->spill_path;
    zT_40 = i < (unsigned int)(512);
    if (!(zT_40)) { pal_trap(); }
    zT_38[i] = zT_37;
    return;
    z_bb_13:
    zT_31 = 1;
    zT_32 = (unsigned int)zT_31;
    zT_33 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_32)), 32u);
    zT_34 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_32)), 32u);
    zT_36 = zT_34 == (unsigned int)(0);
    if (!(zT_36)) { pal_trap(); }
    i = zT_33;
    goto z_bb_10;
    z_bb_14:
    zT_21 = i < (unsigned int)(511);
    goto z_bb_16;
    z_bb_15:
    zT_21 = 0;
    goto z_bb_16;
    z_bb_16:
    if (zT_21) goto z_bb_11; else goto z_bb_12;
}

/* valuePoolOpen */
void zF_E407C3F0_valuePoolOpen(zT_6B0A7D14_AstStore* store, zT_01BE9D46_AstValuePool* p) {
    zT_D21A8776_SpillStore zT_2;
    unsigned char zT_3;
    zT_0426DCE7_SpillBackend zT_8;
    unsigned char zT_9;
    zT_0426DCE7_SpillBackend zT_15;
    zT_0426DCE7_SpillBackend zT_19;
    zT_D21A8776_SpillStore* zT_20;
    zT_0426DCE7_SpillBackend zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    zT_3E40CD83_Sand* zT_23;
    unsigned char* zT_24;
    unsigned char* zT_26;
    unsigned int zT_27;
    int zT_28;
    unsigned char* zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    unsigned char zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned char* zT_36;
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zT_0426DCE7_SpillBackend backend;
    zT_2 = p->spill;
    zT_3 = zT_2.opened;
    if ((unsigned char)(zT_3 != (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = zT_0426DCE7_SpillBackend_disk;
    backend = zT_8;
    zT_9 = p->is_extra;
    if ((unsigned char)(zT_9 != (unsigned char)(0))) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    zT_15 = zF_1AA39172_spillBackendFor((zT_F12DA458_SpillId)(zT_F12DA458_SpillId_s_extra));
    backend = zT_15;
    goto z_bb_4;
    z_bb_4:
    zT_20 = &p->spill;
    zT_21 = backend;
    zT_26 = p->spill_path;
    zT_27 = p->spill_path_len;
    zT_28 = 0;
    zT_29 = zT_26 + zT_28;
    zT_30 = zT_27 - zT_28;
    zT_32 = (unsigned int)zT_28 <= zT_27;
    if (!(zT_32)) { pal_trap(); }
    zT_33 = zT_27 <= (unsigned int)(512);
    if (!(zT_33)) { pal_trap(); }
    zT_34.ptr = (unsigned char*)zT_29;
    zT_34.len = zT_30;
    zT_22 = zT_34;
    zT_23 = store->allocator;
    zT_36 = "w+b";
    zT_24 = zT_36;
    zF_8AF94F71_spillOpen(zT_20, zT_21, zT_22, zT_23, zT_24);
    return;
    z_bb_5:
    zT_19 = zF_1AA39172_spillBackendFor((zT_F12DA458_SpillId)(zT_F12DA458_SpillId_s_side));
    backend = zT_19;
    goto z_bb_4;
}

/* valuePoolEnsureHead */
void zF_76A14F48_valuePoolEnsureHead(zT_6B0A7D14_AstStore* store, zT_01BE9D46_AstValuePool* p) {
    unsigned int zT_2;
    zT_3E40CD83_Sand* zT_6;
    zT_FDFD82FD_EU_362 zT_12;
    unsigned char zT_13;
    unsigned char* zT_14;
    zig_poison_fill((void*)&zT_12, (unsigned int)sizeof zT_12);
    unsigned char* raw;
    zT_2 = p->head_cap;
    if ((unsigned char)(zT_2 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = store->allocator;
    zT_12 = zF_1395EB68_sandAlloc(zT_6, (unsigned int)(4096), (unsigned int)(4));
    zT_13 = zT_12.is_error;
    if (zT_13) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_14 = zT_12.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_14;
    p->head_buf = raw;
    p->head_cap = (unsigned int)(4096);
    return;
}

/* valuePoolAppend */
unsigned int zF_B73DE9D0_valuePoolAppend(zT_6B0A7D14_AstStore* store, zT_01BE9D46_AstValuePool* p, zT_79FAE712_u64 value) {
    zT_6B0A7D14_AstStore* zT_3;
    zT_01BE9D46_AstValuePool* zT_4;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned char zT_12;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_20;
    zT_01BE9D46_AstValuePool* zT_21;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    zT_D21A8776_SpillStore* zT_29;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_33;
    int zT_35;
    unsigned char* zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned char zT_47;
    unsigned int zT_48;
    zT_79FAE712_u64 zT_52;
    unsigned int zT_53;
    unsigned char zT_54;
    unsigned char* zT_55;
    zT_79FAE712_u64 zT_56;
    unsigned char zT_59;
    zT_79FAE712_u64 zT_61;
    unsigned int zT_62;
    unsigned char zT_63;
    unsigned char* zT_64;
    int zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned char zT_69;
    zT_79FAE712_u64 zT_70;
    unsigned char zT_73;
    zT_79FAE712_u64 zT_75;
    unsigned int zT_76;
    unsigned char zT_77;
    unsigned char* zT_78;
    int zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    unsigned char zT_83;
    zT_79FAE712_u64 zT_84;
    unsigned char zT_87;
    zT_79FAE712_u64 zT_89;
    unsigned int zT_90;
    unsigned char zT_91;
    unsigned char* zT_92;
    int zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    unsigned char zT_97;
    zT_79FAE712_u64 zT_99;
    unsigned int zT_100;
    unsigned char zT_101;
    unsigned char* zT_102;
    zT_79FAE712_u64 zT_103;
    unsigned char zT_106;
    zT_79FAE712_u64 zT_108;
    unsigned int zT_109;
    unsigned char zT_110;
    unsigned char* zT_111;
    int zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    unsigned char zT_116;
    zT_79FAE712_u64 zT_117;
    unsigned char zT_120;
    zT_79FAE712_u64 zT_122;
    unsigned int zT_123;
    unsigned char zT_124;
    unsigned char* zT_125;
    int zT_126;
    unsigned int zT_127;
    unsigned int zT_128;
    unsigned char zT_130;
    zT_79FAE712_u64 zT_131;
    unsigned char zT_134;
    zT_79FAE712_u64 zT_136;
    unsigned int zT_137;
    unsigned char zT_138;
    unsigned char* zT_139;
    int zT_140;
    unsigned int zT_141;
    unsigned int zT_142;
    unsigned char zT_144;
    zT_79FAE712_u64 zT_145;
    unsigned char zT_148;
    zT_79FAE712_u64 zT_150;
    unsigned int zT_151;
    unsigned char zT_152;
    unsigned char* zT_153;
    int zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    unsigned char zT_158;
    zT_79FAE712_u64 zT_159;
    unsigned char zT_162;
    zT_79FAE712_u64 zT_164;
    unsigned int zT_165;
    unsigned char zT_166;
    unsigned char* zT_167;
    int zT_168;
    unsigned int zT_169;
    unsigned int zT_170;
    unsigned char zT_172;
    zT_79FAE712_u64 zT_173;
    unsigned char zT_176;
    zT_79FAE712_u64 zT_178;
    unsigned int zT_179;
    unsigned char zT_180;
    unsigned char* zT_181;
    int zT_182;
    unsigned int zT_183;
    unsigned int zT_184;
    unsigned char zT_186;
    zT_79FAE712_u64 zT_187;
    unsigned char zT_190;
    zT_79FAE712_u64 zT_192;
    unsigned int zT_193;
    unsigned char zT_194;
    unsigned char* zT_195;
    int zT_196;
    unsigned int zT_197;
    unsigned int zT_198;
    unsigned char zT_200;
    unsigned int zT_201;
    int zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    unsigned int zT_205;
    unsigned char zT_207;
    unsigned int zT_208;
    int zT_209;
    unsigned int zT_210;
    unsigned int zT_211;
    unsigned int zT_212;
    unsigned char zT_214;
    unsigned int elem_idx;
    unsigned int block;
    unsigned int off;
    unsigned int disk_off;
    unsigned int byte_off;
    zT_3 = store;
    zT_4 = p;
    zF_76A14F48_valuePoolEnsureHead(zT_3, zT_4);
    zT_6 = p->len;
    zT_7 = (unsigned int)zT_6;
    elem_idx = zT_7;
    zT_9 = p->elems_per_block;
    zT_12 = zT_9 != (unsigned int)(0);
    if (!(zT_12)) { pal_trap(); }
    zT_10 = elem_idx / zT_9;
    block = zT_10;
    zT_14 = p->elems_per_block;
    zT_17 = zT_14 != (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    zT_15 = elem_idx % zT_14;
    off = zT_15;
    zT_18 = p->cur_block;
    if ((unsigned char)(block != zT_18)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_20 = store;
    zT_21 = p;
    zF_E407C3F0_valuePoolOpen(zT_20, zT_21);
    zT_23 = p->cur_block;
    zT_24 = 4096;
    zT_25 = zig_wrap_mul_u(((zu64)(zT_23)), ((zu64)(zT_24)), 32u);
    zT_26 = zig_overflow_flag_mul_u(((zu64)(zT_23)), ((zu64)(zT_24)), 32u);
    zT_28 = zT_26 == (unsigned int)(0);
    if (!(zT_28)) { pal_trap(); }
    disk_off = zT_25;
    zT_29 = &p->spill;
    zT_30 = disk_off;
    zT_33 = p->head_buf;
    zT_35 = 0;
    zT_36 = zT_33 + zT_35;
    zT_37 = (unsigned int)(4096) - zT_35;
    zT_38.ptr = (unsigned char*)zT_36;
    zT_38.len = zT_37;
    zT_31 = zT_38;
    zF_BFB33631_spillWriteAt(zT_29, zT_30, zT_31);
    p->cur_block = block;
    p->head_elems = (unsigned int)(0);
    goto z_bb_2;
    z_bb_2:
    zT_41 = (unsigned int)off;
    zT_42 = p->elem_bytes;
    zT_43 = (unsigned int)zT_42;
    zT_44 = zig_wrap_mul_u(((zu64)(zT_41)), ((zu64)(zT_43)), 32u);
    zT_45 = zig_overflow_flag_mul_u(((zu64)(zT_41)), ((zu64)(zT_43)), 32u);
    zT_47 = zT_45 == (unsigned int)(0);
    if (!(zT_47)) { pal_trap(); }
    byte_off = zT_44;
    zT_48 = p->elem_bytes;
    if ((unsigned char)(zT_48 == (unsigned int)(4))) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    zT_52 = value & (zT_79FAE712_u64)(255);
    zT_53 = (unsigned int)zig_cast_checked_u((zu64)zT_52, 64u, 0u, 32u);
    zT_54 = (unsigned char)zig_cast_checked_u((zu64)zT_53, 32u, 0u, 8u);
    zT_55 = p->head_buf;
    zT_55[byte_off] = zT_54;
    zT_56 = 8;
    zT_59 = zT_56 < (unsigned int)(64);
    if (!(zT_59)) { pal_trap(); }
    zT_61 = (zT_79FAE712_u64)(value >> zT_56) & (zT_79FAE712_u64)(255);
    zT_62 = (unsigned int)zig_cast_checked_u((zu64)zT_61, 64u, 0u, 32u);
    zT_63 = (unsigned char)zig_cast_checked_u((zu64)zT_62, 32u, 0u, 8u);
    zT_64 = p->head_buf;
    zT_65 = 1;
    zT_66 = zig_wrap_add_u(((zu64)(byte_off)), ((zu64)(zT_65)), 32u);
    zT_67 = zig_overflow_flag_add_u(((zu64)(byte_off)), ((zu64)(zT_65)), 32u);
    zT_69 = zT_67 == (unsigned int)(0);
    if (!(zT_69)) { pal_trap(); }
    zT_64[zT_66] = zT_63;
    zT_70 = 16;
    zT_73 = zT_70 < (unsigned int)(64);
    if (!(zT_73)) { pal_trap(); }
    zT_75 = (zT_79FAE712_u64)(value >> zT_70) & (zT_79FAE712_u64)(255);
    zT_76 = (unsigned int)zig_cast_checked_u((zu64)zT_75, 64u, 0u, 32u);
    zT_77 = (unsigned char)zig_cast_checked_u((zu64)zT_76, 32u, 0u, 8u);
    zT_78 = p->head_buf;
    zT_79 = 2;
    zT_80 = zig_wrap_add_u(((zu64)(byte_off)), ((zu64)(zT_79)), 32u);
    zT_81 = zig_overflow_flag_add_u(((zu64)(byte_off)), ((zu64)(zT_79)), 32u);
    zT_83 = zT_81 == (unsigned int)(0);
    if (!(zT_83)) { pal_trap(); }
    zT_78[zT_80] = zT_77;
    zT_84 = 24;
    zT_87 = zT_84 < (unsigned int)(64);
    if (!(zT_87)) { pal_trap(); }
    zT_89 = (zT_79FAE712_u64)(value >> zT_84) & (zT_79FAE712_u64)(255);
    zT_90 = (unsigned int)zig_cast_checked_u((zu64)zT_89, 64u, 0u, 32u);
    zT_91 = (unsigned char)zig_cast_checked_u((zu64)zT_90, 32u, 0u, 8u);
    zT_92 = p->head_buf;
    zT_93 = 3;
    zT_94 = zig_wrap_add_u(((zu64)(byte_off)), ((zu64)(zT_93)), 32u);
    zT_95 = zig_overflow_flag_add_u(((zu64)(byte_off)), ((zu64)(zT_93)), 32u);
    zT_97 = zT_95 == (unsigned int)(0);
    if (!(zT_97)) { pal_trap(); }
    zT_92[zT_94] = zT_91;
    goto z_bb_4;
    z_bb_4:
    zT_201 = p->head_elems;
    zT_202 = 1;
    zT_203 = (unsigned int)zT_202;
    zT_204 = zig_wrap_add_u(((zu64)(zT_201)), ((zu64)(zT_203)), 32u);
    zT_205 = zig_overflow_flag_add_u(((zu64)(zT_201)), ((zu64)(zT_203)), 32u);
    zT_207 = zT_205 == (unsigned int)(0);
    if (!(zT_207)) { pal_trap(); }
    p->head_elems = zT_204;
    zT_208 = p->len;
    zT_209 = 1;
    zT_210 = (unsigned int)zT_209;
    zT_211 = zig_wrap_add_u(((zu64)(zT_208)), ((zu64)(zT_210)), 32u);
    zT_212 = zig_overflow_flag_add_u(((zu64)(zT_208)), ((zu64)(zT_210)), 32u);
    zT_214 = zT_212 == (unsigned int)(0);
    if (!(zT_214)) { pal_trap(); }
    p->len = zT_211;
    return elem_idx;
    z_bb_5:
    zT_99 = value & (zT_79FAE712_u64)(255);
    zT_100 = (unsigned int)zig_cast_checked_u((zu64)zT_99, 64u, 0u, 32u);
    zT_101 = (unsigned char)zig_cast_checked_u((zu64)zT_100, 32u, 0u, 8u);
    zT_102 = p->head_buf;
    zT_102[byte_off] = zT_101;
    zT_103 = 8;
    zT_106 = zT_103 < (unsigned int)(64);
    if (!(zT_106)) { pal_trap(); }
    zT_108 = (zT_79FAE712_u64)(value >> zT_103) & (zT_79FAE712_u64)(255);
    zT_109 = (unsigned int)zig_cast_checked_u((zu64)zT_108, 64u, 0u, 32u);
    zT_110 = (unsigned char)zig_cast_checked_u((zu64)zT_109, 32u, 0u, 8u);
    zT_111 = p->head_buf;
    zT_112 = 1;
    zT_113 = zig_wrap_add_u(((zu64)(byte_off)), ((zu64)(zT_112)), 32u);
    zT_114 = zig_overflow_flag_add_u(((zu64)(byte_off)), ((zu64)(zT_112)), 32u);
    zT_116 = zT_114 == (unsigned int)(0);
    if (!(zT_116)) { pal_trap(); }
    zT_111[zT_113] = zT_110;
    zT_117 = 16;
    zT_120 = zT_117 < (unsigned int)(64);
    if (!(zT_120)) { pal_trap(); }
    zT_122 = (zT_79FAE712_u64)(value >> zT_117) & (zT_79FAE712_u64)(255);
    zT_123 = (unsigned int)zig_cast_checked_u((zu64)zT_122, 64u, 0u, 32u);
    zT_124 = (unsigned char)zig_cast_checked_u((zu64)zT_123, 32u, 0u, 8u);
    zT_125 = p->head_buf;
    zT_126 = 2;
    zT_127 = zig_wrap_add_u(((zu64)(byte_off)), ((zu64)(zT_126)), 32u);
    zT_128 = zig_overflow_flag_add_u(((zu64)(byte_off)), ((zu64)(zT_126)), 32u);
    zT_130 = zT_128 == (unsigned int)(0);
    if (!(zT_130)) { pal_trap(); }
    zT_125[zT_127] = zT_124;
    zT_131 = 24;
    zT_134 = zT_131 < (unsigned int)(64);
    if (!(zT_134)) { pal_trap(); }
    zT_136 = (zT_79FAE712_u64)(value >> zT_131) & (zT_79FAE712_u64)(255);
    zT_137 = (unsigned int)zig_cast_checked_u((zu64)zT_136, 64u, 0u, 32u);
    zT_138 = (unsigned char)zig_cast_checked_u((zu64)zT_137, 32u, 0u, 8u);
    zT_139 = p->head_buf;
    zT_140 = 3;
    zT_141 = zig_wrap_add_u(((zu64)(byte_off)), ((zu64)(zT_140)), 32u);
    zT_142 = zig_overflow_flag_add_u(((zu64)(byte_off)), ((zu64)(zT_140)), 32u);
    zT_144 = zT_142 == (unsigned int)(0);
    if (!(zT_144)) { pal_trap(); }
    zT_139[zT_141] = zT_138;
    zT_145 = 32;
    zT_148 = zT_145 < (unsigned int)(64);
    if (!(zT_148)) { pal_trap(); }
    zT_150 = (zT_79FAE712_u64)(value >> zT_145) & (zT_79FAE712_u64)(255);
    zT_151 = (unsigned int)zig_cast_checked_u((zu64)zT_150, 64u, 0u, 32u);
    zT_152 = (unsigned char)zig_cast_checked_u((zu64)zT_151, 32u, 0u, 8u);
    zT_153 = p->head_buf;
    zT_154 = 4;
    zT_155 = zig_wrap_add_u(((zu64)(byte_off)), ((zu64)(zT_154)), 32u);
    zT_156 = zig_overflow_flag_add_u(((zu64)(byte_off)), ((zu64)(zT_154)), 32u);
    zT_158 = zT_156 == (unsigned int)(0);
    if (!(zT_158)) { pal_trap(); }
    zT_153[zT_155] = zT_152;
    zT_159 = 40;
    zT_162 = zT_159 < (unsigned int)(64);
    if (!(zT_162)) { pal_trap(); }
    zT_164 = (zT_79FAE712_u64)(value >> zT_159) & (zT_79FAE712_u64)(255);
    zT_165 = (unsigned int)zig_cast_checked_u((zu64)zT_164, 64u, 0u, 32u);
    zT_166 = (unsigned char)zig_cast_checked_u((zu64)zT_165, 32u, 0u, 8u);
    zT_167 = p->head_buf;
    zT_168 = 5;
    zT_169 = zig_wrap_add_u(((zu64)(byte_off)), ((zu64)(zT_168)), 32u);
    zT_170 = zig_overflow_flag_add_u(((zu64)(byte_off)), ((zu64)(zT_168)), 32u);
    zT_172 = zT_170 == (unsigned int)(0);
    if (!(zT_172)) { pal_trap(); }
    zT_167[zT_169] = zT_166;
    zT_173 = 48;
    zT_176 = zT_173 < (unsigned int)(64);
    if (!(zT_176)) { pal_trap(); }
    zT_178 = (zT_79FAE712_u64)(value >> zT_173) & (zT_79FAE712_u64)(255);
    zT_179 = (unsigned int)zig_cast_checked_u((zu64)zT_178, 64u, 0u, 32u);
    zT_180 = (unsigned char)zig_cast_checked_u((zu64)zT_179, 32u, 0u, 8u);
    zT_181 = p->head_buf;
    zT_182 = 6;
    zT_183 = zig_wrap_add_u(((zu64)(byte_off)), ((zu64)(zT_182)), 32u);
    zT_184 = zig_overflow_flag_add_u(((zu64)(byte_off)), ((zu64)(zT_182)), 32u);
    zT_186 = zT_184 == (unsigned int)(0);
    if (!(zT_186)) { pal_trap(); }
    zT_181[zT_183] = zT_180;
    zT_187 = 56;
    zT_190 = zT_187 < (unsigned int)(64);
    if (!(zT_190)) { pal_trap(); }
    zT_192 = (zT_79FAE712_u64)(value >> zT_187) & (zT_79FAE712_u64)(255);
    zT_193 = (unsigned int)zig_cast_checked_u((zu64)zT_192, 64u, 0u, 32u);
    zT_194 = (unsigned char)zig_cast_checked_u((zu64)zT_193, 32u, 0u, 8u);
    zT_195 = p->head_buf;
    zT_196 = 7;
    zT_197 = zig_wrap_add_u(((zu64)(byte_off)), ((zu64)(zT_196)), 32u);
    zT_198 = zig_overflow_flag_add_u(((zu64)(byte_off)), ((zu64)(zT_196)), 32u);
    zT_200 = zT_198 == (unsigned int)(0);
    if (!(zT_200)) { pal_trap(); }
    zT_195[zT_197] = zT_194;
    goto z_bb_4;
}

/* valuePoolEnsureCache */
void zF_82730D0C_valuePoolEnsureCach(zT_6B0A7D14_AstStore* store, zT_01BE9D46_AstValuePool* p) {
    unsigned char zT_2;
    zT_3E40CD83_Sand* zT_6;
    unsigned int zT_7;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned char zT_15;
    zT_FDFD82FD_EU_362 zT_17;
    unsigned char zT_18;
    unsigned char* zT_19;
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    unsigned char* raw;
    zT_2 = p->cache_allocated;
    if ((unsigned char)(zT_2 != (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = store->allocator;
    zT_10 = 8;
    zT_11 = 4096;
    zT_12 = zig_wrap_mul_u(((zu64)(zT_10)), ((zu64)(zT_11)), 32u);
    zT_13 = zig_overflow_flag_mul_u(((zu64)(zT_10)), ((zu64)(zT_11)), 32u);
    zT_15 = zT_13 == (unsigned int)(0);
    if (!(zT_15)) { pal_trap(); }
    zT_7 = zT_12;
    zT_17 = zF_1395EB68_sandAlloc(zT_6, zT_7, (unsigned int)(4));
    zT_18 = zT_17.is_error;
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_19 = zT_17.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_19;
    p->cache_buf = raw;
    p->cache_allocated = (unsigned char)(1);
    return;
}

/* valuePoolCacheSlot */
unsigned int zF_73B68926_valuePoolCacheSlot(zT_6B0A7D14_AstStore* store, zT_01BE9D46_AstValuePool* p, unsigned int block) {
    zT_6B0A7D14_AstStore* zT_3;
    zT_01BE9D46_AstValuePool* zT_4;
    int zT_6;
    unsigned int zT_7;
    unsigned int* zT_10;
    unsigned char zT_12;
    unsigned int zT_13;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    unsigned int zT_28;
    zT_6B0A7D14_AstStore* zT_32;
    zT_01BE9D46_AstValuePool* zT_33;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    unsigned char* zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned char zT_47;
    unsigned char* zT_48;
    zT_D21A8776_SpillStore* zT_49;
    unsigned int zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    int zT_54;
    unsigned char* zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int* zT_58;
    unsigned char zT_60;
    unsigned int s;
    unsigned int v;
    unsigned int disk_off;
    unsigned char* base;
    zT_3 = store;
    zT_4 = p;
    zF_82730D0C_valuePoolEnsureCach(zT_3, zT_4);
    zT_6 = 0;
    zT_7 = (unsigned int)zT_6;
    s = zT_7;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(s < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = p->slot_block;
    zT_12 = s < (unsigned int)(8);
    if (!(zT_12)) { pal_trap(); }
    zT_13 = zT_10[s];
    if ((unsigned char)(zT_13 == block)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_22 = p->ring_next;
    v = zT_22;
    zT_23 = 1;
    zT_24 = zig_wrap_add_u(((zu64)(v)), ((zu64)(zT_23)), 32u);
    zT_25 = zig_overflow_flag_add_u(((zu64)(v)), ((zu64)(zT_23)), 32u);
    zT_27 = zT_25 == (unsigned int)(0);
    if (!(zT_27)) { pal_trap(); }
    p->ring_next = zT_24;
    zT_28 = p->ring_next;
    if ((unsigned char)(zT_28 >= (unsigned int)(8))) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    zT_15 = 1;
    zT_16 = (unsigned int)zT_15;
    zT_17 = zig_wrap_add_u(((zu64)(s)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(s)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    s = zT_17;
    goto z_bb_1;
    z_bb_5:
    return s;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    p->ring_next = (unsigned int)(0);
    goto z_bb_8;
    z_bb_8:
    zT_32 = store;
    zT_33 = p;
    zF_E407C3F0_valuePoolOpen(zT_32, zT_33);
    zT_35 = 4096;
    zT_36 = zig_wrap_mul_u(((zu64)(block)), ((zu64)(zT_35)), 32u);
    zT_37 = zig_overflow_flag_mul_u(((zu64)(block)), ((zu64)(zT_35)), 32u);
    zT_39 = zT_37 == (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    disk_off = zT_36;
    zT_41 = p->cache_buf;
    zT_42 = (unsigned int)v;
    zT_43 = 4096;
    zT_44 = zig_wrap_mul_u(((zu64)(zT_42)), ((zu64)(zT_43)), 32u);
    zT_45 = zig_overflow_flag_mul_u(((zu64)(zT_42)), ((zu64)(zT_43)), 32u);
    zT_47 = zT_45 == (unsigned int)(0);
    if (!(zT_47)) { pal_trap(); }
    zT_48 = zT_41 + zT_44;
    base = zT_48;
    zT_49 = &p->spill;
    zT_50 = disk_off;
    zT_54 = 0;
    zT_55 = base + zT_54;
    zT_56 = (unsigned int)(4096) - zT_54;
    zT_57.ptr = (unsigned char*)zT_55;
    zT_57.len = zT_56;
    zT_51 = zT_57;
    zF_E9F67450_spillReadAt(zT_49, zT_50, zT_51);
    zT_58 = p->slot_block;
    zT_60 = v < (unsigned int)(8);
    if (!(zT_60)) { pal_trap(); }
    zT_58[v] = block;
    return v;
}

/* valuePoolGetValue */
zT_79FAE712_u64 zF_FDA4EEAD_valuePoolGetValue(zT_6B0A7D14_AstStore* store, zT_01BE9D46_AstValuePool* p, unsigned int elem_idx) {
    unsigned int zT_3;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned char zT_11;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned char zT_22;
    unsigned char* zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    unsigned int zT_28;
    unsigned char* zT_31;
    zT_6B0A7D14_AstStore* zT_33;
    zT_01BE9D46_AstValuePool* zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned char* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned char zT_43;
    unsigned char* zT_44;
    unsigned char zT_46;
    zT_79FAE712_u64 zT_47;
    unsigned int zT_48;
    int zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned char zT_55;
    unsigned char zT_56;
    zT_79FAE712_u64 zT_57;
    zT_79FAE712_u64 zT_58;
    zT_79FAE712_u64 zT_59;
    unsigned char zT_61;
    unsigned int zT_62;
    unsigned char zT_64;
    zT_79FAE712_u64 zT_65;
    int zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned char zT_70;
    unsigned char zT_71;
    zT_79FAE712_u64 zT_72;
    zT_79FAE712_u64 zT_73;
    zT_79FAE712_u64 zT_74;
    unsigned char zT_76;
    unsigned int zT_77;
    unsigned char zT_79;
    zT_79FAE712_u64 zT_80;
    int zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned char zT_85;
    unsigned char zT_86;
    zT_79FAE712_u64 zT_87;
    zT_79FAE712_u64 zT_88;
    zT_79FAE712_u64 zT_89;
    unsigned char zT_91;
    unsigned int zT_92;
    unsigned char zT_94;
    zT_79FAE712_u64 zT_95;
    int zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned char zT_100;
    unsigned char zT_101;
    zT_79FAE712_u64 zT_102;
    zT_79FAE712_u64 zT_103;
    zT_79FAE712_u64 zT_104;
    unsigned char zT_106;
    unsigned int zT_107;
    unsigned char zT_109;
    zT_79FAE712_u64 zT_110;
    int zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    unsigned char zT_115;
    unsigned char zT_116;
    zT_79FAE712_u64 zT_117;
    zT_79FAE712_u64 zT_118;
    zT_79FAE712_u64 zT_119;
    unsigned char zT_121;
    unsigned int zT_122;
    unsigned char zT_124;
    zT_79FAE712_u64 zT_125;
    int zT_126;
    unsigned int zT_127;
    unsigned int zT_128;
    unsigned char zT_130;
    unsigned char zT_131;
    zT_79FAE712_u64 zT_132;
    zT_79FAE712_u64 zT_133;
    zT_79FAE712_u64 zT_134;
    unsigned char zT_136;
    unsigned int zT_137;
    unsigned char zT_139;
    zT_79FAE712_u64 zT_140;
    int zT_141;
    unsigned int zT_142;
    unsigned int zT_143;
    unsigned char zT_145;
    unsigned char zT_146;
    zT_79FAE712_u64 zT_147;
    zT_79FAE712_u64 zT_148;
    zT_79FAE712_u64 zT_149;
    unsigned char zT_151;
    unsigned int zT_152;
    unsigned char zT_154;
    zT_79FAE712_u64 zT_155;
    int zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    unsigned char zT_160;
    unsigned char zT_161;
    zT_79FAE712_u64 zT_162;
    zT_79FAE712_u64 zT_163;
    zT_79FAE712_u64 zT_164;
    unsigned char zT_166;
    unsigned int zT_167;
    unsigned char zT_169;
    zT_79FAE712_u64 zT_170;
    int zT_171;
    unsigned int zT_172;
    unsigned int zT_173;
    unsigned char zT_175;
    unsigned char zT_176;
    zT_79FAE712_u64 zT_177;
    zT_79FAE712_u64 zT_178;
    zT_79FAE712_u64 zT_179;
    unsigned char zT_181;
    unsigned int zT_182;
    unsigned char zT_184;
    zT_79FAE712_u64 zT_185;
    int zT_186;
    unsigned int zT_187;
    unsigned int zT_188;
    unsigned char zT_190;
    unsigned char zT_191;
    zT_79FAE712_u64 zT_192;
    zT_79FAE712_u64 zT_193;
    zT_79FAE712_u64 zT_194;
    unsigned char zT_196;
    unsigned int zT_197;
    unsigned char zT_199;
    zT_79FAE712_u64 zT_200;
    zig_poison_fill((void*)&zT_36, (unsigned int)sizeof zT_36);
    unsigned int block;
    unsigned int off;
    unsigned int byte_off;
    unsigned char* buf;
    zT_79FAE712_u64 v;
    unsigned int slot;
    zT_3 = p->len;
    if ((unsigned char)(elem_idx >= (unsigned int)((unsigned int)zT_3))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_79FAE712_u64)(0);
    z_bb_2:
    zT_8 = p->block_shift;
    zT_11 = zT_8 < (unsigned int)(32);
    if (!(zT_11)) { pal_trap(); }
    zT_9 = elem_idx >> zT_8;
    block = zT_9;
    zT_13 = p->block_mask;
    zT_14 = elem_idx & zT_13;
    off = zT_14;
    zT_16 = (unsigned int)off;
    zT_17 = p->elem_bytes;
    zT_18 = (unsigned int)zT_17;
    zT_19 = zig_wrap_mul_u(((zu64)(zT_16)), ((zu64)(zT_18)), 32u);
    zT_20 = zig_overflow_flag_mul_u(((zu64)(zT_16)), ((zu64)(zT_18)), 32u);
    zT_22 = zT_20 == (unsigned int)(0);
    if (!(zT_22)) { pal_trap(); }
    byte_off = zT_19;
    zig_poison_fill((void*)&zT_24, (unsigned int)sizeof zT_24);
    buf = zT_24;
    zT_25 = p->cur_block;
    if ((unsigned char)(block == zT_25)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_28 = p->head_cap;
    zT_27 = zT_28 != (unsigned int)(0);
    goto z_bb_5;
    z_bb_4:
    zT_27 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_27) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_31 = p->head_buf;
    buf = zT_31;
    goto z_bb_7;
    z_bb_7:
    zT_46 = buf[byte_off];
    zT_47 = (zT_79FAE712_u64)zT_46;
    v = zT_47;
    zT_48 = p->elem_bytes;
    if ((unsigned char)(zT_48 == (unsigned int)(8))) goto z_bb_9; else goto z_bb_11;
    z_bb_8:
    zT_33 = store;
    zT_34 = p;
    zT_35 = block;
    zT_36 = zF_73B68926_valuePoolCacheSlot(zT_33, zT_34, zT_35);
    slot = zT_36;
    zT_37 = p->cache_buf;
    zT_38 = (unsigned int)slot;
    zT_39 = 4096;
    zT_40 = zig_wrap_mul_u(((zu64)(zT_38)), ((zu64)(zT_39)), 32u);
    zT_41 = zig_overflow_flag_mul_u(((zu64)(zT_38)), ((zu64)(zT_39)), 32u);
    zT_43 = zT_41 == (unsigned int)(0);
    if (!(zT_43)) { pal_trap(); }
    zT_44 = zT_37 + zT_40;
    buf = zT_44;
    goto z_bb_7;
    z_bb_9:
    zT_51 = 1;
    zT_52 = zig_wrap_add_u(((zu64)(byte_off)), ((zu64)(zT_51)), 32u);
    zT_53 = zig_overflow_flag_add_u(((zu64)(byte_off)), ((zu64)(zT_51)), 32u);
    zT_55 = zT_53 == (unsigned int)(0);
    if (!(zT_55)) { pal_trap(); }
    zT_56 = buf[zT_52];
    zT_57 = (zT_79FAE712_u64)zT_56;
    zT_58 = 8;
    zT_61 = zT_58 < (unsigned int)(64);
    if (!(zT_61)) { pal_trap(); }
    zT_59 = zig_wrap_shl_u(((zu64)(zT_57)), ((zu64)(zT_58)), 64u);
    zT_62 = zig_overflow_flag_shl_u(((zu64)(zT_57)), ((zu64)(zT_58)), 64u);
    zT_64 = zT_62 == (unsigned int)(0);
    if (!(zT_64)) { pal_trap(); }
    zT_65 = v | zT_59;
    v = zT_65;
    zT_66 = 2;
    zT_67 = zig_wrap_add_u(((zu64)(byte_off)), ((zu64)(zT_66)), 32u);
    zT_68 = zig_overflow_flag_add_u(((zu64)(byte_off)), ((zu64)(zT_66)), 32u);
    zT_70 = zT_68 == (unsigned int)(0);
    if (!(zT_70)) { pal_trap(); }
    zT_71 = buf[zT_67];
    zT_72 = (zT_79FAE712_u64)zT_71;
    zT_73 = 16;
    zT_76 = zT_73 < (unsigned int)(64);
    if (!(zT_76)) { pal_trap(); }
    zT_74 = zig_wrap_shl_u(((zu64)(zT_72)), ((zu64)(zT_73)), 64u);
    zT_77 = zig_overflow_flag_shl_u(((zu64)(zT_72)), ((zu64)(zT_73)), 64u);
    zT_79 = zT_77 == (unsigned int)(0);
    if (!(zT_79)) { pal_trap(); }
    zT_80 = v | zT_74;
    v = zT_80;
    zT_81 = 3;
    zT_82 = zig_wrap_add_u(((zu64)(byte_off)), ((zu64)(zT_81)), 32u);
    zT_83 = zig_overflow_flag_add_u(((zu64)(byte_off)), ((zu64)(zT_81)), 32u);
    zT_85 = zT_83 == (unsigned int)(0);
    if (!(zT_85)) { pal_trap(); }
    zT_86 = buf[zT_82];
    zT_87 = (zT_79FAE712_u64)zT_86;
    zT_88 = 24;
    zT_91 = zT_88 < (unsigned int)(64);
    if (!(zT_91)) { pal_trap(); }
    zT_89 = zig_wrap_shl_u(((zu64)(zT_87)), ((zu64)(zT_88)), 64u);
    zT_92 = zig_overflow_flag_shl_u(((zu64)(zT_87)), ((zu64)(zT_88)), 64u);
    zT_94 = zT_92 == (unsigned int)(0);
    if (!(zT_94)) { pal_trap(); }
    zT_95 = v | zT_89;
    v = zT_95;
    zT_96 = 4;
    zT_97 = zig_wrap_add_u(((zu64)(byte_off)), ((zu64)(zT_96)), 32u);
    zT_98 = zig_overflow_flag_add_u(((zu64)(byte_off)), ((zu64)(zT_96)), 32u);
    zT_100 = zT_98 == (unsigned int)(0);
    if (!(zT_100)) { pal_trap(); }
    zT_101 = buf[zT_97];
    zT_102 = (zT_79FAE712_u64)zT_101;
    zT_103 = 32;
    zT_106 = zT_103 < (unsigned int)(64);
    if (!(zT_106)) { pal_trap(); }
    zT_104 = zig_wrap_shl_u(((zu64)(zT_102)), ((zu64)(zT_103)), 64u);
    zT_107 = zig_overflow_flag_shl_u(((zu64)(zT_102)), ((zu64)(zT_103)), 64u);
    zT_109 = zT_107 == (unsigned int)(0);
    if (!(zT_109)) { pal_trap(); }
    zT_110 = v | zT_104;
    v = zT_110;
    zT_111 = 5;
    zT_112 = zig_wrap_add_u(((zu64)(byte_off)), ((zu64)(zT_111)), 32u);
    zT_113 = zig_overflow_flag_add_u(((zu64)(byte_off)), ((zu64)(zT_111)), 32u);
    zT_115 = zT_113 == (unsigned int)(0);
    if (!(zT_115)) { pal_trap(); }
    zT_116 = buf[zT_112];
    zT_117 = (zT_79FAE712_u64)zT_116;
    zT_118 = 40;
    zT_121 = zT_118 < (unsigned int)(64);
    if (!(zT_121)) { pal_trap(); }
    zT_119 = zig_wrap_shl_u(((zu64)(zT_117)), ((zu64)(zT_118)), 64u);
    zT_122 = zig_overflow_flag_shl_u(((zu64)(zT_117)), ((zu64)(zT_118)), 64u);
    zT_124 = zT_122 == (unsigned int)(0);
    if (!(zT_124)) { pal_trap(); }
    zT_125 = v | zT_119;
    v = zT_125;
    zT_126 = 6;
    zT_127 = zig_wrap_add_u(((zu64)(byte_off)), ((zu64)(zT_126)), 32u);
    zT_128 = zig_overflow_flag_add_u(((zu64)(byte_off)), ((zu64)(zT_126)), 32u);
    zT_130 = zT_128 == (unsigned int)(0);
    if (!(zT_130)) { pal_trap(); }
    zT_131 = buf[zT_127];
    zT_132 = (zT_79FAE712_u64)zT_131;
    zT_133 = 48;
    zT_136 = zT_133 < (unsigned int)(64);
    if (!(zT_136)) { pal_trap(); }
    zT_134 = zig_wrap_shl_u(((zu64)(zT_132)), ((zu64)(zT_133)), 64u);
    zT_137 = zig_overflow_flag_shl_u(((zu64)(zT_132)), ((zu64)(zT_133)), 64u);
    zT_139 = zT_137 == (unsigned int)(0);
    if (!(zT_139)) { pal_trap(); }
    zT_140 = v | zT_134;
    v = zT_140;
    zT_141 = 7;
    zT_142 = zig_wrap_add_u(((zu64)(byte_off)), ((zu64)(zT_141)), 32u);
    zT_143 = zig_overflow_flag_add_u(((zu64)(byte_off)), ((zu64)(zT_141)), 32u);
    zT_145 = zT_143 == (unsigned int)(0);
    if (!(zT_145)) { pal_trap(); }
    zT_146 = buf[zT_142];
    zT_147 = (zT_79FAE712_u64)zT_146;
    zT_148 = 56;
    zT_151 = zT_148 < (unsigned int)(64);
    if (!(zT_151)) { pal_trap(); }
    zT_149 = zig_wrap_shl_u(((zu64)(zT_147)), ((zu64)(zT_148)), 64u);
    zT_152 = zig_overflow_flag_shl_u(((zu64)(zT_147)), ((zu64)(zT_148)), 64u);
    zT_154 = zT_152 == (unsigned int)(0);
    if (!(zT_154)) { pal_trap(); }
    zT_155 = v | zT_149;
    v = zT_155;
    goto z_bb_10;
    z_bb_10:
    return v;
    z_bb_11:
    zT_156 = 1;
    zT_157 = zig_wrap_add_u(((zu64)(byte_off)), ((zu64)(zT_156)), 32u);
    zT_158 = zig_overflow_flag_add_u(((zu64)(byte_off)), ((zu64)(zT_156)), 32u);
    zT_160 = zT_158 == (unsigned int)(0);
    if (!(zT_160)) { pal_trap(); }
    zT_161 = buf[zT_157];
    zT_162 = (zT_79FAE712_u64)zT_161;
    zT_163 = 8;
    zT_166 = zT_163 < (unsigned int)(64);
    if (!(zT_166)) { pal_trap(); }
    zT_164 = zig_wrap_shl_u(((zu64)(zT_162)), ((zu64)(zT_163)), 64u);
    zT_167 = zig_overflow_flag_shl_u(((zu64)(zT_162)), ((zu64)(zT_163)), 64u);
    zT_169 = zT_167 == (unsigned int)(0);
    if (!(zT_169)) { pal_trap(); }
    zT_170 = v | zT_164;
    v = zT_170;
    zT_171 = 2;
    zT_172 = zig_wrap_add_u(((zu64)(byte_off)), ((zu64)(zT_171)), 32u);
    zT_173 = zig_overflow_flag_add_u(((zu64)(byte_off)), ((zu64)(zT_171)), 32u);
    zT_175 = zT_173 == (unsigned int)(0);
    if (!(zT_175)) { pal_trap(); }
    zT_176 = buf[zT_172];
    zT_177 = (zT_79FAE712_u64)zT_176;
    zT_178 = 16;
    zT_181 = zT_178 < (unsigned int)(64);
    if (!(zT_181)) { pal_trap(); }
    zT_179 = zig_wrap_shl_u(((zu64)(zT_177)), ((zu64)(zT_178)), 64u);
    zT_182 = zig_overflow_flag_shl_u(((zu64)(zT_177)), ((zu64)(zT_178)), 64u);
    zT_184 = zT_182 == (unsigned int)(0);
    if (!(zT_184)) { pal_trap(); }
    zT_185 = v | zT_179;
    v = zT_185;
    zT_186 = 3;
    zT_187 = zig_wrap_add_u(((zu64)(byte_off)), ((zu64)(zT_186)), 32u);
    zT_188 = zig_overflow_flag_add_u(((zu64)(byte_off)), ((zu64)(zT_186)), 32u);
    zT_190 = zT_188 == (unsigned int)(0);
    if (!(zT_190)) { pal_trap(); }
    zT_191 = buf[zT_187];
    zT_192 = (zT_79FAE712_u64)zT_191;
    zT_193 = 24;
    zT_196 = zT_193 < (unsigned int)(64);
    if (!(zT_196)) { pal_trap(); }
    zT_194 = zig_wrap_shl_u(((zu64)(zT_192)), ((zu64)(zT_193)), 64u);
    zT_197 = zig_overflow_flag_shl_u(((zu64)(zT_192)), ((zu64)(zT_193)), 64u);
    zT_199 = zT_197 == (unsigned int)(0);
    if (!(zT_199)) { pal_trap(); }
    zT_200 = v | zT_194;
    v = zT_200;
    goto z_bb_10;
}

/* valuePoolClose */
void zF_131F3CDC_valuePoolClose(zT_6B0A7D14_AstStore* store, zT_01BE9D46_AstValuePool* p) {
    zT_D21A8776_SpillStore* zT_2;
    (void)store;
    zT_2 = &p->spill;
    zF_DB2CDC3B_spillClose(zT_2);
    return;
}

/* astStoreIdentifier */
unsigned int zF_53458827_astStoreIdentifier(zT_6B0A7D14_AstStore* store, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_6B0A7D14_AstStore* zT_6;
    zT_01BE9D46_AstValuePool* zT_7;
    unsigned int zT_8;
    zT_79FAE712_u64 zT_10;
    unsigned int zT_11;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    unsigned int pool_idx;
    zT_3 = store;
    zT_4 = node_idx;
    zT_5 = zF_8BA26B9E_astStoreNodePayload(zT_3, zT_4);
    pool_idx = zT_5;
    zT_6 = store;
    zT_7 = &store->identifiers;
    zT_8 = pool_idx;
    zT_10 = zF_FDA4EEAD_valuePoolGetValue(zT_6, zT_7, zT_8);
    zT_11 = (unsigned int)zig_cast_checked_u((zu64)zT_10, 64u, 0u, 32u);
    return zT_11;
}

/* astStoreIntValue */
zT_79FAE712_u64 zF_678B9A72_astStoreIntValue(zT_6B0A7D14_AstStore* store, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_6B0A7D14_AstStore* zT_6;
    zT_01BE9D46_AstValuePool* zT_7;
    unsigned int zT_8;
    zT_79FAE712_u64 zT_10;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    unsigned int pool_idx;
    zT_3 = store;
    zT_4 = node_idx;
    zT_5 = zF_8BA26B9E_astStoreNodePayload(zT_3, zT_4);
    pool_idx = zT_5;
    zT_6 = store;
    zT_7 = &store->int_values;
    zT_8 = pool_idx;
    zT_10 = zF_FDA4EEAD_valuePoolGetValue(zT_6, zT_7, zT_8);
    return zT_10;
}

/* astStoreAddNode */
unsigned int zF_6C9FF72F_astStoreAddNode(zT_6B0A7D14_AstStore* store, zT_8143F551_AstKind kind, unsigned char flags, unsigned int span_start, unsigned int span_end, unsigned int c0, unsigned int c1, unsigned int c2, unsigned int payload) {
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned char zT_13;
    unsigned int zT_14;
    zT_22A7C88B_AstNode zT_16;
    zT_6B0A7D14_AstStore* zT_17;
    zT_22A7C88B_AstNode zT_18;
    unsigned int zT_19;
    zT_61A320D8_anon_323976 zT_20;
    unsigned int zT_21;
    int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned char zT_26;
    unsigned int span_len;
    zT_22A7C88B_AstNode node;
    zT_10 = zig_wrap_sub_u(((zu64)(span_end)), ((zu64)(span_start)), 32u);
    zT_11 = zig_overflow_flag_sub_u(((zu64)(span_end)), ((zu64)(span_start)), 32u);
    zT_13 = zT_11 == (unsigned int)(0);
    if (!(zT_13)) { pal_trap(); }
    zT_14 = (unsigned int)zT_10;
    span_len = zT_14;
    zT_16.kind = kind;
    zT_16.flags = flags;
    zT_16.span_start = span_start;
    zT_16.span_len = span_len;
    zT_16.child_0 = c0;
    zT_16.child_1 = c1;
    zT_16.child_2 = c2;
    node = zT_16;
    zT_17 = store;
    zT_18 = node;
    zT_19 = payload;
    zF_3A477168_astStoreNodeAppend(zT_17, zT_18, zT_19);
    zT_20 = store->nodes;
    zT_21 = zT_20.len;
    zT_22 = 1;
    zT_23 = zig_wrap_sub_u(((zu64)(zT_21)), ((zu64)(zT_22)), 32u);
    zT_24 = zig_overflow_flag_sub_u(((zu64)(zT_21)), ((zu64)(zT_22)), 32u);
    zT_26 = zT_24 == (unsigned int)(0);
    if (!(zT_26)) { pal_trap(); }
    return (unsigned int)((unsigned int)zT_23);
}

/* astStoreNodeAppend */
void zF_3A477168_astStoreNodeAppend(zT_6B0A7D14_AstStore* store, zT_22A7C88B_AstNode node, unsigned int payload) {
    zT_61A320D8_anon_323976 zT_4;
    unsigned int zT_5;
    int zT_7;
    unsigned char zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_6B0A7D14_AstStore* zT_14;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    unsigned int zT_19;
    zT_6B0A7D14_AstStore* zT_20;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_31;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned char zT_37;
    zT_6DD0D007_AstSlot* zT_38;
    unsigned int zT_39;
    unsigned char zT_41;
    zT_6DD0D007_AstSlot zT_42;
    zT_22A7C88B_AstNode* zT_43;
    zT_6DD0D007_AstSlot* zT_44;
    unsigned int zT_45;
    unsigned char zT_47;
    zT_6DD0D007_AstSlot zT_48;
    unsigned int* zT_49;
    zT_61A320D8_anon_323976 zT_50;
    unsigned int zT_51;
    int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned char zT_57;
    zT_61A320D8_anon_323976* zT_58;
    zT_4E36AEA5_anon_324013 zT_59;
    unsigned int zT_60;
    int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned char zT_66;
    zT_4E36AEA5_anon_324013* zT_67;
    unsigned int zT_68;
    int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned char zT_74;
    unsigned int node_idx;
    unsigned int bi;
    unsigned int off;
    zT_4 = store->nodes;
    zT_5 = zT_4.len;
    node_idx = zT_5;
    zT_7 = 12;
    zT_10 = (unsigned int)zT_7 < (unsigned int)(32);
    if (!(zT_10)) { pal_trap(); }
    zT_11 = (unsigned int)(unsigned int)(node_idx >> zT_7);
    bi = zT_11;
    zT_12 = store->cur_block;
    if ((unsigned char)(bi != zT_12)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_14 = store;
    zF_D45C652C_astBlockSpillHead(zT_14);
    zT_15 = store;
    zT_16 = bi;
    zF_BA06A188_astBlockAdvanceHead(zT_15, zT_16);
    goto z_bb_2;
    z_bb_2:
    zT_19 = node_idx & (unsigned int)(4095);
    off = zT_19;
    zT_20 = store;
    zT_24 = 1;
    zT_25 = zig_wrap_add_u(((zu64)(off)), ((zu64)(zT_24)), 32u);
    zT_26 = zig_overflow_flag_add_u(((zu64)(off)), ((zu64)(zT_24)), 32u);
    zT_28 = zT_26 == (unsigned int)(0);
    if (!(zT_28)) { pal_trap(); }
    zT_22 = zT_25;
    zF_420B3B4B_astSlotEnsureNodeCa(zT_20, (unsigned int)(0), zT_22);
    zT_29 = store;
    zT_33 = 1;
    zT_34 = zig_wrap_add_u(((zu64)(off)), ((zu64)(zT_33)), 32u);
    zT_35 = zig_overflow_flag_add_u(((zu64)(off)), ((zu64)(zT_33)), 32u);
    zT_37 = zT_35 == (unsigned int)(0);
    if (!(zT_37)) { pal_trap(); }
    zT_31 = zT_34;
    zF_5184AF33_astSlotEnsurePayloa(zT_29, (unsigned int)(0), zT_31);
    zT_38 = store->slots;
    zT_39 = 0;
    zT_41 = 1;
    if (!(zT_41)) { pal_trap(); }
    zT_42 = zT_38[zT_39];
    zT_43 = zT_42.node_buf;
    zT_43[off] = node;
    zT_44 = store->slots;
    zT_45 = 0;
    zT_47 = 1;
    if (!(zT_47)) { pal_trap(); }
    zT_48 = zT_44[zT_45];
    zT_49 = zT_48.payload_buf;
    zT_49[off] = payload;
    zT_50 = store->nodes;
    zT_51 = zT_50.len;
    zT_52 = 1;
    zT_53 = (unsigned int)zT_52;
    zT_54 = zig_wrap_add_u(((zu64)(zT_51)), ((zu64)(zT_53)), 32u);
    zT_55 = zig_overflow_flag_add_u(((zu64)(zT_51)), ((zu64)(zT_53)), 32u);
    zT_57 = zT_55 == (unsigned int)(0);
    if (!(zT_57)) { pal_trap(); }
    zT_58 = &store->nodes;
    zT_58->len = zT_54;
    zT_59 = store->payload;
    zT_60 = zT_59.len;
    zT_61 = 1;
    zT_62 = (unsigned int)zT_61;
    zT_63 = zig_wrap_add_u(((zu64)(zT_60)), ((zu64)(zT_62)), 32u);
    zT_64 = zig_overflow_flag_add_u(((zu64)(zT_60)), ((zu64)(zT_62)), 32u);
    zT_66 = zT_64 == (unsigned int)(0);
    if (!(zT_66)) { pal_trap(); }
    zT_67 = &store->payload;
    zT_67->len = zT_63;
    zT_68 = store->cur_block_len;
    zT_69 = 1;
    zT_70 = (unsigned int)zT_69;
    zT_71 = zig_wrap_add_u(((zu64)(zT_68)), ((zu64)(zT_70)), 32u);
    zT_72 = zig_overflow_flag_add_u(((zu64)(zT_68)), ((zu64)(zT_70)), 32u);
    zT_74 = zT_72 == (unsigned int)(0);
    if (!(zT_74)) { pal_trap(); }
    store->cur_block_len = zT_71;
    return;
}

/* astBlockTableEnsure */
void zF_1D4F4DCE_astBlockTableEnsure(zT_6B0A7D14_AstStore* store, unsigned int new_len) {
    zT_DA3E46CE_anon_324027 zT_2;
    unsigned int zT_3;
    zT_DA3E46CE_anon_324027 zT_6;
    unsigned int zT_7;
    unsigned int zT_10;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    zT_3E40CD83_Sand* zT_19;
    unsigned int zT_20;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    zT_FDFD82FD_EU_362 zT_29;
    unsigned char zT_30;
    unsigned char* zT_31;
    zT_E2FE8472_NodeBlockInfo* zT_34;
    int zT_36;
    unsigned int zT_37;
    zT_DA3E46CE_anon_324027 zT_38;
    unsigned int zT_39;
    zT_DA3E46CE_anon_324027 zT_41;
    zT_E2FE8472_NodeBlockInfo* zT_42;
    zT_E2FE8472_NodeBlockInfo zT_43;
    int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned char zT_49;
    zT_DA3E46CE_anon_324027* zT_50;
    zT_DA3E46CE_anon_324027* zT_51;
    zT_DA3E46CE_anon_324027* zT_52;
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    unsigned int new_cap;
    unsigned char* raw;
    zT_E2FE8472_NodeBlockInfo* new_items;
    unsigned int i;
    zT_2 = store->block_table;
    zT_3 = zT_2.len;
    if ((unsigned char)(new_len <= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = store->block_table;
    zT_7 = zT_6.capacity;
    new_cap = zT_7;
    if ((unsigned char)(new_cap < (unsigned int)(16))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_10 = 16;
    new_cap = zT_10;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(new_cap < new_len)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_12 = 2;
    zT_13 = (unsigned int)zT_12;
    zT_14 = zig_wrap_mul_u(((zu64)(new_cap)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_mul_u(((zu64)(new_cap)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    new_cap = zT_14;
    goto z_bb_8;
    z_bb_7:
    zT_19 = store->allocator;
    zT_23 = 12;
    zT_24 = zig_wrap_mul_u(((zu64)(zT_23)), ((zu64)(new_cap)), 32u);
    zT_25 = zig_overflow_flag_mul_u(((zu64)(zT_23)), ((zu64)(new_cap)), 32u);
    zT_27 = zT_25 == (unsigned int)(0);
    if (!(zT_27)) { pal_trap(); }
    zT_20 = zT_24;
    zT_29 = zF_1395EB68_sandAlloc(zT_19, zT_20, (unsigned int)(4));
    zT_30 = zT_29.is_error;
    if (zT_30) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    pal_trap();
    z_bb_10:
    zT_31 = zT_29.data.payload;
    goto z_bb_11;
    z_bb_11:
    raw = zT_31;
    zT_34 = (zT_E2FE8472_NodeBlockInfo*)raw;
    new_items = zT_34;
    zT_36 = 0;
    zT_37 = (unsigned int)zT_36;
    i = zT_37;
    goto z_bb_12;
    z_bb_12:
    zT_38 = store->block_table;
    zT_39 = zT_38.len;
    if ((unsigned char)(i < zT_39)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_41 = store->block_table;
    zT_42 = zT_41.items;
    zT_43 = zT_42[i];
    new_items[i] = zT_43;
    goto z_bb_15;
    z_bb_14:
    zT_50 = &store->block_table;
    zT_50->items = new_items;
    zT_51 = &store->block_table;
    zT_51->capacity = new_cap;
    zT_52 = &store->block_table;
    zT_52->len = new_len;
    return;
    z_bb_15:
    zT_44 = 1;
    zT_45 = (unsigned int)zT_44;
    zT_46 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_45)), 32u);
    zT_47 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_45)), 32u);
    zT_49 = zT_47 == (unsigned int)(0);
    if (!(zT_49)) { pal_trap(); }
    i = zT_46;
    goto z_bb_12;
}

/* astBlockOpenSpill */
void zF_548211A2_astBlockOpenSpill(zT_6B0A7D14_AstStore* store) {
    zT_D21A8776_SpillStore zT_1;
    unsigned char zT_2;
    zT_D21A8776_SpillStore* zT_5;
    zT_0426DCE7_SpillBackend zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_3E40CD83_Sand* zT_8;
    unsigned char* zT_9;
    zT_0426DCE7_SpillBackend zT_14;
    unsigned char* zT_15;
    unsigned int zT_16;
    int zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    unsigned char zT_21;
    unsigned char zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned char* zT_25;
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    zT_1 = store->spill;
    zT_2 = zT_1.opened;
    if ((unsigned char)(zT_2 != (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = &store->spill;
    zT_14 = zF_1AA39172_spillBackendFor((zT_F12DA458_SpillId)(zT_F12DA458_SpillId_s_ast));
    zT_6 = zT_14;
    zT_15 = store->spill_path;
    zT_16 = store->spill_path_len;
    zT_17 = 0;
    zT_18 = zT_15 + zT_17;
    zT_19 = zT_16 - zT_17;
    zT_21 = (unsigned int)zT_17 <= zT_16;
    if (!(zT_21)) { pal_trap(); }
    zT_22 = zT_16 <= (unsigned int)(512);
    if (!(zT_22)) { pal_trap(); }
    zT_23.ptr = (unsigned char*)zT_18;
    zT_23.len = zT_19;
    zT_7 = zT_23;
    zT_8 = store->allocator;
    zT_25 = "w+b";
    zT_9 = zT_25;
    zF_8AF94F71_spillOpen(zT_5, zT_6, zT_7, zT_8, zT_9);
    return;
}

/* astBlockSpillHead */
void zF_D45C652C_astBlockSpillHead(zT_6B0A7D14_AstStore* store) {
    zT_6B0A7D14_AstStore* zT_1;
    unsigned int zT_3;
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    int zT_17;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    zT_DA3E46CE_anon_324027 zT_26;
    zT_E2FE8472_NodeBlockInfo* zT_27;
    zT_E2FE8472_NodeBlockInfo zT_28;
    unsigned int zT_30;
    zT_DA3E46CE_anon_324027 zT_32;
    zT_E2FE8472_NodeBlockInfo* zT_33;
    zT_6DD0D007_AstSlot* zT_35;
    unsigned int zT_36;
    unsigned char zT_38;
    zT_6DD0D007_AstSlot zT_39;
    zT_22A7C88B_AstNode* zT_40;
    unsigned char* zT_41;
    zT_D21A8776_SpillStore* zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    int zT_47;
    unsigned char* zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_6DD0D007_AstSlot* zT_52;
    unsigned int zT_53;
    unsigned char zT_55;
    zT_6DD0D007_AstSlot zT_56;
    unsigned int* zT_57;
    unsigned char* zT_58;
    zT_D21A8776_SpillStore* zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned char zT_67;
    int zT_69;
    unsigned char* zT_70;
    unsigned int zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int bi;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    unsigned int disk_off;
    zT_E2FE8472_NodeBlockInfo entry;
    unsigned char* nraw;
    unsigned char* praw;
    zT_1 = store;
    zF_548211A2_astBlockOpenSpill(zT_1);
    zT_3 = store->cur_block;
    bi = zT_3;
    if ((unsigned char)(bi > (unsigned int)(18724))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7 = "S-AST spill block count exceeds i32 seek limit (astBlockSpillHead)";
    zT_9 = 66;
    zT_8.ptr = (unsigned char*)zT_7;
    zT_8.len = zT_9;
    emsg = zT_8;
    zT_11 = "ast.zig";
    zT_13 = 7;
    zT_12.ptr = (unsigned char*)zT_11;
    zT_12.len = zT_13;
    ef = zT_12;
    zT_14 = emsg;
    zT_15 = ef;
    zT_17 = 537;
    zF_6D97D338_panicHandler(zT_14, zT_15, (unsigned int)((unsigned int)zT_17));
    return;
    z_bb_2:
    zT_20 = 114688;
    zT_21 = zig_wrap_mul_u(((zu64)(bi)), ((zu64)(zT_20)), 32u);
    zT_22 = zig_overflow_flag_mul_u(((zu64)(bi)), ((zu64)(zT_20)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    disk_off = zT_21;
    zT_26 = store->block_table;
    zT_27 = zT_26.items;
    zT_28 = zT_27[bi];
    entry = zT_28;
    entry.disk_off = disk_off;
    entry.resident = (unsigned char)(0);
    zT_30 = 4294967295u;
    entry.slot = (unsigned int)((unsigned int)zT_30);
    zT_32 = store->block_table;
    zT_33 = zT_32.items;
    zT_33[bi] = entry;
    zT_35 = store->slots;
    zT_36 = 0;
    zT_38 = 1;
    if (!(zT_38)) { pal_trap(); }
    zT_39 = zT_35[zT_36];
    zT_40 = zT_39.node_buf;
    zT_41 = (unsigned char*)zT_40;
    nraw = zT_41;
    zT_42 = &store->spill;
    zT_43 = disk_off;
    zT_47 = 0;
    zT_48 = nraw + zT_47;
    zT_49 = (unsigned int)(98304) - zT_47;
    zT_50.ptr = (unsigned char*)zT_48;
    zT_50.len = zT_49;
    zT_44 = zT_50;
    zF_BFB33631_spillWriteAt(zT_42, zT_43, zT_44);
    zT_52 = store->slots;
    zT_53 = 0;
    zT_55 = 1;
    if (!(zT_55)) { pal_trap(); }
    zT_56 = zT_52[zT_53];
    zT_57 = zT_56.payload_buf;
    zT_58 = (unsigned char*)zT_57;
    praw = zT_58;
    zT_59 = &store->spill;
    zT_63 = 98304;
    zT_64 = zig_wrap_add_u(((zu64)(disk_off)), ((zu64)(zT_63)), 32u);
    zT_65 = zig_overflow_flag_add_u(((zu64)(disk_off)), ((zu64)(zT_63)), 32u);
    zT_67 = zT_65 == (unsigned int)(0);
    if (!(zT_67)) { pal_trap(); }
    zT_60 = zT_64;
    zT_69 = 0;
    zT_70 = praw + zT_69;
    zT_71 = (unsigned int)(16384) - zT_69;
    zT_72.ptr = (unsigned char*)zT_70;
    zT_72.len = zT_71;
    zT_61 = zT_72;
    zF_BFB33631_spillWriteAt(zT_59, zT_60, zT_61);
    return;
}

/* astBlockAdvanceHead */
void zF_BA06A188_astBlockAdvanceHead(zT_6B0A7D14_AstStore* store, unsigned int new_bi) {
    zT_6B0A7D14_AstStore* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_E2FE8472_NodeBlockInfo zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned char zT_15;
    unsigned char zT_16;
    unsigned int zT_17;
    zT_DA3E46CE_anon_324027 zT_18;
    zT_E2FE8472_NodeBlockInfo* zT_19;
    zT_6DD0D007_AstSlot* zT_21;
    unsigned char zT_24;
    zT_6DD0D007_AstSlot* zT_25;
    unsigned int* zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    zT_2 = store;
    zT_4 = (unsigned int)new_bi;
    zT_5 = 1;
    zT_6 = zig_wrap_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_add_u(((zu64)(zT_4)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_3 = zT_6;
    zF_1D4F4DCE_astBlockTableEnsure(zT_2, zT_3);
    zT_11 = 114688;
    zT_12 = zig_wrap_mul_u(((zu64)(new_bi)), ((zu64)(zT_11)), 32u);
    zT_13 = zig_overflow_flag_mul_u(((zu64)(new_bi)), ((zu64)(zT_11)), 32u);
    zT_15 = zT_13 == (unsigned int)(0);
    if (!(zT_15)) { pal_trap(); }
    zT_10.disk_off = zT_12;
    zT_16 = 1;
    zT_10.resident = zT_16;
    zT_17 = 0;
    zT_10.slot = zT_17;
    zT_18 = store->block_table;
    zT_19 = zT_18.items;
    zT_19[new_bi] = zT_10;
    zT_21 = store->slots;
    zT_24 = 1;
    if (!(zT_24)) { pal_trap(); }
    zT_25 = zT_21 + (unsigned int)(0);
    zT_25->in_use = (unsigned char)(1);
    zT_26 = store->slot_block;
    zT_27 = 0;
    zT_29 = 1;
    if (!(zT_29)) { pal_trap(); }
    zT_26[zT_27] = new_bi;
    store->cur_block = new_bi;
    store->cur_block_len = (unsigned int)(0);
    return;
}

/* astSlotEnsureNodeCap */
void zF_420B3B4B_astSlotEnsureNodeCa(zT_6B0A7D14_AstStore* store, unsigned int s, unsigned int need) {
    zT_6DD0D007_AstSlot* zT_3;
    unsigned char zT_5;
    zT_6DD0D007_AstSlot zT_6;
    unsigned int zT_7;
    zT_6DD0D007_AstSlot* zT_10;
    unsigned char zT_12;
    zT_6DD0D007_AstSlot zT_13;
    unsigned int zT_14;
    unsigned int zT_17;
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    unsigned int zT_27;
    zT_3E40CD83_Sand* zT_29;
    unsigned int zT_30;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned char zT_37;
    zT_FDFD82FD_EU_362 zT_39;
    unsigned char zT_40;
    unsigned char* zT_41;
    zT_22A7C88B_AstNode* zT_44;
    int zT_46;
    unsigned int zT_47;
    zT_6DD0D007_AstSlot* zT_48;
    unsigned char zT_50;
    zT_6DD0D007_AstSlot zT_51;
    unsigned int zT_52;
    zT_6DD0D007_AstSlot* zT_54;
    unsigned char zT_56;
    zT_6DD0D007_AstSlot zT_57;
    zT_22A7C88B_AstNode* zT_58;
    zT_22A7C88B_AstNode zT_59;
    int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned char zT_65;
    zT_6DD0D007_AstSlot* zT_66;
    unsigned char zT_68;
    zT_6DD0D007_AstSlot* zT_69;
    zT_6DD0D007_AstSlot* zT_70;
    unsigned char zT_72;
    zT_6DD0D007_AstSlot* zT_73;
    zig_poison_fill((void*)&zT_39, (unsigned int)sizeof zT_39);
    unsigned int new_cap;
    unsigned char* raw;
    zT_22A7C88B_AstNode* nb;
    unsigned int i;
    zT_3 = store->slots;
    zT_5 = s < (unsigned int)(8);
    if (!(zT_5)) { pal_trap(); }
    zT_6 = zT_3[s];
    zT_7 = zT_6.node_cap;
    if ((unsigned char)(zT_7 >= need)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_10 = store->slots;
    zT_12 = s < (unsigned int)(8);
    if (!(zT_12)) { pal_trap(); }
    zT_13 = zT_10[s];
    zT_14 = zT_13.node_cap;
    new_cap = zT_14;
    if ((unsigned char)(new_cap < (unsigned int)(64))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = 64;
    new_cap = zT_17;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(new_cap < need)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_19 = 2;
    zT_20 = (unsigned int)zT_19;
    zT_21 = zig_wrap_mul_u(((zu64)(new_cap)), ((zu64)(zT_20)), 32u);
    zT_22 = zig_overflow_flag_mul_u(((zu64)(new_cap)), ((zu64)(zT_20)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    new_cap = zT_21;
    goto z_bb_8;
    z_bb_7:
    if ((unsigned char)(new_cap > (unsigned int)(4096))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_27 = 4096;
    new_cap = zT_27;
    goto z_bb_10;
    z_bb_10:
    zT_29 = store->allocator;
    zT_33 = 24;
    zT_34 = zig_wrap_mul_u(((zu64)(zT_33)), ((zu64)(new_cap)), 32u);
    zT_35 = zig_overflow_flag_mul_u(((zu64)(zT_33)), ((zu64)(new_cap)), 32u);
    zT_37 = zT_35 == (unsigned int)(0);
    if (!(zT_37)) { pal_trap(); }
    zT_30 = zT_34;
    zT_39 = zF_1395EB68_sandAlloc(zT_29, zT_30, (unsigned int)(4));
    zT_40 = zT_39.is_error;
    if (zT_40) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_41 = zT_39.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_41;
    zT_44 = (zT_22A7C88B_AstNode*)raw;
    nb = zT_44;
    zT_46 = 0;
    zT_47 = (unsigned int)zT_46;
    i = zT_47;
    goto z_bb_14;
    z_bb_14:
    zT_48 = store->slots;
    zT_50 = s < (unsigned int)(8);
    if (!(zT_50)) { pal_trap(); }
    zT_51 = zT_48[s];
    zT_52 = zT_51.node_cap;
    if ((unsigned char)(i < zT_52)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_54 = store->slots;
    zT_56 = s < (unsigned int)(8);
    if (!(zT_56)) { pal_trap(); }
    zT_57 = zT_54[s];
    zT_58 = zT_57.node_buf;
    zT_59 = zT_58[i];
    nb[i] = zT_59;
    goto z_bb_17;
    z_bb_16:
    zT_66 = store->slots;
    zT_68 = s < (unsigned int)(8);
    if (!(zT_68)) { pal_trap(); }
    zT_69 = zT_66 + s;
    zT_69->node_buf = nb;
    zT_70 = store->slots;
    zT_72 = s < (unsigned int)(8);
    if (!(zT_72)) { pal_trap(); }
    zT_73 = zT_70 + s;
    zT_73->node_cap = new_cap;
    return;
    z_bb_17:
    zT_60 = 1;
    zT_61 = (unsigned int)zT_60;
    zT_62 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_61)), 32u);
    zT_63 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_61)), 32u);
    zT_65 = zT_63 == (unsigned int)(0);
    if (!(zT_65)) { pal_trap(); }
    i = zT_62;
    goto z_bb_14;
}

/* astSlotEnsurePayloadCap */
void zF_5184AF33_astSlotEnsurePayloa(zT_6B0A7D14_AstStore* store, unsigned int s, unsigned int need) {
    zT_6DD0D007_AstSlot* zT_3;
    unsigned char zT_5;
    zT_6DD0D007_AstSlot zT_6;
    unsigned int zT_7;
    zT_6DD0D007_AstSlot* zT_10;
    unsigned char zT_12;
    zT_6DD0D007_AstSlot zT_13;
    unsigned int zT_14;
    unsigned int zT_17;
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    unsigned int zT_27;
    zT_3E40CD83_Sand* zT_29;
    unsigned int zT_30;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned char zT_37;
    zT_FDFD82FD_EU_362 zT_39;
    unsigned char zT_40;
    unsigned char* zT_41;
    unsigned int* zT_44;
    int zT_46;
    unsigned int zT_47;
    zT_6DD0D007_AstSlot* zT_48;
    unsigned char zT_50;
    zT_6DD0D007_AstSlot zT_51;
    unsigned int zT_52;
    zT_6DD0D007_AstSlot* zT_54;
    unsigned char zT_56;
    zT_6DD0D007_AstSlot zT_57;
    unsigned int* zT_58;
    unsigned int zT_59;
    int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned char zT_65;
    zT_6DD0D007_AstSlot* zT_66;
    unsigned char zT_68;
    zT_6DD0D007_AstSlot* zT_69;
    zT_6DD0D007_AstSlot* zT_70;
    unsigned char zT_72;
    zT_6DD0D007_AstSlot* zT_73;
    zig_poison_fill((void*)&zT_39, (unsigned int)sizeof zT_39);
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* nb;
    unsigned int i;
    zT_3 = store->slots;
    zT_5 = s < (unsigned int)(8);
    if (!(zT_5)) { pal_trap(); }
    zT_6 = zT_3[s];
    zT_7 = zT_6.payload_cap;
    if ((unsigned char)(zT_7 >= need)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_10 = store->slots;
    zT_12 = s < (unsigned int)(8);
    if (!(zT_12)) { pal_trap(); }
    zT_13 = zT_10[s];
    zT_14 = zT_13.payload_cap;
    new_cap = zT_14;
    if ((unsigned char)(new_cap < (unsigned int)(64))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = 64;
    new_cap = zT_17;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(new_cap < need)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_19 = 2;
    zT_20 = (unsigned int)zT_19;
    zT_21 = zig_wrap_mul_u(((zu64)(new_cap)), ((zu64)(zT_20)), 32u);
    zT_22 = zig_overflow_flag_mul_u(((zu64)(new_cap)), ((zu64)(zT_20)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    new_cap = zT_21;
    goto z_bb_8;
    z_bb_7:
    if ((unsigned char)(new_cap > (unsigned int)(4096))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_27 = 4096;
    new_cap = zT_27;
    goto z_bb_10;
    z_bb_10:
    zT_29 = store->allocator;
    zT_33 = 4;
    zT_34 = zig_wrap_mul_u(((zu64)(zT_33)), ((zu64)(new_cap)), 32u);
    zT_35 = zig_overflow_flag_mul_u(((zu64)(zT_33)), ((zu64)(new_cap)), 32u);
    zT_37 = zT_35 == (unsigned int)(0);
    if (!(zT_37)) { pal_trap(); }
    zT_30 = zT_34;
    zT_39 = zF_1395EB68_sandAlloc(zT_29, zT_30, (unsigned int)(4));
    zT_40 = zT_39.is_error;
    if (zT_40) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_41 = zT_39.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_41;
    zT_44 = (unsigned int*)raw;
    nb = zT_44;
    zT_46 = 0;
    zT_47 = (unsigned int)zT_46;
    i = zT_47;
    goto z_bb_14;
    z_bb_14:
    zT_48 = store->slots;
    zT_50 = s < (unsigned int)(8);
    if (!(zT_50)) { pal_trap(); }
    zT_51 = zT_48[s];
    zT_52 = zT_51.payload_cap;
    if ((unsigned char)(i < zT_52)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_54 = store->slots;
    zT_56 = s < (unsigned int)(8);
    if (!(zT_56)) { pal_trap(); }
    zT_57 = zT_54[s];
    zT_58 = zT_57.payload_buf;
    zT_59 = zT_58[i];
    nb[i] = zT_59;
    goto z_bb_17;
    z_bb_16:
    zT_66 = store->slots;
    zT_68 = s < (unsigned int)(8);
    if (!(zT_68)) { pal_trap(); }
    zT_69 = zT_66 + s;
    zT_69->payload_buf = nb;
    zT_70 = store->slots;
    zT_72 = s < (unsigned int)(8);
    if (!(zT_72)) { pal_trap(); }
    zT_73 = zT_70 + s;
    zT_73->payload_cap = new_cap;
    return;
    z_bb_17:
    zT_60 = 1;
    zT_61 = (unsigned int)zT_60;
    zT_62 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_61)), 32u);
    zT_63 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_61)), 32u);
    zT_65 = zT_63 == (unsigned int)(0);
    if (!(zT_65)) { pal_trap(); }
    i = zT_62;
    goto z_bb_14;
}

/* astSlotEnsureFull */
void zF_8D6C3544_astSlotEnsureFull(zT_6B0A7D14_AstStore* store, unsigned int s) {
    zT_6B0A7D14_AstStore* zT_2;
    unsigned int zT_3;
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_2 = store;
    zT_3 = s;
    zF_420B3B4B_astSlotEnsureNodeCa(zT_2, zT_3, (unsigned int)(4096));
    zT_6 = store;
    zT_7 = s;
    zF_5184AF33_astSlotEnsurePayloa(zT_6, zT_7, (unsigned int)(4096));
    return;
}

/* astSlotAcquire */
unsigned int zF_E0B03A59_astSlotAcquire(zT_6B0A7D14_AstStore* store) {
    int zT_2;
    unsigned int zT_3;
    zT_6DD0D007_AstSlot* zT_6;
    unsigned char zT_8;
    zT_6DD0D007_AstSlot zT_9;
    unsigned char zT_10;
    zT_6DD0D007_AstSlot* zT_14;
    unsigned char zT_16;
    zT_6DD0D007_AstSlot* zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned char zT_23;
    unsigned int zT_25;
    int zT_28;
    unsigned int zT_29;
    int zT_32;
    unsigned int zT_33;
    unsigned int* zT_35;
    unsigned char zT_37;
    unsigned int zT_38;
    zT_DA3E46CE_anon_324027 zT_40;
    zT_E2FE8472_NodeBlockInfo* zT_41;
    zT_E2FE8472_NodeBlockInfo zT_42;
    unsigned int zT_44;
    zT_DA3E46CE_anon_324027 zT_46;
    zT_E2FE8472_NodeBlockInfo* zT_47;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned char zT_53;
    int zT_56;
    unsigned int zT_57;
    unsigned int i;
    unsigned int victim;
    unsigned int vblock;
    zT_E2FE8472_NodeBlockInfo ventry;
    unsigned int nv;
    zT_2 = 1;
    zT_3 = (unsigned int)zT_2;
    i = zT_3;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_6 = store->slots;
    zT_8 = i < (unsigned int)(8);
    if (!(zT_8)) { pal_trap(); }
    zT_9 = zT_6[i];
    zT_10 = zT_9.in_use;
    if ((unsigned char)(zT_10 == (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_25 = store->ring_next;
    victim = zT_25;
    if ((unsigned char)(victim == (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    zT_18 = 1;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_19)), 32u);
    zT_21 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_19)), 32u);
    zT_23 = zT_21 == (unsigned int)(0);
    if (!(zT_23)) { pal_trap(); }
    i = zT_20;
    goto z_bb_1;
    z_bb_5:
    zT_14 = store->slots;
    zT_16 = i < (unsigned int)(8);
    if (!(zT_16)) { pal_trap(); }
    zT_17 = zT_14 + i;
    zT_17->in_use = (unsigned char)(1);
    return i;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_28 = 1;
    zT_29 = (unsigned int)zT_28;
    victim = zT_29;
    goto z_bb_8;
    z_bb_8:
    if ((unsigned char)(victim >= (unsigned int)(8))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_32 = 1;
    zT_33 = (unsigned int)zT_32;
    victim = zT_33;
    goto z_bb_10;
    z_bb_10:
    zT_35 = store->slot_block;
    zT_37 = victim < (unsigned int)(8);
    if (!(zT_37)) { pal_trap(); }
    zT_38 = zT_35[victim];
    vblock = zT_38;
    zT_40 = store->block_table;
    zT_41 = zT_40.items;
    zT_42 = zT_41[vblock];
    ventry = zT_42;
    ventry.resident = (unsigned char)(0);
    zT_44 = 4294967295u;
    ventry.slot = (unsigned int)((unsigned int)zT_44);
    zT_46 = store->block_table;
    zT_47 = zT_46.items;
    zT_47[vblock] = ventry;
    zT_49 = 1;
    zT_50 = zig_wrap_add_u(((zu64)(victim)), ((zu64)(zT_49)), 32u);
    zT_51 = zig_overflow_flag_add_u(((zu64)(victim)), ((zu64)(zT_49)), 32u);
    zT_53 = zT_51 == (unsigned int)(0);
    if (!(zT_53)) { pal_trap(); }
    nv = zT_50;
    if ((unsigned char)(nv >= (unsigned int)(8))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_56 = 1;
    zT_57 = (unsigned int)zT_56;
    nv = zT_57;
    goto z_bb_12;
    z_bb_12:
    store->ring_next = nv;
    return victim;
}

/* astBlockFaultIn */
void zF_4891718F_astBlockFaultIn(zT_6B0A7D14_AstStore* store, unsigned int bi) {
    zT_6B0A7D14_AstStore* zT_2;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    int zT_16;
    zT_DA3E46CE_anon_324027 zT_19;
    zT_E2FE8472_NodeBlockInfo* zT_20;
    zT_E2FE8472_NodeBlockInfo zT_21;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    zT_6B0A7D14_AstStore* zT_25;
    unsigned int zT_26;
    zT_6DD0D007_AstSlot* zT_28;
    unsigned char zT_30;
    zT_6DD0D007_AstSlot zT_31;
    zT_22A7C88B_AstNode* zT_32;
    unsigned char* zT_33;
    zT_D21A8776_SpillStore* zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    int zT_40;
    unsigned char* zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    zT_6DD0D007_AstSlot* zT_45;
    unsigned char zT_47;
    zT_6DD0D007_AstSlot zT_48;
    unsigned int* zT_49;
    unsigned char* zT_50;
    zT_D21A8776_SpillStore* zT_51;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned char zT_60;
    int zT_62;
    unsigned char* zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    zT_6DD0D007_AstSlot* zT_67;
    unsigned char zT_69;
    zT_6DD0D007_AstSlot* zT_70;
    unsigned int* zT_71;
    unsigned char zT_73;
    zT_DA3E46CE_anon_324027 zT_75;
    zT_E2FE8472_NodeBlockInfo* zT_76;
    zig_poison_fill((void*)&zT_24, (unsigned int)sizeof zT_24);
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    zT_E2FE8472_NodeBlockInfo entry;
    unsigned int s;
    unsigned char* nraw;
    unsigned char* praw;
    zT_2 = store;
    zF_548211A2_astBlockOpenSpill(zT_2);
    if ((unsigned char)(bi > (unsigned int)(18724))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = "S-AST spill block count exceeds i32 seek limit (astBlockFaultIn)";
    zT_8 = 64;
    zT_7.ptr = (unsigned char*)zT_6;
    zT_7.len = zT_8;
    emsg = zT_7;
    zT_10 = "ast.zig";
    zT_12 = 7;
    zT_11.ptr = (unsigned char*)zT_10;
    zT_11.len = zT_12;
    ef = zT_11;
    zT_13 = emsg;
    zT_14 = ef;
    zT_16 = 627;
    zF_6D97D338_panicHandler(zT_13, zT_14, (unsigned int)((unsigned int)zT_16));
    return;
    z_bb_2:
    zT_19 = store->block_table;
    zT_20 = zT_19.items;
    zT_21 = zT_20[bi];
    entry = zT_21;
    zT_23 = store;
    zT_24 = zF_E0B03A59_astSlotAcquire(zT_23);
    s = zT_24;
    zT_25 = store;
    zT_26 = s;
    zF_8D6C3544_astSlotEnsureFull(zT_25, zT_26);
    zT_28 = store->slots;
    zT_30 = s < (unsigned int)(8);
    if (!(zT_30)) { pal_trap(); }
    zT_31 = zT_28[s];
    zT_32 = zT_31.node_buf;
    zT_33 = (unsigned char*)zT_32;
    nraw = zT_33;
    zT_34 = &store->spill;
    zT_35 = entry.disk_off;
    zT_40 = 0;
    zT_41 = nraw + zT_40;
    zT_42 = (unsigned int)(98304) - zT_40;
    zT_43.ptr = (unsigned char*)zT_41;
    zT_43.len = zT_42;
    zT_36 = zT_43;
    zF_E9F67450_spillReadAt(zT_34, zT_35, zT_36);
    zT_45 = store->slots;
    zT_47 = s < (unsigned int)(8);
    if (!(zT_47)) { pal_trap(); }
    zT_48 = zT_45[s];
    zT_49 = zT_48.payload_buf;
    zT_50 = (unsigned char*)zT_49;
    praw = zT_50;
    zT_51 = &store->spill;
    zT_55 = entry.disk_off;
    zT_56 = 98304;
    zT_57 = zig_wrap_add_u(((zu64)(zT_55)), ((zu64)(zT_56)), 32u);
    zT_58 = zig_overflow_flag_add_u(((zu64)(zT_55)), ((zu64)(zT_56)), 32u);
    zT_60 = zT_58 == (unsigned int)(0);
    if (!(zT_60)) { pal_trap(); }
    zT_52 = zT_57;
    zT_62 = 0;
    zT_63 = praw + zT_62;
    zT_64 = (unsigned int)(16384) - zT_62;
    zT_65.ptr = (unsigned char*)zT_63;
    zT_65.len = zT_64;
    zT_53 = zT_65;
    zF_E9F67450_spillReadAt(zT_51, zT_52, zT_53);
    zT_67 = store->slots;
    zT_69 = s < (unsigned int)(8);
    if (!(zT_69)) { pal_trap(); }
    zT_70 = zT_67 + s;
    zT_70->in_use = (unsigned char)(1);
    zT_71 = store->slot_block;
    zT_73 = s < (unsigned int)(8);
    if (!(zT_73)) { pal_trap(); }
    zT_71[s] = bi;
    entry.resident = (unsigned char)(1);
    entry.slot = s;
    zT_75 = store->block_table;
    zT_76 = zT_75.items;
    zT_76[bi] = entry;
    return;
}

/* astStoreNodeAt */
zT_22A7C88B_AstNode zF_FCDD1D35_astStoreNodeAt(zT_6B0A7D14_AstStore* store, unsigned int idx) {
    int zT_3;
    unsigned int zT_4;
    unsigned char zT_6;
    unsigned int zT_9;
    zT_DA3E46CE_anon_324027 zT_11;
    zT_E2FE8472_NodeBlockInfo* zT_12;
    zT_E2FE8472_NodeBlockInfo zT_13;
    unsigned char zT_14;
    zT_6B0A7D14_AstStore* zT_17;
    unsigned int zT_18;
    zT_DA3E46CE_anon_324027 zT_19;
    zT_E2FE8472_NodeBlockInfo* zT_20;
    zT_E2FE8472_NodeBlockInfo zT_21;
    zT_6DD0D007_AstSlot* zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    zT_6DD0D007_AstSlot zT_26;
    zT_22A7C88B_AstNode* zT_27;
    zT_22A7C88B_AstNode zT_28;
    unsigned int bi;
    unsigned int off;
    zT_E2FE8472_NodeBlockInfo entry;
    zT_3 = 12;
    zT_6 = (unsigned int)zT_3 < (unsigned int)(32);
    if (!(zT_6)) { pal_trap(); }
    zT_4 = idx >> zT_3;
    bi = zT_4;
    zT_9 = idx & (unsigned int)(4095);
    off = zT_9;
    zT_11 = store->block_table;
    zT_12 = zT_11.items;
    zT_13 = zT_12[bi];
    entry = zT_13;
    zT_14 = entry.resident;
    if ((unsigned char)(zT_14 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_17 = store;
    zT_18 = bi;
    zF_4891718F_astBlockFaultIn(zT_17, zT_18);
    zT_19 = store->block_table;
    zT_20 = zT_19.items;
    zT_21 = zT_20[bi];
    entry = zT_21;
    goto z_bb_2;
    z_bb_2:
    zT_22 = store->slots;
    zT_23 = entry.slot;
    zT_25 = zT_23 < (unsigned int)(8);
    if (!(zT_25)) { pal_trap(); }
    zT_26 = zT_22[zT_23];
    zT_27 = zT_26.node_buf;
    zT_28 = zT_27[off];
    return zT_28;
}

/* astStoreAddExtraChildren */
unsigned int zF_583E993C_astStoreAddExtraChi(zT_6B0A7D14_AstStore* store, zT_3CB0179A_Slice_zT_05F374B1_u children) {
    zT_01BE9D46_AstValuePool zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_10;
    zT_6B0A7D14_AstStore* zT_12;
    zT_01BE9D46_AstValuePool* zT_13;
    unsigned int* zT_16;
    unsigned int zT_17;
    unsigned char zT_18;
    unsigned int zT_19;
    unsigned int zT_21;
    int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    zT_6B0A7D14_AstStore* zT_29;
    zT_01BE9D46_AstValuePool* zT_30;
    zT_79FAE712_u64 zT_33;
    zT_79FAE712_u64 zT_34;
    zT_79FAE712_u64 zT_35;
    unsigned char zT_37;
    unsigned int zT_38;
    unsigned char zT_40;
    unsigned int zT_42;
    unsigned int zT_45;
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    unsigned int start;
    unsigned int i;
    unsigned int range_idx;
    zT_3 = store->extra_children;
    zT_4 = zT_3.len;
    zT_5 = (unsigned int)zT_4;
    start = zT_5;
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    i = zT_8;
    goto z_bb_1;
    z_bb_1:
    zT_10 = children.len;
    if ((unsigned char)(i < zT_10)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_12 = store;
    zT_13 = &store->extra_children;
    zT_16 = children.ptr;
    zT_17 = children.len;
    zT_18 = i < zT_17;
    if (!(zT_18)) { pal_trap(); }
    zT_19 = zT_16[i];
    zT_21 = zF_B73DE9D0_valuePoolAppend(zT_12, zT_13, (zT_79FAE712_u64)((zT_79FAE712_u64)zT_19));
    (void)zT_21;
    zT_22 = 1;
    zT_23 = (unsigned int)zT_22;
    zT_24 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_23)), 32u);
    zT_25 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_23)), 32u);
    zT_27 = zT_25 == (unsigned int)(0);
    if (!(zT_27)) { pal_trap(); }
    i = zT_24;
    goto z_bb_4;
    z_bb_3:
    zT_29 = store;
    zT_30 = &store->extra_ranges;
    zT_33 = (zT_79FAE712_u64)start;
    zT_34 = 32;
    zT_37 = zT_34 < (unsigned int)(64);
    if (!(zT_37)) { pal_trap(); }
    zT_35 = zig_wrap_shl_u(((zu64)(zT_33)), ((zu64)(zT_34)), 64u);
    zT_38 = zig_overflow_flag_shl_u(((zu64)(zT_33)), ((zu64)(zT_34)), 64u);
    zT_40 = zT_38 == (unsigned int)(0);
    if (!(zT_40)) { pal_trap(); }
    zT_42 = children.len;
    zT_45 = zF_B73DE9D0_valuePoolAppend(zT_29, zT_30, (zT_79FAE712_u64)(zT_35 | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_42)));
    range_idx = zT_45;
    return range_idx;
    z_bb_4:
    goto z_bb_1;
}

/* astStoreGetExtraChildCount */
unsigned int zF_03CE8CAB_astStoreGetExtraChi(zT_6B0A7D14_AstStore* store, zT_79FAE712_u64 payload) {
    zT_79FAE712_u64 zT_3;
    unsigned int zT_4;
    (void)store;
    zT_3 = payload & (zT_79FAE712_u64)(4294967295u);
    zT_4 = (unsigned int)zig_cast_checked_u((zu64)zT_3, 64u, 0u, 32u);
    return zT_4;
}

/* astStoreGetExtraChildAt */
unsigned int zF_E5B10421_astStoreGetExtraChi(zT_6B0A7D14_AstStore* store, zT_79FAE712_u64 payload, unsigned int i) {
    zT_79FAE712_u64 zT_4;
    zT_79FAE712_u64 zT_5;
    unsigned char zT_7;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_9;
    zT_01BE9D46_AstValuePool* zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned char zT_16;
    zT_79FAE712_u64 zT_17;
    unsigned int zT_18;
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    unsigned int start;
    zT_4 = 32;
    zT_7 = zT_4 < (unsigned int)(64);
    if (!(zT_7)) { pal_trap(); }
    zT_5 = payload >> zT_4;
    zT_8 = (unsigned int)zig_cast_checked_u((zu64)zT_5, 64u, 0u, 32u);
    start = zT_8;
    zT_9 = store;
    zT_10 = &store->extra_children;
    zT_13 = zig_wrap_add_u(((zu64)(start)), ((zu64)(i)), 32u);
    zT_14 = zig_overflow_flag_add_u(((zu64)(start)), ((zu64)(i)), 32u);
    zT_16 = zT_14 == (unsigned int)(0);
    if (!(zT_16)) { pal_trap(); }
    zT_11 = zT_13;
    zT_17 = zF_FDA4EEAD_valuePoolGetValue(zT_9, zT_10, zT_11);
    zT_18 = (unsigned int)zig_cast_checked_u((zu64)zT_17, 64u, 0u, 32u);
    return zT_18;
}

/* astStoreGetExtraChildrenCopy */
unsigned int zF_67ADE488_astStoreGetExtraChi(zT_6B0A7D14_AstStore* store, zT_79FAE712_u64 payload, zT_3CB0179A_Slice_zT_05F374B1_u out) {
    zT_6B0A7D14_AstStore* zT_4;
    zT_79FAE712_u64 zT_5;
    unsigned int zT_6;
    unsigned int zT_10;
    unsigned int zT_13;
    unsigned int zT_14;
    int zT_16;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_19;
    zT_79FAE712_u64 zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_26;
    int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    unsigned int count;
    unsigned int n;
    unsigned int i;
    zT_4 = store;
    zT_5 = payload;
    zT_6 = zF_03CE8CAB_astStoreGetExtraChi(zT_4, zT_5);
    count = zT_6;
    n = count;
    zT_10 = out.len;
    if ((unsigned char)((unsigned int)((unsigned int)n) > zT_10)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = out.len;
    zT_14 = (unsigned int)zT_13;
    n = zT_14;
    goto z_bb_2;
    z_bb_2:
    zT_16 = 0;
    zT_17 = (unsigned int)zT_16;
    i = zT_17;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(i < n)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_19 = store;
    zT_20 = payload;
    zT_21 = i;
    zT_22 = zF_E5B10421_astStoreGetExtraChi(zT_19, zT_20, zT_21);
    zT_23 = out.ptr;
    zT_24 = (unsigned int)i;
    zT_25 = out.len;
    zT_26 = zT_24 < zT_25;
    if (!(zT_26)) { pal_trap(); }
    zT_23[zT_24] = zT_22;
    goto z_bb_6;
    z_bb_5:
    return count;
    z_bb_6:
    zT_27 = 1;
    zT_28 = (unsigned int)zT_27;
    zT_29 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_28)), 32u);
    zT_30 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_28)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    i = zT_29;
    goto z_bb_3;
}

/* astStoreExtraChildAtRaw */
unsigned int zF_884B7FF9_astStoreExtraChildA(zT_6B0A7D14_AstStore* store, unsigned int idx) {
    zT_6B0A7D14_AstStore* zT_2;
    zT_01BE9D46_AstValuePool* zT_3;
    unsigned int zT_4;
    zT_79FAE712_u64 zT_6;
    unsigned int zT_7;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zT_2 = store;
    zT_3 = &store->extra_children;
    zT_4 = idx;
    zT_6 = zF_FDA4EEAD_valuePoolGetValue(zT_2, zT_3, zT_4);
    zT_7 = (unsigned int)zig_cast_checked_u((zu64)zT_6, 64u, 0u, 32u);
    return zT_7;
}

/* astStoreExtraRangeAt */
zT_79FAE712_u64 zF_F956A1CA_astStoreExtraRangeA(zT_6B0A7D14_AstStore* store, unsigned int range_idx) {
    zT_6B0A7D14_AstStore* zT_2;
    zT_01BE9D46_AstValuePool* zT_3;
    unsigned int zT_4;
    zT_79FAE712_u64 zT_6;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zT_2 = store;
    zT_3 = &store->extra_ranges;
    zT_4 = range_idx;
    zT_6 = zF_FDA4EEAD_valuePoolGetValue(zT_2, zT_3, zT_4);
    return zT_6;
}

/* astStoreNodePayload */
unsigned int zF_8BA26B9E_astStoreNodePayload(zT_6B0A7D14_AstStore* store, unsigned int node_idx) {
    int zT_3;
    unsigned int zT_4;
    unsigned char zT_6;
    unsigned int zT_9;
    zT_DA3E46CE_anon_324027 zT_11;
    zT_E2FE8472_NodeBlockInfo* zT_12;
    zT_E2FE8472_NodeBlockInfo zT_13;
    unsigned char zT_14;
    zT_6B0A7D14_AstStore* zT_17;
    unsigned int zT_18;
    zT_DA3E46CE_anon_324027 zT_19;
    zT_E2FE8472_NodeBlockInfo* zT_20;
    zT_E2FE8472_NodeBlockInfo zT_21;
    zT_6DD0D007_AstSlot* zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    zT_6DD0D007_AstSlot zT_26;
    unsigned int* zT_27;
    unsigned int zT_28;
    unsigned int bi;
    unsigned int off;
    zT_E2FE8472_NodeBlockInfo entry;
    zT_3 = 12;
    zT_6 = (unsigned int)zT_3 < (unsigned int)(32);
    if (!(zT_6)) { pal_trap(); }
    zT_4 = node_idx >> zT_3;
    bi = zT_4;
    zT_9 = node_idx & (unsigned int)(4095);
    off = zT_9;
    zT_11 = store->block_table;
    zT_12 = zT_11.items;
    zT_13 = zT_12[bi];
    entry = zT_13;
    zT_14 = entry.resident;
    if ((unsigned char)(zT_14 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_17 = store;
    zT_18 = bi;
    zF_4891718F_astBlockFaultIn(zT_17, zT_18);
    zT_19 = store->block_table;
    zT_20 = zT_19.items;
    zT_21 = zT_20[bi];
    entry = zT_21;
    goto z_bb_2;
    z_bb_2:
    zT_22 = store->slots;
    zT_23 = entry.slot;
    zT_25 = zT_23 < (unsigned int)(8);
    if (!(zT_25)) { pal_trap(); }
    zT_26 = zT_22[zT_23];
    zT_27 = zT_26.payload_buf;
    zT_28 = zT_27[off];
    return zT_28;
}

/* astStoreNodePayloadPacked */
zT_79FAE712_u64 zF_0E4E10C6_astStoreNodePayload(zT_6B0A7D14_AstStore* store, unsigned int node_idx, zT_8143F551_AstKind kind) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_8143F551_AstKind zT_10;
    unsigned char zT_11;
    unsigned char zT_12;
    zT_6B0A7D14_AstStore* zT_15;
    zT_01BE9D46_AstValuePool* zT_16;
    unsigned int zT_17;
    zT_79FAE712_u64 zT_19;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    unsigned int v;
    zT_4 = store;
    zT_5 = node_idx;
    zT_6 = zF_8BA26B9E_astStoreNodePayload(zT_4, zT_5);
    v = zT_6;
    if ((unsigned char)(v == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_79FAE712_u64)(0);
    z_bb_2:
    zT_10 = kind;
    zT_11 = zF_A5D7FF20_nodeHasExtraChildre(zT_10);
    if (zT_11) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_12 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call);
    goto z_bb_5;
    z_bb_4:
    zT_12 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_12) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_15 = store;
    zT_16 = &store->extra_ranges;
    zT_17 = v;
    zT_19 = zF_FDA4EEAD_valuePoolGetValue(zT_15, zT_16, zT_17);
    return zT_19;
    z_bb_7:
    return (zT_79FAE712_u64)((zT_79FAE712_u64)v);
}

/* astStoreNodeExtraChildCount */
unsigned int zF_152E19CB_astStoreNodeExtraCh(zT_6B0A7D14_AstStore* store, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_6B0A7D14_AstStore* zT_10;
    zT_01BE9D46_AstValuePool* zT_11;
    unsigned int zT_12;
    zT_79FAE712_u64 zT_14;
    zT_79FAE712_u64 zT_16;
    unsigned int zT_17;
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zig_poison_fill((void*)&zT_14, (unsigned int)sizeof zT_14);
    unsigned int range_idx;
    zT_79FAE712_u64 packed_range;
    zT_3 = store;
    zT_4 = node_idx;
    zT_5 = zF_8BA26B9E_astStoreNodePayload(zT_3, zT_4);
    range_idx = zT_5;
    if ((unsigned char)(range_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_10 = store;
    zT_11 = &store->extra_ranges;
    zT_12 = range_idx;
    zT_14 = zF_FDA4EEAD_valuePoolGetValue(zT_10, zT_11, zT_12);
    packed_range = zT_14;
    zT_16 = packed_range & (zT_79FAE712_u64)(4294967295u);
    zT_17 = (unsigned int)zig_cast_checked_u((zu64)zT_16, 64u, 0u, 32u);
    return zT_17;
}

/* astStoreNodeExtraChildAt */
unsigned int zF_B10B1BC1_astStoreNodeExtraCh(zT_6B0A7D14_AstStore* store, unsigned int node_idx, unsigned int i) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    zT_01BE9D46_AstValuePool* zT_9;
    unsigned int zT_10;
    zT_79FAE712_u64 zT_12;
    zT_79FAE712_u64 zT_14;
    zT_79FAE712_u64 zT_15;
    unsigned char zT_17;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_19;
    zT_01BE9D46_AstValuePool* zT_20;
    unsigned int zT_21;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned char zT_26;
    zT_79FAE712_u64 zT_27;
    unsigned int zT_28;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_12, (unsigned int)sizeof zT_12);
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    unsigned int range_idx;
    zT_79FAE712_u64 packed_range;
    unsigned int start;
    zT_4 = store;
    zT_5 = node_idx;
    zT_6 = zF_8BA26B9E_astStoreNodePayload(zT_4, zT_5);
    range_idx = zT_6;
    zT_8 = store;
    zT_9 = &store->extra_ranges;
    zT_10 = range_idx;
    zT_12 = zF_FDA4EEAD_valuePoolGetValue(zT_8, zT_9, zT_10);
    packed_range = zT_12;
    zT_14 = 32;
    zT_17 = zT_14 < (unsigned int)(64);
    if (!(zT_17)) { pal_trap(); }
    zT_15 = packed_range >> zT_14;
    zT_18 = (unsigned int)zig_cast_checked_u((zu64)zT_15, 64u, 0u, 32u);
    start = zT_18;
    zT_19 = store;
    zT_20 = &store->extra_children;
    zT_23 = zig_wrap_add_u(((zu64)(start)), ((zu64)(i)), 32u);
    zT_24 = zig_overflow_flag_add_u(((zu64)(start)), ((zu64)(i)), 32u);
    zT_26 = zT_24 == (unsigned int)(0);
    if (!(zT_26)) { pal_trap(); }
    zT_21 = zT_23;
    zT_27 = zF_FDA4EEAD_valuePoolGetValue(zT_19, zT_20, zT_21);
    zT_28 = (unsigned int)zig_cast_checked_u((zu64)zT_27, 64u, 0u, 32u);
    return zT_28;
}

/* astStoreNodeExtraChildrenCopy */
unsigned int zF_111E5D28_astStoreNodeExtraCh(zT_6B0A7D14_AstStore* store, unsigned int node_idx, zT_3CB0179A_Slice_zT_05F374B1_u out) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_10;
    unsigned int zT_13;
    unsigned int zT_14;
    int zT_16;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_26;
    int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_22, (unsigned int)sizeof zT_22);
    unsigned int count;
    unsigned int n;
    unsigned int i;
    zT_4 = store;
    zT_5 = node_idx;
    zT_6 = zF_152E19CB_astStoreNodeExtraCh(zT_4, zT_5);
    count = zT_6;
    n = count;
    zT_10 = out.len;
    if ((unsigned char)((unsigned int)((unsigned int)n) > zT_10)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = out.len;
    zT_14 = (unsigned int)zT_13;
    n = zT_14;
    goto z_bb_2;
    z_bb_2:
    zT_16 = 0;
    zT_17 = (unsigned int)zT_16;
    i = zT_17;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(i < n)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_19 = store;
    zT_20 = node_idx;
    zT_21 = i;
    zT_22 = zF_B10B1BC1_astStoreNodeExtraCh(zT_19, zT_20, zT_21);
    zT_23 = out.ptr;
    zT_24 = (unsigned int)i;
    zT_25 = out.len;
    zT_26 = zT_24 < zT_25;
    if (!(zT_26)) { pal_trap(); }
    zT_23[zT_24] = zT_22;
    goto z_bb_6;
    z_bb_5:
    return count;
    z_bb_6:
    zT_27 = 1;
    zT_28 = (unsigned int)zT_27;
    zT_29 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_28)), 32u);
    zT_30 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_28)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    i = zT_29;
    goto z_bb_3;
}

/* astStoreAddIntLiteral */
unsigned int zF_E45552BF_astStoreAddIntLiter(zT_6B0A7D14_AstStore* store, zT_79FAE712_u64 value, unsigned int span_start, unsigned int span_end) {
    zT_6B0A7D14_AstStore* zT_5;
    zT_01BE9D46_AstValuePool* zT_6;
    zT_79FAE712_u64 zT_7;
    unsigned int zT_9;
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_18;
    unsigned int zT_24;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_24, (unsigned int)sizeof zT_24);
    unsigned int val_idx;
    zT_5 = store;
    zT_6 = &store->int_values;
    zT_7 = value;
    zT_9 = zF_B73DE9D0_valuePoolAppend(zT_5, zT_6, zT_7);
    val_idx = zT_9;
    zT_10 = store;
    zT_13 = span_start;
    zT_14 = span_end;
    zT_18 = val_idx;
    zT_24 = zF_6C9FF72F_astStoreAddNode(zT_10, (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal), (unsigned char)(0), zT_13, zT_14, (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_18);
    return zT_24;
}

/* astStoreAddCharLiteral */
unsigned int zF_2CAC92AE_astStoreAddCharLite(zT_6B0A7D14_AstStore* store, zT_79FAE712_u64 value, unsigned int span_start, unsigned int span_end) {
    zT_6B0A7D14_AstStore* zT_5;
    zT_01BE9D46_AstValuePool* zT_6;
    zT_79FAE712_u64 zT_7;
    unsigned int zT_9;
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_18;
    unsigned int zT_24;
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_24, (unsigned int)sizeof zT_24);
    unsigned int val_idx;
    zT_5 = store;
    zT_6 = &store->int_values;
    zT_7 = value;
    zT_9 = zF_B73DE9D0_valuePoolAppend(zT_5, zT_6, zT_7);
    val_idx = zT_9;
    zT_10 = store;
    zT_13 = span_start;
    zT_14 = span_end;
    zT_18 = val_idx;
    zT_24 = zF_6C9FF72F_astStoreAddNode(zT_10, (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal), (unsigned char)(0), zT_13, zT_14, (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_18);
    return zT_24;
}

/* astStoreAddFloatLiteral */
unsigned int zF_0CEAF68A_astStoreAddFloatLit(zT_6B0A7D14_AstStore* store, zT_00435AEB_f64 value, unsigned int span_start, unsigned int span_end) {
    unsigned char zT_4;
    zT_C41F1B06_Arr_unsigned_char_6 zT_6;
    zT_00435AEB_f64 zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    int zT_13;
    unsigned char* zT_14;
    unsigned int zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    zT_E494E487_anon_323991 zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_00435AEB_f64** zT_35;
    unsigned int* zT_36;
    unsigned int* zT_37;
    zT_3E40CD83_Sand* zT_38;
    zT_00435AEB_f64 zT_39;
    zT_E494E487_anon_323991* zT_40;
    zT_E494E487_anon_323991* zT_42;
    zT_E494E487_anon_323991* zT_44;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_55;
    unsigned int zT_61;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zig_poison_fill((void*)&zT_61, (unsigned int)sizeof zT_61);
    zT_C41F1B06_Arr_unsigned_char_6 as0_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u as0;
    zT_8F083A69_Slice_zT_0B42B2F8_u as0s;
    zT_8F083A69_Slice_zT_0B42B2F8_u as0n;
    unsigned int val_idx;
    zT_4 = zF_F632D1ED_isMarkersEnabled();
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    {
    unsigned int _i = 0;
    while (_i < 64) {
        as0_buf[_i] = zT_6[_i];
        _i++;
    }
}
    zT_8 = value;
    zT_13 = 0;
    zT_14 = (unsigned char*)((unsigned char*)as0_buf) + zT_13;
    zT_15 = (unsigned int)(64) - zT_13;
    zT_16.ptr = (unsigned char*)zT_14;
    zT_16.len = zT_15;
    zT_9 = zT_16;
    zT_17 = 64;
    zT_19 = zF_4CAEBE7E_formatF64(zT_8, zT_9, (unsigned int)((unsigned int)zT_17));
    as0 = zT_19;
    zT_21 = "AS:";
    zT_23 = 3;
    zT_22.ptr = (unsigned char*)zT_21;
    zT_22.len = zT_23;
    as0s = zT_22;
    zT_24 = as0s;
    zF_48AC7B3A_markerWrite(zT_24);
    zT_25 = as0;
    zF_48AC7B3A_markerWrite(zT_25);
    zT_27 = "\n";
    zT_29 = 1;
    zT_28.ptr = (unsigned char*)zT_27;
    zT_28.len = zT_29;
    as0n = zT_28;
    zT_30 = as0n;
    zF_48AC7B3A_markerWrite(zT_30);
    goto z_bb_2;
    z_bb_2:
    zT_32 = store->float_values;
    zT_33 = zT_32.len;
    zT_34 = (unsigned int)zT_33;
    val_idx = zT_34;
    zT_40 = &store->float_values;
    zT_35 = &zT_40->items;
    zT_42 = &store->float_values;
    zT_36 = &zT_42->len;
    zT_44 = &store->float_values;
    zT_37 = &zT_44->capacity;
    zT_38 = store->allocator;
    zT_39 = value;
    zF_51A5BB50_f64ArrayListAppendI(zT_35, zT_36, zT_37, zT_38, zT_39);
    zT_47 = store;
    zT_50 = span_start;
    zT_51 = span_end;
    zT_55 = val_idx;
    zT_61 = zF_6C9FF72F_astStoreAddNode(zT_47, (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal), (unsigned char)(0), zT_50, zT_51, (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_55);
    return zT_61;
}

/* astStoreAddStringLiteral */
unsigned int zF_042235B9_astStoreAddStringLi(zT_6B0A7D14_AstStore* store, unsigned int string_id, unsigned int span_start, unsigned int span_end) {
    zT_5138F1F5_anon_324000 zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int** zT_8;
    unsigned int* zT_9;
    unsigned int* zT_10;
    zT_3E40CD83_Sand* zT_11;
    unsigned int zT_12;
    zT_5138F1F5_anon_324000* zT_13;
    zT_5138F1F5_anon_324000* zT_15;
    zT_5138F1F5_anon_324000* zT_17;
    zT_6B0A7D14_AstStore* zT_20;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_28;
    unsigned int zT_34;
    zig_poison_fill((void*)&zT_34, (unsigned int)sizeof zT_34);
    unsigned int sv_idx;
    zT_5 = store->string_values;
    zT_6 = zT_5.len;
    zT_7 = (unsigned int)zT_6;
    sv_idx = zT_7;
    zT_13 = &store->string_values;
    zT_8 = &zT_13->items;
    zT_15 = &store->string_values;
    zT_9 = &zT_15->len;
    zT_17 = &store->string_values;
    zT_10 = &zT_17->capacity;
    zT_11 = store->allocator;
    zT_12 = string_id;
    zF_8B163A32_u32ArrayListAppen_1(zT_8, zT_9, zT_10, zT_11, zT_12);
    zT_20 = store;
    zT_23 = span_start;
    zT_24 = span_end;
    zT_28 = sv_idx;
    zT_34 = zF_6C9FF72F_astStoreAddNode(zT_20, (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal), (unsigned char)(0), zT_23, zT_24, (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_28);
    return zT_34;
}

/* astStoreAddIdentifier */
unsigned int zF_1DF77BD4_astStoreAddIdentifi(zT_6B0A7D14_AstStore* store, zT_8143F551_AstKind kind, unsigned int string_id, unsigned int span_start, unsigned int span_end) {
    zT_6B0A7D14_AstStore* zT_6;
    zT_01BE9D46_AstValuePool* zT_7;
    unsigned int zT_11;
    zT_6B0A7D14_AstStore* zT_12;
    zT_8143F551_AstKind zT_13;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_20;
    unsigned int zT_25;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    unsigned int id_idx;
    zT_6 = store;
    zT_7 = &store->identifiers;
    zT_11 = zF_B73DE9D0_valuePoolAppend(zT_6, zT_7, (zT_79FAE712_u64)((zT_79FAE712_u64)string_id));
    id_idx = zT_11;
    zT_12 = store;
    zT_13 = kind;
    zT_15 = span_start;
    zT_16 = span_end;
    zT_20 = id_idx;
    zT_25 = zF_6C9FF72F_astStoreAddNode(zT_12, zT_13, (unsigned char)(0), zT_15, zT_16, (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_20);
    return zT_25;
}

/* astStoreAddFnProto */
unsigned int zF_F1F8D02B_astStoreAddFnProto(zT_6B0A7D14_AstStore* store, zT_243D6A41_FnProto proto) {
    zT_5838FCFA_anon_324009 zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_243D6A41_FnProto** zT_6;
    unsigned int* zT_7;
    unsigned int* zT_8;
    zT_3E40CD83_Sand* zT_9;
    zT_243D6A41_FnProto zT_10;
    zT_5838FCFA_anon_324009* zT_11;
    zT_5838FCFA_anon_324009* zT_13;
    zT_5838FCFA_anon_324009* zT_15;
    unsigned int idx;
    zT_3 = store->fn_protos;
    zT_4 = zT_3.len;
    zT_5 = (unsigned int)zT_4;
    idx = zT_5;
    zT_11 = &store->fn_protos;
    zT_6 = &zT_11->items;
    zT_13 = &store->fn_protos;
    zT_7 = &zT_13->len;
    zT_15 = &store->fn_protos;
    zT_8 = &zT_15->capacity;
    zT_9 = store->allocator;
    zT_10 = proto;
    zF_F22CE022_fnProtoArrayListApp(zT_6, zT_7, zT_8, zT_9, zT_10);
    return idx;
}

/* nodeHasExtraChildren */
unsigned char zF_A5D7FF20_nodeHasExtraChildre(zT_8143F551_AstKind kind) {
switch (kind) {
case 30: goto z_bb_1;
case 76: goto z_bb_2;
case 3: goto z_bb_3;
case 4: goto z_bb_4;
case 5: goto z_bb_5;
case 56: goto z_bb_6;
case 20: goto z_bb_7;
case 21: goto z_bb_8;
case 22: goto z_bb_9;
case 92: goto z_bb_10;
case 75: goto z_bb_11;
case 9: goto z_bb_12;
default: goto z_bb_13;
}
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    return (unsigned char)(1);
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    return (unsigned char)(1);
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    return (unsigned char)(1);
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    return (unsigned char)(1);
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    return (unsigned char)(1);
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    return (unsigned char)(1);
    z_bb_13:
    return (unsigned char)(0);
    return 0;
}

/* nodeChildIsNode */
unsigned char zF_C395F6FD_nodeChildIsNode(zT_8143F551_AstKind kind, unsigned char slot) {
    int zT_2;
    int zT_4;
    int zT_6;
    int zT_8;
switch (kind) {
case 31: goto z_bb_1;
case 75: goto z_bb_2;
case 73: goto z_bb_3;
case 3: goto z_bb_4;
case 4: goto z_bb_4;
case 5: goto z_bb_4;
default: goto z_bb_5;
}
    z_bb_1:
    zT_2 = 0;
    return (unsigned char)(slot != zT_2);
    z_bb_2:
    zT_4 = 1;
    return (unsigned char)(slot != zT_4);
    z_bb_3:
    zT_6 = 2;
    return (unsigned char)(slot != zT_6);
    z_bb_4:
    zT_8 = 0;
    return (unsigned char)(slot != zT_8);
    z_bb_5:
    return (unsigned char)(1);
    return 0;
}

/* nodeHasNodeExtraChildren */
unsigned char zF_BB9BCB30_nodeHasNodeExtraChi(zT_8143F551_AstKind kind) {
    zT_8143F551_AstKind zT_1;
    unsigned char zT_2;
    unsigned char zT_3;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zT_1 = kind;
    zT_2 = zF_A5D7FF20_nodeHasExtraChildre(zT_1);
    if (zT_2) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_3 = kind != (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 0;
    goto z_bb_3;
    z_bb_3:
    return zT_3;
}

/* visitPreOrder */
void zF_D5CCA077_visitPreOrder(zT_6B0A7D14_AstStore* store, unsigned int root, zT_EEDBD622_FP_void_zT_6B0A7D14 callback) {
    zT_894C14AF_Arr_unsigned_int_51 zT_4;
    int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned char zT_15;
    int zT_16;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned char zT_23;
    unsigned char zT_26;
    unsigned int zT_27;
    int zT_28;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    zT_22A7C88B_AstNode zT_33;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int zT_35;
    zT_8143F551_AstKind zT_36;
    unsigned char zT_38;
    unsigned char zT_39;
    zT_6B0A7D14_AstStore* zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    int zT_43;
    zT_6B0A7D14_AstStore* zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    int zT_50;
    unsigned int zT_51;
    zT_6B0A7D14_AstStore* zT_54;
    unsigned int zT_55;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned char zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned char zT_66;
    unsigned int zT_68;
    unsigned char zT_70;
    int zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    unsigned char zT_76;
    int zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned char zT_82;
    unsigned int zT_83;
    int zT_84;
    unsigned char zT_86;
    zT_8143F551_AstKind zT_87;
    unsigned char zT_91;
    unsigned int zT_92;
    unsigned char zT_94;
    int zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned char zT_100;
    unsigned int zT_101;
    int zT_102;
    unsigned char zT_104;
    zT_8143F551_AstKind zT_105;
    unsigned char zT_109;
    unsigned int zT_110;
    unsigned char zT_112;
    int zT_113;
    unsigned int zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    unsigned char zT_118;
    unsigned int zT_119;
    int zT_120;
    unsigned char zT_122;
    zT_8143F551_AstKind zT_123;
    unsigned char zT_127;
    unsigned int zT_128;
    unsigned char zT_130;
    int zT_131;
    unsigned int zT_132;
    unsigned int zT_133;
    unsigned int zT_134;
    unsigned char zT_136;
    zig_poison_fill((void*)&zT_33, (unsigned int)sizeof zT_33);
    zig_poison_fill((void*)&zT_38, (unsigned int)sizeof zT_38);
    zig_poison_fill((void*)&zT_42, (unsigned int)sizeof zT_42);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zig_poison_fill((void*)&zT_68, (unsigned int)sizeof zT_68);
    zig_poison_fill((void*)&zT_91, (unsigned int)sizeof zT_91);
    zig_poison_fill((void*)&zT_109, (unsigned int)sizeof zT_109);
    zig_poison_fill((void*)&zT_127, (unsigned int)sizeof zT_127);
    zT_894C14AF_Arr_unsigned_int_51 stack;
    unsigned int sp;
    unsigned int node_idx;
    zT_22A7C88B_AstNode node;
    unsigned int ec_count;
    unsigned int ei;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        stack[_i] = zT_4[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned int)zT_6;
    sp = zT_7;
    zT_9 = sp < (unsigned int)(512);
    if (!(zT_9)) { pal_trap(); }
    stack[sp] = root;
    zT_10 = 1;
    zT_11 = (unsigned int)zT_10;
    zT_12 = zig_wrap_add_u(((zu64)(sp)), ((zu64)(zT_11)), 32u);
    zT_13 = zig_overflow_flag_add_u(((zu64)(sp)), ((zu64)(zT_11)), 32u);
    zT_15 = zT_13 == (unsigned int)(0);
    if (!(zT_15)) { pal_trap(); }
    sp = zT_12;
    goto z_bb_1;
    z_bb_1:
    zT_16 = 0;
    if ((unsigned char)(sp > (unsigned int)zT_16)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_18 = 1;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zig_wrap_sub_u(((zu64)(sp)), ((zu64)(zT_19)), 32u);
    zT_21 = zig_overflow_flag_sub_u(((zu64)(sp)), ((zu64)(zT_19)), 32u);
    zT_23 = zT_21 == (unsigned int)(0);
    if (!(zT_23)) { pal_trap(); }
    sp = zT_20;
    zT_26 = sp < (unsigned int)(512);
    if (!(zT_26)) { pal_trap(); }
    zT_27 = stack[sp];
    node_idx = zT_27;
    zT_28 = 0;
    if ((unsigned char)(node_idx == (unsigned int)zT_28)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_31 = store;
    zT_32 = node_idx;
    zT_33 = zF_FCDD1D35_astStoreNodeAt(zT_31, zT_32);
    node = zT_33;
    zT_34 = store;
    zT_35 = node_idx;
    callback(zT_34, zT_35);
    zT_36 = node.kind;
    zT_38 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_36);
    if (zT_38) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_40 = store;
    zT_41 = node_idx;
    zT_42 = zF_8BA26B9E_astStoreNodePayload(zT_40, zT_41);
    zT_43 = 0;
    zT_39 = zT_42 != (unsigned int)zT_43;
    goto z_bb_9;
    z_bb_8:
    zT_39 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_39) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_46 = store;
    zT_47 = node_idx;
    zT_48 = zF_152E19CB_astStoreNodeExtraCh(zT_46, zT_47);
    ec_count = zT_48;
    zT_50 = 0;
    zT_51 = (unsigned int)zT_50;
    ei = zT_51;
    goto z_bb_12;
    z_bb_11:
    zT_83 = node.child_2;
    zT_84 = 0;
    if ((unsigned char)(zT_83 != (unsigned int)zT_84)) goto z_bb_16; else goto z_bb_17;
    z_bb_12:
    if ((unsigned char)(ei < (unsigned int)((unsigned int)ec_count))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_54 = store;
    zT_55 = node_idx;
    zT_57 = (unsigned int)ei;
    zT_58 = zig_wrap_sub_u(((zu64)(ec_count)), ((zu64)(zT_57)), 32u);
    zT_59 = zig_overflow_flag_sub_u(((zu64)(ec_count)), ((zu64)(zT_57)), 32u);
    zT_61 = zT_59 == (unsigned int)(0);
    if (!(zT_61)) { pal_trap(); }
    zT_62 = 1;
    zT_63 = zig_wrap_sub_u(((zu64)(zT_58)), ((zu64)(zT_62)), 32u);
    zT_64 = zig_overflow_flag_sub_u(((zu64)(zT_58)), ((zu64)(zT_62)), 32u);
    zT_66 = zT_64 == (unsigned int)(0);
    if (!(zT_66)) { pal_trap(); }
    zT_68 = zF_B10B1BC1_astStoreNodeExtraCh(zT_54, zT_55, (unsigned int)((unsigned int)zT_63));
    zT_70 = sp < (unsigned int)(512);
    if (!(zT_70)) { pal_trap(); }
    stack[sp] = zT_68;
    zT_71 = 1;
    zT_72 = (unsigned int)zT_71;
    zT_73 = zig_wrap_add_u(((zu64)(sp)), ((zu64)(zT_72)), 32u);
    zT_74 = zig_overflow_flag_add_u(((zu64)(sp)), ((zu64)(zT_72)), 32u);
    zT_76 = zT_74 == (unsigned int)(0);
    if (!(zT_76)) { pal_trap(); }
    sp = zT_73;
    zT_77 = 1;
    zT_78 = (unsigned int)zT_77;
    zT_79 = zig_wrap_add_u(((zu64)(ei)), ((zu64)(zT_78)), 32u);
    zT_80 = zig_overflow_flag_add_u(((zu64)(ei)), ((zu64)(zT_78)), 32u);
    zT_82 = zT_80 == (unsigned int)(0);
    if (!(zT_82)) { pal_trap(); }
    ei = zT_79;
    goto z_bb_15;
    z_bb_14:
    goto z_bb_11;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_87 = node.kind;
    zT_91 = zF_C395F6FD_nodeChildIsNode(zT_87, (unsigned char)(2));
    zT_86 = zT_91;
    goto z_bb_18;
    z_bb_17:
    zT_86 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_86) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_92 = node.child_2;
    zT_94 = sp < (unsigned int)(512);
    if (!(zT_94)) { pal_trap(); }
    stack[sp] = zT_92;
    zT_95 = 1;
    zT_96 = (unsigned int)zT_95;
    zT_97 = zig_wrap_add_u(((zu64)(sp)), ((zu64)(zT_96)), 32u);
    zT_98 = zig_overflow_flag_add_u(((zu64)(sp)), ((zu64)(zT_96)), 32u);
    zT_100 = zT_98 == (unsigned int)(0);
    if (!(zT_100)) { pal_trap(); }
    sp = zT_97;
    goto z_bb_20;
    z_bb_20:
    zT_101 = node.child_1;
    zT_102 = 0;
    if ((unsigned char)(zT_101 != (unsigned int)zT_102)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_105 = node.kind;
    zT_109 = zF_C395F6FD_nodeChildIsNode(zT_105, (unsigned char)(1));
    zT_104 = zT_109;
    goto z_bb_23;
    z_bb_22:
    zT_104 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_104) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_110 = node.child_1;
    zT_112 = sp < (unsigned int)(512);
    if (!(zT_112)) { pal_trap(); }
    stack[sp] = zT_110;
    zT_113 = 1;
    zT_114 = (unsigned int)zT_113;
    zT_115 = zig_wrap_add_u(((zu64)(sp)), ((zu64)(zT_114)), 32u);
    zT_116 = zig_overflow_flag_add_u(((zu64)(sp)), ((zu64)(zT_114)), 32u);
    zT_118 = zT_116 == (unsigned int)(0);
    if (!(zT_118)) { pal_trap(); }
    sp = zT_115;
    goto z_bb_25;
    z_bb_25:
    zT_119 = node.child_0;
    zT_120 = 0;
    if ((unsigned char)(zT_119 != (unsigned int)zT_120)) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_123 = node.kind;
    zT_127 = zF_C395F6FD_nodeChildIsNode(zT_123, (unsigned char)(0));
    zT_122 = zT_127;
    goto z_bb_28;
    z_bb_27:
    zT_122 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_122) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_128 = node.child_0;
    zT_130 = sp < (unsigned int)(512);
    if (!(zT_130)) { pal_trap(); }
    stack[sp] = zT_128;
    zT_131 = 1;
    zT_132 = (unsigned int)zT_131;
    zT_133 = zig_wrap_add_u(((zu64)(sp)), ((zu64)(zT_132)), 32u);
    zT_134 = zig_overflow_flag_add_u(((zu64)(sp)), ((zu64)(zT_132)), 32u);
    zT_136 = zT_134 == (unsigned int)(0);
    if (!(zT_136)) { pal_trap(); }
    sp = zT_133;
    goto z_bb_30;
    z_bb_30:
    goto z_bb_4;
}

/* astStoreComputeMemory */
zT_79FAE712_u64 zF_65495966_astStoreComputeMemo(zT_6B0A7D14_AstStore* store) {
    int zT_2;
    zT_79FAE712_u64 zT_3;
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    zT_DA3E46CE_anon_324027 zT_10;
    unsigned int zT_11;
    zT_DA3E46CE_anon_324027 zT_13;
    zT_E2FE8472_NodeBlockInfo* zT_14;
    zT_E2FE8472_NodeBlockInfo zT_15;
    unsigned char zT_16;
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_30;
    zT_79FAE712_u64 zT_31;
    zT_79FAE712_u64 zT_32;
    zT_79FAE712_u64 zT_33;
    unsigned int zT_34;
    unsigned char zT_36;
    zT_79FAE712_u64 zT_37;
    unsigned int zT_38;
    unsigned char zT_40;
    zT_DA3E46CE_anon_324027 zT_41;
    unsigned int zT_42;
    zT_79FAE712_u64 zT_43;
    unsigned int zT_44;
    zT_79FAE712_u64 zT_45;
    unsigned int zT_46;
    unsigned char zT_48;
    zT_79FAE712_u64 zT_49;
    unsigned int zT_50;
    unsigned char zT_52;
    zT_E494E487_anon_323991 zT_53;
    unsigned int zT_54;
    zT_79FAE712_u64 zT_55;
    unsigned int zT_56;
    zT_79FAE712_u64 zT_57;
    unsigned int zT_58;
    unsigned char zT_60;
    zT_79FAE712_u64 zT_61;
    unsigned int zT_62;
    unsigned char zT_64;
    zT_5138F1F5_anon_324000 zT_65;
    unsigned int zT_66;
    zT_79FAE712_u64 zT_67;
    unsigned int zT_68;
    zT_79FAE712_u64 zT_69;
    unsigned int zT_70;
    unsigned char zT_72;
    zT_79FAE712_u64 zT_73;
    unsigned int zT_74;
    unsigned char zT_76;
    zT_5838FCFA_anon_324009 zT_77;
    unsigned int zT_78;
    zT_79FAE712_u64 zT_79;
    unsigned int zT_80;
    zT_79FAE712_u64 zT_81;
    unsigned int zT_82;
    unsigned char zT_84;
    zT_79FAE712_u64 zT_85;
    unsigned int zT_86;
    unsigned char zT_88;
    zT_6B0A7D14_AstStore* zT_89;
    zT_01BE9D46_AstValuePool* zT_90;
    zT_79FAE712_u64 zT_92;
    zT_79FAE712_u64 zT_93;
    unsigned int zT_94;
    unsigned char zT_96;
    zT_6B0A7D14_AstStore* zT_97;
    zT_01BE9D46_AstValuePool* zT_98;
    zT_79FAE712_u64 zT_100;
    zT_79FAE712_u64 zT_101;
    unsigned int zT_102;
    unsigned char zT_104;
    zT_6B0A7D14_AstStore* zT_105;
    zT_01BE9D46_AstValuePool* zT_106;
    zT_79FAE712_u64 zT_108;
    zT_79FAE712_u64 zT_109;
    unsigned int zT_110;
    unsigned char zT_112;
    zT_6B0A7D14_AstStore* zT_113;
    zT_01BE9D46_AstValuePool* zT_114;
    zT_79FAE712_u64 zT_116;
    zT_79FAE712_u64 zT_117;
    unsigned int zT_118;
    unsigned char zT_120;
    zig_poison_fill((void*)&zT_92, (unsigned int)sizeof zT_92);
    zig_poison_fill((void*)&zT_100, (unsigned int)sizeof zT_100);
    zig_poison_fill((void*)&zT_108, (unsigned int)sizeof zT_108);
    zig_poison_fill((void*)&zT_116, (unsigned int)sizeof zT_116);
    zT_79FAE712_u64 total;
    unsigned int resident_blocks;
    unsigned int bi;
    zT_2 = 0;
    zT_3 = (zT_79FAE712_u64)zT_2;
    total = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    resident_blocks = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    bi = zT_9;
    goto z_bb_1;
    z_bb_1:
    zT_10 = store->block_table;
    zT_11 = zT_10.len;
    if ((unsigned char)(bi < zT_11)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_13 = store->block_table;
    zT_14 = zT_13.items;
    zT_15 = zT_14[bi];
    zT_16 = zT_15.resident;
    if ((unsigned char)(zT_16 != (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_31 = (zT_79FAE712_u64)resident_blocks;
    zT_32 = 114688;
    zT_33 = zig_wrap_mul_u(((zu64)(zT_31)), ((zu64)(zT_32)), 64u);
    zT_34 = zig_overflow_flag_mul_u(((zu64)(zT_31)), ((zu64)(zT_32)), 64u);
    zT_36 = zT_34 == (unsigned int)(0);
    if (!(zT_36)) { pal_trap(); }
    zT_37 = zig_wrap_add_u(((zu64)(total)), ((zu64)(zT_33)), 64u);
    zT_38 = zig_overflow_flag_add_u(((zu64)(total)), ((zu64)(zT_33)), 64u);
    zT_40 = zT_38 == (unsigned int)(0);
    if (!(zT_40)) { pal_trap(); }
    total = zT_37;
    zT_41 = store->block_table;
    zT_42 = zT_41.len;
    zT_43 = (zT_79FAE712_u64)zT_42;
    zT_44 = 12;
    zT_45 = zig_wrap_mul_u(((zu64)(zT_43)), ((zu64)(zT_44)), 64u);
    zT_46 = zig_overflow_flag_mul_u(((zu64)(zT_43)), ((zu64)(zT_44)), 64u);
    zT_48 = zT_46 == (unsigned int)(0);
    if (!(zT_48)) { pal_trap(); }
    zT_49 = zig_wrap_add_u(((zu64)(total)), ((zu64)(zT_45)), 64u);
    zT_50 = zig_overflow_flag_add_u(((zu64)(total)), ((zu64)(zT_45)), 64u);
    zT_52 = zT_50 == (unsigned int)(0);
    if (!(zT_52)) { pal_trap(); }
    total = zT_49;
    zT_53 = store->float_values;
    zT_54 = zT_53.len;
    zT_55 = (zT_79FAE712_u64)zT_54;
    zT_56 = 8;
    zT_57 = zig_wrap_mul_u(((zu64)(zT_55)), ((zu64)(zT_56)), 64u);
    zT_58 = zig_overflow_flag_mul_u(((zu64)(zT_55)), ((zu64)(zT_56)), 64u);
    zT_60 = zT_58 == (unsigned int)(0);
    if (!(zT_60)) { pal_trap(); }
    zT_61 = zig_wrap_add_u(((zu64)(total)), ((zu64)(zT_57)), 64u);
    zT_62 = zig_overflow_flag_add_u(((zu64)(total)), ((zu64)(zT_57)), 64u);
    zT_64 = zT_62 == (unsigned int)(0);
    if (!(zT_64)) { pal_trap(); }
    total = zT_61;
    zT_65 = store->string_values;
    zT_66 = zT_65.len;
    zT_67 = (zT_79FAE712_u64)zT_66;
    zT_68 = 4;
    zT_69 = zig_wrap_mul_u(((zu64)(zT_67)), ((zu64)(zT_68)), 64u);
    zT_70 = zig_overflow_flag_mul_u(((zu64)(zT_67)), ((zu64)(zT_68)), 64u);
    zT_72 = zT_70 == (unsigned int)(0);
    if (!(zT_72)) { pal_trap(); }
    zT_73 = zig_wrap_add_u(((zu64)(total)), ((zu64)(zT_69)), 64u);
    zT_74 = zig_overflow_flag_add_u(((zu64)(total)), ((zu64)(zT_69)), 64u);
    zT_76 = zT_74 == (unsigned int)(0);
    if (!(zT_76)) { pal_trap(); }
    total = zT_73;
    zT_77 = store->fn_protos;
    zT_78 = zT_77.len;
    zT_79 = (zT_79FAE712_u64)zT_78;
    zT_80 = 16;
    zT_81 = zig_wrap_mul_u(((zu64)(zT_79)), ((zu64)(zT_80)), 64u);
    zT_82 = zig_overflow_flag_mul_u(((zu64)(zT_79)), ((zu64)(zT_80)), 64u);
    zT_84 = zT_82 == (unsigned int)(0);
    if (!(zT_84)) { pal_trap(); }
    zT_85 = zig_wrap_add_u(((zu64)(total)), ((zu64)(zT_81)), 64u);
    zT_86 = zig_overflow_flag_add_u(((zu64)(total)), ((zu64)(zT_81)), 64u);
    zT_88 = zT_86 == (unsigned int)(0);
    if (!(zT_88)) { pal_trap(); }
    total = zT_85;
    zT_89 = store;
    zT_90 = &store->extra_children;
    zT_92 = zF_27FFD5B8_valuePoolResident(zT_89, zT_90);
    zT_93 = zig_wrap_add_u(((zu64)(total)), ((zu64)(zT_92)), 64u);
    zT_94 = zig_overflow_flag_add_u(((zu64)(total)), ((zu64)(zT_92)), 64u);
    zT_96 = zT_94 == (unsigned int)(0);
    if (!(zT_96)) { pal_trap(); }
    total = zT_93;
    zT_97 = store;
    zT_98 = &store->extra_ranges;
    zT_100 = zF_27FFD5B8_valuePoolResident(zT_97, zT_98);
    zT_101 = zig_wrap_add_u(((zu64)(total)), ((zu64)(zT_100)), 64u);
    zT_102 = zig_overflow_flag_add_u(((zu64)(total)), ((zu64)(zT_100)), 64u);
    zT_104 = zT_102 == (unsigned int)(0);
    if (!(zT_104)) { pal_trap(); }
    total = zT_101;
    zT_105 = store;
    zT_106 = &store->identifiers;
    zT_108 = zF_27FFD5B8_valuePoolResident(zT_105, zT_106);
    zT_109 = zig_wrap_add_u(((zu64)(total)), ((zu64)(zT_108)), 64u);
    zT_110 = zig_overflow_flag_add_u(((zu64)(total)), ((zu64)(zT_108)), 64u);
    zT_112 = zT_110 == (unsigned int)(0);
    if (!(zT_112)) { pal_trap(); }
    total = zT_109;
    zT_113 = store;
    zT_114 = &store->int_values;
    zT_116 = zF_27FFD5B8_valuePoolResident(zT_113, zT_114);
    zT_117 = zig_wrap_add_u(((zu64)(total)), ((zu64)(zT_116)), 64u);
    zT_118 = zig_overflow_flag_add_u(((zu64)(total)), ((zu64)(zT_116)), 64u);
    zT_120 = zT_118 == (unsigned int)(0);
    if (!(zT_120)) { pal_trap(); }
    total = zT_117;
    return total;
    z_bb_4:
    zT_25 = 1;
    zT_26 = (unsigned int)zT_25;
    zT_27 = zig_wrap_add_u(((zu64)(bi)), ((zu64)(zT_26)), 32u);
    zT_28 = zig_overflow_flag_add_u(((zu64)(bi)), ((zu64)(zT_26)), 32u);
    zT_30 = zT_28 == (unsigned int)(0);
    if (!(zT_30)) { pal_trap(); }
    bi = zT_27;
    goto z_bb_1;
    z_bb_5:
    zT_19 = 1;
    zT_20 = (unsigned int)zT_19;
    zT_21 = zig_wrap_add_u(((zu64)(resident_blocks)), ((zu64)(zT_20)), 32u);
    zT_22 = zig_overflow_flag_add_u(((zu64)(resident_blocks)), ((zu64)(zT_20)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    resident_blocks = zT_21;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* valuePoolResident */
zT_79FAE712_u64 zF_27FFD5B8_valuePoolResident(zT_6B0A7D14_AstStore* store, zT_01BE9D46_AstValuePool* p) {
    int zT_3;
    zT_79FAE712_u64 zT_4;
    unsigned int zT_5;
    zT_79FAE712_u64 zT_8;
    zT_79FAE712_u64 zT_9;
    unsigned int zT_10;
    unsigned char zT_12;
    unsigned char zT_13;
    zT_79FAE712_u64 zT_16;
    zT_79FAE712_u64 zT_17;
    zT_79FAE712_u64 zT_18;
    unsigned int zT_19;
    unsigned char zT_21;
    zT_79FAE712_u64 zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    zT_79FAE712_u64 sum;
    (void)store;
    zT_3 = 0;
    zT_4 = (zT_79FAE712_u64)zT_3;
    sum = zT_4;
    zT_5 = p->head_cap;
    if ((unsigned char)(zT_5 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = 4096;
    zT_9 = zig_wrap_add_u(((zu64)(sum)), ((zu64)(zT_8)), 64u);
    zT_10 = zig_overflow_flag_add_u(((zu64)(sum)), ((zu64)(zT_8)), 64u);
    zT_12 = zT_10 == (unsigned int)(0);
    if (!(zT_12)) { pal_trap(); }
    sum = zT_9;
    goto z_bb_2;
    z_bb_2:
    zT_13 = p->cache_allocated;
    if ((unsigned char)(zT_13 != (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = 8;
    zT_17 = 4096;
    zT_18 = zig_wrap_mul_u(((zu64)(zT_16)), ((zu64)(zT_17)), 64u);
    zT_19 = zig_overflow_flag_mul_u(((zu64)(zT_16)), ((zu64)(zT_17)), 64u);
    zT_21 = zT_19 == (unsigned int)(0);
    if (!(zT_21)) { pal_trap(); }
    zT_22 = zig_wrap_add_u(((zu64)(sum)), ((zu64)(zT_18)), 64u);
    zT_23 = zig_overflow_flag_add_u(((zu64)(sum)), ((zu64)(zT_18)), 64u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    sum = zT_22;
    goto z_bb_4;
    z_bb_4:
    return sum;
}

/* EOF */
