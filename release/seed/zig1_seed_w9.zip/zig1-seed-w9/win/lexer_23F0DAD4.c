#include "lexer_23F0DAD4.h"
#include <stdio.h>
zT_138FFB41_Lexer zG_138FFB41_Lexer;
/* lexerInit */
zT_138FFB41_Lexer zF_151E643F_lexerInit(zT_8F083A69_Slice_zT_0B42B2F8_u source, unsigned int file_id, zT_D3EB6303_StringInterner* interner, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* alloc) {
    zT_3E40CD83_Sand* zT_6;
    zT_81AD2998_EU_952 zT_11;
    unsigned char zT_12;
    unsigned char* zT_13;
    zT_47B162D1_U8ArrayList* zT_16;
    zT_3E40CD83_Sand* zT_17;
    zT_47B162D1_U8ArrayList zT_18;
    zT_138FFB41_Lexer zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    unsigned char* sb_raw;
    zT_47B162D1_U8ArrayList* sb_ptr;
    zT_6 = alloc;
    zT_11 = zF_1395EB68_sandAlloc(zT_6, (unsigned int)(16), (unsigned int)(4));
    zT_12 = zT_11.is_error;
    if (zT_12) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_13 = zT_11.data.payload;
    goto z_bb_3;
    z_bb_3:
    sb_raw = zT_13;
    zT_16 = (zT_47B162D1_U8ArrayList*)sb_raw;
    sb_ptr = zT_16;
    zT_17 = alloc;
    zT_18 = zF_E9FF0E66_byteArrayListInit(zT_17);
    *sb_ptr = zT_18;
    zT_19.source = source;
    zT_20 = 0;
    zT_19.pos = zT_20;
    zT_21 = 1;
    zT_19.line = zT_21;
    zT_22 = 1;
    zT_19.col = zT_22;
    zT_19.file_id = file_id;
    zT_19.interner = interner;
    zT_19.diag = diag;
    zT_19.string_buf = sb_ptr;
    zT_23 = 0;
    zT_19.count_only = zT_23;
    return zT_19;
}

/* lexerNextToken */
zT_3A355BD2_Token zF_B976BEC9_lexerNextToken(zT_138FFB41_Lexer* self) {
    zT_138FFB41_Lexer* zT_1;
    zT_138FFB41_Lexer* zT_2;
    unsigned char zT_3;
    zT_138FFB41_Lexer* zT_4;
    unsigned int zT_6;
    zT_85CBA4DB_TokenValue zT_7;
    zT_85CBA4DB_TokenValue zT_11;
    zT_3A355BD2_Token zT_13;
    unsigned int zT_15;
    zT_138FFB41_Lexer* zT_17;
    unsigned char zT_18;
    zT_138FFB41_Lexer* zT_19;
    unsigned int zT_21;
    zT_85CBA4DB_TokenValue zT_22;
    zT_85CBA4DB_TokenValue zT_25;
    zT_3A355BD2_Token zT_27;
    zT_138FFB41_Lexer* zT_28;
    unsigned int zT_30;
    zT_85CBA4DB_TokenValue zT_31;
    zT_85CBA4DB_TokenValue zT_34;
    zT_3A355BD2_Token zT_36;
    zT_138FFB41_Lexer* zT_37;
    unsigned int zT_39;
    zT_85CBA4DB_TokenValue zT_40;
    zT_85CBA4DB_TokenValue zT_43;
    zT_3A355BD2_Token zT_45;
    zT_138FFB41_Lexer* zT_46;
    unsigned int zT_48;
    zT_85CBA4DB_TokenValue zT_49;
    zT_85CBA4DB_TokenValue zT_52;
    zT_3A355BD2_Token zT_54;
    zT_138FFB41_Lexer* zT_55;
    unsigned int zT_57;
    zT_85CBA4DB_TokenValue zT_58;
    zT_85CBA4DB_TokenValue zT_61;
    zT_3A355BD2_Token zT_63;
    zT_138FFB41_Lexer* zT_64;
    unsigned int zT_66;
    zT_85CBA4DB_TokenValue zT_67;
    zT_85CBA4DB_TokenValue zT_70;
    zT_3A355BD2_Token zT_72;
    zT_138FFB41_Lexer* zT_73;
    unsigned int zT_75;
    zT_85CBA4DB_TokenValue zT_76;
    zT_85CBA4DB_TokenValue zT_79;
    zT_3A355BD2_Token zT_81;
    zT_138FFB41_Lexer* zT_82;
    unsigned int zT_84;
    zT_85CBA4DB_TokenValue zT_85;
    zT_85CBA4DB_TokenValue zT_88;
    zT_3A355BD2_Token zT_90;
    zT_138FFB41_Lexer* zT_91;
    unsigned int zT_93;
    zT_85CBA4DB_TokenValue zT_94;
    zT_85CBA4DB_TokenValue zT_97;
    zT_3A355BD2_Token zT_99;
    zT_138FFB41_Lexer* zT_100;
    unsigned char zT_103;
    zT_138FFB41_Lexer* zT_104;
    unsigned char zT_107;
    zT_138FFB41_Lexer* zT_108;
    unsigned int zT_110;
    zT_85CBA4DB_TokenValue zT_111;
    zT_85CBA4DB_TokenValue zT_114;
    zT_3A355BD2_Token zT_116;
    zT_138FFB41_Lexer* zT_117;
    unsigned int zT_119;
    zT_85CBA4DB_TokenValue zT_120;
    zT_85CBA4DB_TokenValue zT_123;
    zT_3A355BD2_Token zT_125;
    zT_138FFB41_Lexer* zT_126;
    unsigned char zT_129;
    zT_138FFB41_Lexer* zT_130;
    unsigned int zT_132;
    zT_85CBA4DB_TokenValue zT_133;
    zT_85CBA4DB_TokenValue zT_136;
    zT_3A355BD2_Token zT_138;
    zT_138FFB41_Lexer* zT_139;
    unsigned char zT_142;
    zT_138FFB41_Lexer* zT_143;
    unsigned int zT_145;
    zT_85CBA4DB_TokenValue zT_146;
    zT_85CBA4DB_TokenValue zT_149;
    zT_3A355BD2_Token zT_151;
    zT_138FFB41_Lexer* zT_152;
    unsigned int zT_154;
    zT_85CBA4DB_TokenValue zT_155;
    zT_85CBA4DB_TokenValue zT_158;
    zT_3A355BD2_Token zT_160;
    zT_138FFB41_Lexer* zT_161;
    unsigned char zT_164;
    zT_138FFB41_Lexer* zT_165;
    unsigned char zT_168;
    zT_138FFB41_Lexer* zT_169;
    unsigned int zT_171;
    zT_85CBA4DB_TokenValue zT_172;
    zT_85CBA4DB_TokenValue zT_175;
    zT_3A355BD2_Token zT_177;
    zT_138FFB41_Lexer* zT_178;
    unsigned int zT_180;
    zT_85CBA4DB_TokenValue zT_181;
    zT_85CBA4DB_TokenValue zT_184;
    zT_3A355BD2_Token zT_186;
    zT_138FFB41_Lexer* zT_187;
    unsigned char zT_190;
    zT_138FFB41_Lexer* zT_191;
    unsigned char zT_194;
    zT_138FFB41_Lexer* zT_195;
    unsigned int zT_197;
    zT_85CBA4DB_TokenValue zT_198;
    zT_85CBA4DB_TokenValue zT_201;
    zT_3A355BD2_Token zT_203;
    zT_138FFB41_Lexer* zT_204;
    unsigned int zT_206;
    zT_85CBA4DB_TokenValue zT_207;
    zT_85CBA4DB_TokenValue zT_210;
    zT_3A355BD2_Token zT_212;
    zT_138FFB41_Lexer* zT_213;
    unsigned char zT_216;
    zT_138FFB41_Lexer* zT_217;
    unsigned int zT_219;
    zT_85CBA4DB_TokenValue zT_220;
    zT_85CBA4DB_TokenValue zT_223;
    zT_3A355BD2_Token zT_225;
    zT_138FFB41_Lexer* zT_226;
    unsigned int zT_228;
    zT_85CBA4DB_TokenValue zT_229;
    zT_85CBA4DB_TokenValue zT_232;
    zT_3A355BD2_Token zT_234;
    zT_138FFB41_Lexer* zT_235;
    unsigned char zT_238;
    zT_138FFB41_Lexer* zT_239;
    unsigned char zT_242;
    zT_138FFB41_Lexer* zT_243;
    unsigned int zT_245;
    zT_85CBA4DB_TokenValue zT_246;
    zT_85CBA4DB_TokenValue zT_249;
    zT_3A355BD2_Token zT_251;
    zT_138FFB41_Lexer* zT_252;
    unsigned int zT_254;
    zT_85CBA4DB_TokenValue zT_255;
    zT_85CBA4DB_TokenValue zT_258;
    zT_3A355BD2_Token zT_260;
    zT_138FFB41_Lexer* zT_261;
    unsigned char zT_264;
    zT_138FFB41_Lexer* zT_265;
    unsigned char zT_268;
    zT_138FFB41_Lexer* zT_269;
    unsigned int zT_271;
    zT_85CBA4DB_TokenValue zT_272;
    zT_85CBA4DB_TokenValue zT_275;
    zT_3A355BD2_Token zT_277;
    zT_138FFB41_Lexer* zT_278;
    unsigned int zT_280;
    zT_85CBA4DB_TokenValue zT_281;
    zT_85CBA4DB_TokenValue zT_284;
    zT_3A355BD2_Token zT_286;
    zT_138FFB41_Lexer* zT_287;
    unsigned char zT_290;
    zT_138FFB41_Lexer* zT_291;
    unsigned int zT_293;
    zT_85CBA4DB_TokenValue zT_294;
    zT_85CBA4DB_TokenValue zT_297;
    zT_3A355BD2_Token zT_299;
    zT_138FFB41_Lexer* zT_300;
    unsigned int zT_302;
    zT_85CBA4DB_TokenValue zT_303;
    zT_85CBA4DB_TokenValue zT_306;
    zT_3A355BD2_Token zT_308;
    zT_138FFB41_Lexer* zT_309;
    unsigned char zT_312;
    zT_138FFB41_Lexer* zT_313;
    unsigned char zT_316;
    zT_138FFB41_Lexer* zT_317;
    unsigned int zT_319;
    zT_85CBA4DB_TokenValue zT_320;
    zT_85CBA4DB_TokenValue zT_323;
    zT_3A355BD2_Token zT_325;
    zT_138FFB41_Lexer* zT_326;
    unsigned int zT_328;
    zT_85CBA4DB_TokenValue zT_329;
    zT_85CBA4DB_TokenValue zT_332;
    zT_3A355BD2_Token zT_334;
    zT_138FFB41_Lexer* zT_335;
    unsigned char zT_338;
    zT_138FFB41_Lexer* zT_339;
    unsigned char zT_342;
    zT_138FFB41_Lexer* zT_343;
    unsigned int zT_345;
    zT_85CBA4DB_TokenValue zT_346;
    zT_85CBA4DB_TokenValue zT_349;
    zT_3A355BD2_Token zT_351;
    zT_138FFB41_Lexer* zT_352;
    unsigned int zT_354;
    zT_85CBA4DB_TokenValue zT_355;
    zT_85CBA4DB_TokenValue zT_358;
    zT_3A355BD2_Token zT_360;
    zT_138FFB41_Lexer* zT_361;
    unsigned char zT_364;
    zT_138FFB41_Lexer* zT_365;
    unsigned int zT_367;
    zT_85CBA4DB_TokenValue zT_368;
    zT_85CBA4DB_TokenValue zT_371;
    zT_3A355BD2_Token zT_373;
    zT_138FFB41_Lexer* zT_374;
    unsigned int zT_376;
    zT_85CBA4DB_TokenValue zT_377;
    zT_85CBA4DB_TokenValue zT_380;
    zT_3A355BD2_Token zT_382;
    zT_138FFB41_Lexer* zT_383;
    unsigned char zT_386;
    zT_138FFB41_Lexer* zT_387;
    unsigned int zT_389;
    zT_85CBA4DB_TokenValue zT_390;
    zT_85CBA4DB_TokenValue zT_393;
    zT_3A355BD2_Token zT_395;
    zT_138FFB41_Lexer* zT_396;
    unsigned int zT_398;
    zT_85CBA4DB_TokenValue zT_399;
    zT_85CBA4DB_TokenValue zT_402;
    zT_3A355BD2_Token zT_404;
    zT_138FFB41_Lexer* zT_405;
    unsigned char zT_408;
    zT_138FFB41_Lexer* zT_409;
    unsigned int zT_411;
    zT_85CBA4DB_TokenValue zT_412;
    zT_85CBA4DB_TokenValue zT_415;
    zT_3A355BD2_Token zT_417;
    zT_138FFB41_Lexer* zT_418;
    unsigned int zT_420;
    zT_85CBA4DB_TokenValue zT_421;
    zT_85CBA4DB_TokenValue zT_424;
    zT_3A355BD2_Token zT_426;
    zT_138FFB41_Lexer* zT_427;
    unsigned char zT_430;
    zT_138FFB41_Lexer* zT_431;
    unsigned int zT_433;
    zT_85CBA4DB_TokenValue zT_434;
    zT_85CBA4DB_TokenValue zT_437;
    zT_3A355BD2_Token zT_439;
    zT_138FFB41_Lexer* zT_440;
    unsigned int zT_442;
    zT_85CBA4DB_TokenValue zT_443;
    zT_85CBA4DB_TokenValue zT_446;
    zT_3A355BD2_Token zT_448;
    zT_138FFB41_Lexer* zT_449;
    unsigned char zT_452;
    zT_138FFB41_Lexer* zT_453;
    unsigned int zT_455;
    zT_85CBA4DB_TokenValue zT_456;
    zT_85CBA4DB_TokenValue zT_459;
    zT_3A355BD2_Token zT_461;
    zT_138FFB41_Lexer* zT_462;
    unsigned int zT_464;
    zT_85CBA4DB_TokenValue zT_465;
    zT_85CBA4DB_TokenValue zT_468;
    zT_3A355BD2_Token zT_470;
    zT_138FFB41_Lexer* zT_471;
    unsigned char zT_474;
    zT_138FFB41_Lexer* zT_475;
    unsigned int zT_477;
    zT_85CBA4DB_TokenValue zT_478;
    zT_85CBA4DB_TokenValue zT_481;
    zT_3A355BD2_Token zT_483;
    zT_138FFB41_Lexer* zT_484;
    unsigned char zT_487;
    zT_138FFB41_Lexer* zT_488;
    unsigned int zT_490;
    zT_85CBA4DB_TokenValue zT_491;
    zT_85CBA4DB_TokenValue zT_494;
    zT_3A355BD2_Token zT_496;
    zT_138FFB41_Lexer* zT_497;
    unsigned int zT_499;
    zT_85CBA4DB_TokenValue zT_500;
    zT_85CBA4DB_TokenValue zT_503;
    zT_3A355BD2_Token zT_505;
    zT_138FFB41_Lexer* zT_506;
    unsigned char zT_509;
    zT_138FFB41_Lexer* zT_510;
    unsigned int zT_512;
    zT_85CBA4DB_TokenValue zT_513;
    zT_85CBA4DB_TokenValue zT_516;
    zT_3A355BD2_Token zT_518;
    zT_138FFB41_Lexer* zT_519;
    unsigned int zT_521;
    zT_85CBA4DB_TokenValue zT_522;
    zT_85CBA4DB_TokenValue zT_525;
    zT_3A355BD2_Token zT_527;
    zT_138FFB41_Lexer* zT_528;
    unsigned char zT_531;
    zT_138FFB41_Lexer* zT_532;
    unsigned char zT_535;
    zT_138FFB41_Lexer* zT_536;
    unsigned char zT_539;
    zT_138FFB41_Lexer* zT_540;
    unsigned int zT_542;
    zT_85CBA4DB_TokenValue zT_543;
    zT_85CBA4DB_TokenValue zT_546;
    zT_3A355BD2_Token zT_548;
    zT_138FFB41_Lexer* zT_549;
    unsigned int zT_551;
    zT_85CBA4DB_TokenValue zT_552;
    zT_85CBA4DB_TokenValue zT_555;
    zT_3A355BD2_Token zT_557;
    zT_138FFB41_Lexer* zT_558;
    unsigned char zT_561;
    zT_138FFB41_Lexer* zT_562;
    unsigned int zT_564;
    zT_85CBA4DB_TokenValue zT_565;
    zT_85CBA4DB_TokenValue zT_568;
    zT_3A355BD2_Token zT_570;
    zT_138FFB41_Lexer* zT_571;
    unsigned int zT_573;
    zT_85CBA4DB_TokenValue zT_574;
    zT_85CBA4DB_TokenValue zT_577;
    zT_3A355BD2_Token zT_579;
    zT_138FFB41_Lexer* zT_580;
    unsigned char zT_583;
    zT_138FFB41_Lexer* zT_584;
    unsigned int zT_586;
    zT_85CBA4DB_TokenValue zT_587;
    zT_85CBA4DB_TokenValue zT_590;
    zT_3A355BD2_Token zT_592;
    zT_138FFB41_Lexer* zT_593;
    unsigned int zT_595;
    zT_85CBA4DB_TokenValue zT_596;
    zT_85CBA4DB_TokenValue zT_599;
    zT_3A355BD2_Token zT_601;
    zT_138FFB41_Lexer* zT_602;
    unsigned char zT_605;
    zT_138FFB41_Lexer* zT_606;
    unsigned char zT_609;
    zT_138FFB41_Lexer* zT_610;
    unsigned int zT_612;
    zT_85CBA4DB_TokenValue zT_613;
    zT_85CBA4DB_TokenValue zT_616;
    zT_3A355BD2_Token zT_618;
    zT_138FFB41_Lexer* zT_619;
    unsigned int zT_621;
    zT_85CBA4DB_TokenValue zT_622;
    zT_85CBA4DB_TokenValue zT_625;
    zT_3A355BD2_Token zT_627;
    zT_138FFB41_Lexer* zT_628;
    unsigned char zT_631;
    zT_138FFB41_Lexer* zT_632;
    unsigned int zT_634;
    zT_85CBA4DB_TokenValue zT_635;
    zT_85CBA4DB_TokenValue zT_638;
    zT_3A355BD2_Token zT_640;
    zT_138FFB41_Lexer* zT_641;
    unsigned int zT_643;
    zT_85CBA4DB_TokenValue zT_644;
    zT_85CBA4DB_TokenValue zT_647;
    zT_3A355BD2_Token zT_649;
    zT_138FFB41_Lexer* zT_650;
    unsigned char zT_653;
    zT_138FFB41_Lexer* zT_654;
    unsigned int zT_656;
    zT_85CBA4DB_TokenValue zT_657;
    zT_85CBA4DB_TokenValue zT_660;
    zT_3A355BD2_Token zT_662;
    zT_138FFB41_Lexer* zT_663;
    unsigned int zT_665;
    zT_85CBA4DB_TokenValue zT_666;
    zT_85CBA4DB_TokenValue zT_669;
    zT_3A355BD2_Token zT_671;
    zT_138FFB41_Lexer* zT_672;
    unsigned int zT_674;
    zT_85CBA4DB_TokenValue zT_675;
    zT_85CBA4DB_TokenValue zT_678;
    zT_3A355BD2_Token zT_680;
    zT_138FFB41_Lexer* zT_681;
    unsigned int zT_683;
    zT_85CBA4DB_TokenValue zT_684;
    zT_85CBA4DB_TokenValue zT_687;
    zT_3A355BD2_Token zT_689;
    unsigned char zT_690;
    zT_138FFB41_Lexer* zT_691;
    unsigned char zT_692;
    unsigned char zT_693;
    zT_138FFB41_Lexer* zT_694;
    unsigned int zT_695;
    zT_3A355BD2_Token zT_696;
    unsigned char* zT_698;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_699;
    unsigned int zT_700;
    unsigned char zT_701;
    zT_F85C5DED_DiagnosticCollector* zT_703;
    unsigned int zT_706;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_709;
    int zT_711;
    unsigned int zT_716;
    zT_138FFB41_Lexer* zT_719;
    unsigned int zT_720;
    zT_3A355BD2_Token zT_721;
    zT_138FFB41_Lexer* zT_722;
    unsigned int zT_723;
    zT_3A355BD2_Token zT_724;
    zT_138FFB41_Lexer* zT_725;
    unsigned int zT_726;
    zT_3A355BD2_Token zT_727;
    unsigned char zT_728;
    unsigned char zT_729;
    unsigned char zT_730;
    zT_138FFB41_Lexer* zT_733;
    unsigned int zT_734;
    zT_3A355BD2_Token zT_735;
    unsigned char zT_736;
    unsigned char zT_737;
    zT_138FFB41_Lexer* zT_738;
    unsigned int zT_739;
    unsigned char zT_740;
    zT_3A355BD2_Token zT_741;
    unsigned char zT_742;
    unsigned char* zT_745;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_746;
    unsigned int zT_747;
    zT_BBAAFAE2_Arr_unsigned_char_2 zT_749;
    int zT_750;
    unsigned char zT_752;
    unsigned char zT_753;
    int zT_754;
    unsigned char zT_756;
    unsigned char* zT_758;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_759;
    unsigned int zT_760;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_762;
    unsigned int zT_763;
    int zT_766;
    int zT_767;
    unsigned char* zT_768;
    unsigned int zT_769;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_770;
    unsigned int zT_771;
    unsigned int zT_772;
    zT_D3EB6303_StringInterner* zT_774;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_775;
    zT_F85C5DED_DiagnosticCollector* zT_777;
    int zT_779;
    unsigned char zT_781;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_782;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_784;
    zT_F85C5DED_DiagnosticCollector* zT_785;
    unsigned int zT_788;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_791;
    int zT_793;
    unsigned int zT_798;
    zT_138FFB41_Lexer* zT_801;
    unsigned int zT_802;
    zT_3A355BD2_Token zT_803;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zig_poison_fill((void*)&zT_18, (unsigned int)sizeof zT_18);
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zig_poison_fill((void*)&zT_27, (unsigned int)sizeof zT_27);
    zig_poison_fill((void*)&zT_34, (unsigned int)sizeof zT_34);
    zig_poison_fill((void*)&zT_36, (unsigned int)sizeof zT_36);
    zig_poison_fill((void*)&zT_43, (unsigned int)sizeof zT_43);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_52, (unsigned int)sizeof zT_52);
    zig_poison_fill((void*)&zT_54, (unsigned int)sizeof zT_54);
    zig_poison_fill((void*)&zT_61, (unsigned int)sizeof zT_61);
    zig_poison_fill((void*)&zT_63, (unsigned int)sizeof zT_63);
    zig_poison_fill((void*)&zT_70, (unsigned int)sizeof zT_70);
    zig_poison_fill((void*)&zT_72, (unsigned int)sizeof zT_72);
    zig_poison_fill((void*)&zT_79, (unsigned int)sizeof zT_79);
    zig_poison_fill((void*)&zT_81, (unsigned int)sizeof zT_81);
    zig_poison_fill((void*)&zT_88, (unsigned int)sizeof zT_88);
    zig_poison_fill((void*)&zT_90, (unsigned int)sizeof zT_90);
    zig_poison_fill((void*)&zT_97, (unsigned int)sizeof zT_97);
    zig_poison_fill((void*)&zT_99, (unsigned int)sizeof zT_99);
    zig_poison_fill((void*)&zT_103, (unsigned int)sizeof zT_103);
    zig_poison_fill((void*)&zT_107, (unsigned int)sizeof zT_107);
    zig_poison_fill((void*)&zT_114, (unsigned int)sizeof zT_114);
    zig_poison_fill((void*)&zT_116, (unsigned int)sizeof zT_116);
    zig_poison_fill((void*)&zT_123, (unsigned int)sizeof zT_123);
    zig_poison_fill((void*)&zT_125, (unsigned int)sizeof zT_125);
    zig_poison_fill((void*)&zT_129, (unsigned int)sizeof zT_129);
    zig_poison_fill((void*)&zT_136, (unsigned int)sizeof zT_136);
    zig_poison_fill((void*)&zT_138, (unsigned int)sizeof zT_138);
    zig_poison_fill((void*)&zT_142, (unsigned int)sizeof zT_142);
    zig_poison_fill((void*)&zT_149, (unsigned int)sizeof zT_149);
    zig_poison_fill((void*)&zT_151, (unsigned int)sizeof zT_151);
    zig_poison_fill((void*)&zT_158, (unsigned int)sizeof zT_158);
    zig_poison_fill((void*)&zT_160, (unsigned int)sizeof zT_160);
    zig_poison_fill((void*)&zT_164, (unsigned int)sizeof zT_164);
    zig_poison_fill((void*)&zT_168, (unsigned int)sizeof zT_168);
    zig_poison_fill((void*)&zT_175, (unsigned int)sizeof zT_175);
    zig_poison_fill((void*)&zT_177, (unsigned int)sizeof zT_177);
    zig_poison_fill((void*)&zT_184, (unsigned int)sizeof zT_184);
    zig_poison_fill((void*)&zT_186, (unsigned int)sizeof zT_186);
    zig_poison_fill((void*)&zT_190, (unsigned int)sizeof zT_190);
    zig_poison_fill((void*)&zT_194, (unsigned int)sizeof zT_194);
    zig_poison_fill((void*)&zT_201, (unsigned int)sizeof zT_201);
    zig_poison_fill((void*)&zT_203, (unsigned int)sizeof zT_203);
    zig_poison_fill((void*)&zT_210, (unsigned int)sizeof zT_210);
    zig_poison_fill((void*)&zT_212, (unsigned int)sizeof zT_212);
    zig_poison_fill((void*)&zT_216, (unsigned int)sizeof zT_216);
    zig_poison_fill((void*)&zT_223, (unsigned int)sizeof zT_223);
    zig_poison_fill((void*)&zT_225, (unsigned int)sizeof zT_225);
    zig_poison_fill((void*)&zT_232, (unsigned int)sizeof zT_232);
    zig_poison_fill((void*)&zT_234, (unsigned int)sizeof zT_234);
    zig_poison_fill((void*)&zT_238, (unsigned int)sizeof zT_238);
    zig_poison_fill((void*)&zT_242, (unsigned int)sizeof zT_242);
    zig_poison_fill((void*)&zT_249, (unsigned int)sizeof zT_249);
    zig_poison_fill((void*)&zT_251, (unsigned int)sizeof zT_251);
    zig_poison_fill((void*)&zT_258, (unsigned int)sizeof zT_258);
    zig_poison_fill((void*)&zT_260, (unsigned int)sizeof zT_260);
    zig_poison_fill((void*)&zT_264, (unsigned int)sizeof zT_264);
    zig_poison_fill((void*)&zT_268, (unsigned int)sizeof zT_268);
    zig_poison_fill((void*)&zT_275, (unsigned int)sizeof zT_275);
    zig_poison_fill((void*)&zT_277, (unsigned int)sizeof zT_277);
    zig_poison_fill((void*)&zT_284, (unsigned int)sizeof zT_284);
    zig_poison_fill((void*)&zT_286, (unsigned int)sizeof zT_286);
    zig_poison_fill((void*)&zT_290, (unsigned int)sizeof zT_290);
    zig_poison_fill((void*)&zT_297, (unsigned int)sizeof zT_297);
    zig_poison_fill((void*)&zT_299, (unsigned int)sizeof zT_299);
    zig_poison_fill((void*)&zT_306, (unsigned int)sizeof zT_306);
    zig_poison_fill((void*)&zT_308, (unsigned int)sizeof zT_308);
    zig_poison_fill((void*)&zT_312, (unsigned int)sizeof zT_312);
    zig_poison_fill((void*)&zT_316, (unsigned int)sizeof zT_316);
    zig_poison_fill((void*)&zT_323, (unsigned int)sizeof zT_323);
    zig_poison_fill((void*)&zT_325, (unsigned int)sizeof zT_325);
    zig_poison_fill((void*)&zT_332, (unsigned int)sizeof zT_332);
    zig_poison_fill((void*)&zT_334, (unsigned int)sizeof zT_334);
    zig_poison_fill((void*)&zT_338, (unsigned int)sizeof zT_338);
    zig_poison_fill((void*)&zT_342, (unsigned int)sizeof zT_342);
    zig_poison_fill((void*)&zT_349, (unsigned int)sizeof zT_349);
    zig_poison_fill((void*)&zT_351, (unsigned int)sizeof zT_351);
    zig_poison_fill((void*)&zT_358, (unsigned int)sizeof zT_358);
    zig_poison_fill((void*)&zT_360, (unsigned int)sizeof zT_360);
    zig_poison_fill((void*)&zT_364, (unsigned int)sizeof zT_364);
    zig_poison_fill((void*)&zT_371, (unsigned int)sizeof zT_371);
    zig_poison_fill((void*)&zT_373, (unsigned int)sizeof zT_373);
    zig_poison_fill((void*)&zT_380, (unsigned int)sizeof zT_380);
    zig_poison_fill((void*)&zT_382, (unsigned int)sizeof zT_382);
    zig_poison_fill((void*)&zT_386, (unsigned int)sizeof zT_386);
    zig_poison_fill((void*)&zT_393, (unsigned int)sizeof zT_393);
    zig_poison_fill((void*)&zT_395, (unsigned int)sizeof zT_395);
    zig_poison_fill((void*)&zT_402, (unsigned int)sizeof zT_402);
    zig_poison_fill((void*)&zT_404, (unsigned int)sizeof zT_404);
    zig_poison_fill((void*)&zT_408, (unsigned int)sizeof zT_408);
    zig_poison_fill((void*)&zT_415, (unsigned int)sizeof zT_415);
    zig_poison_fill((void*)&zT_417, (unsigned int)sizeof zT_417);
    zig_poison_fill((void*)&zT_424, (unsigned int)sizeof zT_424);
    zig_poison_fill((void*)&zT_426, (unsigned int)sizeof zT_426);
    zig_poison_fill((void*)&zT_430, (unsigned int)sizeof zT_430);
    zig_poison_fill((void*)&zT_437, (unsigned int)sizeof zT_437);
    zig_poison_fill((void*)&zT_439, (unsigned int)sizeof zT_439);
    zig_poison_fill((void*)&zT_446, (unsigned int)sizeof zT_446);
    zig_poison_fill((void*)&zT_448, (unsigned int)sizeof zT_448);
    zig_poison_fill((void*)&zT_452, (unsigned int)sizeof zT_452);
    zig_poison_fill((void*)&zT_459, (unsigned int)sizeof zT_459);
    zig_poison_fill((void*)&zT_461, (unsigned int)sizeof zT_461);
    zig_poison_fill((void*)&zT_468, (unsigned int)sizeof zT_468);
    zig_poison_fill((void*)&zT_470, (unsigned int)sizeof zT_470);
    zig_poison_fill((void*)&zT_474, (unsigned int)sizeof zT_474);
    zig_poison_fill((void*)&zT_481, (unsigned int)sizeof zT_481);
    zig_poison_fill((void*)&zT_483, (unsigned int)sizeof zT_483);
    zig_poison_fill((void*)&zT_487, (unsigned int)sizeof zT_487);
    zig_poison_fill((void*)&zT_494, (unsigned int)sizeof zT_494);
    zig_poison_fill((void*)&zT_496, (unsigned int)sizeof zT_496);
    zig_poison_fill((void*)&zT_503, (unsigned int)sizeof zT_503);
    zig_poison_fill((void*)&zT_505, (unsigned int)sizeof zT_505);
    zig_poison_fill((void*)&zT_509, (unsigned int)sizeof zT_509);
    zig_poison_fill((void*)&zT_516, (unsigned int)sizeof zT_516);
    zig_poison_fill((void*)&zT_518, (unsigned int)sizeof zT_518);
    zig_poison_fill((void*)&zT_525, (unsigned int)sizeof zT_525);
    zig_poison_fill((void*)&zT_527, (unsigned int)sizeof zT_527);
    zig_poison_fill((void*)&zT_531, (unsigned int)sizeof zT_531);
    zig_poison_fill((void*)&zT_535, (unsigned int)sizeof zT_535);
    zig_poison_fill((void*)&zT_539, (unsigned int)sizeof zT_539);
    zig_poison_fill((void*)&zT_546, (unsigned int)sizeof zT_546);
    zig_poison_fill((void*)&zT_548, (unsigned int)sizeof zT_548);
    zig_poison_fill((void*)&zT_555, (unsigned int)sizeof zT_555);
    zig_poison_fill((void*)&zT_557, (unsigned int)sizeof zT_557);
    zig_poison_fill((void*)&zT_561, (unsigned int)sizeof zT_561);
    zig_poison_fill((void*)&zT_568, (unsigned int)sizeof zT_568);
    zig_poison_fill((void*)&zT_570, (unsigned int)sizeof zT_570);
    zig_poison_fill((void*)&zT_577, (unsigned int)sizeof zT_577);
    zig_poison_fill((void*)&zT_579, (unsigned int)sizeof zT_579);
    zig_poison_fill((void*)&zT_583, (unsigned int)sizeof zT_583);
    zig_poison_fill((void*)&zT_590, (unsigned int)sizeof zT_590);
    zig_poison_fill((void*)&zT_592, (unsigned int)sizeof zT_592);
    zig_poison_fill((void*)&zT_599, (unsigned int)sizeof zT_599);
    zig_poison_fill((void*)&zT_601, (unsigned int)sizeof zT_601);
    zig_poison_fill((void*)&zT_605, (unsigned int)sizeof zT_605);
    zig_poison_fill((void*)&zT_609, (unsigned int)sizeof zT_609);
    zig_poison_fill((void*)&zT_616, (unsigned int)sizeof zT_616);
    zig_poison_fill((void*)&zT_618, (unsigned int)sizeof zT_618);
    zig_poison_fill((void*)&zT_625, (unsigned int)sizeof zT_625);
    zig_poison_fill((void*)&zT_627, (unsigned int)sizeof zT_627);
    zig_poison_fill((void*)&zT_631, (unsigned int)sizeof zT_631);
    zig_poison_fill((void*)&zT_638, (unsigned int)sizeof zT_638);
    zig_poison_fill((void*)&zT_640, (unsigned int)sizeof zT_640);
    zig_poison_fill((void*)&zT_647, (unsigned int)sizeof zT_647);
    zig_poison_fill((void*)&zT_649, (unsigned int)sizeof zT_649);
    zig_poison_fill((void*)&zT_653, (unsigned int)sizeof zT_653);
    zig_poison_fill((void*)&zT_660, (unsigned int)sizeof zT_660);
    zig_poison_fill((void*)&zT_662, (unsigned int)sizeof zT_662);
    zig_poison_fill((void*)&zT_669, (unsigned int)sizeof zT_669);
    zig_poison_fill((void*)&zT_671, (unsigned int)sizeof zT_671);
    zig_poison_fill((void*)&zT_678, (unsigned int)sizeof zT_678);
    zig_poison_fill((void*)&zT_680, (unsigned int)sizeof zT_680);
    zig_poison_fill((void*)&zT_687, (unsigned int)sizeof zT_687);
    zig_poison_fill((void*)&zT_689, (unsigned int)sizeof zT_689);
    zig_poison_fill((void*)&zT_692, (unsigned int)sizeof zT_692);
    zig_poison_fill((void*)&zT_693, (unsigned int)sizeof zT_693);
    zig_poison_fill((void*)&zT_696, (unsigned int)sizeof zT_696);
    zig_poison_fill((void*)&zT_721, (unsigned int)sizeof zT_721);
    zig_poison_fill((void*)&zT_724, (unsigned int)sizeof zT_724);
    zig_poison_fill((void*)&zT_727, (unsigned int)sizeof zT_727);
    zig_poison_fill((void*)&zT_729, (unsigned int)sizeof zT_729);
    zig_poison_fill((void*)&zT_735, (unsigned int)sizeof zT_735);
    zig_poison_fill((void*)&zT_737, (unsigned int)sizeof zT_737);
    zig_poison_fill((void*)&zT_741, (unsigned int)sizeof zT_741);
    zig_poison_fill((void*)&zT_784, (unsigned int)sizeof zT_784);
    zig_poison_fill((void*)&zT_803, (unsigned int)sizeof zT_803);
    unsigned int start;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u bare_at_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u up1;
    zT_BBAAFAE2_Arr_unsigned_char_2 char_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u up3;
    zT_4C214FEE_Arr_zT_8F083A69_Sli uparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u unrecognized_msg;
    zT_1 = self;
    zF_F7949B41_lexerSkipWSC(zT_1);
    zT_2 = self;
    zT_3 = zF_07BC1EA1_lexerIsAtEnd(zT_2);
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = self;
    zT_6 = self->pos;
    zT_7 = zT_11;
    zT_13 = zF_369DD718_lexerMakeToken(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof), zT_6, zT_7);
    return zT_13;
    z_bb_2:
    zT_15 = self->pos;
    start = zT_15;
    zT_17 = self;
    zT_18 = zF_7C2FDD01_lexerAdvance(zT_17);
    c = zT_18;
switch (c) {
case 40: goto z_bb_3;
case 41: goto z_bb_4;
case 91: goto z_bb_5;
case 93: goto z_bb_6;
case 123: goto z_bb_7;
case 125: goto z_bb_8;
case 59: goto z_bb_9;
case 58: goto z_bb_10;
case 44: goto z_bb_11;
case 46: goto z_bb_12;
case 43: goto z_bb_13;
case 45: goto z_bb_14;
case 42: goto z_bb_15;
case 47: goto z_bb_16;
case 37: goto z_bb_17;
case 38: goto z_bb_18;
case 124: goto z_bb_19;
case 61: goto z_bb_20;
case 33: goto z_bb_21;
case 60: goto z_bb_22;
case 62: goto z_bb_23;
case 94: goto z_bb_24;
case 126: goto z_bb_25;
case 63: goto z_bb_26;
case 64: goto z_bb_27;
case 34: goto z_bb_28;
case 39: goto z_bb_29;
default: goto z_bb_30;
}
    z_bb_3:
    zT_19 = self;
    zT_21 = start;
    zT_22 = zT_25;
    zT_27 = zF_369DD718_lexerMakeToken(zT_19, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen), zT_21, zT_22);
    return zT_27;
    z_bb_4:
    zT_28 = self;
    zT_30 = start;
    zT_31 = zT_34;
    zT_36 = zF_369DD718_lexerMakeToken(zT_28, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen), zT_30, zT_31);
    return zT_36;
    z_bb_5:
    zT_37 = self;
    zT_39 = start;
    zT_40 = zT_43;
    zT_45 = zF_369DD718_lexerMakeToken(zT_37, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbracket), zT_39, zT_40);
    return zT_45;
    z_bb_6:
    zT_46 = self;
    zT_48 = start;
    zT_49 = zT_52;
    zT_54 = zF_369DD718_lexerMakeToken(zT_46, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket), zT_48, zT_49);
    return zT_54;
    z_bb_7:
    zT_55 = self;
    zT_57 = start;
    zT_58 = zT_61;
    zT_63 = zF_369DD718_lexerMakeToken(zT_55, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace), zT_57, zT_58);
    return zT_63;
    z_bb_8:
    zT_64 = self;
    zT_66 = start;
    zT_67 = zT_70;
    zT_72 = zF_369DD718_lexerMakeToken(zT_64, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace), zT_66, zT_67);
    return zT_72;
    z_bb_9:
    zT_73 = self;
    zT_75 = start;
    zT_76 = zT_79;
    zT_81 = zF_369DD718_lexerMakeToken(zT_73, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon), zT_75, zT_76);
    return zT_81;
    z_bb_10:
    zT_82 = self;
    zT_84 = start;
    zT_85 = zT_88;
    zT_90 = zF_369DD718_lexerMakeToken(zT_82, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon), zT_84, zT_85);
    return zT_90;
    z_bb_11:
    zT_91 = self;
    zT_93 = start;
    zT_94 = zT_97;
    zT_99 = zF_369DD718_lexerMakeToken(zT_91, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma), zT_93, zT_94);
    return zT_99;
    z_bb_12:
    zT_100 = self;
    zT_103 = zF_8A07967A_lexerMatch(zT_100, (unsigned char)(46));
    if (zT_103) goto z_bb_33; else goto z_bb_34;
    z_bb_13:
    zT_161 = self;
    zT_164 = zF_8A07967A_lexerMatch(zT_161, (unsigned char)(37));
    if (zT_164) goto z_bb_41; else goto z_bb_42;
    z_bb_14:
    zT_235 = self;
    zT_238 = zF_8A07967A_lexerMatch(zT_235, (unsigned char)(37));
    if (zT_238) goto z_bb_51; else goto z_bb_52;
    z_bb_15:
    zT_309 = self;
    zT_312 = zF_8A07967A_lexerMatch(zT_309, (unsigned char)(37));
    if (zT_312) goto z_bb_61; else goto z_bb_62;
    z_bb_16:
    zT_383 = self;
    zT_386 = zF_8A07967A_lexerMatch(zT_383, (unsigned char)(61));
    if (zT_386) goto z_bb_71; else goto z_bb_72;
    z_bb_17:
    zT_405 = self;
    zT_408 = zF_8A07967A_lexerMatch(zT_405, (unsigned char)(61));
    if (zT_408) goto z_bb_73; else goto z_bb_74;
    z_bb_18:
    zT_427 = self;
    zT_430 = zF_8A07967A_lexerMatch(zT_427, (unsigned char)(61));
    if (zT_430) goto z_bb_75; else goto z_bb_76;
    z_bb_19:
    zT_449 = self;
    zT_452 = zF_8A07967A_lexerMatch(zT_449, (unsigned char)(61));
    if (zT_452) goto z_bb_77; else goto z_bb_78;
    z_bb_20:
    zT_471 = self;
    zT_474 = zF_8A07967A_lexerMatch(zT_471, (unsigned char)(61));
    if (zT_474) goto z_bb_79; else goto z_bb_80;
    z_bb_21:
    zT_506 = self;
    zT_509 = zF_8A07967A_lexerMatch(zT_506, (unsigned char)(61));
    if (zT_509) goto z_bb_83; else goto z_bb_84;
    z_bb_22:
    zT_528 = self;
    zT_531 = zF_8A07967A_lexerMatch(zT_528, (unsigned char)(60));
    if (zT_531) goto z_bb_85; else goto z_bb_86;
    z_bb_23:
    zT_602 = self;
    zT_605 = zF_8A07967A_lexerMatch(zT_602, (unsigned char)(62));
    if (zT_605) goto z_bb_95; else goto z_bb_96;
    z_bb_24:
    zT_650 = self;
    zT_653 = zF_8A07967A_lexerMatch(zT_650, (unsigned char)(61));
    if (zT_653) goto z_bb_101; else goto z_bb_102;
    z_bb_25:
    zT_672 = self;
    zT_674 = start;
    zT_675 = zT_678;
    zT_680 = zF_369DD718_lexerMakeToken(zT_672, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_tilde), zT_674, zT_675);
    return zT_680;
    z_bb_26:
    zT_681 = self;
    zT_683 = start;
    zT_684 = zT_687;
    zT_689 = zF_369DD718_lexerMakeToken(zT_681, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_question_mark), zT_683, zT_684);
    return zT_689;
    z_bb_27:
    zT_691 = self;
    zT_692 = zF_6ACB12FA_lexerPeek(zT_691);
    zT_690 = zT_692;
    zT_693 = zF_0D29E41B_isAlpha(zT_690);
    if (zT_693) goto z_bb_103; else goto z_bb_104;
    z_bb_28:
    zT_722 = self;
    zT_723 = start;
    zT_724 = zF_D28972ED_lexerScanString(zT_722, zT_723);
    return zT_724;
    z_bb_29:
    zT_725 = self;
    zT_726 = start;
    zT_727 = zF_616D7368_lexerScanChar(zT_725, zT_726);
    return zT_727;
    z_bb_30:
    zT_728 = c;
    zT_729 = zF_0D29E41B_isAlpha(zT_728);
    if (zT_729) goto z_bb_108; else goto z_bb_107;
    { zT_3A355BD2_Token zT_ret_void = {0}; return zT_ret_void; }
    z_bb_33:
    zT_104 = self;
    zT_107 = zF_8A07967A_lexerMatch(zT_104, (unsigned char)(46));
    if (zT_107) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    zT_126 = self;
    zT_129 = zF_8A07967A_lexerMatch(zT_126, (unsigned char)(123));
    if (zT_129) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    zT_108 = self;
    zT_110 = start;
    zT_111 = zT_114;
    zT_116 = zF_369DD718_lexerMakeToken(zT_108, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot_dot), zT_110, zT_111);
    return zT_116;
    z_bb_36:
    zT_117 = self;
    zT_119 = start;
    zT_120 = zT_123;
    zT_125 = zF_369DD718_lexerMakeToken(zT_117, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot), zT_119, zT_120);
    return zT_125;
    z_bb_37:
    zT_130 = self;
    zT_132 = start;
    zT_133 = zT_136;
    zT_138 = zF_369DD718_lexerMakeToken(zT_130, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_lbrace), zT_132, zT_133);
    return zT_138;
    z_bb_38:
    zT_139 = self;
    zT_142 = zF_8A07967A_lexerMatch(zT_139, (unsigned char)(42));
    if (zT_142) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_143 = self;
    zT_145 = start;
    zT_146 = zT_149;
    zT_151 = zF_369DD718_lexerMakeToken(zT_143, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_star), zT_145, zT_146);
    return zT_151;
    z_bb_40:
    zT_152 = self;
    zT_154 = start;
    zT_155 = zT_158;
    zT_160 = zF_369DD718_lexerMakeToken(zT_152, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot), zT_154, zT_155);
    return zT_160;
    z_bb_41:
    zT_165 = self;
    zT_168 = zF_8A07967A_lexerMatch(zT_165, (unsigned char)(61));
    if (zT_168) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    zT_187 = self;
    zT_190 = zF_8A07967A_lexerMatch(zT_187, (unsigned char)(124));
    if (zT_190) goto z_bb_45; else goto z_bb_46;
    z_bb_43:
    zT_169 = self;
    zT_171 = start;
    zT_172 = zT_175;
    zT_177 = zF_369DD718_lexerMakeToken(zT_169, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pct_eq), zT_171, zT_172);
    return zT_177;
    z_bb_44:
    zT_178 = self;
    zT_180 = start;
    zT_181 = zT_184;
    zT_186 = zF_369DD718_lexerMakeToken(zT_178, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pct), zT_180, zT_181);
    return zT_186;
    z_bb_45:
    zT_191 = self;
    zT_194 = zF_8A07967A_lexerMatch(zT_191, (unsigned char)(61));
    if (zT_194) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    zT_213 = self;
    zT_216 = zF_8A07967A_lexerMatch(zT_213, (unsigned char)(61));
    if (zT_216) goto z_bb_49; else goto z_bb_50;
    z_bb_47:
    zT_195 = self;
    zT_197 = start;
    zT_198 = zT_201;
    zT_203 = zF_369DD718_lexerMakeToken(zT_195, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pipe_eq), zT_197, zT_198);
    return zT_203;
    z_bb_48:
    zT_204 = self;
    zT_206 = start;
    zT_207 = zT_210;
    zT_212 = zF_369DD718_lexerMakeToken(zT_204, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pipe), zT_206, zT_207);
    return zT_212;
    z_bb_49:
    zT_217 = self;
    zT_219 = start;
    zT_220 = zT_223;
    zT_225 = zF_369DD718_lexerMakeToken(zT_217, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_eq), zT_219, zT_220);
    return zT_225;
    z_bb_50:
    zT_226 = self;
    zT_228 = start;
    zT_229 = zT_232;
    zT_234 = zF_369DD718_lexerMakeToken(zT_226, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus), zT_228, zT_229);
    return zT_234;
    z_bb_51:
    zT_239 = self;
    zT_242 = zF_8A07967A_lexerMatch(zT_239, (unsigned char)(61));
    if (zT_242) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    zT_261 = self;
    zT_264 = zF_8A07967A_lexerMatch(zT_261, (unsigned char)(124));
    if (zT_264) goto z_bb_55; else goto z_bb_56;
    z_bb_53:
    zT_243 = self;
    zT_245 = start;
    zT_246 = zT_249;
    zT_251 = zF_369DD718_lexerMakeToken(zT_243, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pct_eq), zT_245, zT_246);
    return zT_251;
    z_bb_54:
    zT_252 = self;
    zT_254 = start;
    zT_255 = zT_258;
    zT_260 = zF_369DD718_lexerMakeToken(zT_252, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pct), zT_254, zT_255);
    return zT_260;
    z_bb_55:
    zT_265 = self;
    zT_268 = zF_8A07967A_lexerMatch(zT_265, (unsigned char)(61));
    if (zT_268) goto z_bb_57; else goto z_bb_58;
    z_bb_56:
    zT_287 = self;
    zT_290 = zF_8A07967A_lexerMatch(zT_287, (unsigned char)(61));
    if (zT_290) goto z_bb_59; else goto z_bb_60;
    z_bb_57:
    zT_269 = self;
    zT_271 = start;
    zT_272 = zT_275;
    zT_277 = zF_369DD718_lexerMakeToken(zT_269, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pipe_eq), zT_271, zT_272);
    return zT_277;
    z_bb_58:
    zT_278 = self;
    zT_280 = start;
    zT_281 = zT_284;
    zT_286 = zF_369DD718_lexerMakeToken(zT_278, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pipe), zT_280, zT_281);
    return zT_286;
    z_bb_59:
    zT_291 = self;
    zT_293 = start;
    zT_294 = zT_297;
    zT_299 = zF_369DD718_lexerMakeToken(zT_291, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_eq), zT_293, zT_294);
    return zT_299;
    z_bb_60:
    zT_300 = self;
    zT_302 = start;
    zT_303 = zT_306;
    zT_308 = zF_369DD718_lexerMakeToken(zT_300, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus), zT_302, zT_303);
    return zT_308;
    z_bb_61:
    zT_313 = self;
    zT_316 = zF_8A07967A_lexerMatch(zT_313, (unsigned char)(61));
    if (zT_316) goto z_bb_63; else goto z_bb_64;
    z_bb_62:
    zT_335 = self;
    zT_338 = zF_8A07967A_lexerMatch(zT_335, (unsigned char)(124));
    if (zT_338) goto z_bb_65; else goto z_bb_66;
    z_bb_63:
    zT_317 = self;
    zT_319 = start;
    zT_320 = zT_323;
    zT_325 = zF_369DD718_lexerMakeToken(zT_317, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pct_eq), zT_319, zT_320);
    return zT_325;
    z_bb_64:
    zT_326 = self;
    zT_328 = start;
    zT_329 = zT_332;
    zT_334 = zF_369DD718_lexerMakeToken(zT_326, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pct), zT_328, zT_329);
    return zT_334;
    z_bb_65:
    zT_339 = self;
    zT_342 = zF_8A07967A_lexerMatch(zT_339, (unsigned char)(61));
    if (zT_342) goto z_bb_67; else goto z_bb_68;
    z_bb_66:
    zT_361 = self;
    zT_364 = zF_8A07967A_lexerMatch(zT_361, (unsigned char)(61));
    if (zT_364) goto z_bb_69; else goto z_bb_70;
    z_bb_67:
    zT_343 = self;
    zT_345 = start;
    zT_346 = zT_349;
    zT_351 = zF_369DD718_lexerMakeToken(zT_343, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pipe_eq), zT_345, zT_346);
    return zT_351;
    z_bb_68:
    zT_352 = self;
    zT_354 = start;
    zT_355 = zT_358;
    zT_360 = zF_369DD718_lexerMakeToken(zT_352, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pipe), zT_354, zT_355);
    return zT_360;
    z_bb_69:
    zT_365 = self;
    zT_367 = start;
    zT_368 = zT_371;
    zT_373 = zF_369DD718_lexerMakeToken(zT_365, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_eq), zT_367, zT_368);
    return zT_373;
    z_bb_70:
    zT_374 = self;
    zT_376 = start;
    zT_377 = zT_380;
    zT_382 = zF_369DD718_lexerMakeToken(zT_374, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star), zT_376, zT_377);
    return zT_382;
    z_bb_71:
    zT_387 = self;
    zT_389 = start;
    zT_390 = zT_393;
    zT_395 = zF_369DD718_lexerMakeToken(zT_387, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_slash_eq), zT_389, zT_390);
    return zT_395;
    z_bb_72:
    zT_396 = self;
    zT_398 = start;
    zT_399 = zT_402;
    zT_404 = zF_369DD718_lexerMakeToken(zT_396, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_slash), zT_398, zT_399);
    return zT_404;
    z_bb_73:
    zT_409 = self;
    zT_411 = start;
    zT_412 = zT_415;
    zT_417 = zF_369DD718_lexerMakeToken(zT_409, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_percent_eq), zT_411, zT_412);
    return zT_417;
    z_bb_74:
    zT_418 = self;
    zT_420 = start;
    zT_421 = zT_424;
    zT_426 = zF_369DD718_lexerMakeToken(zT_418, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_percent), zT_420, zT_421);
    return zT_426;
    z_bb_75:
    zT_431 = self;
    zT_433 = start;
    zT_434 = zT_437;
    zT_439 = zF_369DD718_lexerMakeToken(zT_431, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_ampersand_eq), zT_433, zT_434);
    return zT_439;
    z_bb_76:
    zT_440 = self;
    zT_442 = start;
    zT_443 = zT_446;
    zT_448 = zF_369DD718_lexerMakeToken(zT_440, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_ampersand), zT_442, zT_443);
    return zT_448;
    z_bb_77:
    zT_453 = self;
    zT_455 = start;
    zT_456 = zT_459;
    zT_461 = zF_369DD718_lexerMakeToken(zT_453, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe_eq), zT_455, zT_456);
    return zT_461;
    z_bb_78:
    zT_462 = self;
    zT_464 = start;
    zT_465 = zT_468;
    zT_470 = zF_369DD718_lexerMakeToken(zT_462, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe), zT_464, zT_465);
    return zT_470;
    z_bb_79:
    zT_475 = self;
    zT_477 = start;
    zT_478 = zT_481;
    zT_483 = zF_369DD718_lexerMakeToken(zT_475, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq_eq), zT_477, zT_478);
    return zT_483;
    z_bb_80:
    zT_484 = self;
    zT_487 = zF_8A07967A_lexerMatch(zT_484, (unsigned char)(62));
    if (zT_487) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_488 = self;
    zT_490 = start;
    zT_491 = zT_494;
    zT_496 = zF_369DD718_lexerMakeToken(zT_488, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_fat_arrow), zT_490, zT_491);
    return zT_496;
    z_bb_82:
    zT_497 = self;
    zT_499 = start;
    zT_500 = zT_503;
    zT_505 = zF_369DD718_lexerMakeToken(zT_497, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq), zT_499, zT_500);
    return zT_505;
    z_bb_83:
    zT_510 = self;
    zT_512 = start;
    zT_513 = zT_516;
    zT_518 = zF_369DD718_lexerMakeToken(zT_510, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang_eq), zT_512, zT_513);
    return zT_518;
    z_bb_84:
    zT_519 = self;
    zT_521 = start;
    zT_522 = zT_525;
    zT_527 = zF_369DD718_lexerMakeToken(zT_519, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang), zT_521, zT_522);
    return zT_527;
    z_bb_85:
    zT_532 = self;
    zT_535 = zF_8A07967A_lexerMatch(zT_532, (unsigned char)(124));
    if (zT_535) goto z_bb_87; else goto z_bb_88;
    z_bb_86:
    zT_580 = self;
    zT_583 = zF_8A07967A_lexerMatch(zT_580, (unsigned char)(61));
    if (zT_583) goto z_bb_93; else goto z_bb_94;
    z_bb_87:
    zT_536 = self;
    zT_539 = zF_8A07967A_lexerMatch(zT_536, (unsigned char)(61));
    if (zT_539) goto z_bb_89; else goto z_bb_90;
    z_bb_88:
    zT_558 = self;
    zT_561 = zF_8A07967A_lexerMatch(zT_558, (unsigned char)(61));
    if (zT_561) goto z_bb_91; else goto z_bb_92;
    z_bb_89:
    zT_540 = self;
    zT_542 = start;
    zT_543 = zT_546;
    zT_548 = zF_369DD718_lexerMakeToken(zT_540, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl_pipe_eq), zT_542, zT_543);
    return zT_548;
    z_bb_90:
    zT_549 = self;
    zT_551 = start;
    zT_552 = zT_555;
    zT_557 = zF_369DD718_lexerMakeToken(zT_549, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl_pipe), zT_551, zT_552);
    return zT_557;
    z_bb_91:
    zT_562 = self;
    zT_564 = start;
    zT_565 = zT_568;
    zT_570 = zF_369DD718_lexerMakeToken(zT_562, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl_eq), zT_564, zT_565);
    return zT_570;
    z_bb_92:
    zT_571 = self;
    zT_573 = start;
    zT_574 = zT_577;
    zT_579 = zF_369DD718_lexerMakeToken(zT_571, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl), zT_573, zT_574);
    return zT_579;
    z_bb_93:
    zT_584 = self;
    zT_586 = start;
    zT_587 = zT_590;
    zT_592 = zF_369DD718_lexerMakeToken(zT_584, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_less_eq), zT_586, zT_587);
    return zT_592;
    z_bb_94:
    zT_593 = self;
    zT_595 = start;
    zT_596 = zT_599;
    zT_601 = zF_369DD718_lexerMakeToken(zT_593, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_less), zT_595, zT_596);
    return zT_601;
    z_bb_95:
    zT_606 = self;
    zT_609 = zF_8A07967A_lexerMatch(zT_606, (unsigned char)(61));
    if (zT_609) goto z_bb_97; else goto z_bb_98;
    z_bb_96:
    zT_628 = self;
    zT_631 = zF_8A07967A_lexerMatch(zT_628, (unsigned char)(61));
    if (zT_631) goto z_bb_99; else goto z_bb_100;
    z_bb_97:
    zT_610 = self;
    zT_612 = start;
    zT_613 = zT_616;
    zT_618 = zF_369DD718_lexerMakeToken(zT_610, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shr_eq), zT_612, zT_613);
    return zT_618;
    z_bb_98:
    zT_619 = self;
    zT_621 = start;
    zT_622 = zT_625;
    zT_627 = zF_369DD718_lexerMakeToken(zT_619, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shr), zT_621, zT_622);
    return zT_627;
    z_bb_99:
    zT_632 = self;
    zT_634 = start;
    zT_635 = zT_638;
    zT_640 = zF_369DD718_lexerMakeToken(zT_632, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_greater_eq), zT_634, zT_635);
    return zT_640;
    z_bb_100:
    zT_641 = self;
    zT_643 = start;
    zT_644 = zT_647;
    zT_649 = zF_369DD718_lexerMakeToken(zT_641, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_greater), zT_643, zT_644);
    return zT_649;
    z_bb_101:
    zT_654 = self;
    zT_656 = start;
    zT_657 = zT_660;
    zT_662 = zF_369DD718_lexerMakeToken(zT_654, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_caret_eq), zT_656, zT_657);
    return zT_662;
    z_bb_102:
    zT_663 = self;
    zT_665 = start;
    zT_666 = zT_669;
    zT_671 = zF_369DD718_lexerMakeToken(zT_663, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_caret), zT_665, zT_666);
    return zT_671;
    z_bb_103:
    zT_694 = self;
    zT_695 = start;
    zT_696 = zF_9C3BDAA8_lexerScanBuiltinIde(zT_694, zT_695);
    return zT_696;
    z_bb_104:
    zT_698 = "bare '@' is not valid; expected builtin name (e.g., @sizeOf)";
    zT_700 = 60;
    zT_699.ptr = (unsigned char*)zT_698;
    zT_699.len = zT_700;
    bare_at_msg = zT_699;
    zT_701 = self->count_only;
    if ((unsigned char)(!zT_701)) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    zT_703 = self->diag;
    zT_711 = 0;
    zT_706 = self->file_id;
    zT_716 = self->pos;
    zT_709 = bare_at_msg;
    (void)zF_C82559AC_diagnosticCollector(zT_703, (unsigned char)((unsigned char)zT_711), (unsigned short)(4), zT_706, (unsigned int)((unsigned int)start), (unsigned int)((unsigned int)zT_716), zT_709);
    goto z_bb_106;
    z_bb_106:
    zT_719 = self;
    zT_720 = start;
    zT_721 = zF_19A0FF20_lexerMakeErrorToken(zT_719, zT_720);
    return zT_721;
    z_bb_107:
    zT_730 = c == (unsigned char)(95);
    goto z_bb_109;
    z_bb_108:
    zT_730 = 1;
    goto z_bb_109;
    z_bb_109:
    if (zT_730) goto z_bb_110; else goto z_bb_111;
    z_bb_110:
    zT_733 = self;
    zT_734 = start;
    zT_735 = zF_EC7F12C5_lexerScanIdentifier(zT_733, zT_734);
    return zT_735;
    z_bb_111:
    zT_736 = c;
    zT_737 = zF_C95A8EC6_isDigit(zT_736);
    if (zT_737) goto z_bb_112; else goto z_bb_113;
    z_bb_112:
    zT_738 = self;
    zT_739 = start;
    zT_740 = c;
    zT_741 = zF_EF8134BD_lexerScanNumber(zT_738, zT_739, zT_740);
    return zT_741;
    z_bb_113:
    zT_742 = self->count_only;
    if ((unsigned char)(!zT_742)) goto z_bb_114; else goto z_bb_115;
    z_bb_114:
    zT_745 = "unrecognized character: '";
    zT_747 = 25;
    zT_746.ptr = (unsigned char*)zT_745;
    zT_746.len = zT_747;
    up1 = zT_746;
    zig_poison_fill((void*)&zT_749, (unsigned int)sizeof zT_749);
    {
    unsigned int _i = 0;
    while (_i < 2) {
        char_buf[_i] = zT_749[_i];
        _i++;
    }
}
    zT_750 = 0;
    zT_752 = (unsigned int)zT_750 < (unsigned int)(2);
    if (!(zT_752)) { pal_trap(); }
    char_buf[zT_750] = c;
    zT_753 = 0;
    zT_754 = 1;
    zT_756 = (unsigned int)zT_754 < (unsigned int)(2);
    if (!(zT_756)) { pal_trap(); }
    char_buf[zT_754] = zT_753;
    zT_758 = "'";
    zT_760 = 1;
    zT_759.ptr = (unsigned char*)zT_758;
    zT_759.len = zT_760;
    up3 = zT_759;
    zT_763 = 0;
    zT_762[zT_763] = up1;
    zT_766 = 1;
    zT_767 = 0;
    zT_768 = (unsigned char*)((unsigned char*)char_buf) + zT_767;
    zT_769 = zT_766 - zT_767;
    zT_770.ptr = (unsigned char*)zT_768;
    zT_770.len = zT_769;
    zT_771 = 1;
    zT_762[zT_771] = zT_770;
    zT_772 = 2;
    zT_762[zT_772] = up3;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        uparts[_i] = zT_762[_i];
        _i++;
    }
}
    zT_777 = self->diag;
    zT_774 = zT_777->interner;
    zT_779 = 0;
    zT_781 = (unsigned int)zT_779 < (unsigned int)(3);
    if (!(zT_781)) { pal_trap(); }
    zT_782 = uparts + zT_779;
    zT_775 = zT_782;
    zT_784 = zF_8C4BFF7C_diagnosticBuilderMa(zT_774, zT_775, (unsigned int)(3));
    unrecognized_msg = zT_784;
    zT_785 = self->diag;
    zT_793 = 0;
    zT_788 = self->file_id;
    zT_798 = self->pos;
    zT_791 = unrecognized_msg;
    (void)zF_C82559AC_diagnosticCollector(zT_785, (unsigned char)((unsigned char)zT_793), (unsigned short)(5), zT_788, (unsigned int)((unsigned int)start), (unsigned int)((unsigned int)zT_798), zT_791);
    goto z_bb_115;
    z_bb_115:
    zT_801 = self;
    zT_802 = start;
    zT_803 = zF_19A0FF20_lexerMakeErrorToken(zT_801, zT_802);
    return zT_803;
}

/* lexerAdvance */
unsigned char zF_7C2FDD01_lexerAdvance(zT_138FFB41_Lexer* self) {
    unsigned int zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned char* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned char zT_12;
    unsigned char zT_13;
    unsigned int zT_14;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    int zT_30;
    unsigned int zT_32;
    int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned char zT_38;
    unsigned char c;
    zT_1 = self->pos;
    zT_2 = self->source;
    zT_4 = zT_2.len;
    if ((unsigned char)(zT_1 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_8 = self->source;
    zT_9 = zT_8.ptr;
    zT_10 = self->pos;
    zT_11 = zT_8.len;
    zT_12 = zT_10 < zT_11;
    if (!(zT_12)) { pal_trap(); }
    zT_13 = zT_9[zT_10];
    c = zT_13;
    zT_14 = self->pos;
    zT_15 = 1;
    zT_16 = (unsigned int)zT_15;
    zT_17 = zig_wrap_add_u(((zu64)(zT_14)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_add_u(((zu64)(zT_14)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    self->pos = zT_17;
    if ((unsigned char)(c == (unsigned char)(10))) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    zT_23 = self->line;
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zig_wrap_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_27 = zig_overflow_flag_add_u(((zu64)(zT_23)), ((zu64)(zT_25)), 32u);
    zT_29 = zT_27 == (unsigned int)(0);
    if (!(zT_29)) { pal_trap(); }
    self->line = zT_26;
    zT_30 = 1;
    self->col = (unsigned int)((unsigned int)zT_30);
    goto z_bb_4;
    z_bb_4:
    return c;
    z_bb_5:
    zT_32 = self->col;
    zT_33 = 1;
    zT_34 = (unsigned int)zT_33;
    zT_35 = zig_wrap_add_u(((zu64)(zT_32)), ((zu64)(zT_34)), 32u);
    zT_36 = zig_overflow_flag_add_u(((zu64)(zT_32)), ((zu64)(zT_34)), 32u);
    zT_38 = zT_36 == (unsigned int)(0);
    if (!(zT_38)) { pal_trap(); }
    self->col = zT_35;
    goto z_bb_4;
}

/* lexerPeek */
unsigned char zF_6ACB12FA_lexerPeek(zT_138FFB41_Lexer* self) {
    unsigned int zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned char* zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned char zT_11;
    unsigned char zT_12;
    zT_1 = self->pos;
    zT_2 = self->source;
    zT_4 = zT_2.len;
    if ((unsigned char)(zT_1 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = self->source;
    zT_8 = zT_7.ptr;
    zT_9 = self->pos;
    zT_10 = zT_7.len;
    zT_11 = zT_9 < zT_10;
    if (!(zT_11)) { pal_trap(); }
    zT_12 = zT_8[zT_9];
    return zT_12;
}

/* lexerPeekN */
unsigned char zF_D1AE715C_lexerPeekN(zT_138FFB41_Lexer* self, unsigned int n) {
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned char zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char* zT_14;
    unsigned int zT_15;
    unsigned char zT_16;
    unsigned char zT_17;
    unsigned int idx;
    zT_3 = self->pos;
    zT_4 = zig_wrap_add_u(((zu64)(zT_3)), ((zu64)(n)), 32u);
    zT_5 = zig_overflow_flag_add_u(((zu64)(zT_3)), ((zu64)(n)), 32u);
    zT_7 = zT_5 == (unsigned int)(0);
    if (!(zT_7)) { pal_trap(); }
    idx = zT_4;
    zT_8 = self->source;
    zT_10 = zT_8.len;
    if ((unsigned char)(idx >= zT_10)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_13 = self->source;
    zT_14 = zT_13.ptr;
    zT_15 = zT_13.len;
    zT_16 = idx < zT_15;
    if (!(zT_16)) { pal_trap(); }
    zT_17 = zT_14[idx];
    return zT_17;
}

/* lexerIsAtEnd */
unsigned char zF_07BC1EA1_lexerIsAtEnd(zT_138FFB41_Lexer* self) {
    unsigned int zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_4;
    zT_1 = self->pos;
    zT_2 = self->source;
    zT_4 = zT_2.len;
    return (unsigned char)(zT_1 >= zT_4);
}

/* lexerMatch */
unsigned char zF_8A07967A_lexerMatch(zT_138FFB41_Lexer* self, unsigned char expected) {
    zT_138FFB41_Lexer* zT_2;
    unsigned char zT_3;
    zT_138FFB41_Lexer* zT_6;
    unsigned char zT_7;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zT_2 = self;
    zT_3 = zF_6ACB12FA_lexerPeek(zT_2);
    if ((unsigned char)(zT_3 != expected)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = self;
    zT_7 = zF_7C2FDD01_lexerAdvance(zT_6);
    (void)zT_7;
    return (unsigned char)(1);
}

/* lexerSkipWSC */
void zF_F7949B41_lexerSkipWSC(zT_138FFB41_Lexer* self) {
    zT_138FFB41_Lexer* zT_1;
    unsigned char zT_2;
    zT_138FFB41_Lexer* zT_5;
    unsigned char zT_6;
    zT_138FFB41_Lexer* zT_7;
    unsigned char zT_8;
    zT_138FFB41_Lexer* zT_9;
    int zT_11;
    unsigned char zT_13;
    zT_138FFB41_Lexer* zT_16;
    unsigned char zT_17;
    zT_138FFB41_Lexer* zT_18;
    unsigned char zT_19;
    zT_138FFB41_Lexer* zT_20;
    unsigned char zT_21;
    unsigned char zT_23;
    zT_138FFB41_Lexer* zT_24;
    unsigned char zT_25;
    zT_138FFB41_Lexer* zT_28;
    unsigned char zT_29;
    zT_138FFB41_Lexer* zT_30;
    int zT_32;
    unsigned char zT_34;
    zT_138FFB41_Lexer* zT_37;
    unsigned char zT_38;
    zT_138FFB41_Lexer* zT_39;
    unsigned char zT_40;
    int zT_42;
    unsigned int zT_43;
    zT_138FFB41_Lexer* zT_44;
    unsigned char zT_45;
    unsigned char zT_47;
    int zT_48;
    zT_138FFB41_Lexer* zT_50;
    unsigned char zT_51;
    unsigned char zT_54;
    zT_138FFB41_Lexer* zT_55;
    int zT_57;
    unsigned char zT_59;
    zT_138FFB41_Lexer* zT_62;
    unsigned char zT_63;
    zT_138FFB41_Lexer* zT_64;
    unsigned char zT_65;
    int zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned char zT_71;
    zT_138FFB41_Lexer* zT_72;
    unsigned char zT_73;
    unsigned char zT_76;
    zT_138FFB41_Lexer* zT_77;
    int zT_79;
    unsigned char zT_81;
    zT_138FFB41_Lexer* zT_84;
    unsigned char zT_85;
    zT_138FFB41_Lexer* zT_86;
    unsigned char zT_87;
    int zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    unsigned char zT_93;
    zT_138FFB41_Lexer* zT_94;
    unsigned char zT_95;
    int zT_96;
    unsigned char* zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    unsigned int zT_101;
    unsigned char zT_102;
    zT_F85C5DED_DiagnosticCollector* zT_104;
    unsigned int zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    int zT_112;
    unsigned int zT_116;
    unsigned int zT_118;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zig_poison_fill((void*)&zT_34, (unsigned int)sizeof zT_34);
    zig_poison_fill((void*)&zT_38, (unsigned int)sizeof zT_38);
    zig_poison_fill((void*)&zT_40, (unsigned int)sizeof zT_40);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_51, (unsigned int)sizeof zT_51);
    zig_poison_fill((void*)&zT_59, (unsigned int)sizeof zT_59);
    zig_poison_fill((void*)&zT_63, (unsigned int)sizeof zT_63);
    zig_poison_fill((void*)&zT_65, (unsigned int)sizeof zT_65);
    zig_poison_fill((void*)&zT_73, (unsigned int)sizeof zT_73);
    zig_poison_fill((void*)&zT_81, (unsigned int)sizeof zT_81);
    zig_poison_fill((void*)&zT_85, (unsigned int)sizeof zT_85);
    zig_poison_fill((void*)&zT_87, (unsigned int)sizeof zT_87);
    zig_poison_fill((void*)&zT_95, (unsigned int)sizeof zT_95);
    unsigned char c;
    unsigned int depth;
    zT_8F083A69_Slice_zT_0B42B2F8_u unterminated_block_msg;
    goto z_bb_1;
    z_bb_1:
    zT_1 = self;
    zT_2 = zF_07BC1EA1_lexerIsAtEnd(zT_1);
    if ((unsigned char)(!zT_2)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_5 = self;
    zT_6 = zF_6ACB12FA_lexerPeek(zT_5);
    c = zT_6;
switch (c) {
case 32: goto z_bb_5;
case 9: goto z_bb_5;
case 10: goto z_bb_5;
case 13: goto z_bb_5;
case 47: goto z_bb_6;
default: goto z_bb_7;
}
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_7 = self;
    zT_8 = zF_7C2FDD01_lexerAdvance(zT_7);
    (void)zT_8;
    goto z_bb_9;
    z_bb_6:
    zT_9 = self;
    zT_11 = 1;
    zT_13 = zF_D1AE715C_lexerPeekN(zT_9, (unsigned int)((unsigned int)zT_11));
    if ((unsigned char)(zT_13 == (unsigned char)(47))) goto z_bb_10; else goto z_bb_12;
    z_bb_7:
    return;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_16 = self;
    zT_17 = zF_7C2FDD01_lexerAdvance(zT_16);
    (void)zT_17;
    zT_18 = self;
    zT_19 = zF_7C2FDD01_lexerAdvance(zT_18);
    (void)zT_19;
    goto z_bb_13;
    z_bb_11:
    goto z_bb_9;
    z_bb_12:
    zT_30 = self;
    zT_32 = 1;
    zT_34 = zF_D1AE715C_lexerPeekN(zT_30, (unsigned int)((unsigned int)zT_32));
    if ((unsigned char)(zT_34 == (unsigned char)(42))) goto z_bb_20; else goto z_bb_22;
    z_bb_13:
    zT_20 = self;
    zT_21 = zF_07BC1EA1_lexerIsAtEnd(zT_20);
    if ((unsigned char)(!zT_21)) goto z_bb_17; else goto z_bb_18;
    z_bb_14:
    zT_28 = self;
    zT_29 = zF_7C2FDD01_lexerAdvance(zT_28);
    (void)zT_29;
    goto z_bb_16;
    z_bb_15:
    goto z_bb_11;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    zT_24 = self;
    zT_25 = zF_6ACB12FA_lexerPeek(zT_24);
    zT_23 = zT_25 != (unsigned char)(10);
    goto z_bb_19;
    z_bb_18:
    zT_23 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_23) goto z_bb_14; else goto z_bb_15;
    z_bb_20:
    zT_37 = self;
    zT_38 = zF_7C2FDD01_lexerAdvance(zT_37);
    (void)zT_38;
    zT_39 = self;
    zT_40 = zF_7C2FDD01_lexerAdvance(zT_39);
    (void)zT_40;
    zT_42 = 1;
    zT_43 = (unsigned int)zT_42;
    depth = zT_43;
    goto z_bb_23;
    z_bb_21:
    goto z_bb_11;
    z_bb_22:
    return;
    z_bb_23:
    zT_44 = self;
    zT_45 = zF_07BC1EA1_lexerIsAtEnd(zT_44);
    if ((unsigned char)(!zT_45)) goto z_bb_27; else goto z_bb_28;
    z_bb_24:
    zT_50 = self;
    zT_51 = zF_6ACB12FA_lexerPeek(zT_50);
    if ((unsigned char)(zT_51 == (unsigned char)(42))) goto z_bb_30; else goto z_bb_31;
    z_bb_25:
    zT_96 = 0;
    if ((unsigned char)(depth > (unsigned int)zT_96)) goto z_bb_42; else goto z_bb_43;
    z_bb_26:
    goto z_bb_23;
    z_bb_27:
    zT_48 = 0;
    zT_47 = depth > (unsigned int)zT_48;
    goto z_bb_29;
    z_bb_28:
    zT_47 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_47) goto z_bb_24; else goto z_bb_25;
    z_bb_30:
    zT_55 = self;
    zT_57 = 1;
    zT_59 = zF_D1AE715C_lexerPeekN(zT_55, (unsigned int)((unsigned int)zT_57));
    zT_54 = zT_59 == (unsigned char)(47);
    goto z_bb_32;
    z_bb_31:
    zT_54 = 0;
    goto z_bb_32;
    z_bb_32:
    if (zT_54) goto z_bb_33; else goto z_bb_35;
    z_bb_33:
    zT_62 = self;
    zT_63 = zF_7C2FDD01_lexerAdvance(zT_62);
    (void)zT_63;
    zT_64 = self;
    zT_65 = zF_7C2FDD01_lexerAdvance(zT_64);
    (void)zT_65;
    zT_66 = 1;
    zT_67 = (unsigned int)zT_66;
    zT_68 = zig_wrap_sub_u(((zu64)(depth)), ((zu64)(zT_67)), 32u);
    zT_69 = zig_overflow_flag_sub_u(((zu64)(depth)), ((zu64)(zT_67)), 32u);
    zT_71 = zT_69 == (unsigned int)(0);
    if (!(zT_71)) { pal_trap(); }
    depth = zT_68;
    goto z_bb_34;
    z_bb_34:
    goto z_bb_26;
    z_bb_35:
    zT_72 = self;
    zT_73 = zF_6ACB12FA_lexerPeek(zT_72);
    if ((unsigned char)(zT_73 == (unsigned char)(47))) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_77 = self;
    zT_79 = 1;
    zT_81 = zF_D1AE715C_lexerPeekN(zT_77, (unsigned int)((unsigned int)zT_79));
    zT_76 = zT_81 == (unsigned char)(42);
    goto z_bb_38;
    z_bb_37:
    zT_76 = 0;
    goto z_bb_38;
    z_bb_38:
    if (zT_76) goto z_bb_39; else goto z_bb_41;
    z_bb_39:
    zT_84 = self;
    zT_85 = zF_7C2FDD01_lexerAdvance(zT_84);
    (void)zT_85;
    zT_86 = self;
    zT_87 = zF_7C2FDD01_lexerAdvance(zT_86);
    (void)zT_87;
    zT_88 = 1;
    zT_89 = (unsigned int)zT_88;
    zT_90 = zig_wrap_add_u(((zu64)(depth)), ((zu64)(zT_89)), 32u);
    zT_91 = zig_overflow_flag_add_u(((zu64)(depth)), ((zu64)(zT_89)), 32u);
    zT_93 = zT_91 == (unsigned int)(0);
    if (!(zT_93)) { pal_trap(); }
    depth = zT_90;
    goto z_bb_40;
    z_bb_40:
    goto z_bb_34;
    z_bb_41:
    zT_94 = self;
    zT_95 = zF_7C2FDD01_lexerAdvance(zT_94);
    (void)zT_95;
    goto z_bb_40;
    z_bb_42:
    zT_99 = "unterminated block comment";
    zT_101 = 26;
    zT_100.ptr = (unsigned char*)zT_99;
    zT_100.len = zT_101;
    unterminated_block_msg = zT_100;
    zT_102 = self->count_only;
    if ((unsigned char)(!zT_102)) goto z_bb_44; else goto z_bb_45;
    z_bb_43:
    goto z_bb_21;
    z_bb_44:
    zT_104 = self->diag;
    zT_112 = 0;
    zT_107 = self->file_id;
    zT_116 = self->pos;
    zT_118 = self->pos;
    zT_110 = unterminated_block_msg;
    (void)zF_C82559AC_diagnosticCollector(zT_104, (unsigned char)((unsigned char)zT_112), (unsigned short)(1), zT_107, (unsigned int)((unsigned int)zT_116), (unsigned int)((unsigned int)zT_118), zT_110);
    goto z_bb_45;
    z_bb_45:
    goto z_bb_43;
}

/* lexerMakeToken */
zT_3A355BD2_Token zF_369DD718_lexerMakeToken(zT_138FFB41_Lexer* self, zT_EAC3E484_TokenKind kind, unsigned int start, zT_85CBA4DB_TokenValue value) {
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    unsigned short zT_10;
    zT_3A355BD2_Token zT_11;
    unsigned int zT_12;
    unsigned short zT_13;
    unsigned short span_len;
    zT_5 = self->pos;
    zT_6 = zig_wrap_sub_u(((zu64)(zT_5)), ((zu64)(start)), 32u);
    zT_7 = zig_overflow_flag_sub_u(((zu64)(zT_5)), ((zu64)(start)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_10 = (unsigned short)zig_cast_checked_u((zu64)zT_6, 32u, 0u, 16u);
    span_len = zT_10;
    zT_11.kind = kind;
    zT_12 = (unsigned int)start;
    zT_11.span_start = zT_12;
    zT_13 = (unsigned short)span_len;
    zT_11.span_len = zT_13;
    zT_11.value = value;
    return zT_11;
}

/* lexerMakeErrorToken */
zT_3A355BD2_Token zF_19A0FF20_lexerMakeErrorToken(zT_138FFB41_Lexer* self, unsigned int start) {
    zT_3A355BD2_Token zT_2;
    zT_EAC3E484_TokenKind zT_4;
    unsigned int zT_5;
    unsigned short zT_6;
    zT_85CBA4DB_TokenValue zT_7;
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    (void)self;
    zT_4 = zT_EAC3E484_TokenKind_err_token;
    zT_2.kind = zT_4;
    zT_5 = (unsigned int)start;
    zT_2.span_start = zT_5;
    zT_6 = 1;
    zT_2.span_len = zT_6;
    zT_2.value = zT_7;
    return zT_2;
}

/* lexerScanString */
zT_3A355BD2_Token zF_D28972ED_lexerScanString(zT_138FFB41_Lexer* self, unsigned int start) {
    unsigned char zT_2;
    int zT_4;
    zT_47B162D1_U8ArrayList* zT_6;
    zT_138FFB41_Lexer* zT_7;
    unsigned char zT_8;
    zT_138FFB41_Lexer* zT_11;
    unsigned char zT_12;
    zT_138FFB41_Lexer* zT_15;
    unsigned char zT_16;
    unsigned char zT_17;
    zT_3A355BD2_Token zT_18;
    zT_EAC3E484_TokenKind zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned char zT_26;
    unsigned short zT_27;
    zT_85CBA4DB_TokenValue zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    zT_47B162D1_U8ArrayList* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_37;
    int zT_38;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_D3EB6303_StringInterner* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_48;
    zT_3A355BD2_Token zT_49;
    zT_EAC3E484_TokenKind zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned char zT_57;
    unsigned short zT_58;
    zT_85CBA4DB_TokenValue zT_59;
    unsigned char zT_62;
    int zT_63;
    unsigned char zT_65;
    unsigned char* zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70;
    zT_F85C5DED_DiagnosticCollector* zT_71;
    unsigned int zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    int zT_79;
    unsigned int zT_84;
    zT_138FFB41_Lexer* zT_87;
    unsigned int zT_88;
    zT_3A355BD2_Token zT_89;
    zT_138FFB41_Lexer* zT_90;
    unsigned char zT_91;
    unsigned char zT_94;
    zT_47B162D1_U8ArrayList* zT_96;
    unsigned char zT_97;
    zT_138FFB41_Lexer* zT_99;
    unsigned char zT_100;
    zT_138FFB41_Lexer* zT_101;
    unsigned char zT_102;
    unsigned char zT_103;
    zT_47B162D1_U8ArrayList* zT_105;
    unsigned char zT_106;
    zT_138FFB41_Lexer* zT_108;
    unsigned int zT_109;
    zT_3A355BD2_Token zT_110;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_12, (unsigned int)sizeof zT_12);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_35, (unsigned int)sizeof zT_35);
    zig_poison_fill((void*)&zT_48, (unsigned int)sizeof zT_48);
    zig_poison_fill((void*)&zT_89, (unsigned int)sizeof zT_89);
    zig_poison_fill((void*)&zT_91, (unsigned int)sizeof zT_91);
    zig_poison_fill((void*)&zT_100, (unsigned int)sizeof zT_100);
    zig_poison_fill((void*)&zT_102, (unsigned int)sizeof zT_102);
    zig_poison_fill((void*)&zT_110, (unsigned int)sizeof zT_110);
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    zT_8F083A69_Slice_zT_0B42B2F8_u sb_slice;
    unsigned int id;
    zT_8F083A69_Slice_zT_0B42B2F8_u empty_str;
    zT_8F083A69_Slice_zT_0B42B2F8_u unterminated_string_msg;
    zT_2 = self->count_only;
    if ((unsigned char)(!zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = 0;
    zT_6 = self->string_buf;
    zT_6->len = (unsigned int)((unsigned int)zT_4);
    goto z_bb_2;
    z_bb_2:
    goto z_bb_3;
    z_bb_3:
    zT_7 = self;
    zT_8 = zF_07BC1EA1_lexerIsAtEnd(zT_7);
    if ((unsigned char)(!zT_8)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_11 = self;
    zT_12 = zF_6ACB12FA_lexerPeek(zT_11);
    c = zT_12;
    if ((unsigned char)(c == (unsigned char)(34))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_108 = self;
    zT_109 = start;
    zT_110 = zF_19A0FF20_lexerMakeErrorToken(zT_108, zT_109);
    return zT_110;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_15 = self;
    zT_16 = zF_7C2FDD01_lexerAdvance(zT_15);
    (void)zT_16;
    zT_17 = self->count_only;
    if (zT_17) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    if ((unsigned char)(c == (unsigned char)(10))) goto z_bb_15; else goto z_bb_14;
    z_bb_9:
    zT_20 = zT_EAC3E484_TokenKind_string_literal;
    zT_18.kind = zT_20;
    zT_21 = (unsigned int)start;
    zT_18.span_start = zT_21;
    zT_22 = self->pos;
    zT_23 = zig_wrap_sub_u(((zu64)(zT_22)), ((zu64)(start)), 32u);
    zT_24 = zig_overflow_flag_sub_u(((zu64)(zT_22)), ((zu64)(start)), 32u);
    zT_26 = zT_24 == (unsigned int)(0);
    if (!(zT_26)) { pal_trap(); }
    zT_27 = (unsigned short)zig_cast_checked_u((zu64)zT_23, 32u, 0u, 16u);
    zT_18.span_len = zT_27;
    zT_29 = 0;
    zT_28.string_id = zT_29;
    zT_18.value = zT_28;
    return zT_18;
    z_bb_10:
    zig_poison_fill((void*)&zT_31, (unsigned int)sizeof zT_31);
    text = zT_31;
    zT_33 = self->string_buf;
    zT_35 = zF_2ADA0742_byteArrayListGetSli(zT_33);
    sb_slice = zT_35;
    zT_37 = sb_slice.len;
    zT_38 = 0;
    if ((unsigned char)(zT_37 > (unsigned int)zT_38)) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    text = sb_slice;
    goto z_bb_12;
    z_bb_12:
    zT_45 = self->interner;
    zT_46 = text;
    zT_48 = zF_50C274AF_stringInternerInter(zT_45, zT_46);
    id = zT_48;
    zT_51 = zT_EAC3E484_TokenKind_string_literal;
    zT_49.kind = zT_51;
    zT_52 = (unsigned int)start;
    zT_49.span_start = zT_52;
    zT_53 = self->pos;
    zT_54 = zig_wrap_sub_u(((zu64)(zT_53)), ((zu64)(start)), 32u);
    zT_55 = zig_overflow_flag_sub_u(((zu64)(zT_53)), ((zu64)(start)), 32u);
    zT_57 = zT_55 == (unsigned int)(0);
    if (!(zT_57)) { pal_trap(); }
    zT_58 = (unsigned short)zig_cast_checked_u((zu64)zT_54, 32u, 0u, 16u);
    zT_49.span_len = zT_58;
    zT_59.string_id = id;
    zT_49.value = zT_59;
    return zT_49;
    z_bb_13:
    zT_41 = "";
    zT_43 = 0;
    zT_42.ptr = (unsigned char*)zT_41;
    zT_42.len = zT_43;
    empty_str = zT_42;
    text = empty_str;
    goto z_bb_12;
    z_bb_14:
    zT_63 = 0;
    zT_62 = c == zT_63;
    goto z_bb_16;
    z_bb_15:
    zT_62 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_62) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_65 = self->count_only;
    if ((unsigned char)(!zT_65)) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_90 = self;
    zT_91 = zF_7C2FDD01_lexerAdvance(zT_90);
    (void)zT_91;
    if ((unsigned char)(c == (unsigned char)(92))) goto z_bb_21; else goto z_bb_23;
    z_bb_19:
    zT_68 = "unterminated string literal";
    zT_70 = 27;
    zT_69.ptr = (unsigned char*)zT_68;
    zT_69.len = zT_70;
    unterminated_string_msg = zT_69;
    zT_71 = self->diag;
    zT_79 = 0;
    zT_74 = self->file_id;
    zT_84 = self->pos;
    zT_77 = unterminated_string_msg;
    (void)zF_C82559AC_diagnosticCollector(zT_71, (unsigned char)((unsigned char)zT_79), (unsigned short)(0), zT_74, (unsigned int)((unsigned int)start), (unsigned int)((unsigned int)zT_84), zT_77);
    goto z_bb_20;
    z_bb_20:
    zT_87 = self;
    zT_88 = start;
    zT_89 = zF_19A0FF20_lexerMakeErrorToken(zT_87, zT_88);
    return zT_89;
    z_bb_21:
    zT_94 = self->count_only;
    if ((unsigned char)(!zT_94)) goto z_bb_24; else goto z_bb_26;
    z_bb_22:
    goto z_bb_6;
    z_bb_23:
    zT_103 = self->count_only;
    if ((unsigned char)(!zT_103)) goto z_bb_27; else goto z_bb_28;
    z_bb_24:
    zT_96 = self->string_buf;
    zT_99 = self;
    zT_100 = zF_7D4EA30A_lexerParseEscapeSeq(zT_99);
    zT_97 = zT_100;
    zF_463FE7A4_byteArrayListAppend(zT_96, zT_97);
    goto z_bb_25;
    z_bb_25:
    goto z_bb_22;
    z_bb_26:
    zT_101 = self;
    zT_102 = zF_7D4EA30A_lexerParseEscapeSeq(zT_101);
    (void)zT_102;
    goto z_bb_25;
    z_bb_27:
    zT_105 = self->string_buf;
    zT_106 = c;
    zF_463FE7A4_byteArrayListAppend(zT_105, zT_106);
    goto z_bb_28;
    z_bb_28:
    goto z_bb_22;
}

/* lexerScanChar */
zT_3A355BD2_Token zF_616D7368_lexerScanChar(zT_138FFB41_Lexer* self, unsigned int start) {
    zT_138FFB41_Lexer* zT_2;
    unsigned char zT_3;
    unsigned char zT_4;
    zT_138FFB41_Lexer* zT_5;
    unsigned char zT_6;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    unsigned char zT_13;
    zT_F85C5DED_DiagnosticCollector* zT_15;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    int zT_23;
    unsigned int zT_28;
    zT_138FFB41_Lexer* zT_31;
    unsigned char zT_32;
    zT_138FFB41_Lexer* zT_35;
    unsigned char zT_36;
    zT_138FFB41_Lexer* zT_37;
    unsigned int zT_39;
    zT_85CBA4DB_TokenValue zT_40;
    zT_85CBA4DB_TokenValue zT_43;
    zT_79FAE712_u64 zT_44;
    zT_3A355BD2_Token zT_45;
    int zT_47;
    unsigned int zT_48;
    zT_138FFB41_Lexer* zT_50;
    unsigned char zT_51;
    zT_138FFB41_Lexer* zT_54;
    unsigned char zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    zT_138FFB41_Lexer* zT_58;
    unsigned char zT_59;
    unsigned char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    unsigned char zT_66;
    zT_F85C5DED_DiagnosticCollector* zT_68;
    unsigned int zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    int zT_76;
    unsigned int zT_81;
    zT_138FFB41_Lexer* zT_84;
    unsigned char zT_85;
    zT_3A355BD2_Token zT_86;
    zT_EAC3E484_TokenKind zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    unsigned char zT_94;
    unsigned short zT_95;
    zT_85CBA4DB_TokenValue zT_96;
    zT_79FAE712_u64 zT_97;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zig_poison_fill((void*)&zT_36, (unsigned int)sizeof zT_36);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_51, (unsigned int)sizeof zT_51);
    zig_poison_fill((void*)&zT_55, (unsigned int)sizeof zT_55);
    zig_poison_fill((void*)&zT_59, (unsigned int)sizeof zT_59);
    zig_poison_fill((void*)&zT_85, (unsigned int)sizeof zT_85);
    zT_8F083A69_Slice_zT_0B42B2F8_u empty_char_msg;
    unsigned int value;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u expected_close_msg;
    zT_2 = self;
    zT_3 = zF_07BC1EA1_lexerIsAtEnd(zT_2);
    if (zT_3) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = self;
    zT_6 = zF_6ACB12FA_lexerPeek(zT_5);
    zT_4 = zT_6 == (unsigned char)(39);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_10 = "empty character literal";
    zT_12 = 23;
    zT_11.ptr = (unsigned char*)zT_10;
    zT_11.len = zT_12;
    empty_char_msg = zT_11;
    zT_13 = self->count_only;
    if ((unsigned char)(!zT_13)) goto z_bb_6; else goto z_bb_7;
    z_bb_5:
    zT_47 = 0;
    zT_48 = (unsigned int)zT_47;
    value = zT_48;
    zT_50 = self;
    zT_51 = zF_7C2FDD01_lexerAdvance(zT_50);
    c = zT_51;
    if ((unsigned char)(c == (unsigned char)(92))) goto z_bb_10; else goto z_bb_12;
    z_bb_6:
    zT_15 = self->diag;
    zT_23 = 0;
    zT_18 = self->file_id;
    zT_28 = self->pos;
    zT_21 = empty_char_msg;
    (void)zF_C82559AC_diagnosticCollector(zT_15, (unsigned char)((unsigned char)zT_23), (unsigned short)(2), zT_18, (unsigned int)((unsigned int)start), (unsigned int)((unsigned int)zT_28), zT_21);
    goto z_bb_7;
    z_bb_7:
    zT_31 = self;
    zT_32 = zF_6ACB12FA_lexerPeek(zT_31);
    if ((unsigned char)(zT_32 == (unsigned char)(39))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_35 = self;
    zT_36 = zF_7C2FDD01_lexerAdvance(zT_35);
    (void)zT_36;
    goto z_bb_9;
    z_bb_9:
    zT_37 = self;
    zT_39 = start;
    zT_44 = 0;
    zT_43.int_val = zT_44;
    zT_40 = zT_43;
    zT_45 = zF_369DD718_lexerMakeToken(zT_37, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_char_literal), zT_39, zT_40);
    return zT_45;
    z_bb_10:
    zT_54 = self;
    zT_55 = zF_7D4EA30A_lexerParseEscapeSeq(zT_54);
    zT_56 = (unsigned int)zT_55;
    value = zT_56;
    goto z_bb_11;
    z_bb_11:
    zT_58 = self;
    zT_59 = zF_6ACB12FA_lexerPeek(zT_58);
    if ((unsigned char)(zT_59 != (unsigned char)(39))) goto z_bb_13; else goto z_bb_15;
    z_bb_12:
    zT_57 = (unsigned int)c;
    value = zT_57;
    goto z_bb_11;
    z_bb_13:
    zT_63 = "expected closing ' in character literal";
    zT_65 = 39;
    zT_64.ptr = (unsigned char*)zT_63;
    zT_64.len = zT_65;
    expected_close_msg = zT_64;
    zT_66 = self->count_only;
    if ((unsigned char)(!zT_66)) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    zT_88 = zT_EAC3E484_TokenKind_char_literal;
    zT_86.kind = zT_88;
    zT_89 = (unsigned int)start;
    zT_86.span_start = zT_89;
    zT_90 = self->pos;
    zT_91 = zig_wrap_sub_u(((zu64)(zT_90)), ((zu64)(start)), 32u);
    zT_92 = zig_overflow_flag_sub_u(((zu64)(zT_90)), ((zu64)(start)), 32u);
    zT_94 = zT_92 == (unsigned int)(0);
    if (!(zT_94)) { pal_trap(); }
    zT_95 = (unsigned short)zig_cast_checked_u((zu64)zT_91, 32u, 0u, 16u);
    zT_86.span_len = zT_95;
    zT_97 = (zT_79FAE712_u64)value;
    zT_96.int_val = zT_97;
    zT_86.value = zT_96;
    return zT_86;
    z_bb_15:
    zT_84 = self;
    zT_85 = zF_7C2FDD01_lexerAdvance(zT_84);
    (void)zT_85;
    goto z_bb_14;
    z_bb_16:
    zT_68 = self->diag;
    zT_76 = 0;
    zT_71 = self->file_id;
    zT_81 = self->pos;
    zT_74 = expected_close_msg;
    (void)zF_C82559AC_diagnosticCollector(zT_68, (unsigned char)((unsigned char)zT_76), (unsigned short)(2), zT_71, (unsigned int)((unsigned int)start), (unsigned int)((unsigned int)zT_81), zT_74);
    goto z_bb_17;
    z_bb_17:
    goto z_bb_14;
}

/* lexerScanNumber */
zT_3A355BD2_Token zF_EF8134BD_lexerScanNumber(zT_138FFB41_Lexer* self, unsigned int start, unsigned char first) {
    unsigned char zT_4;
    int zT_6;
    unsigned char zT_7;
    unsigned char zT_10;
    zT_138FFB41_Lexer* zT_11;
    unsigned char zT_12;
    zT_138FFB41_Lexer* zT_15;
    unsigned char zT_16;
    unsigned char zT_19;
    int zT_22;
    unsigned char zT_23;
    zT_138FFB41_Lexer* zT_24;
    unsigned char zT_25;
    unsigned char zT_28;
    int zT_31;
    unsigned char zT_32;
    zT_138FFB41_Lexer* zT_33;
    unsigned char zT_34;
    unsigned char zT_37;
    int zT_40;
    unsigned char zT_41;
    zT_138FFB41_Lexer* zT_42;
    unsigned char zT_43;
    zT_138FFB41_Lexer* zT_44;
    unsigned char zT_45;
    zT_138FFB41_Lexer* zT_48;
    unsigned char zT_49;
    zT_138FFB41_Lexer* zT_52;
    unsigned char zT_53;
    unsigned char zT_54;
    unsigned char zT_55;
    unsigned char zT_56;
    zT_138FFB41_Lexer* zT_58;
    unsigned char zT_59;
    int zT_60;
    unsigned char zT_62;
    zT_138FFB41_Lexer* zT_63;
    unsigned char zT_64;
    unsigned char zT_67;
    zT_138FFB41_Lexer* zT_68;
    int zT_70;
    unsigned char zT_72;
    zT_138FFB41_Lexer* zT_75;
    unsigned char zT_76;
    unsigned char zT_77;
    zT_138FFB41_Lexer* zT_78;
    unsigned char zT_79;
    zT_138FFB41_Lexer* zT_82;
    unsigned char zT_83;
    zT_138FFB41_Lexer* zT_86;
    unsigned char zT_87;
    unsigned char zT_88;
    unsigned char zT_89;
    zT_138FFB41_Lexer* zT_91;
    unsigned char zT_92;
    int zT_93;
    unsigned char zT_95;
    zT_138FFB41_Lexer* zT_96;
    unsigned char zT_97;
    unsigned char zT_100;
    zT_138FFB41_Lexer* zT_101;
    unsigned char zT_102;
    zT_138FFB41_Lexer* zT_105;
    unsigned char zT_106;
    zT_138FFB41_Lexer* zT_107;
    unsigned char zT_108;
    unsigned char zT_111;
    zT_138FFB41_Lexer* zT_112;
    unsigned char zT_113;
    zT_138FFB41_Lexer* zT_116;
    unsigned char zT_117;
    zT_138FFB41_Lexer* zT_118;
    unsigned char zT_119;
    unsigned char zT_121;
    unsigned char zT_122;
    zT_138FFB41_Lexer* zT_123;
    unsigned char zT_124;
    unsigned char zT_125;
    zT_138FFB41_Lexer* zT_126;
    unsigned char zT_127;
    unsigned char zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned char* zT_131;
    unsigned int zT_132;
    unsigned int zT_133;
    unsigned char* zT_134;
    unsigned int zT_135;
    unsigned char zT_136;
    unsigned char zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    zT_00435AEB_f64 zT_141;
    zT_138FFB41_Lexer* zT_142;
    unsigned int zT_144;
    zT_85CBA4DB_TokenValue zT_145;
    zT_85CBA4DB_TokenValue zT_148;
    zT_3A355BD2_Token zT_149;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned char zT_152;
    zT_79FAE712_u64 zT_153;
    zT_79FAE712_u64 zT_154;
    unsigned char zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    unsigned char zT_158;
    unsigned char* zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    unsigned int zT_163;
    unsigned char zT_164;
    zT_F85C5DED_DiagnosticCollector* zT_166;
    unsigned int zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_172;
    int zT_174;
    unsigned int zT_179;
    zT_138FFB41_Lexer* zT_182;
    unsigned int zT_184;
    zT_85CBA4DB_TokenValue zT_185;
    zT_85CBA4DB_TokenValue zT_188;
    zT_3A355BD2_Token zT_189;
    zig_poison_fill((void*)&zT_12, (unsigned int)sizeof zT_12);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_25, (unsigned int)sizeof zT_25);
    zig_poison_fill((void*)&zT_34, (unsigned int)sizeof zT_34);
    zig_poison_fill((void*)&zT_43, (unsigned int)sizeof zT_43);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_49, (unsigned int)sizeof zT_49);
    zig_poison_fill((void*)&zT_53, (unsigned int)sizeof zT_53);
    zig_poison_fill((void*)&zT_56, (unsigned int)sizeof zT_56);
    zig_poison_fill((void*)&zT_59, (unsigned int)sizeof zT_59);
    zig_poison_fill((void*)&zT_64, (unsigned int)sizeof zT_64);
    zig_poison_fill((void*)&zT_72, (unsigned int)sizeof zT_72);
    zig_poison_fill((void*)&zT_76, (unsigned int)sizeof zT_76);
    zig_poison_fill((void*)&zT_79, (unsigned int)sizeof zT_79);
    zig_poison_fill((void*)&zT_83, (unsigned int)sizeof zT_83);
    zig_poison_fill((void*)&zT_87, (unsigned int)sizeof zT_87);
    zig_poison_fill((void*)&zT_89, (unsigned int)sizeof zT_89);
    zig_poison_fill((void*)&zT_92, (unsigned int)sizeof zT_92);
    zig_poison_fill((void*)&zT_97, (unsigned int)sizeof zT_97);
    zig_poison_fill((void*)&zT_102, (unsigned int)sizeof zT_102);
    zig_poison_fill((void*)&zT_106, (unsigned int)sizeof zT_106);
    zig_poison_fill((void*)&zT_108, (unsigned int)sizeof zT_108);
    zig_poison_fill((void*)&zT_113, (unsigned int)sizeof zT_113);
    zig_poison_fill((void*)&zT_117, (unsigned int)sizeof zT_117);
    zig_poison_fill((void*)&zT_119, (unsigned int)sizeof zT_119);
    zig_poison_fill((void*)&zT_124, (unsigned int)sizeof zT_124);
    zig_poison_fill((void*)&zT_125, (unsigned int)sizeof zT_125);
    zig_poison_fill((void*)&zT_127, (unsigned int)sizeof zT_127);
    zig_poison_fill((void*)&zT_141, (unsigned int)sizeof zT_141);
    zig_poison_fill((void*)&zT_149, (unsigned int)sizeof zT_149);
    zig_poison_fill((void*)&zT_153, (unsigned int)sizeof zT_153);
    zig_poison_fill((void*)&zT_158, (unsigned int)sizeof zT_158);
    zig_poison_fill((void*)&zT_189, (unsigned int)sizeof zT_189);
    unsigned char is_float;
    unsigned char base;
    unsigned char next;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    zT_00435AEB_f64 value;
    zT_79FAE712_u64 value_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u overflow_msg;
    zT_4 = 0;
    is_float = zT_4;
    zT_6 = 10;
    zT_7 = (unsigned char)zT_6;
    base = zT_7;
    if ((unsigned char)(first == (unsigned char)(48))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = self;
    zT_12 = zF_07BC1EA1_lexerIsAtEnd(zT_11);
    zT_10 = !zT_12;
    goto z_bb_3;
    z_bb_2:
    zT_10 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_10) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_15 = self;
    zT_16 = zF_6ACB12FA_lexerPeek(zT_15);
    next = zT_16;
    if ((unsigned char)(next == (unsigned char)(120))) goto z_bb_7; else goto z_bb_6;
    z_bb_5:
    goto z_bb_23;
    z_bb_6:
    zT_19 = next == (unsigned char)(88);
    goto z_bb_8;
    z_bb_7:
    zT_19 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_19) goto z_bb_9; else goto z_bb_11;
    z_bb_9:
    zT_22 = 16;
    zT_23 = (unsigned char)zT_22;
    base = zT_23;
    zT_24 = self;
    zT_25 = zF_7C2FDD01_lexerAdvance(zT_24);
    (void)zT_25;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_5;
    z_bb_11:
    if ((unsigned char)(next == (unsigned char)(98))) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_28 = next == (unsigned char)(66);
    goto z_bb_14;
    z_bb_13:
    zT_28 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_28) goto z_bb_15; else goto z_bb_17;
    z_bb_15:
    zT_31 = 2;
    zT_32 = (unsigned char)zT_31;
    base = zT_32;
    zT_33 = self;
    zT_34 = zF_7C2FDD01_lexerAdvance(zT_33);
    (void)zT_34;
    goto z_bb_16;
    z_bb_16:
    goto z_bb_10;
    z_bb_17:
    if ((unsigned char)(next == (unsigned char)(111))) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_37 = next == (unsigned char)(79);
    goto z_bb_20;
    z_bb_19:
    zT_37 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_37) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_40 = 8;
    zT_41 = (unsigned char)zT_40;
    base = zT_41;
    zT_42 = self;
    zT_43 = zF_7C2FDD01_lexerAdvance(zT_42);
    (void)zT_43;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_16;
    z_bb_23:
    zT_44 = self;
    zT_45 = zF_07BC1EA1_lexerIsAtEnd(zT_44);
    if ((unsigned char)(!zT_45)) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_48 = self;
    zT_49 = zF_6ACB12FA_lexerPeek(zT_48);
    c = zT_49;
    if ((unsigned char)(c == (unsigned char)(95))) goto z_bb_27; else goto z_bb_28;
    z_bb_25:
    zT_60 = 10;
    if ((unsigned char)(base == zT_60)) goto z_bb_31; else goto z_bb_32;
    z_bb_26:
    goto z_bb_23;
    z_bb_27:
    zT_52 = self;
    zT_53 = zF_7C2FDD01_lexerAdvance(zT_52);
    (void)zT_53;
    goto z_bb_26;
    z_bb_28:
    zT_54 = c;
    zT_55 = base;
    zT_56 = zF_C5E3A034_isDigitInBase(zT_54, zT_55);
    if ((unsigned char)(!zT_56)) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    goto z_bb_25;
    z_bb_30:
    zT_58 = self;
    zT_59 = zF_7C2FDD01_lexerAdvance(zT_58);
    (void)zT_59;
    goto z_bb_26;
    z_bb_31:
    zT_63 = self;
    zT_64 = zF_6ACB12FA_lexerPeek(zT_63);
    zT_62 = zT_64 == (unsigned char)(46);
    goto z_bb_33;
    z_bb_32:
    zT_62 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_62) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_68 = self;
    zT_70 = 1;
    zT_72 = zF_D1AE715C_lexerPeekN(zT_68, (unsigned int)((unsigned int)zT_70));
    zT_67 = zT_72 != (unsigned char)(46);
    goto z_bb_36;
    z_bb_35:
    zT_67 = 0;
    goto z_bb_36;
    z_bb_36:
    if (zT_67) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_75 = self;
    zT_76 = zF_7C2FDD01_lexerAdvance(zT_75);
    (void)zT_76;
    zT_77 = 1;
    is_float = zT_77;
    goto z_bb_39;
    z_bb_38:
    zT_93 = 10;
    if ((unsigned char)(base == zT_93)) goto z_bb_47; else goto z_bb_48;
    z_bb_39:
    zT_78 = self;
    zT_79 = zF_07BC1EA1_lexerIsAtEnd(zT_78);
    if ((unsigned char)(!zT_79)) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_82 = self;
    zT_83 = zF_6ACB12FA_lexerPeek(zT_82);
    c = zT_83;
    if ((unsigned char)(c == (unsigned char)(95))) goto z_bb_43; else goto z_bb_44;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    goto z_bb_39;
    z_bb_43:
    zT_86 = self;
    zT_87 = zF_7C2FDD01_lexerAdvance(zT_86);
    (void)zT_87;
    goto z_bb_42;
    z_bb_44:
    zT_88 = c;
    zT_89 = zF_C95A8EC6_isDigit(zT_88);
    if ((unsigned char)(!zT_89)) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    goto z_bb_41;
    z_bb_46:
    zT_91 = self;
    zT_92 = zF_7C2FDD01_lexerAdvance(zT_91);
    (void)zT_92;
    goto z_bb_42;
    z_bb_47:
    zT_96 = self;
    zT_97 = zF_6ACB12FA_lexerPeek(zT_96);
    if ((unsigned char)(zT_97 == (unsigned char)(101))) goto z_bb_51; else goto z_bb_50;
    z_bb_48:
    zT_95 = 0;
    goto z_bb_49;
    z_bb_49:
    if (zT_95) goto z_bb_53; else goto z_bb_54;
    z_bb_50:
    zT_101 = self;
    zT_102 = zF_6ACB12FA_lexerPeek(zT_101);
    zT_100 = zT_102 == (unsigned char)(69);
    goto z_bb_52;
    z_bb_51:
    zT_100 = 1;
    goto z_bb_52;
    z_bb_52:
    zT_95 = zT_100;
    goto z_bb_49;
    z_bb_53:
    zT_105 = self;
    zT_106 = zF_7C2FDD01_lexerAdvance(zT_105);
    (void)zT_106;
    zT_107 = self;
    zT_108 = zF_6ACB12FA_lexerPeek(zT_107);
    if ((unsigned char)(zT_108 == (unsigned char)(43))) goto z_bb_56; else goto z_bb_55;
    z_bb_54:
    zT_130 = self->source;
    zT_131 = zT_130.ptr;
    zT_132 = zT_130.len;
    zT_133 = self->pos;
    zT_134 = zT_131 + start;
    zT_135 = zT_133 - start;
    zT_136 = start <= zT_133;
    if (!(zT_136)) { pal_trap(); }
    zT_137 = zT_133 <= zT_132;
    if (!(zT_137)) { pal_trap(); }
    zT_138.ptr = (unsigned char*)zT_134;
    zT_138.len = zT_135;
    text = zT_138;
    if (is_float) goto z_bb_67; else goto z_bb_69;
    z_bb_55:
    zT_112 = self;
    zT_113 = zF_6ACB12FA_lexerPeek(zT_112);
    zT_111 = zT_113 == (unsigned char)(45);
    goto z_bb_57;
    z_bb_56:
    zT_111 = 1;
    goto z_bb_57;
    z_bb_57:
    if (zT_111) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_116 = self;
    zT_117 = zF_7C2FDD01_lexerAdvance(zT_116);
    (void)zT_117;
    goto z_bb_59;
    z_bb_59:
    goto z_bb_60;
    z_bb_60:
    zT_118 = self;
    zT_119 = zF_07BC1EA1_lexerIsAtEnd(zT_118);
    if ((unsigned char)(!zT_119)) goto z_bb_64; else goto z_bb_65;
    z_bb_61:
    zT_126 = self;
    zT_127 = zF_7C2FDD01_lexerAdvance(zT_126);
    (void)zT_127;
    goto z_bb_63;
    z_bb_62:
    zT_128 = 1;
    is_float = zT_128;
    goto z_bb_54;
    z_bb_63:
    goto z_bb_60;
    z_bb_64:
    zT_123 = self;
    zT_124 = zF_6ACB12FA_lexerPeek(zT_123);
    zT_122 = zT_124;
    zT_125 = zF_C95A8EC6_isDigit(zT_122);
    zT_121 = zT_125;
    goto z_bb_66;
    z_bb_65:
    zT_121 = 0;
    goto z_bb_66;
    z_bb_66:
    if (zT_121) goto z_bb_61; else goto z_bb_62;
    z_bb_67:
    zT_140 = text;
    zT_141 = zF_37CDE8A4_parseF64(zT_140);
    value = zT_141;
    zT_142 = self;
    zT_144 = start;
    zT_148.float_val = value;
    zT_145 = zT_148;
    zT_149 = zF_369DD718_lexerMakeToken(zT_142, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_float_literal), zT_144, zT_145);
    return zT_149;
    { zT_3A355BD2_Token zT_ret_void = {0}; return zT_ret_void; }
    z_bb_69:
    zT_151 = text;
    zT_152 = base;
    zT_153 = zF_8EC79679_parseU64(zT_151, zT_152);
    value_1 = zT_153;
    zT_154 = Z98_U64_C(18446744073709551615);
    if ((unsigned char)(value_1 == (zT_79FAE712_u64)zT_154)) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_157 = text;
    zT_158 = zF_6E4D822B_isU64MaxLiteral(zT_157);
    zT_156 = !zT_158;
    goto z_bb_72;
    z_bb_71:
    zT_156 = 0;
    goto z_bb_72;
    z_bb_72:
    if (zT_156) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_161 = "integer literal overflow; value truncated";
    zT_163 = 41;
    zT_162.ptr = (unsigned char*)zT_161;
    zT_162.len = zT_163;
    overflow_msg = zT_162;
    zT_164 = self->count_only;
    if ((unsigned char)(!zT_164)) goto z_bb_75; else goto z_bb_76;
    z_bb_74:
    zT_182 = self;
    zT_184 = start;
    zT_188.int_val = value_1;
    zT_185 = zT_188;
    zT_189 = zF_369DD718_lexerMakeToken(zT_182, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_integer_literal), zT_184, zT_185);
    return zT_189;
    z_bb_75:
    zT_166 = self->diag;
    zT_174 = 1;
    zT_169 = self->file_id;
    zT_179 = self->pos;
    zT_172 = overflow_msg;
    (void)zF_C82559AC_diagnosticCollector(zT_166, (unsigned char)((unsigned char)zT_174), (unsigned short)(7), zT_169, (unsigned int)((unsigned int)start), (unsigned int)((unsigned int)zT_179), zT_172);
    goto z_bb_76;
    z_bb_76:
    goto z_bb_74;
}

/* lexerScanIdentifierOrKeyword */
zT_3A355BD2_Token zF_EC7F12C5_lexerScanIdentifier(zT_138FFB41_Lexer* self, unsigned int start) {
    zT_138FFB41_Lexer* zT_2;
    unsigned char zT_3;
    zT_138FFB41_Lexer* zT_6;
    unsigned char zT_7;
    unsigned char zT_8;
    unsigned char zT_9;
    unsigned char zT_11;
    unsigned char zT_12;
    unsigned char zT_13;
    unsigned char zT_15;
    zT_138FFB41_Lexer* zT_18;
    unsigned char zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned char* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned char* zT_25;
    unsigned int zT_26;
    unsigned char zT_27;
    unsigned char zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_31;
    int zT_32;
    unsigned char zT_34;
    unsigned char* zT_35;
    int zT_36;
    unsigned int zT_37;
    unsigned char zT_38;
    unsigned char zT_39;
    int zT_43;
    unsigned int zT_44;
    unsigned char zT_45;
    zT_D3EB6303_StringInterner* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_50;
    zT_138FFB41_Lexer* zT_51;
    unsigned int zT_53;
    zT_85CBA4DB_TokenValue zT_54;
    zT_85CBA4DB_TokenValue zT_57;
    zT_3A355BD2_Token zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    zT_ABDCB870_Opt_85 zT_60;
    unsigned char zT_61;
    zT_138FFB41_Lexer* zT_63;
    zT_EAC3E484_TokenKind zT_64;
    unsigned int zT_65;
    zT_85CBA4DB_TokenValue zT_66;
    zT_85CBA4DB_TokenValue zT_67;
    zT_3A355BD2_Token zT_69;
    int zT_71;
    unsigned int zT_72;
    unsigned char zT_73;
    zT_D3EB6303_StringInterner* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_78;
    unsigned int zT_80;
    unsigned char* zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    unsigned char zT_86;
    unsigned char zT_87;
    unsigned char zT_90;
    unsigned char* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned char zT_94;
    unsigned char zT_95;
    unsigned char zT_98;
    unsigned char* zT_99;
    unsigned int zT_100;
    unsigned int zT_101;
    unsigned char zT_102;
    unsigned char zT_103;
    unsigned char zT_106;
    unsigned char* zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    unsigned char zT_110;
    unsigned char zT_111;
    unsigned char zT_114;
    unsigned char* zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    unsigned char zT_118;
    unsigned char zT_119;
    unsigned char zT_122;
    unsigned char* zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned char zT_126;
    unsigned char zT_127;
    unsigned char zT_130;
    unsigned char* zT_131;
    unsigned int zT_132;
    unsigned int zT_133;
    unsigned char zT_134;
    unsigned char zT_135;
    unsigned char zT_138;
    unsigned char* zT_139;
    unsigned int zT_140;
    unsigned int zT_141;
    unsigned char zT_142;
    unsigned char zT_143;
    unsigned char zT_146;
    unsigned char* zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    unsigned char zT_150;
    unsigned char zT_151;
    unsigned char zT_154;
    unsigned char* zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    unsigned int zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    zT_138FFB41_Lexer* zT_161;
    unsigned int zT_163;
    zT_85CBA4DB_TokenValue zT_164;
    zT_85CBA4DB_TokenValue zT_167;
    zT_3A355BD2_Token zT_168;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zig_poison_fill((void*)&zT_19, (unsigned int)sizeof zT_19);
    zig_poison_fill((void*)&zT_50, (unsigned int)sizeof zT_50);
    zig_poison_fill((void*)&zT_58, (unsigned int)sizeof zT_58);
    zig_poison_fill((void*)&zT_60, (unsigned int)sizeof zT_60);
    zig_poison_fill((void*)&zT_67, (unsigned int)sizeof zT_67);
    zig_poison_fill((void*)&zT_69, (unsigned int)sizeof zT_69);
    zig_poison_fill((void*)&zT_78, (unsigned int)sizeof zT_78);
    zig_poison_fill((void*)&zT_168, (unsigned int)sizeof zT_168);
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    unsigned int string_id;
    zT_EAC3E484_TokenKind kind;
    zT_8F083A69_Slice_zT_0B42B2F8_u lxm;
    goto z_bb_1;
    z_bb_1:
    zT_2 = self;
    zT_3 = zF_07BC1EA1_lexerIsAtEnd(zT_2);
    if ((unsigned char)(!zT_3)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_6 = self;
    zT_7 = zF_6ACB12FA_lexerPeek(zT_6);
    c = zT_7;
    zT_8 = c;
    zT_9 = zF_0D29E41B_isAlpha(zT_8);
    if ((unsigned char)(!zT_9)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_21 = self->source;
    zT_22 = zT_21.ptr;
    zT_23 = zT_21.len;
    zT_24 = self->pos;
    zT_25 = zT_22 + start;
    zT_26 = zT_24 - start;
    zT_27 = start <= zT_24;
    if (!(zT_27)) { pal_trap(); }
    zT_28 = zT_24 <= zT_23;
    if (!(zT_28)) { pal_trap(); }
    zT_29.ptr = (unsigned char*)zT_25;
    zT_29.len = zT_26;
    text = zT_29;
    zT_31 = text.len;
    zT_32 = 1;
    if ((unsigned char)(zT_31 == (unsigned int)zT_32)) goto z_bb_13; else goto z_bb_14;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_12 = c;
    zT_13 = zF_C95A8EC6_isDigit(zT_12);
    zT_11 = !zT_13;
    goto z_bb_7;
    z_bb_6:
    zT_11 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_11) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_15 = c != (unsigned char)(95);
    goto z_bb_10;
    z_bb_9:
    zT_15 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_15) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    goto z_bb_3;
    z_bb_12:
    zT_18 = self;
    zT_19 = zF_7C2FDD01_lexerAdvance(zT_18);
    (void)zT_19;
    goto z_bb_4;
    z_bb_13:
    zT_35 = text.ptr;
    zT_36 = 0;
    zT_37 = text.len;
    zT_38 = (unsigned int)zT_36 < zT_37;
    if (!(zT_38)) { pal_trap(); }
    zT_39 = zT_35[zT_36];
    zT_34 = zT_39 == (unsigned char)(95);
    goto z_bb_15;
    z_bb_14:
    zT_34 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_34) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_43 = 0;
    zT_44 = (unsigned int)zT_43;
    string_id = zT_44;
    zT_45 = self->count_only;
    if ((unsigned char)(!zT_45)) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    zT_59 = text;
    zT_60 = zF_6FF3ED46_lookupKeyword(zT_59);
    zT_61 = zT_60.has_value;
    if (zT_61) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    zT_47 = self->interner;
    zT_48 = text;
    zT_50 = zF_50C274AF_stringInternerInter(zT_47, zT_48);
    string_id = zT_50;
    goto z_bb_19;
    z_bb_19:
    zT_51 = self;
    zT_53 = start;
    zT_57.string_id = string_id;
    zT_54 = zT_57;
    zT_58 = zF_369DD718_lexerMakeToken(zT_51, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore), zT_53, zT_54);
    return zT_58;
    z_bb_20:
    if (!(zT_60.has_value)) { pal_trap(); }
    kind = zT_60.value;
    zT_63 = self;
    zT_64 = kind;
    zT_65 = start;
    zT_66 = zT_67;
    zT_69 = zF_369DD718_lexerMakeToken(zT_63, zT_64, zT_65, zT_66);
    return zT_69;
    z_bb_21:
    zT_71 = 0;
    zT_72 = (unsigned int)zT_71;
    string_id = zT_72;
    zT_73 = self->count_only;
    if ((unsigned char)(!zT_73)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_75 = self->interner;
    zT_76 = text;
    zT_78 = zF_50C274AF_stringInternerInter(zT_75, zT_76);
    string_id = zT_78;
    goto z_bb_23;
    z_bb_23:
    zT_80 = text.len;
    if ((unsigned char)(zT_80 == (unsigned int)(9))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_83 = text.ptr;
    zT_84 = 0;
    zT_85 = text.len;
    zT_86 = zT_84 < zT_85;
    if (!(zT_86)) { pal_trap(); }
    zT_87 = zT_83[zT_84];
    if ((unsigned char)(zT_87 == (unsigned char)(110))) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    zT_161 = self;
    zT_163 = start;
    zT_167.string_id = string_id;
    zT_164 = zT_167;
    zT_168 = zF_369DD718_lexerMakeToken(zT_161, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier), zT_163, zT_164);
    return zT_168;
    z_bb_26:
    zT_91 = text.ptr;
    zT_92 = 1;
    zT_93 = text.len;
    zT_94 = zT_92 < zT_93;
    if (!(zT_94)) { pal_trap(); }
    zT_95 = zT_91[zT_92];
    zT_90 = zT_95 == (unsigned char)(101);
    goto z_bb_28;
    z_bb_27:
    zT_90 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_90) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_99 = text.ptr;
    zT_100 = 2;
    zT_101 = text.len;
    zT_102 = zT_100 < zT_101;
    if (!(zT_102)) { pal_trap(); }
    zT_103 = zT_99[zT_100];
    zT_98 = zT_103 == (unsigned char)(105);
    goto z_bb_31;
    z_bb_30:
    zT_98 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_98) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_107 = text.ptr;
    zT_108 = 3;
    zT_109 = text.len;
    zT_110 = zT_108 < zT_109;
    if (!(zT_110)) { pal_trap(); }
    zT_111 = zT_107[zT_108];
    zT_106 = zT_111 == (unsigned char)(103);
    goto z_bb_34;
    z_bb_33:
    zT_106 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_106) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_115 = text.ptr;
    zT_116 = 4;
    zT_117 = text.len;
    zT_118 = zT_116 < zT_117;
    if (!(zT_118)) { pal_trap(); }
    zT_119 = zT_115[zT_116];
    zT_114 = zT_119 == (unsigned char)(104);
    goto z_bb_37;
    z_bb_36:
    zT_114 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_114) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_123 = text.ptr;
    zT_124 = 5;
    zT_125 = text.len;
    zT_126 = zT_124 < zT_125;
    if (!(zT_126)) { pal_trap(); }
    zT_127 = zT_123[zT_124];
    zT_122 = zT_127 == (unsigned char)(98);
    goto z_bb_40;
    z_bb_39:
    zT_122 = 0;
    goto z_bb_40;
    z_bb_40:
    if (zT_122) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_131 = text.ptr;
    zT_132 = 6;
    zT_133 = text.len;
    zT_134 = zT_132 < zT_133;
    if (!(zT_134)) { pal_trap(); }
    zT_135 = zT_131[zT_132];
    zT_130 = zT_135 == (unsigned char)(111);
    goto z_bb_43;
    z_bb_42:
    zT_130 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_130) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_139 = text.ptr;
    zT_140 = 7;
    zT_141 = text.len;
    zT_142 = zT_140 < zT_141;
    if (!(zT_142)) { pal_trap(); }
    zT_143 = zT_139[zT_140];
    zT_138 = zT_143 == (unsigned char)(114);
    goto z_bb_46;
    z_bb_45:
    zT_138 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_138) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_147 = text.ptr;
    zT_148 = 8;
    zT_149 = text.len;
    zT_150 = zT_148 < zT_149;
    if (!(zT_150)) { pal_trap(); }
    zT_151 = zT_147[zT_148];
    zT_146 = zT_151 == (unsigned char)(115);
    goto z_bb_49;
    z_bb_48:
    zT_146 = 0;
    goto z_bb_49;
    z_bb_49:
    if (zT_146) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_154 = self->count_only;
    if ((unsigned char)(!zT_154)) goto z_bb_52; else goto z_bb_53;
    z_bb_51:
    goto z_bb_25;
    z_bb_52:
    zT_157 = "LEX";
    zT_159 = 3;
    zT_158.ptr = (unsigned char*)zT_157;
    zT_158.len = zT_159;
    lxm = zT_158;
    zT_160 = lxm;
    zF_E4B2EF19_stderr_write(zT_160);
    goto z_bb_53;
    z_bb_53:
    goto z_bb_51;
}

/* lexerScanBuiltinIdentifier */
zT_3A355BD2_Token zF_9C3BDAA8_lexerScanBuiltinIde(zT_138FFB41_Lexer* self, unsigned int start) {
    zT_138FFB41_Lexer* zT_2;
    unsigned char zT_3;
    zT_138FFB41_Lexer* zT_6;
    unsigned char zT_7;
    unsigned char zT_8;
    unsigned char zT_9;
    unsigned char zT_11;
    zT_138FFB41_Lexer* zT_14;
    unsigned char zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned char* zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    int zT_27;
    unsigned int zT_28;
    unsigned char zT_29;
    zT_D3EB6303_StringInterner* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned char* zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned char zT_42;
    unsigned char zT_43;
    unsigned char zT_46;
    unsigned char* zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned char zT_50;
    unsigned char zT_51;
    unsigned char zT_54;
    unsigned char* zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned char zT_58;
    unsigned char zT_59;
    unsigned char zT_62;
    unsigned char* zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned char zT_66;
    unsigned char zT_67;
    unsigned char zT_70;
    unsigned char* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned char zT_74;
    unsigned char zT_75;
    unsigned char zT_78;
    unsigned char* zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    unsigned char zT_82;
    unsigned char zT_83;
    unsigned char zT_86;
    unsigned char* zT_87;
    unsigned int zT_88;
    unsigned int zT_89;
    unsigned char zT_90;
    unsigned char zT_91;
    unsigned char zT_94;
    unsigned char* zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    unsigned char zT_98;
    unsigned char zT_99;
    unsigned char zT_102;
    unsigned char* zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    unsigned char zT_106;
    unsigned char zT_107;
    zT_138FFB41_Lexer* zT_110;
    unsigned int zT_112;
    zT_85CBA4DB_TokenValue zT_113;
    zT_85CBA4DB_TokenValue zT_116;
    zT_3A355BD2_Token zT_117;
    zT_138FFB41_Lexer* zT_118;
    unsigned int zT_120;
    zT_85CBA4DB_TokenValue zT_121;
    zT_85CBA4DB_TokenValue zT_124;
    zT_3A355BD2_Token zT_125;
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    zig_poison_fill((void*)&zT_7, (unsigned int)sizeof zT_7);
    zig_poison_fill((void*)&zT_9, (unsigned int)sizeof zT_9);
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_34, (unsigned int)sizeof zT_34);
    zig_poison_fill((void*)&zT_117, (unsigned int)sizeof zT_117);
    zig_poison_fill((void*)&zT_125, (unsigned int)sizeof zT_125);
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    unsigned int string_id;
    goto z_bb_1;
    z_bb_1:
    zT_2 = self;
    zT_3 = zF_07BC1EA1_lexerIsAtEnd(zT_2);
    if ((unsigned char)(!zT_3)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_6 = self;
    zT_7 = zF_6ACB12FA_lexerPeek(zT_6);
    c = zT_7;
    zT_8 = c;
    zT_9 = zF_97170599_isAlphaNum(zT_8);
    if ((unsigned char)(!zT_9)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_17 = self->source;
    zT_18 = zT_17.ptr;
    zT_19 = zT_17.len;
    zT_20 = self->pos;
    zT_21 = zT_18 + start;
    zT_22 = zT_20 - start;
    zT_23 = start <= zT_20;
    if (!(zT_23)) { pal_trap(); }
    zT_24 = zT_20 <= zT_19;
    if (!(zT_24)) { pal_trap(); }
    zT_25.ptr = (unsigned char*)zT_21;
    zT_25.len = zT_22;
    text = zT_25;
    zT_27 = 0;
    zT_28 = (unsigned int)zT_27;
    string_id = zT_28;
    zT_29 = self->count_only;
    if ((unsigned char)(!zT_29)) goto z_bb_10; else goto z_bb_11;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_11 = c != (unsigned char)(95);
    goto z_bb_7;
    z_bb_6:
    zT_11 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_11) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    goto z_bb_3;
    z_bb_9:
    zT_14 = self;
    zT_15 = zF_7C2FDD01_lexerAdvance(zT_14);
    (void)zT_15;
    goto z_bb_4;
    z_bb_10:
    zT_31 = self->interner;
    zT_32 = text;
    zT_34 = zF_50C274AF_stringInternerInter(zT_31, zT_32);
    string_id = zT_34;
    goto z_bb_11;
    z_bb_11:
    zT_36 = text.len;
    if ((unsigned char)(zT_36 == (unsigned int)(9))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_39 = text.ptr;
    zT_40 = 0;
    zT_41 = text.len;
    zT_42 = zT_40 < zT_41;
    if (!(zT_42)) { pal_trap(); }
    zT_43 = zT_39[zT_40];
    if ((unsigned char)(zT_43 == (unsigned char)(64))) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_118 = self;
    zT_120 = start;
    zT_124.string_id = string_id;
    zT_121 = zT_124;
    zT_125 = zF_369DD718_lexerMakeToken(zT_118, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_builtin_identifier), zT_120, zT_121);
    return zT_125;
    z_bb_14:
    zT_47 = text.ptr;
    zT_48 = 1;
    zT_49 = text.len;
    zT_50 = zT_48 < zT_49;
    if (!(zT_50)) { pal_trap(); }
    zT_51 = zT_47[zT_48];
    zT_46 = zT_51 == (unsigned char)(99);
    goto z_bb_16;
    z_bb_15:
    zT_46 = 0;
    goto z_bb_16;
    z_bb_16:
    if (zT_46) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_55 = text.ptr;
    zT_56 = 2;
    zT_57 = text.len;
    zT_58 = zT_56 < zT_57;
    if (!(zT_58)) { pal_trap(); }
    zT_59 = zT_55[zT_56];
    zT_54 = zT_59 == (unsigned char)(73);
    goto z_bb_19;
    z_bb_18:
    zT_54 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_54) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_63 = text.ptr;
    zT_64 = 3;
    zT_65 = text.len;
    zT_66 = zT_64 < zT_65;
    if (!(zT_66)) { pal_trap(); }
    zT_67 = zT_63[zT_64];
    zT_62 = zT_67 == (unsigned char)(110);
    goto z_bb_22;
    z_bb_21:
    zT_62 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_62) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_71 = text.ptr;
    zT_72 = 4;
    zT_73 = text.len;
    zT_74 = zT_72 < zT_73;
    if (!(zT_74)) { pal_trap(); }
    zT_75 = zT_71[zT_72];
    zT_70 = zT_75 == (unsigned char)(99);
    goto z_bb_25;
    z_bb_24:
    zT_70 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_70) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_79 = text.ptr;
    zT_80 = 5;
    zT_81 = text.len;
    zT_82 = zT_80 < zT_81;
    if (!(zT_82)) { pal_trap(); }
    zT_83 = zT_79[zT_80];
    zT_78 = zT_83 == (unsigned char)(108);
    goto z_bb_28;
    z_bb_27:
    zT_78 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_78) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_87 = text.ptr;
    zT_88 = 6;
    zT_89 = text.len;
    zT_90 = zT_88 < zT_89;
    if (!(zT_90)) { pal_trap(); }
    zT_91 = zT_87[zT_88];
    zT_86 = zT_91 == (unsigned char)(117);
    goto z_bb_31;
    z_bb_30:
    zT_86 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_86) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_95 = text.ptr;
    zT_96 = 7;
    zT_97 = text.len;
    zT_98 = zT_96 < zT_97;
    if (!(zT_98)) { pal_trap(); }
    zT_99 = zT_95[zT_96];
    zT_94 = zT_99 == (unsigned char)(100);
    goto z_bb_34;
    z_bb_33:
    zT_94 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_94) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_103 = text.ptr;
    zT_104 = 8;
    zT_105 = text.len;
    zT_106 = zT_104 < zT_105;
    if (!(zT_106)) { pal_trap(); }
    zT_107 = zT_103[zT_104];
    zT_102 = zT_107 == (unsigned char)(101);
    goto z_bb_37;
    z_bb_36:
    zT_102 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_102) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_110 = self;
    zT_112 = start;
    zT_116.string_id = string_id;
    zT_113 = zT_116;
    zT_117 = zF_369DD718_lexerMakeToken(zT_110, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_c_include_builtin), zT_112, zT_113);
    return zT_117;
    z_bb_39:
    goto z_bb_13;
}

/* isAlpha */
unsigned char zF_0D29E41B_isAlpha(unsigned char c) {
    unsigned char zT_3;
    unsigned char zT_6;
    unsigned char zT_9;
    unsigned char zT_12;
    if ((unsigned char)(c >= (unsigned char)(97))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_3 = c <= (unsigned char)(122);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(c >= (unsigned char)(65))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_6 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_6) goto z_bb_11; else goto z_bb_10;
    z_bb_7:
    zT_9 = c <= (unsigned char)(90);
    goto z_bb_9;
    z_bb_8:
    zT_9 = 0;
    goto z_bb_9;
    z_bb_9:
    zT_6 = zT_9;
    goto z_bb_6;
    z_bb_10:
    zT_12 = c == (unsigned char)(95);
    goto z_bb_12;
    z_bb_11:
    zT_12 = 1;
    goto z_bb_12;
    z_bb_12:
    return zT_12;
}

/* isDigit */
unsigned char zF_C95A8EC6_isDigit(unsigned char c) {
    unsigned char zT_3;
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_3 = c <= (unsigned char)(57);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 0;
    goto z_bb_3;
    z_bb_3:
    return zT_3;
}

/* isAlphaNum */
unsigned char zF_97170599_isAlphaNum(unsigned char c) {
    unsigned char zT_1;
    unsigned char zT_2;
    unsigned char zT_3;
    unsigned char zT_4;
    unsigned char zT_5;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    zT_1 = c;
    zT_2 = zF_0D29E41B_isAlpha(zT_1);
    if (zT_2) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = c;
    zT_5 = zF_C95A8EC6_isDigit(zT_4);
    zT_3 = zT_5;
    goto z_bb_3;
    z_bb_2:
    zT_3 = 1;
    goto z_bb_3;
    z_bb_3:
    return zT_3;
}

/* hexDigitValue */
unsigned char zF_24E4C5BC_hexDigitValue(unsigned char c) {
    unsigned char zT_3;
    unsigned char zT_6;
    unsigned char zT_7;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned char zT_13;
    unsigned char zT_16;
    unsigned char zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    int zT_21;
    unsigned char zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    unsigned char zT_28;
    unsigned char zT_31;
    unsigned char zT_32;
    unsigned int zT_33;
    unsigned char zT_35;
    int zT_36;
    unsigned char zT_37;
    unsigned int zT_38;
    unsigned char zT_40;
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_3 = c <= (unsigned char)(57);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_6 = 48;
    zT_7 = zig_wrap_sub_u(((zu64)(c)), ((zu64)(zT_6)), 8u);
    zT_8 = zig_overflow_flag_sub_u(((zu64)(c)), ((zu64)(zT_6)), 8u);
    zT_10 = zT_8 == (unsigned int)(0);
    if (!(zT_10)) { pal_trap(); }
    return zT_7;
    z_bb_5:
    if ((unsigned char)(c >= (unsigned char)(97))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_13 = c <= (unsigned char)(102);
    goto z_bb_8;
    z_bb_7:
    zT_13 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_13) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_16 = 97;
    zT_17 = zig_wrap_sub_u(((zu64)(c)), ((zu64)(zT_16)), 8u);
    zT_18 = zig_overflow_flag_sub_u(((zu64)(c)), ((zu64)(zT_16)), 8u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_21 = 10;
    zT_22 = zig_wrap_add_u(((zu64)(zT_17)), ((zu64)(zT_21)), 8u);
    zT_23 = zig_overflow_flag_add_u(((zu64)(zT_17)), ((zu64)(zT_21)), 8u);
    zT_25 = zT_23 == (unsigned int)(0);
    if (!(zT_25)) { pal_trap(); }
    return zT_22;
    z_bb_10:
    if ((unsigned char)(c >= (unsigned char)(65))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_28 = c <= (unsigned char)(70);
    goto z_bb_13;
    z_bb_12:
    zT_28 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_28) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_31 = 65;
    zT_32 = zig_wrap_sub_u(((zu64)(c)), ((zu64)(zT_31)), 8u);
    zT_33 = zig_overflow_flag_sub_u(((zu64)(c)), ((zu64)(zT_31)), 8u);
    zT_35 = zT_33 == (unsigned int)(0);
    if (!(zT_35)) { pal_trap(); }
    zT_36 = 10;
    zT_37 = zig_wrap_add_u(((zu64)(zT_32)), ((zu64)(zT_36)), 8u);
    zT_38 = zig_overflow_flag_add_u(((zu64)(zT_32)), ((zu64)(zT_36)), 8u);
    zT_40 = zT_38 == (unsigned int)(0);
    if (!(zT_40)) { pal_trap(); }
    return zT_37;
    z_bb_15:
    return (unsigned char)(255);
}

/* lexerParseHexEscape */
unsigned char zF_3EAE09C6_lexerParseHexEscape(zT_138FFB41_Lexer* self) {
    int zT_2;
    unsigned char zT_3;
    int zT_5;
    unsigned char zT_6;
    int zT_7;
    unsigned char zT_9;
    zT_138FFB41_Lexer* zT_10;
    unsigned char zT_11;
    unsigned char zT_14;
    zT_138FFB41_Lexer* zT_15;
    unsigned char zT_16;
    unsigned char zT_17;
    int zT_18;
    int zT_20;
    unsigned char zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    unsigned char zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    zT_138FFB41_Lexer* zT_29;
    unsigned char zT_30;
    int zT_31;
    unsigned char zT_32;
    unsigned char zT_33;
    unsigned int zT_34;
    unsigned char zT_36;
    int zT_37;
    unsigned char* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42;
    unsigned char zT_43;
    zT_F85C5DED_DiagnosticCollector* zT_45;
    unsigned int zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    int zT_53;
    unsigned int zT_57;
    int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned char zT_62;
    unsigned int zT_64;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zig_poison_fill((void*)&zT_16, (unsigned int)sizeof zT_16);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_30, (unsigned int)sizeof zT_30);
    unsigned char value;
    unsigned char count;
    unsigned char digit;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_hex;
    zT_2 = 0;
    zT_3 = (unsigned char)zT_2;
    value = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned char)zT_5;
    count = zT_6;
    goto z_bb_1;
    z_bb_1:
    zT_7 = 2;
    if ((unsigned char)(count < zT_7)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_15 = self;
    zT_16 = zF_6ACB12FA_lexerPeek(zT_15);
    zT_14 = zT_16;
    zT_17 = zF_24E4C5BC_hexDigitValue(zT_14);
    digit = zT_17;
    zT_18 = 255;
    if ((unsigned char)(digit == zT_18)) goto z_bb_8; else goto z_bb_9;
    z_bb_3:
    zT_37 = 0;
    if ((unsigned char)(count == zT_37)) goto z_bb_10; else goto z_bb_11;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_10 = self;
    zT_11 = zF_07BC1EA1_lexerIsAtEnd(zT_10);
    zT_9 = !zT_11;
    goto z_bb_7;
    z_bb_6:
    zT_9 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_9) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    goto z_bb_3;
    z_bb_9:
    zT_20 = 16;
    zT_21 = zig_wrap_mul_u(((zu64)(value)), ((zu64)(zT_20)), 8u);
    zT_22 = zig_overflow_flag_mul_u(((zu64)(value)), ((zu64)(zT_20)), 8u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    zT_25 = zig_wrap_add_u(((zu64)(zT_21)), ((zu64)(digit)), 8u);
    zT_26 = zig_overflow_flag_add_u(((zu64)(zT_21)), ((zu64)(digit)), 8u);
    zT_28 = zT_26 == (unsigned int)(0);
    if (!(zT_28)) { pal_trap(); }
    value = zT_25;
    zT_29 = self;
    zT_30 = zF_7C2FDD01_lexerAdvance(zT_29);
    (void)zT_30;
    zT_31 = 1;
    zT_32 = (unsigned char)zT_31;
    zT_33 = zig_wrap_add_u(((zu64)(count)), ((zu64)(zT_32)), 8u);
    zT_34 = zig_overflow_flag_add_u(((zu64)(count)), ((zu64)(zT_32)), 8u);
    zT_36 = zT_34 == (unsigned int)(0);
    if (!(zT_36)) { pal_trap(); }
    count = zT_33;
    goto z_bb_4;
    z_bb_10:
    zT_40 = "\\x requires at least one hex digit";
    zT_42 = 34;
    zT_41.ptr = (unsigned char*)zT_40;
    zT_41.len = zT_42;
    s_hex = zT_41;
    zT_43 = self->count_only;
    if ((unsigned char)(!zT_43)) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    return value;
    z_bb_12:
    zT_45 = self->diag;
    zT_53 = 0;
    zT_48 = self->file_id;
    zT_57 = self->pos;
    zT_58 = 2;
    zT_59 = zig_wrap_sub_u(((zu64)(zT_57)), ((zu64)(zT_58)), 32u);
    zT_60 = zig_overflow_flag_sub_u(((zu64)(zT_57)), ((zu64)(zT_58)), 32u);
    zT_62 = zT_60 == (unsigned int)(0);
    if (!(zT_62)) { pal_trap(); }
    zT_64 = self->pos;
    zT_51 = s_hex;
    (void)zF_C82559AC_diagnosticCollector(zT_45, (unsigned char)((unsigned char)zT_53), (unsigned short)(3), zT_48, (unsigned int)((unsigned int)zT_59), (unsigned int)((unsigned int)zT_64), zT_51);
    goto z_bb_13;
    z_bb_13:
    goto z_bb_11;
}

/* lexerParseEscapeSequence */
unsigned char zF_7D4EA30A_lexerParseEscapeSeq(zT_138FFB41_Lexer* self) {
    zT_138FFB41_Lexer* zT_1;
    unsigned char zT_2;
    zT_138FFB41_Lexer* zT_5;
    unsigned char zT_6;
    zT_138FFB41_Lexer* zT_14;
    unsigned char zT_15;
    unsigned char zT_16;
    unsigned char* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    zT_BBAAFAE2_Arr_unsigned_char_2 zT_23;
    int zT_24;
    unsigned char zT_26;
    unsigned char zT_27;
    int zT_28;
    unsigned char zT_30;
    unsigned char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_36;
    unsigned int zT_37;
    int zT_40;
    int zT_41;
    unsigned char* zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    zT_D3EB6303_StringInterner* zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_49;
    zT_F85C5DED_DiagnosticCollector* zT_51;
    int zT_53;
    unsigned char zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_F85C5DED_DiagnosticCollector* zT_59;
    unsigned int zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    int zT_67;
    unsigned int zT_71;
    int zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    unsigned char zT_76;
    unsigned int zT_78;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zig_poison_fill((void*)&zT_6, (unsigned int)sizeof zT_6);
    zig_poison_fill((void*)&zT_15, (unsigned int)sizeof zT_15);
    zig_poison_fill((void*)&zT_58, (unsigned int)sizeof zT_58);
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u ue1;
    zT_BBAAFAE2_Arr_unsigned_char_2 ue_char_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u ue3;
    zT_4C214FEE_Arr_zT_8F083A69_Sli ueparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_unesc;
    zT_1 = self;
    zT_2 = zF_07BC1EA1_lexerIsAtEnd(zT_1);
    if (zT_2) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(92);
    z_bb_2:
    zT_5 = self;
    zT_6 = zF_7C2FDD01_lexerAdvance(zT_5);
    c = zT_6;
switch (c) {
case 110: goto z_bb_3;
case 116: goto z_bb_4;
case 114: goto z_bb_5;
case 92: goto z_bb_6;
case 34: goto z_bb_7;
case 39: goto z_bb_8;
case 48: goto z_bb_9;
case 120: goto z_bb_10;
default: goto z_bb_11;
}
    z_bb_3:
    return (unsigned char)(10);
    z_bb_4:
    return (unsigned char)(9);
    z_bb_5:
    return (unsigned char)(13);
    z_bb_6:
    return (unsigned char)(92);
    z_bb_7:
    return (unsigned char)(34);
    z_bb_8:
    return (unsigned char)(39);
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_14 = self;
    zT_15 = zF_3EAE09C6_lexerParseHexEscape(zT_14);
    return zT_15;
    z_bb_11:
    zT_16 = self->count_only;
    if ((unsigned char)(!zT_16)) goto z_bb_14; else goto z_bb_15;
    return 0;
    z_bb_14:
    zT_19 = "unrecognized escape sequence: '\\";
    zT_21 = 32;
    zT_20.ptr = (unsigned char*)zT_19;
    zT_20.len = zT_21;
    ue1 = zT_20;
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    {
    unsigned int _i = 0;
    while (_i < 2) {
        ue_char_buf[_i] = zT_23[_i];
        _i++;
    }
}
    zT_24 = 0;
    zT_26 = (unsigned int)zT_24 < (unsigned int)(2);
    if (!(zT_26)) { pal_trap(); }
    ue_char_buf[zT_24] = c;
    zT_27 = 0;
    zT_28 = 1;
    zT_30 = (unsigned int)zT_28 < (unsigned int)(2);
    if (!(zT_30)) { pal_trap(); }
    ue_char_buf[zT_28] = zT_27;
    zT_32 = "'";
    zT_34 = 1;
    zT_33.ptr = (unsigned char*)zT_32;
    zT_33.len = zT_34;
    ue3 = zT_33;
    zT_37 = 0;
    zT_36[zT_37] = ue1;
    zT_40 = 1;
    zT_41 = 0;
    zT_42 = (unsigned char*)((unsigned char*)ue_char_buf) + zT_41;
    zT_43 = zT_40 - zT_41;
    zT_44.ptr = (unsigned char*)zT_42;
    zT_44.len = zT_43;
    zT_45 = 1;
    zT_36[zT_45] = zT_44;
    zT_46 = 2;
    zT_36[zT_46] = ue3;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        ueparts[_i] = zT_36[_i];
        _i++;
    }
}
    zT_51 = self->diag;
    zT_48 = zT_51->interner;
    zT_53 = 0;
    zT_55 = (unsigned int)zT_53 < (unsigned int)(3);
    if (!(zT_55)) { pal_trap(); }
    zT_56 = ueparts + zT_53;
    zT_49 = zT_56;
    zT_58 = zF_8C4BFF7C_diagnosticBuilderMa(zT_48, zT_49, (unsigned int)(3));
    s_unesc = zT_58;
    zT_59 = self->diag;
    zT_67 = 1;
    zT_62 = self->file_id;
    zT_71 = self->pos;
    zT_72 = 2;
    zT_73 = zig_wrap_sub_u(((zu64)(zT_71)), ((zu64)(zT_72)), 32u);
    zT_74 = zig_overflow_flag_sub_u(((zu64)(zT_71)), ((zu64)(zT_72)), 32u);
    zT_76 = zT_74 == (unsigned int)(0);
    if (!(zT_76)) { pal_trap(); }
    zT_78 = self->pos;
    zT_65 = s_unesc;
    (void)zF_C82559AC_diagnosticCollector(zT_59, (unsigned char)((unsigned char)zT_67), (unsigned short)(6), zT_62, (unsigned int)((unsigned int)zT_73), (unsigned int)((unsigned int)zT_78), zT_65);
    goto z_bb_15;
    z_bb_15:
    return c;
}

/* isDigitInBase */
unsigned char zF_C5E3A034_isDigitInBase(unsigned char c, unsigned char base) {
    unsigned char zT_4;
    unsigned char zT_9;
    unsigned char zT_14;
    unsigned char zT_19;
    unsigned char zT_22;
    unsigned char zT_25;
    unsigned char zT_28;
    unsigned char zT_31;
switch (base) {
case 2: goto z_bb_1;
case 8: goto z_bb_2;
case 10: goto z_bb_3;
case 16: goto z_bb_4;
default: goto z_bb_5;
}
    z_bb_1:
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_8; else goto z_bb_9;
    z_bb_2:
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_11; else goto z_bb_12;
    z_bb_3:
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_14; else goto z_bb_15;
    z_bb_4:
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_17; else goto z_bb_18;
    z_bb_5:
    return (unsigned char)(0);
    return 0;
    z_bb_8:
    zT_4 = c <= (unsigned char)(49);
    goto z_bb_10;
    z_bb_9:
    zT_4 = 0;
    goto z_bb_10;
    z_bb_10:
    return zT_4;
    z_bb_11:
    zT_9 = c <= (unsigned char)(55);
    goto z_bb_13;
    z_bb_12:
    zT_9 = 0;
    goto z_bb_13;
    z_bb_13:
    return zT_9;
    z_bb_14:
    zT_14 = c <= (unsigned char)(57);
    goto z_bb_16;
    z_bb_15:
    zT_14 = 0;
    goto z_bb_16;
    z_bb_16:
    return zT_14;
    z_bb_17:
    zT_19 = c <= (unsigned char)(57);
    goto z_bb_19;
    z_bb_18:
    zT_19 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_19) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    if ((unsigned char)(c >= (unsigned char)(97))) goto z_bb_23; else goto z_bb_24;
    z_bb_21:
    zT_22 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_22) goto z_bb_27; else goto z_bb_26;
    z_bb_23:
    zT_25 = c <= (unsigned char)(102);
    goto z_bb_25;
    z_bb_24:
    zT_25 = 0;
    goto z_bb_25;
    z_bb_25:
    zT_22 = zT_25;
    goto z_bb_22;
    z_bb_26:
    if ((unsigned char)(c >= (unsigned char)(65))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    zT_28 = 1;
    goto z_bb_28;
    z_bb_28:
    return zT_28;
    z_bb_29:
    zT_31 = c <= (unsigned char)(70);
    goto z_bb_31;
    z_bb_30:
    zT_31 = 0;
    goto z_bb_31;
    z_bb_31:
    zT_28 = zT_31;
    goto z_bb_28;
}

/* parseU64 */
zT_79FAE712_u64 zF_8EC79679_parseU64(zT_8F083A69_Slice_zT_0B42B2F8_u text, unsigned char base) {
    int zT_3;
    zT_79FAE712_u64 zT_4;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_9;
    int zT_10;
    unsigned char zT_12;
    unsigned char* zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned char zT_16;
    unsigned char zT_17;
    unsigned char* zT_21;
    int zT_22;
    unsigned int zT_23;
    unsigned char zT_24;
    unsigned char zT_25;
    unsigned char zT_28;
    unsigned char zT_31;
    unsigned char zT_34;
    unsigned char zT_37;
    unsigned char zT_40;
    int zT_43;
    unsigned int zT_44;
    unsigned int zT_46;
    unsigned char* zT_49;
    unsigned int zT_50;
    unsigned char zT_51;
    unsigned char zT_52;
    int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned char zT_58;
    int zT_62;
    zT_79FAE712_u64 zT_63;
    unsigned char zT_65;
    unsigned char zT_68;
    unsigned char zT_71;
    unsigned char zT_72;
    unsigned int zT_73;
    unsigned char zT_75;
    zT_79FAE712_u64 zT_76;
    unsigned char zT_79;
    unsigned char zT_82;
    unsigned char zT_83;
    unsigned int zT_84;
    unsigned char zT_86;
    int zT_87;
    unsigned char zT_88;
    unsigned int zT_89;
    unsigned char zT_91;
    zT_79FAE712_u64 zT_92;
    unsigned char zT_95;
    unsigned char zT_98;
    unsigned char zT_99;
    unsigned int zT_100;
    unsigned char zT_102;
    int zT_103;
    unsigned char zT_104;
    unsigned int zT_105;
    unsigned char zT_107;
    zT_79FAE712_u64 zT_108;
    unsigned char zT_109;
    zT_79FAE712_u64 zT_113;
    zT_79FAE712_u64 zT_116;
    zT_79FAE712_u64 zT_117;
    zT_79FAE712_u64 zT_119;
    unsigned char zT_121;
    zT_79FAE712_u64 zT_123;
    unsigned int zT_124;
    unsigned char zT_126;
    zT_79FAE712_u64 zT_128;
    unsigned int zT_129;
    unsigned char zT_131;
    zT_79FAE712_u64 zT_133;
    unsigned int zT_134;
    unsigned char zT_136;
    zT_79FAE712_u64 result;
    unsigned int i;
    unsigned char p;
    unsigned char c;
    zT_79FAE712_u64 digit;
    unsigned char found_digit;
    zT_79FAE712_u64 base_u64;
    zT_79FAE712_u64 max_u64;
    zT_79FAE712_u64 max_before_mul;
    zT_79FAE712_u64 after_mul;
    zT_3 = 0;
    zT_4 = (zT_79FAE712_u64)zT_3;
    result = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned int)zT_6;
    i = zT_7;
    zT_9 = text.len;
    zT_10 = 2;
    if ((unsigned char)(zT_9 > (unsigned int)zT_10)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = text.ptr;
    zT_14 = 0;
    zT_15 = text.len;
    zT_16 = (unsigned int)zT_14 < zT_15;
    if (!(zT_16)) { pal_trap(); }
    zT_17 = zT_13[zT_14];
    zT_12 = zT_17 == (unsigned char)(48);
    goto z_bb_3;
    z_bb_2:
    zT_12 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_12) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_21 = text.ptr;
    zT_22 = 1;
    zT_23 = text.len;
    zT_24 = (unsigned int)zT_22 < zT_23;
    if (!(zT_24)) { pal_trap(); }
    zT_25 = zT_21[zT_22];
    p = zT_25;
    if ((unsigned char)(p == (unsigned char)(120))) goto z_bb_7; else goto z_bb_6;
    z_bb_5:
    goto z_bb_23;
    z_bb_6:
    zT_28 = p == (unsigned char)(88);
    goto z_bb_8;
    z_bb_7:
    zT_28 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_28) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_31 = p == (unsigned char)(98);
    goto z_bb_11;
    z_bb_10:
    zT_31 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_31) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_34 = p == (unsigned char)(66);
    goto z_bb_14;
    z_bb_13:
    zT_34 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_34) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_37 = p == (unsigned char)(111);
    goto z_bb_17;
    z_bb_16:
    zT_37 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_37) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_40 = p == (unsigned char)(79);
    goto z_bb_20;
    z_bb_19:
    zT_40 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_40) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_43 = 2;
    zT_44 = (unsigned int)zT_43;
    i = zT_44;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_5;
    z_bb_23:
    zT_46 = text.len;
    if ((unsigned char)(i < zT_46)) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_49 = text.ptr;
    zT_50 = text.len;
    zT_51 = i < zT_50;
    if (!(zT_51)) { pal_trap(); }
    zT_52 = zT_49[i];
    c = zT_52;
    zT_53 = 1;
    zT_54 = (unsigned int)zT_53;
    zT_55 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_54)), 32u);
    zT_56 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_54)), 32u);
    zT_58 = zT_56 == (unsigned int)(0);
    if (!(zT_58)) { pal_trap(); }
    i = zT_55;
    if ((unsigned char)(c == (unsigned char)(95))) goto z_bb_27; else goto z_bb_28;
    z_bb_25:
    return result;
    z_bb_26:
    goto z_bb_23;
    z_bb_27:
    goto z_bb_26;
    z_bb_28:
    zT_62 = 0;
    zT_63 = (zT_79FAE712_u64)zT_62;
    digit = zT_63;
    zT_65 = 1;
    found_digit = zT_65;
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_68 = c <= (unsigned char)(57);
    goto z_bb_31;
    z_bb_30:
    zT_68 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_68) goto z_bb_32; else goto z_bb_34;
    z_bb_32:
    zT_71 = 48;
    zT_72 = zig_wrap_sub_u(((zu64)(c)), ((zu64)(zT_71)), 8u);
    zT_73 = zig_overflow_flag_sub_u(((zu64)(c)), ((zu64)(zT_71)), 8u);
    zT_75 = zT_73 == (unsigned int)(0);
    if (!(zT_75)) { pal_trap(); }
    zT_76 = (zT_79FAE712_u64)zT_72;
    digit = zT_76;
    goto z_bb_33;
    z_bb_33:
    if ((unsigned char)(!found_digit)) goto z_bb_47; else goto z_bb_48;
    z_bb_34:
    if ((unsigned char)(c >= (unsigned char)(97))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_79 = c <= (unsigned char)(102);
    goto z_bb_37;
    z_bb_36:
    zT_79 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_79) goto z_bb_38; else goto z_bb_40;
    z_bb_38:
    zT_82 = 97;
    zT_83 = zig_wrap_sub_u(((zu64)(c)), ((zu64)(zT_82)), 8u);
    zT_84 = zig_overflow_flag_sub_u(((zu64)(c)), ((zu64)(zT_82)), 8u);
    zT_86 = zT_84 == (unsigned int)(0);
    if (!(zT_86)) { pal_trap(); }
    zT_87 = 10;
    zT_88 = zig_wrap_add_u(((zu64)(zT_83)), ((zu64)(zT_87)), 8u);
    zT_89 = zig_overflow_flag_add_u(((zu64)(zT_83)), ((zu64)(zT_87)), 8u);
    zT_91 = zT_89 == (unsigned int)(0);
    if (!(zT_91)) { pal_trap(); }
    zT_92 = (zT_79FAE712_u64)zT_88;
    digit = zT_92;
    goto z_bb_39;
    z_bb_39:
    goto z_bb_33;
    z_bb_40:
    if ((unsigned char)(c >= (unsigned char)(65))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_95 = c <= (unsigned char)(70);
    goto z_bb_43;
    z_bb_42:
    zT_95 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_95) goto z_bb_44; else goto z_bb_46;
    z_bb_44:
    zT_98 = 65;
    zT_99 = zig_wrap_sub_u(((zu64)(c)), ((zu64)(zT_98)), 8u);
    zT_100 = zig_overflow_flag_sub_u(((zu64)(c)), ((zu64)(zT_98)), 8u);
    zT_102 = zT_100 == (unsigned int)(0);
    if (!(zT_102)) { pal_trap(); }
    zT_103 = 10;
    zT_104 = zig_wrap_add_u(((zu64)(zT_99)), ((zu64)(zT_103)), 8u);
    zT_105 = zig_overflow_flag_add_u(((zu64)(zT_99)), ((zu64)(zT_103)), 8u);
    zT_107 = zT_105 == (unsigned int)(0);
    if (!(zT_107)) { pal_trap(); }
    zT_108 = (zT_79FAE712_u64)zT_104;
    digit = zT_108;
    goto z_bb_45;
    z_bb_45:
    goto z_bb_39;
    z_bb_46:
    zT_109 = 0;
    found_digit = zT_109;
    goto z_bb_45;
    z_bb_47:
    goto z_bb_25;
    z_bb_48:
    zT_113 = (zT_79FAE712_u64)(unsigned int)((unsigned int)base);
    base_u64 = zT_113;
    if ((unsigned char)(digit >= base_u64)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    goto z_bb_25;
    z_bb_50:
    zT_116 = Z98_U64_C(18446744073709551615);
    zT_117 = (zT_79FAE712_u64)zT_116;
    max_u64 = zT_117;
    zT_121 = base_u64 != (unsigned int)(0);
    if (!(zT_121)) { pal_trap(); }
    zT_119 = max_u64 / base_u64;
    max_before_mul = zT_119;
    if ((unsigned char)(result > max_before_mul)) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    return max_u64;
    z_bb_52:
    zT_123 = zig_wrap_mul_u(((zu64)(result)), ((zu64)(base_u64)), 64u);
    zT_124 = zig_overflow_flag_mul_u(((zu64)(result)), ((zu64)(base_u64)), 64u);
    zT_126 = zT_124 == (unsigned int)(0);
    if (!(zT_126)) { pal_trap(); }
    result = zT_123;
    after_mul = result;
    zT_128 = zig_wrap_sub_u(((zu64)(max_u64)), ((zu64)(digit)), 64u);
    zT_129 = zig_overflow_flag_sub_u(((zu64)(max_u64)), ((zu64)(digit)), 64u);
    zT_131 = zT_129 == (unsigned int)(0);
    if (!(zT_131)) { pal_trap(); }
    if ((unsigned char)(after_mul > zT_128)) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    return max_u64;
    z_bb_54:
    zT_133 = zig_wrap_add_u(((zu64)(result)), ((zu64)(digit)), 64u);
    zT_134 = zig_overflow_flag_add_u(((zu64)(result)), ((zu64)(digit)), 64u);
    zT_136 = zT_134 == (unsigned int)(0);
    if (!(zT_136)) { pal_trap(); }
    result = zT_133;
    goto z_bb_26;
}

/* f64FromBits */
zT_00435AEB_f64 zF_E24707C3_f64FromBits(zT_79FAE712_u64 bits) {
    zT_79FAE712_u64* zT_2;
    zT_00435AEB_f64* zT_3;
    zT_00435AEB_f64 zT_4;
    zT_00435AEB_f64* p;
    zT_2 = (zT_79FAE712_u64*)&bits;
    zT_3 = (zT_00435AEB_f64*)zT_2;
    p = zT_3;
    zT_4 = *p;
    return zT_4;
}

/* f64SignedZero */
zT_00435AEB_f64 zF_4836A299_f64SignedZero(unsigned char negative) {
    zT_79FAE712_u64 zT_2;
    zT_00435AEB_f64 zT_4;
    int zT_6;
    zT_00435AEB_f64 zT_8;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    if (negative) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_2 = Z98_U64_C(9223372036854775808);
    zT_4 = zF_E24707C3_f64FromBits((zT_79FAE712_u64)((zT_79FAE712_u64)zT_2));
    return zT_4;
    z_bb_2:
    zT_6 = 0;
    zT_8 = zF_E24707C3_f64FromBits((zT_79FAE712_u64)((zT_79FAE712_u64)zT_6));
    return zT_8;
}

/* f64SignedInf */
zT_00435AEB_f64 zF_5493CDCE_f64SignedInf(unsigned char negative) {
    zT_79FAE712_u64 zT_2;
    zT_00435AEB_f64 zT_4;
    zT_79FAE712_u64 zT_6;
    zT_00435AEB_f64 zT_8;
    zig_poison_fill((void*)&zT_4, (unsigned int)sizeof zT_4);
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    if (negative) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_2 = Z98_U64_C(18442240474082181120);
    zT_4 = zF_E24707C3_f64FromBits((zT_79FAE712_u64)((zT_79FAE712_u64)zT_2));
    return zT_4;
    z_bb_2:
    zT_6 = Z98_U64_C(9218868437227405312);
    zT_8 = zF_E24707C3_f64FromBits((zT_79FAE712_u64)((zT_79FAE712_u64)zT_6));
    return zT_8;
}

/* pow5of */
zT_79FAE712_u64 zF_E87F3361_pow5of(unsigned int k) {
    int zT_2;
    zT_79FAE712_u64 zT_3;
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    zT_79FAE712_u64 zT_9;
    unsigned int zT_10;
    unsigned char zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    zT_79FAE712_u64 r;
    unsigned int i;
    zT_2 = 1;
    zT_3 = (zT_79FAE712_u64)zT_2;
    r = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    i = zT_6;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < k)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = 5;
    zT_9 = zig_wrap_mul_u(((zu64)(r)), ((zu64)(zT_8)), 64u);
    zT_10 = zig_overflow_flag_mul_u(((zu64)(r)), ((zu64)(zT_8)), 64u);
    zT_12 = zT_10 == (unsigned int)(0);
    if (!(zT_12)) { pal_trap(); }
    r = zT_9;
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_14)), 32u);
    zT_16 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_14)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    i = zT_15;
    goto z_bb_4;
    z_bb_3:
    return r;
    z_bb_4:
    goto z_bb_1;
}

/* bitlen128 */
unsigned int zF_DE0896E8_bitlen128(zT_79FAE712_u64 hi, zT_79FAE712_u64 lo) {
    int zT_4;
    unsigned int zT_5;
    int zT_6;
    int zT_8;
    unsigned int zT_9;
    int zT_10;
    int zT_12;
    int zT_15;
    int zT_17;
    zT_79FAE712_u64 zT_18;
    unsigned char zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned char zT_26;
    zT_79FAE712_u64 v;
    unsigned int base;
    unsigned int n;
    v = hi;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    base = zT_5;
    zT_6 = 0;
    if ((unsigned char)(v == (zT_79FAE712_u64)zT_6)) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    v = lo;
    goto z_bb_2;
    z_bb_2:
    zT_10 = 0;
    if ((unsigned char)(v == (zT_79FAE712_u64)zT_10)) goto z_bb_4; else goto z_bb_5;
    z_bb_3:
    zT_8 = 64;
    zT_9 = (unsigned int)zT_8;
    base = zT_9;
    goto z_bb_2;
    z_bb_4:
    zT_12 = 0;
    return (unsigned int)((unsigned int)zT_12);
    z_bb_5:
    n = base;
    goto z_bb_6;
    z_bb_6:
    zT_15 = 0;
    if ((unsigned char)(v != (zT_79FAE712_u64)zT_15)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_17 = 1;
    zT_20 = (unsigned int)zT_17 < (unsigned int)(64);
    if (!(zT_20)) { pal_trap(); }
    zT_18 = v >> zT_17;
    v = zT_18;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zig_wrap_add_u(((zu64)(n)), ((zu64)(zT_22)), 32u);
    zT_24 = zig_overflow_flag_add_u(((zu64)(n)), ((zu64)(zT_22)), 32u);
    zT_26 = zT_24 == (unsigned int)(0);
    if (!(zT_26)) { pal_trap(); }
    n = zT_23;
    goto z_bb_9;
    z_bb_8:
    return n;
    z_bb_9:
    goto z_bb_6;
}

/* shr128 */
zT_79FAE712_u64 zF_17BA7F4D_shr128(zT_79FAE712_u64 hi, zT_79FAE712_u64 lo, unsigned int shift) {
    int zT_3;
    int zT_5;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned char zT_11;
    zT_79FAE712_u64 zT_12;
    unsigned char zT_15;
    zT_79FAE712_u64 zT_16;
    unsigned char zT_19;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_24;
    zT_79FAE712_u64 zT_25;
    zT_79FAE712_u64 zT_26;
    unsigned char zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    zT_3 = 0;
    if ((unsigned char)(shift == (unsigned int)zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return lo;
    z_bb_2:
    zT_5 = 64;
    if ((unsigned char)(shift >= (unsigned int)zT_5)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_7 = 64;
    zT_8 = zig_wrap_sub_u(((zu64)(shift)), ((zu64)(zT_7)), 32u);
    zT_9 = zig_overflow_flag_sub_u(((zu64)(shift)), ((zu64)(zT_7)), 32u);
    zT_11 = zT_9 == (unsigned int)(0);
    if (!(zT_11)) { pal_trap(); }
    zT_12 = (zT_79FAE712_u64)zT_8;
    zT_15 = zT_12 < (unsigned int)(64);
    if (!(zT_15)) { pal_trap(); }
    return (zT_79FAE712_u64)(hi >> zT_12);
    z_bb_4:
    zT_16 = (zT_79FAE712_u64)shift;
    zT_19 = zT_16 < (unsigned int)(64);
    if (!(zT_19)) { pal_trap(); }
    zT_20 = 64;
    zT_21 = zig_wrap_sub_u(((zu64)(zT_20)), ((zu64)(shift)), 32u);
    zT_22 = zig_overflow_flag_sub_u(((zu64)(zT_20)), ((zu64)(shift)), 32u);
    zT_24 = zT_22 == (unsigned int)(0);
    if (!(zT_24)) { pal_trap(); }
    zT_25 = (zT_79FAE712_u64)zT_21;
    zT_28 = zT_25 < (unsigned int)(64);
    if (!(zT_28)) { pal_trap(); }
    zT_26 = zig_wrap_shl_u(((zu64)(hi)), ((zu64)(zT_25)), 64u);
    zT_29 = zig_overflow_flag_shl_u(((zu64)(hi)), ((zu64)(zT_25)), 64u);
    zT_31 = zT_29 == (unsigned int)(0);
    if (!(zT_31)) { pal_trap(); }
    return (zT_79FAE712_u64)((zT_79FAE712_u64)(lo >> zT_16) | zT_26);
}

/* bit128 */
zT_79FAE712_u64 zF_6E7F5C11_bit128(zT_79FAE712_u64 hi, zT_79FAE712_u64 lo, unsigned int i) {
    int zT_3;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_79FAE712_u64 zT_10;
    unsigned char zT_13;
    int zT_14;
    zT_79FAE712_u64 zT_16;
    unsigned char zT_19;
    int zT_20;
    zT_3 = 64;
    if ((unsigned char)(i >= (unsigned int)zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 64;
    zT_6 = zig_wrap_sub_u(((zu64)(i)), ((zu64)(zT_5)), 32u);
    zT_7 = zig_overflow_flag_sub_u(((zu64)(i)), ((zu64)(zT_5)), 32u);
    zT_9 = zT_7 == (unsigned int)(0);
    if (!(zT_9)) { pal_trap(); }
    zT_10 = (zT_79FAE712_u64)zT_6;
    zT_13 = zT_10 < (unsigned int)(64);
    if (!(zT_13)) { pal_trap(); }
    zT_14 = 1;
    return (zT_79FAE712_u64)((zT_79FAE712_u64)(hi >> zT_10) & zT_14);
    z_bb_2:
    zT_16 = (zT_79FAE712_u64)i;
    zT_19 = zT_16 < (unsigned int)(64);
    if (!(zT_19)) { pal_trap(); }
    zT_20 = 1;
    return (zT_79FAE712_u64)((zT_79FAE712_u64)(lo >> zT_16) & zT_20);
}

/* lowNonZero128 */
unsigned char zF_62E97F03_lowNonZero128(zT_79FAE712_u64 hi, zT_79FAE712_u64 lo, unsigned int cnt) {
    int zT_3;
    int zT_6;
    int zT_8;
    int zT_11;
    zT_79FAE712_u64 zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    zT_79FAE712_u64 zT_21;
    zT_79FAE712_u64 zT_22;
    unsigned char zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    int zT_28;
    zT_79FAE712_u64 zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    int zT_34;
    zT_79FAE712_u64 zT_37;
    zT_79FAE712_u64 zT_38;
    zT_79FAE712_u64 zT_39;
    unsigned char zT_41;
    unsigned int zT_42;
    unsigned char zT_44;
    int zT_45;
    zT_79FAE712_u64 zT_46;
    unsigned int zT_47;
    unsigned char zT_49;
    int zT_51;
    zT_79FAE712_u64 lm;
    zT_79FAE712_u64 hm;
    zT_3 = 0;
    if ((unsigned char)(cnt == (unsigned int)zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = 64;
    if ((unsigned char)(cnt >= (unsigned int)zT_6)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8 = 0;
    if ((unsigned char)(lo != (zT_79FAE712_u64)zT_8)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_37 = 1;
    zT_38 = (zT_79FAE712_u64)cnt;
    zT_41 = zT_38 < (unsigned int)(64);
    if (!(zT_41)) { pal_trap(); }
    zT_39 = zig_wrap_shl_u(((zu64)(zT_37)), ((zu64)(zT_38)), 64u);
    zT_42 = zig_overflow_flag_shl_u(((zu64)(zT_37)), ((zu64)(zT_38)), 64u);
    zT_44 = zT_42 == (unsigned int)(0);
    if (!(zT_44)) { pal_trap(); }
    zT_45 = 1;
    zT_46 = zig_wrap_sub_u(((zu64)(zT_39)), ((zu64)(zT_45)), 64u);
    zT_47 = zig_overflow_flag_sub_u(((zu64)(zT_39)), ((zu64)(zT_45)), 64u);
    zT_49 = zT_47 == (unsigned int)(0);
    if (!(zT_49)) { pal_trap(); }
    lm = zT_46;
    zT_51 = 0;
    return (unsigned char)((zT_79FAE712_u64)(lo & lm) != (zT_79FAE712_u64)zT_51);
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    zT_11 = 64;
    if ((unsigned char)(cnt == (unsigned int)zT_11)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_15 = 1;
    zT_16 = 64;
    zT_17 = zig_wrap_sub_u(((zu64)(cnt)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_sub_u(((zu64)(cnt)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    zT_21 = (zT_79FAE712_u64)zT_17;
    zT_24 = zT_21 < (unsigned int)(64);
    if (!(zT_24)) { pal_trap(); }
    zT_22 = zig_wrap_shl_u(((zu64)(zT_15)), ((zu64)(zT_21)), 64u);
    zT_25 = zig_overflow_flag_shl_u(((zu64)(zT_15)), ((zu64)(zT_21)), 64u);
    zT_27 = zT_25 == (unsigned int)(0);
    if (!(zT_27)) { pal_trap(); }
    zT_28 = 1;
    zT_29 = zig_wrap_sub_u(((zu64)(zT_22)), ((zu64)(zT_28)), 64u);
    zT_30 = zig_overflow_flag_sub_u(((zu64)(zT_22)), ((zu64)(zT_28)), 64u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    hm = zT_29;
    zT_34 = 0;
    return (unsigned char)((zT_79FAE712_u64)(hi & hm) != (zT_79FAE712_u64)zT_34);
}

/* fastRound */
zT_00435AEB_f64 zF_13EBBFAD_fastRound(zT_79FAE712_u64 qhi, zT_79FAE712_u64 qlo, unsigned char sticky, int e_prime, unsigned char negative) {
    zT_79FAE712_u64 zT_6;
    zT_79FAE712_u64 zT_7;
    unsigned int zT_8;
    int zT_9;
    int zT_10;
    unsigned char zT_12;
    zT_00435AEB_f64 zT_13;
    int zT_15;
    unsigned int zT_16;
    unsigned char zT_18;
    int zT_19;
    int zT_20;
    unsigned int zT_21;
    unsigned char zT_23;
    int zT_24;
    int zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    int zT_29;
    unsigned char zT_31;
    zT_00435AEB_f64 zT_32;
    int zT_33;
    int zT_34;
    unsigned int zT_35;
    unsigned char zT_37;
    int zT_38;
    int zT_41;
    unsigned char zT_43;
    int zT_44;
    zT_79FAE712_u64 zT_45;
    unsigned int zT_46;
    unsigned char zT_48;
    int zT_50;
    unsigned char zT_52;
    unsigned char zT_54;
    zT_00435AEB_f64 zT_55;
    int zT_57;
    zT_79FAE712_u64 zT_58;
    zT_79FAE712_u64 zT_59;
    zT_79FAE712_u64 zT_60;
    int zT_62;
    zT_00435AEB_f64 zT_64;
    int zT_66;
    int zT_67;
    int zT_68;
    int zT_69;
    unsigned int zT_70;
    unsigned char zT_72;
    int zT_73;
    int zT_75;
    int zT_76;
    unsigned int zT_77;
    unsigned char zT_79;
    int zT_81;
    zT_79FAE712_u64 zT_82;
    int zT_84;
    unsigned int zT_85;
    unsigned char zT_87;
    int zT_88;
    int zT_90;
    unsigned int zT_91;
    unsigned char zT_93;
    zT_79FAE712_u64 zT_94;
    zT_79FAE712_u64 zT_95;
    unsigned char zT_97;
    unsigned int zT_98;
    unsigned char zT_100;
    zT_79FAE712_u64 zT_101;
    zT_79FAE712_u64 zT_102;
    unsigned int zT_103;
    zT_79FAE712_u64 zT_105;
    zT_79FAE712_u64 zT_107;
    zT_79FAE712_u64 zT_108;
    unsigned int zT_109;
    int zT_110;
    int zT_111;
    unsigned int zT_112;
    unsigned char zT_114;
    zT_79FAE712_u64 zT_116;
    unsigned char zT_118;
    zT_79FAE712_u64 zT_119;
    zT_79FAE712_u64 zT_120;
    unsigned int zT_121;
    int zT_122;
    int zT_123;
    unsigned int zT_124;
    unsigned char zT_126;
    unsigned char zT_128;
    int zT_129;
    unsigned char zT_131;
    unsigned char zT_132;
    int zT_133;
    int zT_135;
    int zT_137;
    zT_79FAE712_u64 zT_138;
    unsigned int zT_139;
    unsigned char zT_141;
    int zT_142;
    zT_79FAE712_u64 zT_144;
    int zT_145;
    zT_79FAE712_u64 zT_146;
    unsigned char zT_148;
    unsigned int zT_149;
    unsigned char zT_151;
    zT_79FAE712_u64 zT_153;
    int zT_154;
    zT_79FAE712_u64 zT_155;
    unsigned char zT_157;
    unsigned int zT_158;
    unsigned char zT_160;
    int zT_161;
    int zT_162;
    unsigned int zT_163;
    unsigned char zT_165;
    int zT_166;
    unsigned char zT_168;
    zT_00435AEB_f64 zT_169;
    int zT_171;
    int zT_172;
    unsigned int zT_173;
    unsigned char zT_175;
    zT_79FAE712_u64 zT_176;
    zT_79FAE712_u64 zT_178;
    zT_79FAE712_u64 zT_179;
    int zT_181;
    zT_79FAE712_u64 zT_182;
    unsigned char zT_184;
    unsigned int zT_185;
    unsigned char zT_187;
    zT_79FAE712_u64 zT_188;
    zT_79FAE712_u64 zT_189;
    zT_79FAE712_u64 zT_190;
    zT_79FAE712_u64 zT_191;
    zT_00435AEB_f64 zT_192;
    zT_79FAE712_u64 zT_194;
    zT_00435AEB_f64 zT_196;
    zT_79FAE712_u64 zT_197;
    zT_00435AEB_f64 zT_198;
    zig_poison_fill((void*)&zT_8, (unsigned int)sizeof zT_8);
    zig_poison_fill((void*)&zT_13, (unsigned int)sizeof zT_13);
    zig_poison_fill((void*)&zT_32, (unsigned int)sizeof zT_32);
    zig_poison_fill((void*)&zT_55, (unsigned int)sizeof zT_55);
    zig_poison_fill((void*)&zT_64, (unsigned int)sizeof zT_64);
    zig_poison_fill((void*)&zT_105, (unsigned int)sizeof zT_105);
    zig_poison_fill((void*)&zT_116, (unsigned int)sizeof zT_116);
    zig_poison_fill((void*)&zT_128, (unsigned int)sizeof zT_128);
    zig_poison_fill((void*)&zT_169, (unsigned int)sizeof zT_169);
    zig_poison_fill((void*)&zT_192, (unsigned int)sizeof zT_192);
    zig_poison_fill((void*)&zT_196, (unsigned int)sizeof zT_196);
    zig_poison_fill((void*)&zT_198, (unsigned int)sizeof zT_198);
    int l;
    int e;
    unsigned char is_pow2;
    int prec;
    zT_79FAE712_u64 sign;
    zT_79FAE712_u64 keep;
    int shift;
    zT_79FAE712_u64 round_bit;
    unsigned char sticky2;
    zT_79FAE712_u64 biased;
    zT_79FAE712_u64 frac;
    zT_79FAE712_u64 bits;
    zT_6 = qhi;
    zT_7 = qlo;
    zT_8 = zF_DE0896E8_bitlen128(zT_6, zT_7);
    zT_9 = (int)zig_cast_checked_s((zu64)zT_8, 32u, 0u, 32u);
    l = zT_9;
    zT_10 = 0;
    if ((unsigned char)(l == zT_10)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = negative;
    zT_13 = zF_4836A299_f64SignedZero(zT_12);
    return zT_13;
    z_bb_2:
    zT_15 = zig_wrap_add_s(((z64)(e_prime)), ((z64)(l)), 32u);
    zT_16 = zig_overflow_flag_add_s(((z64)(e_prime)), ((z64)(l)), 32u);
    zT_18 = zT_16 == (unsigned int)(0);
    if (!(zT_18)) { pal_trap(); }
    zT_19 = 1;
    zT_20 = zig_wrap_sub_s(((z64)(zT_15)), ((z64)(zT_19)), 32u);
    zT_21 = zig_overflow_flag_sub_s(((z64)(zT_15)), ((z64)(zT_19)), 32u);
    zT_23 = zT_21 == (unsigned int)(0);
    if (!(zT_23)) { pal_trap(); }
    e = zT_20;
    zT_24 = 1075;
    zT_25 = zig_wrap_add_s(((z64)(e)), ((z64)(zT_24)), 32u);
    zT_26 = zig_overflow_flag_add_s(((z64)(e)), ((z64)(zT_24)), 32u);
    zT_28 = zT_26 == (unsigned int)(0);
    if (!(zT_28)) { pal_trap(); }
    zT_29 = 0;
    if ((unsigned char)(zT_25 < zT_29)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_31 = negative;
    zT_32 = zF_4836A299_f64SignedZero(zT_31);
    return zT_32;
    z_bb_4:
    zT_33 = 1075;
    zT_34 = zig_wrap_add_s(((z64)(e)), ((z64)(zT_33)), 32u);
    zT_35 = zig_overflow_flag_add_s(((z64)(e)), ((z64)(zT_33)), 32u);
    zT_37 = zT_35 == (unsigned int)(0);
    if (!(zT_37)) { pal_trap(); }
    zT_38 = 0;
    if ((unsigned char)(zT_34 == zT_38)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_41 = 0;
    if ((unsigned char)(qhi == (zT_79FAE712_u64)zT_41)) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_66 = 53;
    zT_67 = (int)zT_66;
    prec = zT_67;
    zT_68 = 1022;
    zT_69 = zig_wrap_add_s(((z64)(e)), ((z64)(zT_68)), 32u);
    zT_70 = zig_overflow_flag_add_s(((z64)(e)), ((z64)(zT_68)), 32u);
    zT_72 = zT_70 == (unsigned int)(0);
    if (!(zT_72)) { pal_trap(); }
    zT_73 = 0;
    if ((unsigned char)(zT_69 < zT_73)) goto z_bb_17; else goto z_bb_18;
    z_bb_7:
    zT_44 = 1;
    zT_45 = zig_wrap_sub_u(((zu64)(qlo)), ((zu64)(zT_44)), 64u);
    zT_46 = zig_overflow_flag_sub_u(((zu64)(qlo)), ((zu64)(zT_44)), 64u);
    zT_48 = zT_46 == (unsigned int)(0);
    if (!(zT_48)) { pal_trap(); }
    zT_50 = 0;
    zT_43 = (zT_79FAE712_u64)(qlo & zT_45) == (zT_79FAE712_u64)zT_50;
    goto z_bb_9;
    z_bb_8:
    zT_43 = 0;
    goto z_bb_9;
    z_bb_9:
    is_pow2 = zT_43;
    if (is_pow2) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_52 = !sticky;
    goto z_bb_12;
    z_bb_11:
    zT_52 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_52) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_54 = negative;
    zT_55 = zF_4836A299_f64SignedZero(zT_54);
    return zT_55;
    z_bb_14:
    zT_57 = 0;
    zT_58 = (zT_79FAE712_u64)zT_57;
    sign = zT_58;
    if (negative) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_59 = Z98_U64_C(9223372036854775808);
    zT_60 = (zT_79FAE712_u64)zT_59;
    sign = zT_60;
    goto z_bb_16;
    z_bb_16:
    zT_62 = 1;
    zT_64 = zF_E24707C3_f64FromBits((zT_79FAE712_u64)(zT_62 | sign));
    return zT_64;
    z_bb_17:
    zT_75 = 1075;
    zT_76 = zig_wrap_add_s(((z64)(e)), ((z64)(zT_75)), 32u);
    zT_77 = zig_overflow_flag_add_s(((z64)(e)), ((z64)(zT_75)), 32u);
    zT_79 = zT_77 == (unsigned int)(0);
    if (!(zT_79)) { pal_trap(); }
    prec = zT_76;
    goto z_bb_18;
    z_bb_18:
    zT_81 = 0;
    zT_82 = (zT_79FAE712_u64)zT_81;
    keep = zT_82;
    zT_84 = zig_wrap_sub_s(((z64)(l)), ((z64)(prec)), 32u);
    zT_85 = zig_overflow_flag_sub_s(((z64)(l)), ((z64)(prec)), 32u);
    zT_87 = zT_85 == (unsigned int)(0);
    if (!(zT_87)) { pal_trap(); }
    shift = zT_84;
    zT_88 = 0;
    if ((unsigned char)(shift <= zT_88)) goto z_bb_19; else goto z_bb_21;
    z_bb_19:
    zT_90 = zig_wrap_sub_s(((z64)(prec)), ((z64)(l)), 32u);
    zT_91 = zig_overflow_flag_sub_s(((z64)(prec)), ((z64)(l)), 32u);
    zT_93 = zT_91 == (unsigned int)(0);
    if (!(zT_93)) { pal_trap(); }
    zT_94 = (zT_79FAE712_u64)zig_cast_checked_u((zu64)zT_90, 32u, 1u, 64u);
    zT_97 = zT_94 < (unsigned int)(64);
    if (!(zT_97)) { pal_trap(); }
    zT_95 = zig_wrap_shl_u(((zu64)(qlo)), ((zu64)(zT_94)), 64u);
    zT_98 = zig_overflow_flag_shl_u(((zu64)(qlo)), ((zu64)(zT_94)), 64u);
    zT_100 = zT_98 == (unsigned int)(0);
    if (!(zT_100)) { pal_trap(); }
    keep = zT_95;
    goto z_bb_20;
    z_bb_20:
    zT_142 = 53;
    if ((unsigned char)(prec == zT_142)) goto z_bb_33; else goto z_bb_34;
    z_bb_21:
    zT_101 = qhi;
    zT_102 = qlo;
    zT_103 = (unsigned int)zig_cast_checked_u((zu64)shift, 32u, 1u, 32u);
    zT_105 = zF_17BA7F4D_shr128(zT_101, zT_102, zT_103);
    keep = zT_105;
    zT_107 = qhi;
    zT_108 = qlo;
    zT_110 = 1;
    zT_111 = zig_wrap_sub_s(((z64)(shift)), ((z64)(zT_110)), 32u);
    zT_112 = zig_overflow_flag_sub_s(((z64)(shift)), ((z64)(zT_110)), 32u);
    zT_114 = zT_112 == (unsigned int)(0);
    if (!(zT_114)) { pal_trap(); }
    zT_109 = (unsigned int)zig_cast_checked_u((zu64)zT_111, 32u, 1u, 32u);
    zT_116 = zF_6E7F5C11_bit128(zT_107, zT_108, zT_109);
    round_bit = zT_116;
    if (sticky) goto z_bb_23; else goto z_bb_22;
    z_bb_22:
    zT_119 = qhi;
    zT_120 = qlo;
    zT_122 = 1;
    zT_123 = zig_wrap_sub_s(((z64)(shift)), ((z64)(zT_122)), 32u);
    zT_124 = zig_overflow_flag_sub_s(((z64)(shift)), ((z64)(zT_122)), 32u);
    zT_126 = zT_124 == (unsigned int)(0);
    if (!(zT_126)) { pal_trap(); }
    zT_121 = (unsigned int)zig_cast_checked_u((zu64)zT_123, 32u, 1u, 32u);
    zT_128 = zF_62E97F03_lowNonZero128(zT_119, zT_120, zT_121);
    zT_118 = zT_128;
    goto z_bb_24;
    z_bb_23:
    zT_118 = 1;
    goto z_bb_24;
    z_bb_24:
    sticky2 = zT_118;
    zT_129 = 0;
    if ((unsigned char)(round_bit != (zT_79FAE712_u64)zT_129)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    if (sticky2) goto z_bb_29; else goto z_bb_28;
    z_bb_26:
    zT_131 = 0;
    goto z_bb_27;
    z_bb_27:
    if (zT_131) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_133 = 1;
    zT_135 = 0;
    zT_132 = (zT_79FAE712_u64)(keep & zT_133) != (zT_79FAE712_u64)zT_135;
    goto z_bb_30;
    z_bb_29:
    zT_132 = 1;
    goto z_bb_30;
    z_bb_30:
    zT_131 = zT_132;
    goto z_bb_27;
    z_bb_31:
    zT_137 = 1;
    zT_138 = zig_wrap_add_u(((zu64)(keep)), ((zu64)(zT_137)), 64u);
    zT_139 = zig_overflow_flag_add_u(((zu64)(keep)), ((zu64)(zT_137)), 64u);
    zT_141 = zT_139 == (unsigned int)(0);
    if (!(zT_141)) { pal_trap(); }
    keep = zT_138;
    goto z_bb_32;
    z_bb_32:
    goto z_bb_20;
    z_bb_33:
    zT_144 = 1;
    zT_145 = 53;
    zT_148 = (unsigned int)zT_145 < (unsigned int)(64);
    if (!(zT_148)) { pal_trap(); }
    zT_146 = zig_wrap_shl_u(((zu64)(zT_144)), ((zu64)(zT_145)), 64u);
    zT_149 = zig_overflow_flag_shl_u(((zu64)(zT_144)), ((zu64)(zT_145)), 64u);
    zT_151 = zT_149 == (unsigned int)(0);
    if (!(zT_151)) { pal_trap(); }
    if ((unsigned char)(keep >= zT_146)) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    if (negative) goto z_bb_41; else goto z_bb_42;
    z_bb_35:
    zT_153 = 1;
    zT_154 = 52;
    zT_157 = (unsigned int)zT_154 < (unsigned int)(64);
    if (!(zT_157)) { pal_trap(); }
    zT_155 = zig_wrap_shl_u(((zu64)(zT_153)), ((zu64)(zT_154)), 64u);
    zT_158 = zig_overflow_flag_shl_u(((zu64)(zT_153)), ((zu64)(zT_154)), 64u);
    zT_160 = zT_158 == (unsigned int)(0);
    if (!(zT_160)) { pal_trap(); }
    keep = zT_155;
    zT_161 = 1;
    zT_162 = zig_wrap_add_s(((z64)(e)), ((z64)(zT_161)), 32u);
    zT_163 = zig_overflow_flag_add_s(((z64)(e)), ((z64)(zT_161)), 32u);
    zT_165 = zT_163 == (unsigned int)(0);
    if (!(zT_165)) { pal_trap(); }
    e = zT_162;
    goto z_bb_36;
    z_bb_36:
    zT_166 = 1023;
    if ((unsigned char)(e > zT_166)) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_168 = negative;
    zT_169 = zF_5493CDCE_f64SignedInf(zT_168);
    return zT_169;
    z_bb_38:
    zT_171 = 1023;
    zT_172 = zig_wrap_add_s(((z64)(e)), ((z64)(zT_171)), 32u);
    zT_173 = zig_overflow_flag_add_s(((z64)(e)), ((z64)(zT_171)), 32u);
    zT_175 = zT_173 == (unsigned int)(0);
    if (!(zT_175)) { pal_trap(); }
    zT_176 = (zT_79FAE712_u64)zig_cast_checked_u((zu64)zT_172, 32u, 1u, 64u);
    biased = zT_176;
    zT_178 = Z98_U64_C(4503599627370495);
    zT_179 = keep & zT_178;
    frac = zT_179;
    zT_181 = 52;
    zT_184 = (unsigned int)zT_181 < (unsigned int)(64);
    if (!(zT_184)) { pal_trap(); }
    zT_182 = zig_wrap_shl_u(((zu64)(biased)), ((zu64)(zT_181)), 64u);
    zT_185 = zig_overflow_flag_shl_u(((zu64)(biased)), ((zu64)(zT_181)), 64u);
    zT_187 = zT_185 == (unsigned int)(0);
    if (!(zT_187)) { pal_trap(); }
    zT_188 = zT_182 | frac;
    bits = zT_188;
    if (negative) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_189 = Z98_U64_C(9223372036854775808);
    zT_190 = bits | zT_189;
    bits = zT_190;
    goto z_bb_40;
    z_bb_40:
    zT_191 = bits;
    zT_192 = zF_E24707C3_f64FromBits(zT_191);
    return zT_192;
    z_bb_41:
    zT_194 = Z98_U64_C(9223372036854775808);
    zT_196 = zF_E24707C3_f64FromBits((zT_79FAE712_u64)(keep | zT_194));
    return zT_196;
    z_bb_42:
    zT_197 = keep;
    zT_198 = zF_E24707C3_f64FromBits(zT_197);
    return zT_198;
}

/* hpdTrim */
void zF_BD11B99B_hpdTrim(zT_4324C233_Hpd* h) {
    unsigned int zT_2;
    unsigned int zT_3;
    int zT_4;
    unsigned char zT_6;
    unsigned char* zT_7;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned char zT_12;
    unsigned char zT_14;
    unsigned char zT_15;
    int zT_16;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned char zT_23;
    unsigned int n;
    zT_2 = h->num_digits;
    zT_3 = (unsigned int)zT_2;
    n = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = 0;
    if ((unsigned char)(n != (unsigned int)zT_4)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_18 = 1;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zig_wrap_sub_u(((zu64)(n)), ((zu64)(zT_19)), 32u);
    zT_21 = zig_overflow_flag_sub_u(((zu64)(n)), ((zu64)(zT_19)), 32u);
    zT_23 = zT_21 == (unsigned int)(0);
    if (!(zT_23)) { pal_trap(); }
    n = zT_20;
    goto z_bb_4;
    z_bb_3:
    h->num_digits = (unsigned int)((unsigned int)n);
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_7 = h->digits;
    zT_8 = 1;
    zT_9 = zig_wrap_sub_u(((zu64)(n)), ((zu64)(zT_8)), 32u);
    zT_10 = zig_overflow_flag_sub_u(((zu64)(n)), ((zu64)(zT_8)), 32u);
    zT_12 = zT_10 == (unsigned int)(0);
    if (!(zT_12)) { pal_trap(); }
    zT_14 = zT_9 < (unsigned int)(800);
    if (!(zT_14)) { pal_trap(); }
    zT_15 = zT_7[zT_9];
    zT_16 = 0;
    zT_6 = zT_15 == zT_16;
    goto z_bb_7;
    z_bb_6:
    zT_6 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_6) goto z_bb_2; else goto z_bb_3;
}

/* hpdMul2 */
void zF_0E0CD583_hpdMul2(zT_4324C233_Hpd* h) {
    unsigned int zT_2;
    unsigned int zT_3;
    int zT_4;
    int zT_7;
    unsigned int zT_8;
    int zT_10;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    unsigned char* zT_19;
    unsigned char zT_21;
    unsigned char zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    int zT_33;
    unsigned int zT_34;
    unsigned char zT_36;
    unsigned char zT_37;
    unsigned char* zT_38;
    unsigned char zT_40;
    int zT_41;
    unsigned int zT_42;
    unsigned char zT_44;
    int zT_45;
    int zT_47;
    unsigned char* zT_49;
    int zT_50;
    unsigned char zT_52;
    unsigned char zT_53;
    int zT_54;
    int zT_58;
    unsigned int zT_59;
    int zT_60;
    unsigned char* zT_62;
    int zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned char zT_67;
    unsigned char zT_69;
    unsigned char zT_70;
    unsigned char* zT_71;
    unsigned char zT_73;
    int zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned char zT_79;
    unsigned char zT_80;
    unsigned char* zT_81;
    int zT_82;
    unsigned char zT_84;
    int zT_86;
    unsigned char* zT_88;
    int zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    unsigned char zT_93;
    unsigned char zT_95;
    unsigned char zT_96;
    unsigned char* zT_97;
    unsigned char zT_99;
    int zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    unsigned char zT_105;
    unsigned char zT_106;
    unsigned char* zT_107;
    int zT_108;
    unsigned char zT_110;
    int zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    unsigned char zT_116;
    int zT_118;
    int zT_119;
    int zT_120;
    int zT_121;
    unsigned int zT_122;
    unsigned char zT_124;
    zT_4324C233_Hpd* zT_125;
    unsigned int n;
    unsigned int carry;
    unsigned int i;
    unsigned int t;
    unsigned int j;
    zT_2 = h->num_digits;
    zT_3 = (unsigned int)zT_2;
    n = zT_3;
    zT_4 = 0;
    if ((unsigned char)(n == (unsigned int)zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    carry = zT_8;
    i = n;
    goto z_bb_3;
    z_bb_3:
    zT_10 = 0;
    if ((unsigned char)(i > (unsigned int)zT_10)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_12 = 1;
    zT_13 = (unsigned int)zT_12;
    zT_14 = zig_wrap_sub_u(((zu64)(i)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_sub_u(((zu64)(i)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    i = zT_14;
    zT_19 = h->digits;
    zT_21 = i < (unsigned int)(800);
    if (!(zT_21)) { pal_trap(); }
    zT_22 = zT_19[i];
    zT_23 = (unsigned int)zT_22;
    zT_24 = 2;
    zT_25 = zig_wrap_mul_u(((zu64)(zT_23)), ((zu64)(zT_24)), 32u);
    zT_26 = zig_overflow_flag_mul_u(((zu64)(zT_23)), ((zu64)(zT_24)), 32u);
    zT_28 = zT_26 == (unsigned int)(0);
    if (!(zT_28)) { pal_trap(); }
    zT_29 = zig_wrap_add_u(((zu64)(zT_25)), ((zu64)(carry)), 32u);
    zT_30 = zig_overflow_flag_add_u(((zu64)(zT_25)), ((zu64)(carry)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    t = zT_29;
    zT_33 = 10;
    zT_36 = (unsigned int)zT_33 != (unsigned int)(0);
    if (!(zT_36)) { pal_trap(); }
    zT_34 = t % zT_33;
    zT_37 = (unsigned char)zig_cast_checked_u((zu64)zT_34, 32u, 0u, 8u);
    zT_38 = h->digits;
    zT_40 = i < (unsigned int)(800);
    if (!(zT_40)) { pal_trap(); }
    zT_38[i] = zT_37;
    zT_41 = 10;
    zT_44 = (unsigned int)zT_41 != (unsigned int)(0);
    if (!(zT_44)) { pal_trap(); }
    zT_42 = t / zT_41;
    carry = zT_42;
    goto z_bb_6;
    z_bb_5:
    zT_45 = 0;
    if ((unsigned char)(carry != (unsigned int)zT_45)) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_47 = 800;
    if ((unsigned char)(n == (unsigned int)zT_47)) goto z_bb_9; else goto z_bb_11;
    z_bb_8:
    zT_125 = h;
    zF_BD11B99B_hpdTrim(zT_125);
    return;
    z_bb_9:
    zT_49 = h->digits;
    zT_50 = 799;
    zT_52 = (unsigned int)zT_50 < (unsigned int)(800);
    if (!(zT_52)) { pal_trap(); }
    zT_53 = zT_49[zT_50];
    zT_54 = 0;
    if ((unsigned char)(zT_53 != zT_54)) goto z_bb_12; else goto z_bb_13;
    z_bb_10:
    zT_118 = h->decimal_point;
    zT_119 = 1;
    zT_120 = (int)zT_119;
    zT_121 = zig_wrap_add_s(((z64)(zT_118)), ((z64)(zT_120)), 32u);
    zT_122 = zig_overflow_flag_add_s(((z64)(zT_118)), ((z64)(zT_120)), 32u);
    zT_124 = zT_122 == (unsigned int)(0);
    if (!(zT_124)) { pal_trap(); }
    h->decimal_point = zT_121;
    goto z_bb_8;
    z_bb_11:
    j = n;
    goto z_bb_18;
    z_bb_12:
    h->truncated = (unsigned char)(1);
    goto z_bb_13;
    z_bb_13:
    zT_58 = 799;
    zT_59 = (unsigned int)zT_58;
    j = zT_59;
    goto z_bb_14;
    z_bb_14:
    zT_60 = 0;
    if ((unsigned char)(j > (unsigned int)zT_60)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_62 = h->digits;
    zT_63 = 1;
    zT_64 = zig_wrap_sub_u(((zu64)(j)), ((zu64)(zT_63)), 32u);
    zT_65 = zig_overflow_flag_sub_u(((zu64)(j)), ((zu64)(zT_63)), 32u);
    zT_67 = zT_65 == (unsigned int)(0);
    if (!(zT_67)) { pal_trap(); }
    zT_69 = zT_64 < (unsigned int)(800);
    if (!(zT_69)) { pal_trap(); }
    zT_70 = zT_62[zT_64];
    zT_71 = h->digits;
    zT_73 = j < (unsigned int)(800);
    if (!(zT_73)) { pal_trap(); }
    zT_71[j] = zT_70;
    zT_74 = 1;
    zT_75 = (unsigned int)zT_74;
    zT_76 = zig_wrap_sub_u(((zu64)(j)), ((zu64)(zT_75)), 32u);
    zT_77 = zig_overflow_flag_sub_u(((zu64)(j)), ((zu64)(zT_75)), 32u);
    zT_79 = zT_77 == (unsigned int)(0);
    if (!(zT_79)) { pal_trap(); }
    j = zT_76;
    goto z_bb_17;
    z_bb_16:
    zT_80 = (unsigned char)zig_cast_checked_u((zu64)carry, 32u, 0u, 8u);
    zT_81 = h->digits;
    zT_82 = 0;
    zT_84 = (unsigned int)zT_82 < (unsigned int)(800);
    if (!(zT_84)) { pal_trap(); }
    zT_81[zT_82] = zT_80;
    goto z_bb_10;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    zT_86 = 0;
    if ((unsigned char)(j > (unsigned int)zT_86)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_88 = h->digits;
    zT_89 = 1;
    zT_90 = zig_wrap_sub_u(((zu64)(j)), ((zu64)(zT_89)), 32u);
    zT_91 = zig_overflow_flag_sub_u(((zu64)(j)), ((zu64)(zT_89)), 32u);
    zT_93 = zT_91 == (unsigned int)(0);
    if (!(zT_93)) { pal_trap(); }
    zT_95 = zT_90 < (unsigned int)(800);
    if (!(zT_95)) { pal_trap(); }
    zT_96 = zT_88[zT_90];
    zT_97 = h->digits;
    zT_99 = j < (unsigned int)(800);
    if (!(zT_99)) { pal_trap(); }
    zT_97[j] = zT_96;
    zT_100 = 1;
    zT_101 = (unsigned int)zT_100;
    zT_102 = zig_wrap_sub_u(((zu64)(j)), ((zu64)(zT_101)), 32u);
    zT_103 = zig_overflow_flag_sub_u(((zu64)(j)), ((zu64)(zT_101)), 32u);
    zT_105 = zT_103 == (unsigned int)(0);
    if (!(zT_105)) { pal_trap(); }
    j = zT_102;
    goto z_bb_21;
    z_bb_20:
    zT_106 = (unsigned char)zig_cast_checked_u((zu64)carry, 32u, 0u, 8u);
    zT_107 = h->digits;
    zT_108 = 0;
    zT_110 = (unsigned int)zT_108 < (unsigned int)(800);
    if (!(zT_110)) { pal_trap(); }
    zT_107[zT_108] = zT_106;
    zT_111 = 1;
    zT_112 = (unsigned int)zT_111;
    zT_113 = zig_wrap_add_u(((zu64)(n)), ((zu64)(zT_112)), 32u);
    zT_114 = zig_overflow_flag_add_u(((zu64)(n)), ((zu64)(zT_112)), 32u);
    zT_116 = zT_114 == (unsigned int)(0);
    if (!(zT_116)) { pal_trap(); }
    n = zT_113;
    h->num_digits = (unsigned int)((unsigned int)n);
    goto z_bb_10;
    z_bb_21:
    goto z_bb_18;
}

/* hpdDiv2 */
void zF_A5013D9C_hpdDiv2(zT_4324C233_Hpd* h) {
    unsigned int zT_2;
    unsigned int zT_3;
    int zT_4;
    int zT_7;
    unsigned int zT_8;
    int zT_10;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned char zT_17;
    unsigned char* zT_19;
    unsigned char zT_21;
    unsigned char zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    int zT_33;
    unsigned int zT_34;
    unsigned char zT_36;
    unsigned char zT_37;
    unsigned char* zT_38;
    unsigned char zT_40;
    int zT_41;
    unsigned int zT_42;
    unsigned char zT_44;
    int zT_45;
    int zT_47;
    unsigned char* zT_49;
    int zT_50;
    unsigned char zT_52;
    unsigned char zT_53;
    int zT_54;
    int zT_58;
    unsigned int zT_59;
    int zT_60;
    unsigned char* zT_62;
    int zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned char zT_67;
    unsigned char zT_69;
    unsigned char zT_70;
    unsigned char* zT_71;
    unsigned char zT_73;
    int zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned char zT_79;
    unsigned char zT_80;
    unsigned char* zT_81;
    int zT_82;
    unsigned char zT_84;
    int zT_86;
    unsigned char* zT_88;
    int zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    unsigned char zT_93;
    unsigned char zT_95;
    unsigned char zT_96;
    unsigned char* zT_97;
    unsigned char zT_99;
    int zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    unsigned char zT_105;
    unsigned char zT_106;
    unsigned char* zT_107;
    int zT_108;
    unsigned char zT_110;
    int zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    unsigned char zT_116;
    int zT_118;
    int zT_119;
    int zT_120;
    int zT_121;
    unsigned int zT_122;
    unsigned char zT_124;
    zT_4324C233_Hpd* zT_125;
    unsigned int n;
    unsigned int carry;
    unsigned int i;
    unsigned int t;
    unsigned int j;
    zT_2 = h->num_digits;
    zT_3 = (unsigned int)zT_2;
    n = zT_3;
    zT_4 = 0;
    if ((unsigned char)(n == (unsigned int)zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    carry = zT_8;
    i = n;
    goto z_bb_3;
    z_bb_3:
    zT_10 = 0;
    if ((unsigned char)(i > (unsigned int)zT_10)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_12 = 1;
    zT_13 = (unsigned int)zT_12;
    zT_14 = zig_wrap_sub_u(((zu64)(i)), ((zu64)(zT_13)), 32u);
    zT_15 = zig_overflow_flag_sub_u(((zu64)(i)), ((zu64)(zT_13)), 32u);
    zT_17 = zT_15 == (unsigned int)(0);
    if (!(zT_17)) { pal_trap(); }
    i = zT_14;
    zT_19 = h->digits;
    zT_21 = i < (unsigned int)(800);
    if (!(zT_21)) { pal_trap(); }
    zT_22 = zT_19[i];
    zT_23 = (unsigned int)zT_22;
    zT_24 = 5;
    zT_25 = zig_wrap_mul_u(((zu64)(zT_23)), ((zu64)(zT_24)), 32u);
    zT_26 = zig_overflow_flag_mul_u(((zu64)(zT_23)), ((zu64)(zT_24)), 32u);
    zT_28 = zT_26 == (unsigned int)(0);
    if (!(zT_28)) { pal_trap(); }
    zT_29 = zig_wrap_add_u(((zu64)(zT_25)), ((zu64)(carry)), 32u);
    zT_30 = zig_overflow_flag_add_u(((zu64)(zT_25)), ((zu64)(carry)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    t = zT_29;
    zT_33 = 10;
    zT_36 = (unsigned int)zT_33 != (unsigned int)(0);
    if (!(zT_36)) { pal_trap(); }
    zT_34 = t % zT_33;
    zT_37 = (unsigned char)zig_cast_checked_u((zu64)zT_34, 32u, 0u, 8u);
    zT_38 = h->digits;
    zT_40 = i < (unsigned int)(800);
    if (!(zT_40)) { pal_trap(); }
    zT_38[i] = zT_37;
    zT_41 = 10;
    zT_44 = (unsigned int)zT_41 != (unsigned int)(0);
    if (!(zT_44)) { pal_trap(); }
    zT_42 = t / zT_41;
    carry = zT_42;
    goto z_bb_6;
    z_bb_5:
    zT_45 = 0;
    if ((unsigned char)(carry != (unsigned int)zT_45)) goto z_bb_7; else goto z_bb_9;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_47 = 800;
    if ((unsigned char)(n == (unsigned int)zT_47)) goto z_bb_10; else goto z_bb_12;
    z_bb_8:
    zT_125 = h;
    zF_BD11B99B_hpdTrim(zT_125);
    return;
    z_bb_9:
    zT_118 = h->decimal_point;
    zT_119 = 1;
    zT_120 = (int)zT_119;
    zT_121 = zig_wrap_sub_s(((z64)(zT_118)), ((z64)(zT_120)), 32u);
    zT_122 = zig_overflow_flag_sub_s(((z64)(zT_118)), ((z64)(zT_120)), 32u);
    zT_124 = zT_122 == (unsigned int)(0);
    if (!(zT_124)) { pal_trap(); }
    h->decimal_point = zT_121;
    goto z_bb_8;
    z_bb_10:
    zT_49 = h->digits;
    zT_50 = 799;
    zT_52 = (unsigned int)zT_50 < (unsigned int)(800);
    if (!(zT_52)) { pal_trap(); }
    zT_53 = zT_49[zT_50];
    zT_54 = 0;
    if ((unsigned char)(zT_53 != zT_54)) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    j = n;
    goto z_bb_19;
    z_bb_13:
    h->truncated = (unsigned char)(1);
    goto z_bb_14;
    z_bb_14:
    zT_58 = 799;
    zT_59 = (unsigned int)zT_58;
    j = zT_59;
    goto z_bb_15;
    z_bb_15:
    zT_60 = 0;
    if ((unsigned char)(j > (unsigned int)zT_60)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_62 = h->digits;
    zT_63 = 1;
    zT_64 = zig_wrap_sub_u(((zu64)(j)), ((zu64)(zT_63)), 32u);
    zT_65 = zig_overflow_flag_sub_u(((zu64)(j)), ((zu64)(zT_63)), 32u);
    zT_67 = zT_65 == (unsigned int)(0);
    if (!(zT_67)) { pal_trap(); }
    zT_69 = zT_64 < (unsigned int)(800);
    if (!(zT_69)) { pal_trap(); }
    zT_70 = zT_62[zT_64];
    zT_71 = h->digits;
    zT_73 = j < (unsigned int)(800);
    if (!(zT_73)) { pal_trap(); }
    zT_71[j] = zT_70;
    zT_74 = 1;
    zT_75 = (unsigned int)zT_74;
    zT_76 = zig_wrap_sub_u(((zu64)(j)), ((zu64)(zT_75)), 32u);
    zT_77 = zig_overflow_flag_sub_u(((zu64)(j)), ((zu64)(zT_75)), 32u);
    zT_79 = zT_77 == (unsigned int)(0);
    if (!(zT_79)) { pal_trap(); }
    j = zT_76;
    goto z_bb_18;
    z_bb_17:
    zT_80 = (unsigned char)zig_cast_checked_u((zu64)carry, 32u, 0u, 8u);
    zT_81 = h->digits;
    zT_82 = 0;
    zT_84 = (unsigned int)zT_82 < (unsigned int)(800);
    if (!(zT_84)) { pal_trap(); }
    zT_81[zT_82] = zT_80;
    goto z_bb_11;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_86 = 0;
    if ((unsigned char)(j > (unsigned int)zT_86)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_88 = h->digits;
    zT_89 = 1;
    zT_90 = zig_wrap_sub_u(((zu64)(j)), ((zu64)(zT_89)), 32u);
    zT_91 = zig_overflow_flag_sub_u(((zu64)(j)), ((zu64)(zT_89)), 32u);
    zT_93 = zT_91 == (unsigned int)(0);
    if (!(zT_93)) { pal_trap(); }
    zT_95 = zT_90 < (unsigned int)(800);
    if (!(zT_95)) { pal_trap(); }
    zT_96 = zT_88[zT_90];
    zT_97 = h->digits;
    zT_99 = j < (unsigned int)(800);
    if (!(zT_99)) { pal_trap(); }
    zT_97[j] = zT_96;
    zT_100 = 1;
    zT_101 = (unsigned int)zT_100;
    zT_102 = zig_wrap_sub_u(((zu64)(j)), ((zu64)(zT_101)), 32u);
    zT_103 = zig_overflow_flag_sub_u(((zu64)(j)), ((zu64)(zT_101)), 32u);
    zT_105 = zT_103 == (unsigned int)(0);
    if (!(zT_105)) { pal_trap(); }
    j = zT_102;
    goto z_bb_22;
    z_bb_21:
    zT_106 = (unsigned char)zig_cast_checked_u((zu64)carry, 32u, 0u, 8u);
    zT_107 = h->digits;
    zT_108 = 0;
    zT_110 = (unsigned int)zT_108 < (unsigned int)(800);
    if (!(zT_110)) { pal_trap(); }
    zT_107[zT_108] = zT_106;
    zT_111 = 1;
    zT_112 = (unsigned int)zT_111;
    zT_113 = zig_wrap_add_u(((zu64)(n)), ((zu64)(zT_112)), 32u);
    zT_114 = zig_overflow_flag_add_u(((zu64)(n)), ((zu64)(zT_112)), 32u);
    zT_116 = zT_114 == (unsigned int)(0);
    if (!(zT_116)) { pal_trap(); }
    n = zT_113;
    h->num_digits = (unsigned int)((unsigned int)n);
    goto z_bb_11;
    z_bb_22:
    goto z_bb_19;
}

/* hpdRound */
zT_79FAE712_u64 zF_4EA36099_hpdRound(zT_4324C233_Hpd* h) {
    unsigned int zT_1;
    int zT_2;
    unsigned char zT_4;
    int zT_5;
    int zT_6;
    int zT_8;
    int zT_10;
    int zT_11;
    zT_79FAE712_u64 zT_13;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_22;
    zT_79FAE712_u64 zT_23;
    int zT_25;
    unsigned int zT_26;
    int zT_28;
    zT_79FAE712_u64 zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    unsigned char* zT_34;
    unsigned char zT_36;
    unsigned char zT_37;
    zT_79FAE712_u64 zT_38;
    zT_79FAE712_u64 zT_39;
    unsigned int zT_40;
    unsigned char zT_42;
    int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned char zT_48;
    unsigned char zT_50;
    unsigned char* zT_52;
    unsigned char zT_54;
    unsigned char zT_55;
    int zT_56;
    unsigned char zT_57;
    unsigned char* zT_58;
    unsigned char zT_60;
    unsigned char zT_61;
    int zT_62;
    unsigned char zT_64;
    int zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned char zT_69;
    unsigned char zT_71;
    unsigned char zT_72;
    int zT_73;
    unsigned char zT_75;
    int zT_76;
    unsigned char* zT_77;
    int zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned char zT_82;
    unsigned char zT_84;
    unsigned char zT_85;
    int zT_87;
    int zT_89;
    zT_79FAE712_u64 zT_90;
    unsigned int zT_91;
    unsigned char zT_93;
    unsigned int dp;
    unsigned int n;
    zT_79FAE712_u64 acc;
    unsigned int i;
    unsigned char round_up;
    zT_1 = h->num_digits;
    zT_2 = 0;
    if ((unsigned char)(zT_1 == (unsigned int)zT_2)) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = h->decimal_point;
    zT_6 = 0;
    zT_4 = zT_5 < zT_6;
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_8 = 0;
    return (zT_79FAE712_u64)((zT_79FAE712_u64)zT_8);
    z_bb_5:
    zT_10 = h->decimal_point;
    zT_11 = 18;
    if ((unsigned char)(zT_10 > zT_11)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_13 = Z98_U64_C(18446744073709551615);
    return (zT_79FAE712_u64)((zT_79FAE712_u64)zT_13);
    z_bb_7:
    zT_16 = h->decimal_point;
    zT_17 = (unsigned int)zig_cast_checked_u((zu64)zT_16, 32u, 1u, 32u);
    dp = zT_17;
    zT_19 = h->num_digits;
    zT_20 = (unsigned int)zT_19;
    n = zT_20;
    zT_22 = 0;
    zT_23 = (zT_79FAE712_u64)zT_22;
    acc = zT_23;
    zT_25 = 0;
    zT_26 = (unsigned int)zT_25;
    i = zT_26;
    goto z_bb_8;
    z_bb_8:
    if ((unsigned char)(i < dp)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_28 = 10;
    zT_29 = zig_wrap_mul_u(((zu64)(acc)), ((zu64)(zT_28)), 64u);
    zT_30 = zig_overflow_flag_mul_u(((zu64)(acc)), ((zu64)(zT_28)), 64u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    acc = zT_29;
    if ((unsigned char)(i < n)) goto z_bb_12; else goto z_bb_13;
    z_bb_10:
    zT_50 = 0;
    round_up = zT_50;
    if ((unsigned char)(dp < n)) goto z_bb_14; else goto z_bb_15;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_34 = h->digits;
    zT_36 = i < (unsigned int)(800);
    if (!(zT_36)) { pal_trap(); }
    zT_37 = zT_34[i];
    zT_38 = (zT_79FAE712_u64)zT_37;
    zT_39 = zig_wrap_add_u(((zu64)(acc)), ((zu64)(zT_38)), 64u);
    zT_40 = zig_overflow_flag_add_u(((zu64)(acc)), ((zu64)(zT_38)), 64u);
    zT_42 = zT_40 == (unsigned int)(0);
    if (!(zT_42)) { pal_trap(); }
    acc = zT_39;
    goto z_bb_13;
    z_bb_13:
    zT_43 = 1;
    zT_44 = (unsigned int)zT_43;
    zT_45 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_44)), 32u);
    zT_46 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_44)), 32u);
    zT_48 = zT_46 == (unsigned int)(0);
    if (!(zT_48)) { pal_trap(); }
    i = zT_45;
    goto z_bb_11;
    z_bb_14:
    zT_52 = h->digits;
    zT_54 = dp < (unsigned int)(800);
    if (!(zT_54)) { pal_trap(); }
    zT_55 = zT_52[dp];
    zT_56 = 5;
    zT_57 = zT_55 >= zT_56;
    round_up = zT_57;
    zT_58 = h->digits;
    zT_60 = dp < (unsigned int)(800);
    if (!(zT_60)) { pal_trap(); }
    zT_61 = zT_58[dp];
    zT_62 = 5;
    if ((unsigned char)(zT_61 == zT_62)) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    if (round_up) goto z_bb_27; else goto z_bb_28;
    z_bb_16:
    zT_65 = 1;
    zT_66 = zig_wrap_add_u(((zu64)(dp)), ((zu64)(zT_65)), 32u);
    zT_67 = zig_overflow_flag_add_u(((zu64)(dp)), ((zu64)(zT_65)), 32u);
    zT_69 = zT_67 == (unsigned int)(0);
    if (!(zT_69)) { pal_trap(); }
    zT_64 = zT_66 == n;
    goto z_bb_18;
    z_bb_17:
    zT_64 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_64) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_71 = h->truncated;
    if (zT_71) goto z_bb_22; else goto z_bb_21;
    z_bb_20:
    goto z_bb_15;
    z_bb_21:
    zT_73 = 0;
    if ((unsigned char)(dp != (unsigned int)zT_73)) goto z_bb_24; else goto z_bb_25;
    z_bb_22:
    zT_72 = 1;
    goto z_bb_23;
    z_bb_23:
    round_up = zT_72;
    goto z_bb_20;
    z_bb_24:
    zT_76 = 1;
    zT_77 = h->digits;
    zT_78 = 1;
    zT_79 = zig_wrap_sub_u(((zu64)(dp)), ((zu64)(zT_78)), 32u);
    zT_80 = zig_overflow_flag_sub_u(((zu64)(dp)), ((zu64)(zT_78)), 32u);
    zT_82 = zT_80 == (unsigned int)(0);
    if (!(zT_82)) { pal_trap(); }
    zT_84 = zT_79 < (unsigned int)(800);
    if (!(zT_84)) { pal_trap(); }
    zT_85 = zT_77[zT_79];
    zT_87 = 0;
    zT_75 = (unsigned char)(zT_76 & zT_85) != zT_87;
    goto z_bb_26;
    z_bb_25:
    zT_75 = 0;
    goto z_bb_26;
    z_bb_26:
    zT_72 = zT_75;
    goto z_bb_23;
    z_bb_27:
    zT_89 = 1;
    zT_90 = zig_wrap_add_u(((zu64)(acc)), ((zu64)(zT_89)), 64u);
    zT_91 = zig_overflow_flag_add_u(((zu64)(acc)), ((zu64)(zT_89)), 64u);
    zT_93 = zT_91 == (unsigned int)(0);
    if (!(zT_93)) { pal_trap(); }
    acc = zT_90;
    goto z_bb_28;
    z_bb_28:
    return acc;
}

/* parseF64 */
zT_00435AEB_f64 zF_37CDE8A4_parseF64(zT_8F083A69_Slice_zT_0B42B2F8_u text) {
    zT_4324C233_Hpd zT_2;
    int zT_3;
    int zT_5;
    int zT_10;
    unsigned int zT_11;
    int zT_13;
    int zT_14;
    unsigned int zT_16;
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned int zT_20;
    unsigned char zT_21;
    unsigned char zT_22;
    int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_31;
    unsigned int zT_33;
    unsigned char zT_35;
    unsigned char* zT_36;
    unsigned int zT_37;
    unsigned char zT_38;
    unsigned char zT_39;
    int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned char zT_47;
    unsigned int zT_49;
    unsigned char* zT_52;
    unsigned int zT_53;
    unsigned char zT_54;
    unsigned char zT_55;
    int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned char zT_61;
    unsigned char zT_66;
    unsigned char zT_69;
    int zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    unsigned char zT_77;
    unsigned char zT_78;
    unsigned char zT_79;
    int zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned char zT_86;
    unsigned int zT_87;
    int zT_88;
    unsigned char zT_90;
    unsigned char zT_91;
    unsigned int zT_92;
    unsigned char zT_94;
    unsigned char* zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    unsigned char zT_99;
    unsigned int zT_100;
    int zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    unsigned int zT_104;
    unsigned char zT_106;
    int zT_110;
    int zT_111;
    int zT_112;
    unsigned int zT_113;
    unsigned char zT_115;
    unsigned int zT_117;
    unsigned char zT_119;
    unsigned char* zT_120;
    unsigned int zT_121;
    unsigned char zT_122;
    unsigned char zT_123;
    int zT_126;
    unsigned int zT_127;
    unsigned int zT_128;
    unsigned int zT_129;
    unsigned char zT_131;
    unsigned int zT_133;
    unsigned char* zT_136;
    unsigned int zT_137;
    unsigned char zT_138;
    unsigned char zT_139;
    int zT_140;
    unsigned int zT_141;
    unsigned int zT_142;
    unsigned int zT_143;
    unsigned char zT_145;
    unsigned char zT_150;
    int zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    unsigned char zT_158;
    unsigned char zT_159;
    unsigned char zT_160;
    unsigned int zT_162;
    int zT_163;
    unsigned char zT_165;
    unsigned char zT_166;
    unsigned int zT_167;
    unsigned char zT_169;
    unsigned char* zT_170;
    unsigned int zT_171;
    unsigned int zT_172;
    unsigned char zT_174;
    unsigned int zT_175;
    int zT_176;
    unsigned int zT_177;
    unsigned int zT_178;
    unsigned int zT_179;
    unsigned char zT_181;
    int zT_186;
    int zT_187;
    unsigned char zT_189;
    unsigned int zT_191;
    unsigned char zT_193;
    unsigned char* zT_194;
    unsigned int zT_195;
    unsigned char zT_196;
    unsigned char zT_197;
    unsigned char zT_200;
    unsigned char* zT_201;
    unsigned int zT_202;
    unsigned char zT_203;
    unsigned char zT_204;
    int zT_207;
    unsigned int zT_208;
    unsigned int zT_209;
    unsigned int zT_210;
    unsigned char zT_212;
    unsigned int zT_214;
    unsigned char zT_216;
    unsigned char* zT_217;
    unsigned int zT_218;
    unsigned char zT_219;
    unsigned char zT_220;
    unsigned char zT_223;
    int zT_224;
    unsigned int zT_225;
    unsigned int zT_226;
    unsigned int zT_227;
    unsigned char zT_229;
    unsigned int zT_231;
    unsigned char zT_233;
    unsigned char* zT_234;
    unsigned int zT_235;
    unsigned char zT_236;
    unsigned char zT_237;
    int zT_240;
    unsigned int zT_241;
    unsigned int zT_242;
    unsigned int zT_243;
    unsigned char zT_245;
    unsigned int zT_247;
    unsigned char* zT_250;
    unsigned int zT_251;
    unsigned char zT_252;
    unsigned char zT_253;
    int zT_256;
    unsigned int zT_257;
    unsigned int zT_258;
    unsigned int zT_259;
    unsigned char zT_261;
    unsigned char zT_262;
    unsigned char zT_263;
    int zT_265;
    unsigned int zT_266;
    unsigned int zT_267;
    unsigned int zT_268;
    unsigned char zT_270;
    int zT_271;
    int zT_273;
    int zT_274;
    unsigned int zT_275;
    unsigned char zT_277;
    unsigned char zT_278;
    unsigned char zT_279;
    unsigned int zT_280;
    unsigned char zT_282;
    int zT_283;
    int zT_284;
    unsigned int zT_285;
    unsigned char zT_287;
    int zT_288;
    unsigned int zT_289;
    unsigned char zT_291;
    int zT_292;
    unsigned int zT_293;
    unsigned char zT_295;
    unsigned int zT_296;
    int zT_297;
    unsigned char zT_299;
    unsigned char* zT_300;
    unsigned int zT_301;
    int zT_302;
    unsigned int zT_303;
    unsigned int zT_304;
    unsigned char zT_306;
    unsigned int zT_307;
    unsigned char zT_309;
    unsigned char zT_310;
    int zT_311;
    unsigned int zT_313;
    int zT_314;
    unsigned int zT_315;
    unsigned int zT_316;
    unsigned int zT_317;
    unsigned char zT_319;
    int zT_321;
    unsigned int zT_322;
    unsigned int zT_324;
    unsigned int zT_325;
    unsigned char zT_327;
    unsigned char* zT_328;
    unsigned char zT_330;
    unsigned char zT_331;
    int zT_332;
    int zT_334;
    unsigned int zT_335;
    unsigned int zT_336;
    unsigned int zT_337;
    unsigned char zT_339;
    int zT_340;
    int zT_343;
    unsigned int zT_344;
    unsigned int zT_345;
    unsigned int zT_346;
    unsigned char zT_348;
    unsigned char* zT_350;
    unsigned int zT_351;
    unsigned int zT_352;
    unsigned char zT_354;
    unsigned char zT_356;
    unsigned char zT_357;
    unsigned char* zT_358;
    unsigned char zT_360;
    int zT_361;
    unsigned int zT_362;
    unsigned int zT_363;
    unsigned int zT_364;
    unsigned char zT_366;
    unsigned int zT_367;
    unsigned int zT_368;
    unsigned int zT_369;
    unsigned int zT_370;
    unsigned char zT_372;
    int zT_373;
    int zT_374;
    int zT_375;
    unsigned int zT_376;
    unsigned char zT_378;
    unsigned int zT_379;
    int zT_380;
    unsigned char zT_382;
    zT_00435AEB_f64 zT_384;
    int zT_385;
    int zT_386;
    int zT_387;
    unsigned int zT_388;
    unsigned char zT_390;
    int zT_391;
    unsigned char zT_393;
    zT_00435AEB_f64 zT_395;
    int zT_396;
    int zT_397;
    unsigned char zT_399;
    zT_00435AEB_f64 zT_401;
    unsigned int zT_403;
    unsigned int zT_404;
    unsigned char zT_405;
    unsigned char zT_407;
    int zT_408;
    int zT_411;
    zT_79FAE712_u64 zT_412;
    int zT_414;
    unsigned int zT_415;
    int zT_417;
    zT_79FAE712_u64 zT_418;
    unsigned int zT_419;
    unsigned char zT_421;
    unsigned char* zT_422;
    unsigned char zT_424;
    unsigned char zT_425;
    zT_79FAE712_u64 zT_426;
    zT_79FAE712_u64 zT_427;
    unsigned int zT_428;
    unsigned char zT_430;
    int zT_431;
    unsigned int zT_432;
    unsigned int zT_433;
    unsigned int zT_434;
    unsigned char zT_436;
    zT_79FAE712_u64 zT_437;
    int zT_438;
    zT_79FAE712_u64 zT_439;
    unsigned char zT_441;
    unsigned int zT_442;
    unsigned char zT_444;
    int zT_447;
    int zT_448;
    int zT_449;
    unsigned int zT_450;
    unsigned char zT_452;
    int zT_453;
    int zT_454;
    unsigned int zT_455;
    unsigned char zT_457;
    int zT_458;
    unsigned char zT_460;
    int zT_461;
    int zT_463;
    unsigned int zT_466;
    zT_79FAE712_u64 zT_468;
    unsigned int zT_470;
    zT_79FAE712_u64 zT_471;
    int zT_473;
    zT_79FAE712_u64 zT_474;
    unsigned char zT_476;
    unsigned int zT_478;
    zT_79FAE712_u64 zT_479;
    int zT_481;
    zT_79FAE712_u64 zT_482;
    unsigned char zT_484;
    zT_79FAE712_u64 zT_486;
    unsigned int zT_487;
    unsigned char zT_489;
    zT_79FAE712_u64 zT_491;
    unsigned int zT_492;
    unsigned char zT_494;
    zT_79FAE712_u64 zT_496;
    unsigned int zT_497;
    unsigned char zT_499;
    zT_79FAE712_u64 zT_501;
    unsigned int zT_502;
    unsigned char zT_504;
    int zT_506;
    zT_79FAE712_u64 zT_507;
    unsigned char zT_509;
    unsigned int zT_510;
    zT_79FAE712_u64 zT_511;
    zT_79FAE712_u64 zT_512;
    unsigned int zT_513;
    unsigned char zT_515;
    unsigned int zT_516;
    zT_79FAE712_u64 zT_517;
    zT_79FAE712_u64 zT_518;
    unsigned int zT_519;
    unsigned char zT_521;
    unsigned int zT_523;
    zT_79FAE712_u64 zT_524;
    int zT_525;
    zT_79FAE712_u64 zT_526;
    unsigned char zT_528;
    unsigned int zT_529;
    unsigned char zT_531;
    unsigned int zT_532;
    zT_79FAE712_u64 zT_534;
    int zT_536;
    zT_79FAE712_u64 zT_537;
    unsigned char zT_539;
    zT_79FAE712_u64 zT_540;
    unsigned int zT_541;
    unsigned char zT_543;
    int zT_544;
    zT_79FAE712_u64 zT_545;
    unsigned char zT_547;
    zT_79FAE712_u64 zT_548;
    unsigned int zT_549;
    unsigned char zT_551;
    int zT_552;
    zT_79FAE712_u64 zT_553;
    unsigned char zT_555;
    zT_79FAE712_u64 zT_556;
    unsigned int zT_557;
    unsigned char zT_559;
    zT_79FAE712_u64 zT_560;
    zT_79FAE712_u64 zT_561;
    int zT_563;
    unsigned char zT_564;
    zT_00435AEB_f64 zT_567;
    int zT_569;
    int zT_570;
    unsigned int zT_571;
    unsigned char zT_573;
    unsigned int zT_575;
    zT_79FAE712_u64 zT_577;
    zT_79FAE712_u64 zT_579;
    unsigned char zT_581;
    zT_79FAE712_u64 zT_583;
    unsigned char zT_585;
    int zT_587;
    zT_79FAE712_u64 zT_588;
    int zT_591;
    int zT_592;
    zT_79FAE712_u64 zT_593;
    zT_79FAE712_u64 zT_594;
    unsigned int zT_595;
    int zT_596;
    unsigned char zT_598;
    int zT_599;
    int zT_601;
    zT_79FAE712_u64 zT_602;
    unsigned int zT_603;
    unsigned char zT_605;
    int zT_607;
    zT_79FAE712_u64 zT_608;
    zT_79FAE712_u64 zT_610;
    unsigned int zT_611;
    unsigned char zT_613;
    int zT_614;
    zT_79FAE712_u64 zT_615;
    int zT_617;
    zT_79FAE712_u64 zT_618;
    unsigned char zT_620;
    int zT_621;
    zT_79FAE712_u64 zT_622;
    unsigned int zT_623;
    unsigned char zT_625;
    zT_79FAE712_u64 zT_626;
    unsigned int zT_627;
    unsigned char zT_629;
    int zT_630;
    zT_79FAE712_u64 zT_631;
    unsigned int zT_632;
    unsigned char zT_634;
    zT_79FAE712_u64 zT_635;
    unsigned int zT_636;
    unsigned char zT_638;
    int zT_639;
    int zT_640;
    int zT_641;
    unsigned int zT_642;
    unsigned char zT_644;
    int zT_646;
    int zT_647;
    unsigned int zT_648;
    unsigned char zT_650;
    int zT_651;
    unsigned int zT_652;
    unsigned char zT_654;
    zT_79FAE712_u64 zT_655;
    zT_79FAE712_u64 zT_656;
    int zT_658;
    unsigned char zT_659;
    int zT_660;
    zT_00435AEB_f64 zT_663;
    int zT_665;
    int zT_666;
    int zT_667;
    int zT_668;
    zT_4324C233_Hpd* zT_670;
    int zT_672;
    int zT_673;
    int zT_674;
    unsigned int zT_675;
    unsigned char zT_677;
    int zT_679;
    int zT_680;
    unsigned char zT_682;
    unsigned char* zT_683;
    int zT_684;
    unsigned char zT_686;
    unsigned char zT_687;
    int zT_688;
    zT_4324C233_Hpd* zT_690;
    int zT_692;
    int zT_693;
    int zT_694;
    unsigned int zT_695;
    unsigned char zT_697;
    int zT_698;
    int zT_699;
    int zT_700;
    unsigned int zT_701;
    unsigned char zT_703;
    int zT_704;
    int zT_705;
    unsigned int zT_706;
    unsigned char zT_708;
    int zT_709;
    zT_4324C233_Hpd* zT_711;
    int zT_713;
    int zT_714;
    int zT_715;
    unsigned int zT_716;
    unsigned char zT_718;
    int zT_719;
    int zT_720;
    unsigned int zT_721;
    unsigned char zT_723;
    int zT_724;
    unsigned char zT_726;
    zT_00435AEB_f64 zT_728;
    int zT_730;
    unsigned int zT_731;
    int zT_732;
    zT_4324C233_Hpd* zT_734;
    int zT_736;
    unsigned int zT_737;
    unsigned int zT_738;
    unsigned int zT_739;
    unsigned char zT_741;
    zT_4324C233_Hpd* zT_743;
    zT_79FAE712_u64 zT_745;
    zT_79FAE712_u64 zT_746;
    int zT_747;
    zT_79FAE712_u64 zT_748;
    unsigned char zT_750;
    unsigned int zT_751;
    unsigned char zT_753;
    zT_4324C233_Hpd* zT_755;
    int zT_757;
    int zT_758;
    int zT_759;
    unsigned int zT_760;
    unsigned char zT_762;
    zT_4324C233_Hpd* zT_763;
    zT_79FAE712_u64 zT_765;
    int zT_766;
    int zT_767;
    unsigned int zT_768;
    unsigned char zT_770;
    int zT_771;
    unsigned char zT_773;
    zT_00435AEB_f64 zT_775;
    int zT_777;
    int zT_778;
    unsigned int zT_779;
    unsigned char zT_781;
    zT_79FAE712_u64 zT_782;
    int zT_783;
    zT_79FAE712_u64 zT_784;
    unsigned char zT_786;
    unsigned int zT_787;
    unsigned char zT_789;
    int zT_791;
    int zT_792;
    int zT_793;
    unsigned int zT_794;
    unsigned char zT_796;
    zT_79FAE712_u64 zT_797;
    zT_79FAE712_u64 zT_798;
    zT_79FAE712_u64 zT_800;
    int zT_801;
    zT_79FAE712_u64 zT_802;
    unsigned char zT_804;
    unsigned int zT_805;
    unsigned char zT_807;
    zT_79FAE712_u64 zT_808;
    unsigned char zT_809;
    zT_79FAE712_u64 zT_810;
    zT_79FAE712_u64 zT_811;
    zT_79FAE712_u64 zT_812;
    zT_00435AEB_f64 zT_813;
    zig_poison_fill((void*)&zT_79, (unsigned int)sizeof zT_79);
    zig_poison_fill((void*)&zT_160, (unsigned int)sizeof zT_160);
    zig_poison_fill((void*)&zT_263, (unsigned int)sizeof zT_263);
    zig_poison_fill((void*)&zT_384, (unsigned int)sizeof zT_384);
    zig_poison_fill((void*)&zT_395, (unsigned int)sizeof zT_395);
    zig_poison_fill((void*)&zT_401, (unsigned int)sizeof zT_401);
    zig_poison_fill((void*)&zT_468, (unsigned int)sizeof zT_468);
    zig_poison_fill((void*)&zT_567, (unsigned int)sizeof zT_567);
    zig_poison_fill((void*)&zT_577, (unsigned int)sizeof zT_577);
    zig_poison_fill((void*)&zT_595, (unsigned int)sizeof zT_595);
    zig_poison_fill((void*)&zT_663, (unsigned int)sizeof zT_663);
    zig_poison_fill((void*)&zT_728, (unsigned int)sizeof zT_728);
    zig_poison_fill((void*)&zT_745, (unsigned int)sizeof zT_745);
    zig_poison_fill((void*)&zT_765, (unsigned int)sizeof zT_765);
    zig_poison_fill((void*)&zT_775, (unsigned int)sizeof zT_775);
    zig_poison_fill((void*)&zT_813, (unsigned int)sizeof zT_813);
    zT_4324C233_Hpd h;
    unsigned int i;
    int int_digits;
    unsigned char c;
    int e10;
    unsigned char e10_neg;
    unsigned int lz;
    unsigned int tot;
    unsigned int j;
    unsigned int n;
    zT_79FAE712_u64 m;
    int exp2;
    int e;
    zT_79FAE712_u64 p5;
    zT_79FAE712_u64 m_lo;
    zT_79FAE712_u64 m_hi;
    zT_79FAE712_u64 p_lo;
    zT_79FAE712_u64 p_hi;
    zT_79FAE712_u64 ll;
    zT_79FAE712_u64 lh;
    zT_79FAE712_u64 hl;
    zT_79FAE712_u64 hh;
    zT_79FAE712_u64 mid;
    zT_79FAE712_u64 lo;
    zT_79FAE712_u64 hi;
    int k;
    zT_79FAE712_u64 p5b;
    zT_79FAE712_u64 q;
    zT_79FAE712_u64 rr;
    zT_79FAE712_u64 qhi;
    zT_79FAE712_u64 qlo;
    int t;
    zT_79FAE712_u64 bit;
    int e_prime;
    zT_79FAE712_u64 carry;
    unsigned int s;
    zT_79FAE712_u64 mantissa;
    int power2;
    zT_79FAE712_u64 bits;
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    h = zT_2;
    zT_3 = 0;
    h.num_digits = (unsigned int)((unsigned int)zT_3);
    zT_5 = 0;
    h.decimal_point = (int)((int)zT_5);
    h.negative = (unsigned char)(0);
    h.truncated = (unsigned char)(0);
    zT_10 = 0;
    zT_11 = (unsigned int)zT_10;
    i = zT_11;
    zT_13 = 0;
    zT_14 = (int)zT_13;
    int_digits = zT_14;
    zT_16 = text.len;
    if ((unsigned char)(i < zT_16)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_19 = text.ptr;
    zT_20 = text.len;
    zT_21 = i < zT_20;
    if (!(zT_21)) { pal_trap(); }
    zT_22 = zT_19[i];
    zT_18 = zT_22 == (unsigned char)(45);
    goto z_bb_3;
    z_bb_2:
    zT_18 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_18) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    h.negative = (unsigned char)(1);
    zT_26 = 1;
    zT_27 = (unsigned int)zT_26;
    zT_28 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_27)), 32u);
    zT_29 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_27)), 32u);
    zT_31 = zT_29 == (unsigned int)(0);
    if (!(zT_31)) { pal_trap(); }
    i = zT_28;
    goto z_bb_5;
    z_bb_5:
    zT_33 = text.len;
    if ((unsigned char)(i < zT_33)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_36 = text.ptr;
    zT_37 = text.len;
    zT_38 = i < zT_37;
    if (!(zT_38)) { pal_trap(); }
    zT_39 = zT_36[i];
    zT_35 = zT_39 == (unsigned char)(43);
    goto z_bb_8;
    z_bb_7:
    zT_35 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_35) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_42 = 1;
    zT_43 = (unsigned int)zT_42;
    zT_44 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_43)), 32u);
    zT_45 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_43)), 32u);
    zT_47 = zT_45 == (unsigned int)(0);
    if (!(zT_47)) { pal_trap(); }
    i = zT_44;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_11;
    z_bb_11:
    zT_49 = text.len;
    if ((unsigned char)(i < zT_49)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_52 = text.ptr;
    zT_53 = text.len;
    zT_54 = i < zT_53;
    if (!(zT_54)) { pal_trap(); }
    zT_55 = zT_52[i];
    c = zT_55;
    zT_56 = 1;
    zT_57 = (unsigned int)zT_56;
    zT_58 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_57)), 32u);
    zT_59 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_57)), 32u);
    zT_61 = zT_59 == (unsigned int)(0);
    if (!(zT_61)) { pal_trap(); }
    i = zT_58;
    if ((unsigned char)(c == (unsigned char)(95))) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    zT_117 = text.len;
    if ((unsigned char)(i < zT_117)) goto z_bb_32; else goto z_bb_33;
    z_bb_14:
    goto z_bb_11;
    z_bb_15:
    goto z_bb_14;
    z_bb_16:
    if ((unsigned char)(c == (unsigned char)(46))) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_66 = c == (unsigned char)(101);
    goto z_bb_19;
    z_bb_18:
    zT_66 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_66) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_69 = c == (unsigned char)(69);
    goto z_bb_22;
    z_bb_21:
    zT_69 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_69) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_72 = 1;
    zT_73 = (unsigned int)zT_72;
    zT_74 = zig_wrap_sub_u(((zu64)(i)), ((zu64)(zT_73)), 32u);
    zT_75 = zig_overflow_flag_sub_u(((zu64)(i)), ((zu64)(zT_73)), 32u);
    zT_77 = zT_75 == (unsigned int)(0);
    if (!(zT_77)) { pal_trap(); }
    i = zT_74;
    goto z_bb_13;
    z_bb_24:
    zT_78 = c;
    zT_79 = zF_C95A8EC6_isDigit(zT_78);
    if ((unsigned char)(!zT_79)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_81 = 1;
    zT_82 = (unsigned int)zT_81;
    zT_83 = zig_wrap_sub_u(((zu64)(i)), ((zu64)(zT_82)), 32u);
    zT_84 = zig_overflow_flag_sub_u(((zu64)(i)), ((zu64)(zT_82)), 32u);
    zT_86 = zT_84 == (unsigned int)(0);
    if (!(zT_86)) { pal_trap(); }
    i = zT_83;
    goto z_bb_13;
    z_bb_26:
    zT_87 = h.num_digits;
    zT_88 = 800;
    if ((unsigned char)(zT_87 < (unsigned int)zT_88)) goto z_bb_27; else goto z_bb_29;
    z_bb_27:
    zT_90 = 48;
    zT_91 = zig_wrap_sub_u(((zu64)(c)), ((zu64)(zT_90)), 8u);
    zT_92 = zig_overflow_flag_sub_u(((zu64)(c)), ((zu64)(zT_90)), 8u);
    zT_94 = zT_92 == (unsigned int)(0);
    if (!(zT_94)) { pal_trap(); }
    zT_95 = h.digits;
    zT_96 = h.num_digits;
    zT_97 = (unsigned int)zT_96;
    zT_99 = zT_97 < (unsigned int)(800);
    if (!(zT_99)) { pal_trap(); }
    zT_95[zT_97] = zT_91;
    zT_100 = h.num_digits;
    zT_101 = 1;
    zT_102 = (unsigned int)zT_101;
    zT_103 = zig_wrap_add_u(((zu64)(zT_100)), ((zu64)(zT_102)), 32u);
    zT_104 = zig_overflow_flag_add_u(((zu64)(zT_100)), ((zu64)(zT_102)), 32u);
    zT_106 = zT_104 == (unsigned int)(0);
    if (!(zT_106)) { pal_trap(); }
    h.num_digits = zT_103;
    goto z_bb_28;
    z_bb_28:
    zT_110 = 1;
    zT_111 = (int)zT_110;
    zT_112 = zig_wrap_add_s(((z64)(int_digits)), ((z64)(zT_111)), 32u);
    zT_113 = zig_overflow_flag_add_s(((z64)(int_digits)), ((z64)(zT_111)), 32u);
    zT_115 = zT_113 == (unsigned int)(0);
    if (!(zT_115)) { pal_trap(); }
    int_digits = zT_112;
    goto z_bb_14;
    z_bb_29:
    if ((unsigned char)(c != (unsigned char)(48))) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    h.truncated = (unsigned char)(1);
    goto z_bb_31;
    z_bb_31:
    goto z_bb_28;
    z_bb_32:
    zT_120 = text.ptr;
    zT_121 = text.len;
    zT_122 = i < zT_121;
    if (!(zT_122)) { pal_trap(); }
    zT_123 = zT_120[i];
    zT_119 = zT_123 == (unsigned char)(46);
    goto z_bb_34;
    z_bb_33:
    zT_119 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_119) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_126 = 1;
    zT_127 = (unsigned int)zT_126;
    zT_128 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_127)), 32u);
    zT_129 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_127)), 32u);
    zT_131 = zT_129 == (unsigned int)(0);
    if (!(zT_131)) { pal_trap(); }
    i = zT_128;
    goto z_bb_37;
    z_bb_36:
    zT_186 = 0;
    zT_187 = (int)zT_186;
    e10 = zT_187;
    zT_189 = 0;
    e10_neg = zT_189;
    zT_191 = text.len;
    if ((unsigned char)(i < zT_191)) goto z_bb_55; else goto z_bb_56;
    z_bb_37:
    zT_133 = text.len;
    if ((unsigned char)(i < zT_133)) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_136 = text.ptr;
    zT_137 = text.len;
    zT_138 = i < zT_137;
    if (!(zT_138)) { pal_trap(); }
    zT_139 = zT_136[i];
    c = zT_139;
    zT_140 = 1;
    zT_141 = (unsigned int)zT_140;
    zT_142 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_141)), 32u);
    zT_143 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_141)), 32u);
    zT_145 = zT_143 == (unsigned int)(0);
    if (!(zT_145)) { pal_trap(); }
    i = zT_142;
    if ((unsigned char)(c == (unsigned char)(95))) goto z_bb_41; else goto z_bb_42;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    goto z_bb_37;
    z_bb_41:
    goto z_bb_40;
    z_bb_42:
    if ((unsigned char)(c == (unsigned char)(101))) goto z_bb_44; else goto z_bb_43;
    z_bb_43:
    zT_150 = c == (unsigned char)(69);
    goto z_bb_45;
    z_bb_44:
    zT_150 = 1;
    goto z_bb_45;
    z_bb_45:
    if (zT_150) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_153 = 1;
    zT_154 = (unsigned int)zT_153;
    zT_155 = zig_wrap_sub_u(((zu64)(i)), ((zu64)(zT_154)), 32u);
    zT_156 = zig_overflow_flag_sub_u(((zu64)(i)), ((zu64)(zT_154)), 32u);
    zT_158 = zT_156 == (unsigned int)(0);
    if (!(zT_158)) { pal_trap(); }
    i = zT_155;
    goto z_bb_39;
    z_bb_47:
    zT_159 = c;
    zT_160 = zF_C95A8EC6_isDigit(zT_159);
    if ((unsigned char)(!zT_160)) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    goto z_bb_39;
    z_bb_49:
    zT_162 = h.num_digits;
    zT_163 = 800;
    if ((unsigned char)(zT_162 < (unsigned int)zT_163)) goto z_bb_50; else goto z_bb_52;
    z_bb_50:
    zT_165 = 48;
    zT_166 = zig_wrap_sub_u(((zu64)(c)), ((zu64)(zT_165)), 8u);
    zT_167 = zig_overflow_flag_sub_u(((zu64)(c)), ((zu64)(zT_165)), 8u);
    zT_169 = zT_167 == (unsigned int)(0);
    if (!(zT_169)) { pal_trap(); }
    zT_170 = h.digits;
    zT_171 = h.num_digits;
    zT_172 = (unsigned int)zT_171;
    zT_174 = zT_172 < (unsigned int)(800);
    if (!(zT_174)) { pal_trap(); }
    zT_170[zT_172] = zT_166;
    zT_175 = h.num_digits;
    zT_176 = 1;
    zT_177 = (unsigned int)zT_176;
    zT_178 = zig_wrap_add_u(((zu64)(zT_175)), ((zu64)(zT_177)), 32u);
    zT_179 = zig_overflow_flag_add_u(((zu64)(zT_175)), ((zu64)(zT_177)), 32u);
    zT_181 = zT_179 == (unsigned int)(0);
    if (!(zT_181)) { pal_trap(); }
    h.num_digits = zT_178;
    goto z_bb_51;
    z_bb_51:
    goto z_bb_40;
    z_bb_52:
    if ((unsigned char)(c != (unsigned char)(48))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    h.truncated = (unsigned char)(1);
    goto z_bb_54;
    z_bb_54:
    goto z_bb_51;
    z_bb_55:
    zT_194 = text.ptr;
    zT_195 = text.len;
    zT_196 = i < zT_195;
    if (!(zT_196)) { pal_trap(); }
    zT_197 = zT_194[i];
    if ((unsigned char)(zT_197 == (unsigned char)(101))) goto z_bb_59; else goto z_bb_58;
    z_bb_56:
    zT_193 = 0;
    goto z_bb_57;
    z_bb_57:
    if (zT_193) goto z_bb_61; else goto z_bb_62;
    z_bb_58:
    zT_201 = text.ptr;
    zT_202 = text.len;
    zT_203 = i < zT_202;
    if (!(zT_203)) { pal_trap(); }
    zT_204 = zT_201[i];
    zT_200 = zT_204 == (unsigned char)(69);
    goto z_bb_60;
    z_bb_59:
    zT_200 = 1;
    goto z_bb_60;
    z_bb_60:
    zT_193 = zT_200;
    goto z_bb_57;
    z_bb_61:
    zT_207 = 1;
    zT_208 = (unsigned int)zT_207;
    zT_209 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_208)), 32u);
    zT_210 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_208)), 32u);
    zT_212 = zT_210 == (unsigned int)(0);
    if (!(zT_212)) { pal_trap(); }
    i = zT_209;
    zT_214 = text.len;
    if ((unsigned char)(i < zT_214)) goto z_bb_63; else goto z_bb_64;
    z_bb_62:
    if (e10_neg) goto z_bb_83; else goto z_bb_85;
    z_bb_63:
    zT_217 = text.ptr;
    zT_218 = text.len;
    zT_219 = i < zT_218;
    if (!(zT_219)) { pal_trap(); }
    zT_220 = zT_217[i];
    zT_216 = zT_220 == (unsigned char)(45);
    goto z_bb_65;
    z_bb_64:
    zT_216 = 0;
    goto z_bb_65;
    z_bb_65:
    if (zT_216) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_223 = 1;
    e10_neg = zT_223;
    zT_224 = 1;
    zT_225 = (unsigned int)zT_224;
    zT_226 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_225)), 32u);
    zT_227 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_225)), 32u);
    zT_229 = zT_227 == (unsigned int)(0);
    if (!(zT_229)) { pal_trap(); }
    i = zT_226;
    goto z_bb_67;
    z_bb_67:
    zT_231 = text.len;
    if ((unsigned char)(i < zT_231)) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_234 = text.ptr;
    zT_235 = text.len;
    zT_236 = i < zT_235;
    if (!(zT_236)) { pal_trap(); }
    zT_237 = zT_234[i];
    zT_233 = zT_237 == (unsigned char)(43);
    goto z_bb_70;
    z_bb_69:
    zT_233 = 0;
    goto z_bb_70;
    z_bb_70:
    if (zT_233) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    zT_240 = 1;
    zT_241 = (unsigned int)zT_240;
    zT_242 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_241)), 32u);
    zT_243 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_241)), 32u);
    zT_245 = zT_243 == (unsigned int)(0);
    if (!(zT_245)) { pal_trap(); }
    i = zT_242;
    goto z_bb_72;
    z_bb_72:
    goto z_bb_73;
    z_bb_73:
    zT_247 = text.len;
    if ((unsigned char)(i < zT_247)) goto z_bb_74; else goto z_bb_75;
    z_bb_74:
    zT_250 = text.ptr;
    zT_251 = text.len;
    zT_252 = i < zT_251;
    if (!(zT_252)) { pal_trap(); }
    zT_253 = zT_250[i];
    c = zT_253;
    if ((unsigned char)(c == (unsigned char)(95))) goto z_bb_77; else goto z_bb_78;
    z_bb_75:
    goto z_bb_62;
    z_bb_76:
    goto z_bb_73;
    z_bb_77:
    zT_256 = 1;
    zT_257 = (unsigned int)zT_256;
    zT_258 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_257)), 32u);
    zT_259 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_257)), 32u);
    zT_261 = zT_259 == (unsigned int)(0);
    if (!(zT_261)) { pal_trap(); }
    i = zT_258;
    goto z_bb_76;
    z_bb_78:
    zT_262 = c;
    zT_263 = zF_C95A8EC6_isDigit(zT_262);
    if ((unsigned char)(!zT_263)) goto z_bb_79; else goto z_bb_80;
    z_bb_79:
    goto z_bb_75;
    z_bb_80:
    zT_265 = 1;
    zT_266 = (unsigned int)zT_265;
    zT_267 = zig_wrap_add_u(((zu64)(i)), ((zu64)(zT_266)), 32u);
    zT_268 = zig_overflow_flag_add_u(((zu64)(i)), ((zu64)(zT_266)), 32u);
    zT_270 = zT_268 == (unsigned int)(0);
    if (!(zT_270)) { pal_trap(); }
    i = zT_267;
    zT_271 = 100000;
    if ((unsigned char)(e10 < zT_271)) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_273 = 10;
    zT_274 = zig_wrap_mul_s(((z64)(e10)), ((z64)(zT_273)), 32u);
    zT_275 = zig_overflow_flag_mul_s(((z64)(e10)), ((z64)(zT_273)), 32u);
    zT_277 = zT_275 == (unsigned int)(0);
    if (!(zT_277)) { pal_trap(); }
    zT_278 = 48;
    zT_279 = zig_wrap_sub_u(((zu64)(c)), ((zu64)(zT_278)), 8u);
    zT_280 = zig_overflow_flag_sub_u(((zu64)(c)), ((zu64)(zT_278)), 8u);
    zT_282 = zT_280 == (unsigned int)(0);
    if (!(zT_282)) { pal_trap(); }
    zT_283 = (int)zT_279;
    zT_284 = zig_wrap_add_s(((z64)(zT_274)), ((z64)(zT_283)), 32u);
    zT_285 = zig_overflow_flag_add_s(((z64)(zT_274)), ((z64)(zT_283)), 32u);
    zT_287 = zT_285 == (unsigned int)(0);
    if (!(zT_287)) { pal_trap(); }
    e10 = zT_284;
    goto z_bb_82;
    z_bb_82:
    goto z_bb_76;
    z_bb_83:
    zT_288 = zig_wrap_sub_s(((z64)(int_digits)), ((z64)(e10)), 32u);
    zT_289 = zig_overflow_flag_sub_s(((z64)(int_digits)), ((z64)(e10)), 32u);
    zT_291 = zT_289 == (unsigned int)(0);
    if (!(zT_291)) { pal_trap(); }
    h.decimal_point = zT_288;
    goto z_bb_84;
    z_bb_84:
    goto z_bb_86;
    z_bb_85:
    zT_292 = zig_wrap_add_s(((z64)(int_digits)), ((z64)(e10)), 32u);
    zT_293 = zig_overflow_flag_add_s(((z64)(int_digits)), ((z64)(e10)), 32u);
    zT_295 = zT_293 == (unsigned int)(0);
    if (!(zT_295)) { pal_trap(); }
    h.decimal_point = zT_292;
    goto z_bb_84;
    z_bb_86:
    zT_296 = h.num_digits;
    zT_297 = 0;
    if ((unsigned char)(zT_296 != (unsigned int)zT_297)) goto z_bb_90; else goto z_bb_91;
    z_bb_87:
    zT_313 = h.num_digits;
    zT_314 = 1;
    zT_315 = (unsigned int)zT_314;
    zT_316 = zig_wrap_sub_u(((zu64)(zT_313)), ((zu64)(zT_315)), 32u);
    zT_317 = zig_overflow_flag_sub_u(((zu64)(zT_313)), ((zu64)(zT_315)), 32u);
    zT_319 = zT_317 == (unsigned int)(0);
    if (!(zT_319)) { pal_trap(); }
    h.num_digits = zT_316;
    goto z_bb_89;
    z_bb_88:
    zT_321 = 0;
    zT_322 = (unsigned int)zT_321;
    lz = zT_322;
    zT_324 = h.num_digits;
    zT_325 = (unsigned int)zT_324;
    tot = zT_325;
    goto z_bb_93;
    z_bb_89:
    goto z_bb_86;
    z_bb_90:
    zT_300 = h.digits;
    zT_301 = h.num_digits;
    zT_302 = 1;
    zT_303 = zig_wrap_sub_u(((zu64)(zT_301)), ((zu64)(zT_302)), 32u);
    zT_304 = zig_overflow_flag_sub_u(((zu64)(zT_301)), ((zu64)(zT_302)), 32u);
    zT_306 = zT_304 == (unsigned int)(0);
    if (!(zT_306)) { pal_trap(); }
    zT_307 = (unsigned int)zT_303;
    zT_309 = zT_307 < (unsigned int)(800);
    if (!(zT_309)) { pal_trap(); }
    zT_310 = zT_300[zT_307];
    zT_311 = 0;
    zT_299 = zT_310 == zT_311;
    goto z_bb_92;
    z_bb_91:
    zT_299 = 0;
    goto z_bb_92;
    z_bb_92:
    if (zT_299) goto z_bb_87; else goto z_bb_88;
    z_bb_93:
    if ((unsigned char)(lz < tot)) goto z_bb_97; else goto z_bb_98;
    z_bb_94:
    zT_334 = 1;
    zT_335 = (unsigned int)zT_334;
    zT_336 = zig_wrap_add_u(((zu64)(lz)), ((zu64)(zT_335)), 32u);
    zT_337 = zig_overflow_flag_add_u(((zu64)(lz)), ((zu64)(zT_335)), 32u);
    zT_339 = zT_337 == (unsigned int)(0);
    if (!(zT_339)) { pal_trap(); }
    lz = zT_336;
    goto z_bb_96;
    z_bb_95:
    zT_340 = 0;
    if ((unsigned char)(lz > (unsigned int)zT_340)) goto z_bb_100; else goto z_bb_101;
    z_bb_96:
    goto z_bb_93;
    z_bb_97:
    zT_328 = h.digits;
    zT_330 = lz < (unsigned int)(800);
    if (!(zT_330)) { pal_trap(); }
    zT_331 = zT_328[lz];
    zT_332 = 0;
    zT_327 = zT_331 == zT_332;
    goto z_bb_99;
    z_bb_98:
    zT_327 = 0;
    goto z_bb_99;
    z_bb_99:
    if (zT_327) goto z_bb_94; else goto z_bb_95;
    z_bb_100:
    zT_343 = 0;
    zT_344 = (unsigned int)zT_343;
    j = zT_344;
    goto z_bb_102;
    z_bb_101:
    zT_379 = h.num_digits;
    zT_380 = 0;
    if ((unsigned char)(zT_379 == (unsigned int)zT_380)) goto z_bb_106; else goto z_bb_107;
    z_bb_102:
    zT_345 = zig_wrap_add_u(((zu64)(lz)), ((zu64)(j)), 32u);
    zT_346 = zig_overflow_flag_add_u(((zu64)(lz)), ((zu64)(j)), 32u);
    zT_348 = zT_346 == (unsigned int)(0);
    if (!(zT_348)) { pal_trap(); }
    if ((unsigned char)(zT_345 < tot)) goto z_bb_103; else goto z_bb_104;
    z_bb_103:
    zT_350 = h.digits;
    zT_351 = zig_wrap_add_u(((zu64)(lz)), ((zu64)(j)), 32u);
    zT_352 = zig_overflow_flag_add_u(((zu64)(lz)), ((zu64)(j)), 32u);
    zT_354 = zT_352 == (unsigned int)(0);
    if (!(zT_354)) { pal_trap(); }
    zT_356 = zT_351 < (unsigned int)(800);
    if (!(zT_356)) { pal_trap(); }
    zT_357 = zT_350[zT_351];
    zT_358 = h.digits;
    zT_360 = j < (unsigned int)(800);
    if (!(zT_360)) { pal_trap(); }
    zT_358[j] = zT_357;
    zT_361 = 1;
    zT_362 = (unsigned int)zT_361;
    zT_363 = zig_wrap_add_u(((zu64)(j)), ((zu64)(zT_362)), 32u);
    zT_364 = zig_overflow_flag_add_u(((zu64)(j)), ((zu64)(zT_362)), 32u);
    zT_366 = zT_364 == (unsigned int)(0);
    if (!(zT_366)) { pal_trap(); }
    j = zT_363;
    goto z_bb_105;
    z_bb_104:
    zT_367 = h.num_digits;
    zT_368 = (unsigned int)lz;
    zT_369 = zig_wrap_sub_u(((zu64)(zT_367)), ((zu64)(zT_368)), 32u);
    zT_370 = zig_overflow_flag_sub_u(((zu64)(zT_367)), ((zu64)(zT_368)), 32u);
    zT_372 = zT_370 == (unsigned int)(0);
    if (!(zT_372)) { pal_trap(); }
    h.num_digits = zT_369;
    zT_373 = h.decimal_point;
    zT_374 = (int)zig_cast_checked_s((zu64)lz, 32u, 0u, 32u);
    zT_375 = zig_wrap_sub_s(((z64)(zT_373)), ((z64)(zT_374)), 32u);
    zT_376 = zig_overflow_flag_sub_s(((z64)(zT_373)), ((z64)(zT_374)), 32u);
    zT_378 = zT_376 == (unsigned int)(0);
    if (!(zT_378)) { pal_trap(); }
    h.decimal_point = zT_375;
    goto z_bb_101;
    z_bb_105:
    goto z_bb_102;
    z_bb_106:
    zT_382 = h.negative;
    zT_384 = zF_4836A299_f64SignedZero(zT_382);
    return zT_384;
    z_bb_107:
    zT_385 = h.decimal_point;
    zT_386 = 324;
    zT_387 = zig_wrap_add_s(((z64)(zT_385)), ((z64)(zT_386)), 32u);
    zT_388 = zig_overflow_flag_add_s(((z64)(zT_385)), ((z64)(zT_386)), 32u);
    zT_390 = zT_388 == (unsigned int)(0);
    if (!(zT_390)) { pal_trap(); }
    zT_391 = 0;
    if ((unsigned char)(zT_387 < zT_391)) goto z_bb_108; else goto z_bb_109;
    z_bb_108:
    zT_393 = h.negative;
    zT_395 = zF_4836A299_f64SignedZero(zT_393);
    return zT_395;
    z_bb_109:
    zT_396 = h.decimal_point;
    zT_397 = 310;
    if ((unsigned char)(zT_396 >= zT_397)) goto z_bb_110; else goto z_bb_111;
    z_bb_110:
    zT_399 = h.negative;
    zT_401 = zF_5493CDCE_f64SignedInf(zT_399);
    return zT_401;
    z_bb_111:
    zT_403 = h.num_digits;
    zT_404 = (unsigned int)zT_403;
    n = zT_404;
    zT_405 = h.truncated;
    if ((unsigned char)(!zT_405)) goto z_bb_112; else goto z_bb_113;
    z_bb_112:
    zT_408 = 16;
    zT_407 = n <= (unsigned int)zT_408;
    goto z_bb_114;
    z_bb_113:
    zT_407 = 0;
    goto z_bb_114;
    z_bb_114:
    if (zT_407) goto z_bb_115; else goto z_bb_116;
    z_bb_115:
    zT_411 = 0;
    zT_412 = (zT_79FAE712_u64)zT_411;
    m = zT_412;
    zT_414 = 0;
    zT_415 = (unsigned int)zT_414;
    j = zT_415;
    goto z_bb_117;
    z_bb_116:
    zT_665 = 0;
    zT_666 = (int)zT_665;
    exp2 = zT_666;
    goto z_bb_140;
    z_bb_117:
    if ((unsigned char)(j < n)) goto z_bb_118; else goto z_bb_119;
    z_bb_118:
    zT_417 = 10;
    zT_418 = zig_wrap_mul_u(((zu64)(m)), ((zu64)(zT_417)), 64u);
    zT_419 = zig_overflow_flag_mul_u(((zu64)(m)), ((zu64)(zT_417)), 64u);
    zT_421 = zT_419 == (unsigned int)(0);
    if (!(zT_421)) { pal_trap(); }
    zT_422 = h.digits;
    zT_424 = j < (unsigned int)(800);
    if (!(zT_424)) { pal_trap(); }
    zT_425 = zT_422[j];
    zT_426 = (zT_79FAE712_u64)zT_425;
    zT_427 = zig_wrap_add_u(((zu64)(zT_418)), ((zu64)(zT_426)), 64u);
    zT_428 = zig_overflow_flag_add_u(((zu64)(zT_418)), ((zu64)(zT_426)), 64u);
    zT_430 = zT_428 == (unsigned int)(0);
    if (!(zT_430)) { pal_trap(); }
    m = zT_427;
    zT_431 = 1;
    zT_432 = (unsigned int)zT_431;
    zT_433 = zig_wrap_add_u(((zu64)(j)), ((zu64)(zT_432)), 32u);
    zT_434 = zig_overflow_flag_add_u(((zu64)(j)), ((zu64)(zT_432)), 32u);
    zT_436 = zT_434 == (unsigned int)(0);
    if (!(zT_436)) { pal_trap(); }
    j = zT_433;
    goto z_bb_120;
    z_bb_119:
    zT_437 = 1;
    zT_438 = 53;
    zT_441 = (unsigned int)zT_438 < (unsigned int)(64);
    if (!(zT_441)) { pal_trap(); }
    zT_439 = zig_wrap_shl_u(((zu64)(zT_437)), ((zu64)(zT_438)), 64u);
    zT_442 = zig_overflow_flag_shl_u(((zu64)(zT_437)), ((zu64)(zT_438)), 64u);
    zT_444 = zT_442 == (unsigned int)(0);
    if (!(zT_444)) { pal_trap(); }
    if ((unsigned char)(m < zT_439)) goto z_bb_121; else goto z_bb_122;
    z_bb_120:
    goto z_bb_117;
    z_bb_121:
    zT_447 = h.decimal_point;
    zT_448 = (int)zig_cast_checked_s((zu64)n, 32u, 0u, 32u);
    zT_449 = zig_wrap_sub_s(((z64)(zT_447)), ((z64)(zT_448)), 32u);
    zT_450 = zig_overflow_flag_sub_s(((z64)(zT_447)), ((z64)(zT_448)), 32u);
    zT_452 = zT_450 == (unsigned int)(0);
    if (!(zT_452)) { pal_trap(); }
    e = zT_449;
    zT_453 = 22;
    zT_454 = zig_wrap_add_s(((z64)(e)), ((z64)(zT_453)), 32u);
    zT_455 = zig_overflow_flag_add_s(((z64)(e)), ((z64)(zT_453)), 32u);
    zT_457 = zT_455 == (unsigned int)(0);
    if (!(zT_457)) { pal_trap(); }
    zT_458 = 0;
    if ((unsigned char)(zT_454 >= zT_458)) goto z_bb_123; else goto z_bb_124;
    z_bb_122:
    goto z_bb_116;
    z_bb_123:
    zT_461 = 22;
    zT_460 = e <= zT_461;
    goto z_bb_125;
    z_bb_124:
    zT_460 = 0;
    goto z_bb_125;
    z_bb_125:
    if (zT_460) goto z_bb_126; else goto z_bb_127;
    z_bb_126:
    zT_463 = 0;
    if ((unsigned char)(e >= zT_463)) goto z_bb_128; else goto z_bb_130;
    z_bb_127:
    goto z_bb_122;
    z_bb_128:
    zT_466 = (unsigned int)zig_cast_checked_u((zu64)e, 32u, 1u, 32u);
    zT_468 = zF_E87F3361_pow5of(zT_466);
    p5 = zT_468;
    zT_470 = 4294967295u;
    zT_471 = m & zT_470;
    m_lo = zT_471;
    zT_473 = 32;
    zT_476 = (unsigned int)zT_473 < (unsigned int)(64);
    if (!(zT_476)) { pal_trap(); }
    zT_474 = m >> zT_473;
    m_hi = zT_474;
    zT_478 = 4294967295u;
    zT_479 = p5 & zT_478;
    p_lo = zT_479;
    zT_481 = 32;
    zT_484 = (unsigned int)zT_481 < (unsigned int)(64);
    if (!(zT_484)) { pal_trap(); }
    zT_482 = p5 >> zT_481;
    p_hi = zT_482;
    zT_486 = zig_wrap_mul_u(((zu64)(m_lo)), ((zu64)(p_lo)), 64u);
    zT_487 = zig_overflow_flag_mul_u(((zu64)(m_lo)), ((zu64)(p_lo)), 64u);
    zT_489 = zT_487 == (unsigned int)(0);
    if (!(zT_489)) { pal_trap(); }
    ll = zT_486;
    zT_491 = zig_wrap_mul_u(((zu64)(m_lo)), ((zu64)(p_hi)), 64u);
    zT_492 = zig_overflow_flag_mul_u(((zu64)(m_lo)), ((zu64)(p_hi)), 64u);
    zT_494 = zT_492 == (unsigned int)(0);
    if (!(zT_494)) { pal_trap(); }
    lh = zT_491;
    zT_496 = zig_wrap_mul_u(((zu64)(m_hi)), ((zu64)(p_lo)), 64u);
    zT_497 = zig_overflow_flag_mul_u(((zu64)(m_hi)), ((zu64)(p_lo)), 64u);
    zT_499 = zT_497 == (unsigned int)(0);
    if (!(zT_499)) { pal_trap(); }
    hl = zT_496;
    zT_501 = zig_wrap_mul_u(((zu64)(m_hi)), ((zu64)(p_hi)), 64u);
    zT_502 = zig_overflow_flag_mul_u(((zu64)(m_hi)), ((zu64)(p_hi)), 64u);
    zT_504 = zT_502 == (unsigned int)(0);
    if (!(zT_504)) { pal_trap(); }
    hh = zT_501;
    zT_506 = 32;
    zT_509 = (unsigned int)zT_506 < (unsigned int)(64);
    if (!(zT_509)) { pal_trap(); }
    zT_507 = ll >> zT_506;
    zT_510 = 4294967295u;
    zT_511 = lh & zT_510;
    zT_512 = zig_wrap_add_u(((zu64)(zT_507)), ((zu64)(zT_511)), 64u);
    zT_513 = zig_overflow_flag_add_u(((zu64)(zT_507)), ((zu64)(zT_511)), 64u);
    zT_515 = zT_513 == (unsigned int)(0);
    if (!(zT_515)) { pal_trap(); }
    zT_516 = 4294967295u;
    zT_517 = hl & zT_516;
    zT_518 = zig_wrap_add_u(((zu64)(zT_512)), ((zu64)(zT_517)), 64u);
    zT_519 = zig_overflow_flag_add_u(((zu64)(zT_512)), ((zu64)(zT_517)), 64u);
    zT_521 = zT_519 == (unsigned int)(0);
    if (!(zT_521)) { pal_trap(); }
    mid = zT_518;
    zT_523 = 4294967295u;
    zT_524 = mid & zT_523;
    zT_525 = 32;
    zT_528 = (unsigned int)zT_525 < (unsigned int)(64);
    if (!(zT_528)) { pal_trap(); }
    zT_526 = zig_wrap_shl_u(((zu64)(zT_524)), ((zu64)(zT_525)), 64u);
    zT_529 = zig_overflow_flag_shl_u(((zu64)(zT_524)), ((zu64)(zT_525)), 64u);
    zT_531 = zT_529 == (unsigned int)(0);
    if (!(zT_531)) { pal_trap(); }
    zT_532 = 4294967295u;
    zT_534 = zT_526 | (zT_79FAE712_u64)(ll & zT_532);
    lo = zT_534;
    zT_536 = 32;
    zT_539 = (unsigned int)zT_536 < (unsigned int)(64);
    if (!(zT_539)) { pal_trap(); }
    zT_537 = lh >> zT_536;
    zT_540 = zig_wrap_add_u(((zu64)(hh)), ((zu64)(zT_537)), 64u);
    zT_541 = zig_overflow_flag_add_u(((zu64)(hh)), ((zu64)(zT_537)), 64u);
    zT_543 = zT_541 == (unsigned int)(0);
    if (!(zT_543)) { pal_trap(); }
    zT_544 = 32;
    zT_547 = (unsigned int)zT_544 < (unsigned int)(64);
    if (!(zT_547)) { pal_trap(); }
    zT_545 = hl >> zT_544;
    zT_548 = zig_wrap_add_u(((zu64)(zT_540)), ((zu64)(zT_545)), 64u);
    zT_549 = zig_overflow_flag_add_u(((zu64)(zT_540)), ((zu64)(zT_545)), 64u);
    zT_551 = zT_549 == (unsigned int)(0);
    if (!(zT_551)) { pal_trap(); }
    zT_552 = 32;
    zT_555 = (unsigned int)zT_552 < (unsigned int)(64);
    if (!(zT_555)) { pal_trap(); }
    zT_553 = mid >> zT_552;
    zT_556 = zig_wrap_add_u(((zu64)(zT_548)), ((zu64)(zT_553)), 64u);
    zT_557 = zig_overflow_flag_add_u(((zu64)(zT_548)), ((zu64)(zT_553)), 64u);
    zT_559 = zT_557 == (unsigned int)(0);
    if (!(zT_559)) { pal_trap(); }
    hi = zT_556;
    zT_560 = hi;
    zT_561 = lo;
    zT_563 = e;
    zT_564 = h.negative;
    zT_567 = zF_13EBBFAD_fastRound(zT_560, zT_561, (unsigned char)(0), zT_563, zT_564);
    return zT_567;
    goto z_bb_127;
    z_bb_130:
    zT_569 = 0;
    zT_570 = zig_wrap_sub_s(((z64)(zT_569)), ((z64)(e)), 32u);
    zT_571 = zig_overflow_flag_sub_s(((z64)(zT_569)), ((z64)(e)), 32u);
    zT_573 = zT_571 == (unsigned int)(0);
    if (!(zT_573)) { pal_trap(); }
    k = zT_570;
    zT_575 = (unsigned int)zig_cast_checked_u((zu64)k, 32u, 1u, 32u);
    zT_577 = zF_E87F3361_pow5of(zT_575);
    p5b = zT_577;
    zT_581 = p5b != (unsigned int)(0);
    if (!(zT_581)) { pal_trap(); }
    zT_579 = m / p5b;
    q = zT_579;
    zT_585 = p5b != (unsigned int)(0);
    if (!(zT_585)) { pal_trap(); }
    zT_583 = m % p5b;
    rr = zT_583;
    zT_587 = 0;
    zT_588 = (zT_79FAE712_u64)zT_587;
    qhi = zT_588;
    qlo = q;
    zT_591 = 0;
    zT_592 = (int)zT_591;
    t = zT_592;
    goto z_bb_131;
    z_bb_131:
    zT_593 = qhi;
    zT_594 = qlo;
    zT_595 = zF_DE0896E8_bitlen128(zT_593, zT_594);
    zT_596 = 54;
    if ((unsigned char)(zT_595 < (unsigned int)zT_596)) goto z_bb_135; else goto z_bb_136;
    z_bb_132:
    zT_601 = 2;
    zT_602 = zig_wrap_mul_u(((zu64)(rr)), ((zu64)(zT_601)), 64u);
    zT_603 = zig_overflow_flag_mul_u(((zu64)(rr)), ((zu64)(zT_601)), 64u);
    zT_605 = zT_603 == (unsigned int)(0);
    if (!(zT_605)) { pal_trap(); }
    rr = zT_602;
    zT_607 = 0;
    zT_608 = (zT_79FAE712_u64)zT_607;
    bit = zT_608;
    if ((unsigned char)(rr >= p5b)) goto z_bb_138; else goto z_bb_139;
    z_bb_133:
    zT_646 = 0;
    zT_647 = zig_wrap_sub_s(((z64)(zT_646)), ((z64)(t)), 32u);
    zT_648 = zig_overflow_flag_sub_s(((z64)(zT_646)), ((z64)(t)), 32u);
    zT_650 = zT_648 == (unsigned int)(0);
    if (!(zT_650)) { pal_trap(); }
    zT_651 = zig_wrap_sub_s(((z64)(zT_647)), ((z64)(k)), 32u);
    zT_652 = zig_overflow_flag_sub_s(((z64)(zT_647)), ((z64)(k)), 32u);
    zT_654 = zT_652 == (unsigned int)(0);
    if (!(zT_654)) { pal_trap(); }
    e_prime = zT_651;
    zT_655 = qhi;
    zT_656 = qlo;
    zT_660 = 0;
    zT_658 = e_prime;
    zT_659 = h.negative;
    zT_663 = zF_13EBBFAD_fastRound(zT_655, zT_656, (unsigned char)(rr != (zT_79FAE712_u64)zT_660), zT_658, zT_659);
    return zT_663;
    z_bb_134:
    goto z_bb_131;
    z_bb_135:
    zT_599 = 0;
    zT_598 = rr != (zT_79FAE712_u64)zT_599;
    goto z_bb_137;
    z_bb_136:
    zT_598 = 0;
    goto z_bb_137;
    z_bb_137:
    if (zT_598) goto z_bb_132; else goto z_bb_133;
    z_bb_138:
    zT_610 = zig_wrap_sub_u(((zu64)(rr)), ((zu64)(p5b)), 64u);
    zT_611 = zig_overflow_flag_sub_u(((zu64)(rr)), ((zu64)(p5b)), 64u);
    zT_613 = zT_611 == (unsigned int)(0);
    if (!(zT_613)) { pal_trap(); }
    rr = zT_610;
    zT_614 = 1;
    zT_615 = (zT_79FAE712_u64)zT_614;
    bit = zT_615;
    goto z_bb_139;
    z_bb_139:
    zT_617 = 63;
    zT_620 = (unsigned int)zT_617 < (unsigned int)(64);
    if (!(zT_620)) { pal_trap(); }
    zT_618 = qlo >> zT_617;
    carry = zT_618;
    zT_621 = 2;
    zT_622 = zig_wrap_mul_u(((zu64)(qlo)), ((zu64)(zT_621)), 64u);
    zT_623 = zig_overflow_flag_mul_u(((zu64)(qlo)), ((zu64)(zT_621)), 64u);
    zT_625 = zT_623 == (unsigned int)(0);
    if (!(zT_625)) { pal_trap(); }
    zT_626 = zig_wrap_add_u(((zu64)(zT_622)), ((zu64)(bit)), 64u);
    zT_627 = zig_overflow_flag_add_u(((zu64)(zT_622)), ((zu64)(bit)), 64u);
    zT_629 = zT_627 == (unsigned int)(0);
    if (!(zT_629)) { pal_trap(); }
    qlo = zT_626;
    zT_630 = 2;
    zT_631 = zig_wrap_mul_u(((zu64)(qhi)), ((zu64)(zT_630)), 64u);
    zT_632 = zig_overflow_flag_mul_u(((zu64)(qhi)), ((zu64)(zT_630)), 64u);
    zT_634 = zT_632 == (unsigned int)(0);
    if (!(zT_634)) { pal_trap(); }
    zT_635 = zig_wrap_add_u(((zu64)(zT_631)), ((zu64)(carry)), 64u);
    zT_636 = zig_overflow_flag_add_u(((zu64)(zT_631)), ((zu64)(carry)), 64u);
    zT_638 = zT_636 == (unsigned int)(0);
    if (!(zT_638)) { pal_trap(); }
    qhi = zT_635;
    zT_639 = 1;
    zT_640 = (int)zT_639;
    zT_641 = zig_wrap_add_s(((z64)(t)), ((z64)(zT_640)), 32u);
    zT_642 = zig_overflow_flag_add_s(((z64)(t)), ((z64)(zT_640)), 32u);
    zT_644 = zT_642 == (unsigned int)(0);
    if (!(zT_644)) { pal_trap(); }
    t = zT_641;
    goto z_bb_134;
    z_bb_140:
    zT_667 = h.decimal_point;
    zT_668 = 0;
    if ((unsigned char)(zT_667 > zT_668)) goto z_bb_141; else goto z_bb_142;
    z_bb_141:
    zT_670 = (zT_4324C233_Hpd*)&h;
    zF_A5013D9C_hpdDiv2(zT_670);
    zT_672 = 1;
    zT_673 = (int)zT_672;
    zT_674 = zig_wrap_add_s(((z64)(exp2)), ((z64)(zT_673)), 32u);
    zT_675 = zig_overflow_flag_add_s(((z64)(exp2)), ((z64)(zT_673)), 32u);
    zT_677 = zT_675 == (unsigned int)(0);
    if (!(zT_677)) { pal_trap(); }
    exp2 = zT_674;
    goto z_bb_143;
    z_bb_142:
    goto z_bb_144;
    z_bb_143:
    goto z_bb_140;
    z_bb_144:
    if ((unsigned char)(1)) goto z_bb_145; else goto z_bb_146;
    z_bb_145:
    zT_679 = h.decimal_point;
    zT_680 = 0;
    if ((unsigned char)(zT_679 == zT_680)) goto z_bb_148; else goto z_bb_149;
    z_bb_146:
    zT_698 = 1;
    zT_699 = (int)zT_698;
    zT_700 = zig_wrap_sub_s(((z64)(exp2)), ((z64)(zT_699)), 32u);
    zT_701 = zig_overflow_flag_sub_s(((z64)(exp2)), ((z64)(zT_699)), 32u);
    zT_703 = zT_701 == (unsigned int)(0);
    if (!(zT_703)) { pal_trap(); }
    exp2 = zT_700;
    goto z_bb_153;
    z_bb_147:
    goto z_bb_144;
    z_bb_148:
    zT_683 = h.digits;
    zT_684 = 0;
    zT_686 = (unsigned int)zT_684 < (unsigned int)(800);
    if (!(zT_686)) { pal_trap(); }
    zT_687 = zT_683[zT_684];
    zT_688 = 5;
    zT_682 = zT_687 >= zT_688;
    goto z_bb_150;
    z_bb_149:
    zT_682 = 0;
    goto z_bb_150;
    z_bb_150:
    if (zT_682) goto z_bb_151; else goto z_bb_152;
    z_bb_151:
    goto z_bb_146;
    z_bb_152:
    zT_690 = (zT_4324C233_Hpd*)&h;
    zF_0E0CD583_hpdMul2(zT_690);
    zT_692 = 1;
    zT_693 = (int)zT_692;
    zT_694 = zig_wrap_sub_s(((z64)(exp2)), ((z64)(zT_693)), 32u);
    zT_695 = zig_overflow_flag_sub_s(((z64)(exp2)), ((z64)(zT_693)), 32u);
    zT_697 = zT_695 == (unsigned int)(0);
    if (!(zT_697)) { pal_trap(); }
    exp2 = zT_694;
    goto z_bb_147;
    z_bb_153:
    zT_704 = 1022;
    zT_705 = zig_wrap_add_s(((z64)(exp2)), ((z64)(zT_704)), 32u);
    zT_706 = zig_overflow_flag_add_s(((z64)(exp2)), ((z64)(zT_704)), 32u);
    zT_708 = zT_706 == (unsigned int)(0);
    if (!(zT_708)) { pal_trap(); }
    zT_709 = 0;
    if ((unsigned char)(zT_705 < zT_709)) goto z_bb_154; else goto z_bb_155;
    z_bb_154:
    zT_711 = (zT_4324C233_Hpd*)&h;
    zF_A5013D9C_hpdDiv2(zT_711);
    zT_713 = 1;
    zT_714 = (int)zT_713;
    zT_715 = zig_wrap_add_s(((z64)(exp2)), ((z64)(zT_714)), 32u);
    zT_716 = zig_overflow_flag_add_s(((z64)(exp2)), ((z64)(zT_714)), 32u);
    zT_718 = zT_716 == (unsigned int)(0);
    if (!(zT_718)) { pal_trap(); }
    exp2 = zT_715;
    goto z_bb_156;
    z_bb_155:
    zT_719 = 1023;
    zT_720 = zig_wrap_add_s(((z64)(exp2)), ((z64)(zT_719)), 32u);
    zT_721 = zig_overflow_flag_add_s(((z64)(exp2)), ((z64)(zT_719)), 32u);
    zT_723 = zT_721 == (unsigned int)(0);
    if (!(zT_723)) { pal_trap(); }
    zT_724 = 2047;
    if ((unsigned char)(zT_720 >= zT_724)) goto z_bb_157; else goto z_bb_158;
    z_bb_156:
    goto z_bb_153;
    z_bb_157:
    zT_726 = h.negative;
    zT_728 = zF_5493CDCE_f64SignedInf(zT_726);
    return zT_728;
    z_bb_158:
    zT_730 = 0;
    zT_731 = (unsigned int)zT_730;
    s = zT_731;
    goto z_bb_159;
    z_bb_159:
    zT_732 = 53;
    if ((unsigned char)(s < (unsigned int)zT_732)) goto z_bb_160; else goto z_bb_161;
    z_bb_160:
    zT_734 = (zT_4324C233_Hpd*)&h;
    zF_0E0CD583_hpdMul2(zT_734);
    zT_736 = 1;
    zT_737 = (unsigned int)zT_736;
    zT_738 = zig_wrap_add_u(((zu64)(s)), ((zu64)(zT_737)), 32u);
    zT_739 = zig_overflow_flag_add_u(((zu64)(s)), ((zu64)(zT_737)), 32u);
    zT_741 = zT_739 == (unsigned int)(0);
    if (!(zT_741)) { pal_trap(); }
    s = zT_738;
    goto z_bb_162;
    z_bb_161:
    zT_743 = (zT_4324C233_Hpd*)&h;
    zT_745 = zF_4EA36099_hpdRound(zT_743);
    mantissa = zT_745;
    zT_746 = 1;
    zT_747 = 53;
    zT_750 = (unsigned int)zT_747 < (unsigned int)(64);
    if (!(zT_750)) { pal_trap(); }
    zT_748 = zig_wrap_shl_u(((zu64)(zT_746)), ((zu64)(zT_747)), 64u);
    zT_751 = zig_overflow_flag_shl_u(((zu64)(zT_746)), ((zu64)(zT_747)), 64u);
    zT_753 = zT_751 == (unsigned int)(0);
    if (!(zT_753)) { pal_trap(); }
    if ((unsigned char)(mantissa >= zT_748)) goto z_bb_163; else goto z_bb_164;
    z_bb_162:
    goto z_bb_159;
    z_bb_163:
    zT_755 = (zT_4324C233_Hpd*)&h;
    zF_A5013D9C_hpdDiv2(zT_755);
    zT_757 = 1;
    zT_758 = (int)zT_757;
    zT_759 = zig_wrap_add_s(((z64)(exp2)), ((z64)(zT_758)), 32u);
    zT_760 = zig_overflow_flag_add_s(((z64)(exp2)), ((z64)(zT_758)), 32u);
    zT_762 = zT_760 == (unsigned int)(0);
    if (!(zT_762)) { pal_trap(); }
    exp2 = zT_759;
    zT_763 = (zT_4324C233_Hpd*)&h;
    zT_765 = zF_4EA36099_hpdRound(zT_763);
    mantissa = zT_765;
    zT_766 = 1023;
    zT_767 = zig_wrap_add_s(((z64)(exp2)), ((z64)(zT_766)), 32u);
    zT_768 = zig_overflow_flag_add_s(((z64)(exp2)), ((z64)(zT_766)), 32u);
    zT_770 = zT_768 == (unsigned int)(0);
    if (!(zT_770)) { pal_trap(); }
    zT_771 = 2047;
    if ((unsigned char)(zT_767 >= zT_771)) goto z_bb_165; else goto z_bb_166;
    z_bb_164:
    zT_777 = 1023;
    zT_778 = zig_wrap_add_s(((z64)(exp2)), ((z64)(zT_777)), 32u);
    zT_779 = zig_overflow_flag_add_s(((z64)(exp2)), ((z64)(zT_777)), 32u);
    zT_781 = zT_779 == (unsigned int)(0);
    if (!(zT_781)) { pal_trap(); }
    power2 = zT_778;
    zT_782 = 1;
    zT_783 = 52;
    zT_786 = (unsigned int)zT_783 < (unsigned int)(64);
    if (!(zT_786)) { pal_trap(); }
    zT_784 = zig_wrap_shl_u(((zu64)(zT_782)), ((zu64)(zT_783)), 64u);
    zT_787 = zig_overflow_flag_shl_u(((zu64)(zT_782)), ((zu64)(zT_783)), 64u);
    zT_789 = zT_787 == (unsigned int)(0);
    if (!(zT_789)) { pal_trap(); }
    if ((unsigned char)(mantissa < zT_784)) goto z_bb_167; else goto z_bb_168;
    z_bb_165:
    zT_773 = h.negative;
    zT_775 = zF_5493CDCE_f64SignedInf(zT_773);
    return zT_775;
    z_bb_166:
    goto z_bb_164;
    z_bb_167:
    zT_791 = 1;
    zT_792 = (int)zT_791;
    zT_793 = zig_wrap_sub_s(((z64)(power2)), ((z64)(zT_792)), 32u);
    zT_794 = zig_overflow_flag_sub_s(((z64)(power2)), ((z64)(zT_792)), 32u);
    zT_796 = zT_794 == (unsigned int)(0);
    if (!(zT_796)) { pal_trap(); }
    power2 = zT_793;
    goto z_bb_168;
    z_bb_168:
    zT_797 = Z98_U64_C(4503599627370495);
    zT_798 = mantissa & zT_797;
    mantissa = zT_798;
    zT_800 = (zT_79FAE712_u64)zig_cast_checked_u((zu64)power2, 32u, 1u, 64u);
    zT_801 = 52;
    zT_804 = (unsigned int)zT_801 < (unsigned int)(64);
    if (!(zT_804)) { pal_trap(); }
    zT_802 = zig_wrap_shl_u(((zu64)(zT_800)), ((zu64)(zT_801)), 64u);
    zT_805 = zig_overflow_flag_shl_u(((zu64)(zT_800)), ((zu64)(zT_801)), 64u);
    zT_807 = zT_805 == (unsigned int)(0);
    if (!(zT_807)) { pal_trap(); }
    zT_808 = zT_802 | mantissa;
    bits = zT_808;
    zT_809 = h.negative;
    if (zT_809) goto z_bb_169; else goto z_bb_170;
    z_bb_169:
    zT_810 = Z98_U64_C(9223372036854775808);
    zT_811 = bits | zT_810;
    bits = zT_811;
    goto z_bb_170;
    z_bb_170:
    zT_812 = bits;
    zT_813 = zF_E24707C3_f64FromBits(zT_812);
    return zT_813;
}

/* isU64MaxLiteral */
unsigned char zF_6E4D822B_isU64MaxLiteral(zT_8F083A69_Slice_zT_0B42B2F8_u text) {
    unsigned int zT_2;
    int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    int zT_9;
    zT_79FAE712_u64 zT_11;
    zT_79FAE712_u64 zT_12;
    zig_poison_fill((void*)&zT_11, (unsigned int)sizeof zT_11);
    zT_79FAE712_u64 val;
    zT_2 = text.len;
    zT_3 = 2;
    if ((unsigned char)(zT_2 < (unsigned int)zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = text;
    zT_9 = 16;
    zT_11 = zF_8EC79679_parseU64(zT_7, (unsigned char)((unsigned char)zT_9));
    val = zT_11;
    zT_12 = Z98_U64_C(18446744073709551615);
    return (unsigned char)(val == (zT_79FAE712_u64)zT_12);
}

/* assertEqBool */
void zF_F0A50871_assertEqBool(unsigned char actual, unsigned char expected, unsigned int line) {
    zT_5826BFC7_Arr_unsigned_char_1 zT_5;
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    int zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    unsigned char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned char* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    zT_5826BFC7_Arr_unsigned_char_1 fmt_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fail;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_exp;
    zT_8F083A69_Slice_zT_0B42B2F8_u str_true;
    zT_8F083A69_Slice_zT_0B42B2F8_u str_false;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_got;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_nl;
    if ((unsigned char)(actual != expected)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fmt_buf[_i] = zT_5[_i];
        _i++;
    }
}
    zT_7 = "FAIL line ";
    zT_9 = 10;
    zT_8.ptr = (unsigned char*)zT_7;
    zT_8.len = zT_9;
    s_fail = zT_8;
    zT_10 = s_fail;
    zF_E4B2EF19_stderr_write(zT_10);
    zT_12 = line;
    zT_17 = 0;
    zT_18 = (unsigned char*)((unsigned char*)fmt_buf) + zT_17;
    zT_19 = (unsigned int)(12) - zT_17;
    zT_20.ptr = (unsigned char*)zT_18;
    zT_20.len = zT_19;
    zT_13 = zT_20;
    zT_21 = 12;
    zT_23 = zF_2FED9490_formatU32_1(zT_12, zT_13, (unsigned int)((unsigned int)zT_21));
    zT_11 = zT_23;
    zF_E4B2EF19_stderr_write(zT_11);
    zT_25 = ": expected ";
    zT_27 = 11;
    zT_26.ptr = (unsigned char*)zT_25;
    zT_26.len = zT_27;
    s_exp = zT_26;
    zT_28 = s_exp;
    zF_E4B2EF19_stderr_write(zT_28);
    zT_30 = "true";
    zT_32 = 4;
    zT_31.ptr = (unsigned char*)zT_30;
    zT_31.len = zT_32;
    str_true = zT_31;
    zT_34 = "false";
    zT_36 = 5;
    zT_35.ptr = (unsigned char*)zT_34;
    zT_35.len = zT_36;
    str_false = zT_35;
    if (expected) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    return;
    z_bb_3:
    zT_37 = str_true;
    zF_E4B2EF19_stderr_write(zT_37);
    goto z_bb_4;
    z_bb_4:
    zT_40 = ", got ";
    zT_42 = 6;
    zT_41.ptr = (unsigned char*)zT_40;
    zT_41.len = zT_42;
    s_got = zT_41;
    zT_43 = s_got;
    zF_E4B2EF19_stderr_write(zT_43);
    if (actual) goto z_bb_6; else goto z_bb_8;
    z_bb_5:
    zT_38 = str_false;
    zF_E4B2EF19_stderr_write(zT_38);
    goto z_bb_4;
    z_bb_6:
    zT_44 = str_true;
    zF_E4B2EF19_stderr_write(zT_44);
    goto z_bb_7;
    z_bb_7:
    zT_47 = "\n";
    zT_49 = 1;
    zT_48.ptr = (unsigned char*)zT_47;
    zT_48.len = zT_49;
    s_nl = zT_48;
    zT_50 = s_nl;
    zF_E4B2EF19_stderr_write(zT_50);
    goto z_bb_2;
    z_bb_8:
    zT_45 = str_false;
    zF_E4B2EF19_stderr_write(zT_45);
    goto z_bb_7;
}

/* assertEqU32 */
void zF_EFB8936D_assertEqU32(unsigned int actual, unsigned int expected, unsigned int line) {
    zT_5826BFC7_Arr_unsigned_char_1 zT_5;
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    int zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    int zT_35;
    unsigned char* zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned char* zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    int zT_53;
    unsigned char* zT_54;
    unsigned int zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    zig_poison_fill((void*)&zT_41, (unsigned int)sizeof zT_41);
    zig_poison_fill((void*)&zT_59, (unsigned int)sizeof zT_59);
    zT_5826BFC7_Arr_unsigned_char_1 fmt_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fail;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_exp;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_got;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_nl;
    if ((unsigned char)(actual != expected)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fmt_buf[_i] = zT_5[_i];
        _i++;
    }
}
    zT_7 = "FAIL line ";
    zT_9 = 10;
    zT_8.ptr = (unsigned char*)zT_7;
    zT_8.len = zT_9;
    s_fail = zT_8;
    zT_10 = s_fail;
    zF_E4B2EF19_stderr_write(zT_10);
    zT_12 = line;
    zT_17 = 0;
    zT_18 = (unsigned char*)((unsigned char*)fmt_buf) + zT_17;
    zT_19 = (unsigned int)(12) - zT_17;
    zT_20.ptr = (unsigned char*)zT_18;
    zT_20.len = zT_19;
    zT_13 = zT_20;
    zT_21 = 12;
    zT_23 = zF_2FED9490_formatU32_1(zT_12, zT_13, (unsigned int)((unsigned int)zT_21));
    zT_11 = zT_23;
    zF_E4B2EF19_stderr_write(zT_11);
    zT_25 = ": expected ";
    zT_27 = 11;
    zT_26.ptr = (unsigned char*)zT_25;
    zT_26.len = zT_27;
    s_exp = zT_26;
    zT_28 = s_exp;
    zF_E4B2EF19_stderr_write(zT_28);
    zT_30 = expected;
    zT_35 = 0;
    zT_36 = (unsigned char*)((unsigned char*)fmt_buf) + zT_35;
    zT_37 = (unsigned int)(12) - zT_35;
    zT_38.ptr = (unsigned char*)zT_36;
    zT_38.len = zT_37;
    zT_31 = zT_38;
    zT_39 = 12;
    zT_41 = zF_2FED9490_formatU32_1(zT_30, zT_31, (unsigned int)((unsigned int)zT_39));
    zT_29 = zT_41;
    zF_E4B2EF19_stderr_write(zT_29);
    zT_43 = ", got ";
    zT_45 = 6;
    zT_44.ptr = (unsigned char*)zT_43;
    zT_44.len = zT_45;
    s_got = zT_44;
    zT_46 = s_got;
    zF_E4B2EF19_stderr_write(zT_46);
    zT_48 = actual;
    zT_53 = 0;
    zT_54 = (unsigned char*)((unsigned char*)fmt_buf) + zT_53;
    zT_55 = (unsigned int)(12) - zT_53;
    zT_56.ptr = (unsigned char*)zT_54;
    zT_56.len = zT_55;
    zT_49 = zT_56;
    zT_57 = 12;
    zT_59 = zF_2FED9490_formatU32_1(zT_48, zT_49, (unsigned int)((unsigned int)zT_57));
    zT_47 = zT_59;
    zF_E4B2EF19_stderr_write(zT_47);
    zT_61 = "\n";
    zT_63 = 1;
    zT_62.ptr = (unsigned char*)zT_61;
    zT_62.len = zT_63;
    s_nl = zT_62;
    zT_64 = s_nl;
    zF_E4B2EF19_stderr_write(zT_64);
    goto z_bb_2;
    z_bb_2:
    return;
}

/* assertEqU8 */
void zF_8856257C_assertEqU8(unsigned char actual, unsigned char expected, unsigned int line) {
    zT_5826BFC7_Arr_unsigned_char_1 zT_5;
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    int zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    zT_5826BFC7_Arr_unsigned_char_1 fmt_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fail;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_msg;
    if ((unsigned char)(actual != expected)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fmt_buf[_i] = zT_5[_i];
        _i++;
    }
}
    zT_7 = "FAIL line ";
    zT_9 = 10;
    zT_8.ptr = (unsigned char*)zT_7;
    zT_8.len = zT_9;
    s_fail = zT_8;
    zT_10 = s_fail;
    zF_E4B2EF19_stderr_write(zT_10);
    zT_12 = line;
    zT_17 = 0;
    zT_18 = (unsigned char*)((unsigned char*)fmt_buf) + zT_17;
    zT_19 = (unsigned int)(12) - zT_17;
    zT_20.ptr = (unsigned char*)zT_18;
    zT_20.len = zT_19;
    zT_13 = zT_20;
    zT_21 = 12;
    zT_23 = zF_2FED9490_formatU32_1(zT_12, zT_13, (unsigned int)((unsigned int)zT_21));
    zT_11 = zT_23;
    zF_E4B2EF19_stderr_write(zT_11);
    zT_25 = ": expected char\n";
    zT_27 = 16;
    zT_26.ptr = (unsigned char*)zT_25;
    zT_26.len = zT_27;
    s_msg = zT_26;
    zT_28 = s_msg;
    zF_E4B2EF19_stderr_write(zT_28);
    goto z_bb_2;
    z_bb_2:
    return;
}

/* assertEqTokenKind */
void zF_1058D9A8_assertEqTokenKind(zT_EAC3E484_TokenKind actual, zT_EAC3E484_TokenKind expected, unsigned int line) {
    zT_5826BFC7_Arr_unsigned_char_1 zT_5;
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    int zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    zig_poison_fill((void*)&zT_23, (unsigned int)sizeof zT_23);
    zT_5826BFC7_Arr_unsigned_char_1 fmt_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg1;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg2;
    if ((unsigned char)(actual != expected)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zig_poison_fill((void*)&zT_5, (unsigned int)sizeof zT_5);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fmt_buf[_i] = zT_5[_i];
        _i++;
    }
}
    zT_7 = "FAIL line ";
    zT_9 = 10;
    zT_8.ptr = (unsigned char*)zT_7;
    zT_8.len = zT_9;
    msg1 = zT_8;
    zT_10 = msg1;
    zF_E4B2EF19_stderr_write(zT_10);
    zT_12 = line;
    zT_17 = 0;
    zT_18 = (unsigned char*)((unsigned char*)fmt_buf) + zT_17;
    zT_19 = (unsigned int)(12) - zT_17;
    zT_20.ptr = (unsigned char*)zT_18;
    zT_20.len = zT_19;
    zT_13 = zT_20;
    zT_21 = 12;
    zT_23 = zF_2FED9490_formatU32_1(zT_12, zT_13, (unsigned int)((unsigned int)zT_21));
    zT_11 = zT_23;
    zF_E4B2EF19_stderr_write(zT_11);
    zT_25 = ": token kind mismatch\n";
    zT_27 = 22;
    zT_26.ptr = (unsigned char*)zT_25;
    zT_26.len = zT_27;
    msg2 = zT_26;
    zT_28 = msg2;
    zF_E4B2EF19_stderr_write(zT_28);
    goto z_bb_2;
    z_bb_2:
    return;
}

/* formatU32 */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_2FED9490_formatU32_1(unsigned int val, zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int buf_len) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned char zT_8;
    int zT_10;
    unsigned char zT_11;
    unsigned char* zT_12;
    unsigned int zT_13;
    unsigned char zT_14;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    int zT_21;
    unsigned char zT_23;
    unsigned char* zT_24;
    unsigned int zT_25;
    unsigned char zT_26;
    int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    int zT_33;
    unsigned int zT_35;
    int zT_36;
    unsigned int zT_37;
    unsigned char zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned char zT_43;
    unsigned char zT_44;
    unsigned char* zT_45;
    unsigned int zT_46;
    unsigned char zT_47;
    int zT_48;
    unsigned int zT_49;
    unsigned char zT_51;
    int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned char zT_57;
    int zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned char zT_63;
    unsigned char* zT_64;
    unsigned int zT_65;
    int zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned char zT_70;
    unsigned char* zT_71;
    unsigned int zT_72;
    unsigned char zT_73;
    unsigned char zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int idx;
    unsigned int v;
    unsigned int start;
    zT_4 = 1;
    zT_5 = zig_wrap_sub_u(((zu64)(buf_len)), ((zu64)(zT_4)), 32u);
    zT_6 = zig_overflow_flag_sub_u(((zu64)(buf_len)), ((zu64)(zT_4)), 32u);
    zT_8 = zT_6 == (unsigned int)(0);
    if (!(zT_8)) { pal_trap(); }
    idx = zT_5;
    v = val;
    zT_10 = 0;
    zT_11 = (unsigned char)zT_10;
    zT_12 = buf.ptr;
    zT_13 = buf.len;
    zT_14 = idx < zT_13;
    if (!(zT_14)) { pal_trap(); }
    zT_12[idx] = zT_11;
    zT_15 = 1;
    zT_16 = (unsigned int)zT_15;
    zT_17 = zig_wrap_sub_u(((zu64)(idx)), ((zu64)(zT_16)), 32u);
    zT_18 = zig_overflow_flag_sub_u(((zu64)(idx)), ((zu64)(zT_16)), 32u);
    zT_20 = zT_18 == (unsigned int)(0);
    if (!(zT_20)) { pal_trap(); }
    idx = zT_17;
    zT_21 = 0;
    if ((unsigned char)(v == (unsigned int)zT_21)) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_23 = 48;
    zT_24 = buf.ptr;
    zT_25 = buf.len;
    zT_26 = idx < zT_25;
    if (!(zT_26)) { pal_trap(); }
    zT_24[idx] = zT_23;
    zT_27 = 1;
    zT_28 = (unsigned int)zT_27;
    zT_29 = zig_wrap_sub_u(((zu64)(idx)), ((zu64)(zT_28)), 32u);
    zT_30 = zig_overflow_flag_sub_u(((zu64)(idx)), ((zu64)(zT_28)), 32u);
    zT_32 = zT_30 == (unsigned int)(0);
    if (!(zT_32)) { pal_trap(); }
    idx = zT_29;
    goto z_bb_2;
    z_bb_2:
    zT_59 = 1;
    zT_60 = zig_wrap_add_u(((zu64)(idx)), ((zu64)(zT_59)), 32u);
    zT_61 = zig_overflow_flag_add_u(((zu64)(idx)), ((zu64)(zT_59)), 32u);
    zT_63 = zT_61 == (unsigned int)(0);
    if (!(zT_63)) { pal_trap(); }
    start = zT_60;
    zT_64 = buf.ptr;
    zT_65 = buf.len;
    zT_66 = 1;
    zT_67 = zig_wrap_sub_u(((zu64)(buf_len)), ((zu64)(zT_66)), 32u);
    zT_68 = zig_overflow_flag_sub_u(((zu64)(buf_len)), ((zu64)(zT_66)), 32u);
    zT_70 = zT_68 == (unsigned int)(0);
    if (!(zT_70)) { pal_trap(); }
    zT_71 = zT_64 + start;
    zT_72 = zT_67 - start;
    zT_73 = start <= zT_67;
    if (!(zT_73)) { pal_trap(); }
    zT_74 = zT_67 <= zT_65;
    if (!(zT_74)) { pal_trap(); }
    zT_75.ptr = (unsigned char*)zT_71;
    zT_75.len = zT_72;
    return zT_75;
    z_bb_3:
    goto z_bb_4;
    z_bb_4:
    zT_33 = 0;
    if ((unsigned char)(v > (unsigned int)zT_33)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_35 = 48;
    zT_36 = 10;
    zT_39 = (unsigned int)zT_36 != (unsigned int)(0);
    if (!(zT_39)) { pal_trap(); }
    zT_37 = v % zT_36;
    zT_40 = zig_wrap_add_u(((zu64)(zT_35)), ((zu64)(zT_37)), 32u);
    zT_41 = zig_overflow_flag_add_u(((zu64)(zT_35)), ((zu64)(zT_37)), 32u);
    zT_43 = zT_41 == (unsigned int)(0);
    if (!(zT_43)) { pal_trap(); }
    zT_44 = (unsigned char)zig_cast_checked_u((zu64)zT_40, 32u, 0u, 8u);
    zT_45 = buf.ptr;
    zT_46 = buf.len;
    zT_47 = idx < zT_46;
    if (!(zT_47)) { pal_trap(); }
    zT_45[idx] = zT_44;
    zT_48 = 10;
    zT_51 = (unsigned int)zT_48 != (unsigned int)(0);
    if (!(zT_51)) { pal_trap(); }
    zT_49 = v / zT_48;
    v = zT_49;
    zT_52 = 1;
    zT_53 = (unsigned int)zT_52;
    zT_54 = zig_wrap_sub_u(((zu64)(idx)), ((zu64)(zT_53)), 32u);
    zT_55 = zig_overflow_flag_sub_u(((zu64)(idx)), ((zu64)(zT_53)), 32u);
    zT_57 = zT_55 == (unsigned int)(0);
    if (!(zT_57)) { pal_trap(); }
    idx = zT_54;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_2;
    z_bb_7:
    goto z_bb_4;
}

/* lexerRunAllTests */
void zF_C3A6E90A_lexerRunAllTests(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg1;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg2;
    zT_1 = "Running lexer tests...\n";
    zT_3 = 23;
    zT_2.ptr = (unsigned char*)zT_1;
    zT_2.len = zT_3;
    msg1 = zT_2;
    zT_4 = msg1;
    zF_E4B2EF19_stderr_write(zT_4);
    zF_6492230E_lexerTestHelpers();
    zF_BF88F19A_lexerTestSkipWhites();
    zF_9AA3D1F6_lexerTestOperators();
    zF_4CB82885_lexerTestScanNumber();
    zF_A76AF035_lexerTestScanString();
    zF_13791BA0_lexerTestScanChar();
    zF_B8F07D3E_lexerTestIdentifier();
    zF_1C8729CF_lexerTestBuiltinIde();
    zF_6836167B_lexerTestDiagnostic();
    zF_4B029FD3_runLexerUnitTests();
    zT_6 = "All lexer tests passed.\n";
    zT_8 = 24;
    zT_7.ptr = (unsigned char*)zT_6;
    zT_7.len = zT_8;
    msg2 = zT_7;
    zT_9 = msg2;
    zF_E4B2EF19_stderr_write(zT_9);
    return;
}

/* lexerTestSanityCheck */
void zF_519E4401_lexerTestSanityChec(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    char* zT_5;
    unsigned int zT_6;
    char* zT_7;
    unsigned int zT_8;
    char* zT_9;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_1 = "Running lexer sanity check (should fail)...\n";
    zT_3 = 44;
    zT_2.ptr = (unsigned char*)zT_1;
    zT_2.len = zT_3;
    msg = zT_2;
    zT_4 = msg;
    zF_E4B2EF19_stderr_write(zT_4);
    zT_5 = "panic: ";
    zT_6 = 7;
    fwrite(zT_5, 1, zT_6, stderr);
    zT_7 = "intentional sanity check failure";
    zT_8 = 32;
    fwrite(zT_7, 1, zT_8, stderr);
    zT_9 = "\n";
    zT_10 = 1;
    fwrite(zT_9, 1, zT_10, stderr);
    pal_trap();
}

/* lexerTestHelpers */
void zF_6492230E_lexerTestHelpers(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10;
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17;
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21;
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45;
    unsigned char zT_46;
    zT_138FFB41_Lexer* zT_49;
    unsigned char zT_51;
    unsigned int zT_57;
    int zT_59;
    unsigned int zT_62;
    int zT_66;
    unsigned int zT_69;
    int zT_73;
    unsigned char zT_76;
    zT_138FFB41_Lexer* zT_79;
    unsigned char zT_81;
    unsigned char zT_84;
    zT_138FFB41_Lexer* zT_87;
    unsigned char zT_89;
    unsigned char zT_92;
    zT_138FFB41_Lexer* zT_95;
    int zT_98;
    unsigned char zT_100;
    unsigned char zT_103;
    zT_138FFB41_Lexer* zT_106;
    unsigned char zT_108;
    unsigned char zT_111;
    zT_138FFB41_Lexer* zT_114;
    unsigned char zT_116;
    unsigned char zT_119;
    zT_138FFB41_Lexer* zT_122;
    unsigned char zT_124;
    unsigned char zT_127;
    zT_138FFB41_Lexer* zT_130;
    unsigned char zT_132;
    unsigned char zT_135;
    zT_138FFB41_Lexer* zT_138;
    unsigned char zT_140;
    int zT_141;
    unsigned char zT_144;
    zT_138FFB41_Lexer* zT_147;
    unsigned char zT_149;
    int zT_150;
    unsigned char* zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned int zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    zT_D3EB6303_StringInterner* zT_160;
    zT_F85C5DED_DiagnosticCollector* zT_161;
    zT_3E40CD83_Sand* zT_162;
    int zT_163;
    zT_138FFB41_Lexer zT_168;
    unsigned char zT_169;
    zT_138FFB41_Lexer* zT_172;
    unsigned char zT_176;
    unsigned char zT_179;
    zT_138FFB41_Lexer* zT_182;
    unsigned char zT_186;
    unsigned char zT_189;
    zT_138FFB41_Lexer* zT_192;
    unsigned char zT_196;
    unsigned char* zT_200;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_201;
    unsigned int zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_204;
    zT_D3EB6303_StringInterner* zT_206;
    zT_F85C5DED_DiagnosticCollector* zT_207;
    zT_3E40CD83_Sand* zT_208;
    int zT_209;
    zT_138FFB41_Lexer zT_214;
    zT_138FFB41_Lexer* zT_215;
    unsigned char zT_217;
    unsigned int zT_218;
    int zT_222;
    unsigned int zT_225;
    int zT_229;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_51, (unsigned int)sizeof zT_51);
    zig_poison_fill((void*)&zT_81, (unsigned int)sizeof zT_81);
    zig_poison_fill((void*)&zT_89, (unsigned int)sizeof zT_89);
    zig_poison_fill((void*)&zT_100, (unsigned int)sizeof zT_100);
    zig_poison_fill((void*)&zT_108, (unsigned int)sizeof zT_108);
    zig_poison_fill((void*)&zT_116, (unsigned int)sizeof zT_116);
    zig_poison_fill((void*)&zT_124, (unsigned int)sizeof zT_124);
    zig_poison_fill((void*)&zT_132, (unsigned int)sizeof zT_132);
    zig_poison_fill((void*)&zT_140, (unsigned int)sizeof zT_140);
    zig_poison_fill((void*)&zT_149, (unsigned int)sizeof zT_149);
    zig_poison_fill((void*)&zT_168, (unsigned int)sizeof zT_168);
    zig_poison_fill((void*)&zT_176, (unsigned int)sizeof zT_176);
    zig_poison_fill((void*)&zT_186, (unsigned int)sizeof zT_186);
    zig_poison_fill((void*)&zT_196, (unsigned int)sizeof zT_196);
    zig_poison_fill((void*)&zT_214, (unsigned int)sizeof zT_214);
    zig_poison_fill((void*)&zT_217, (unsigned int)sizeof zT_217);
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u test_src;
    zT_138FFB41_Lexer lexer;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ab;
    zT_138FFB41_Lexer lexer2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_nl;
    zT_138FFB41_Lexer lexer3;
    zig_poison_fill((void*)&zT_1, (unsigned int)sizeof zT_1);
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = (unsigned char*)zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = (zT_3E40CD83_Sand*)&sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = (zT_3E40CD83_Sand*)&sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = (zT_3E40CD83_Sand*)&sand;
    zT_24 = (zT_227EDE07_SourceManager*)&source_man;
    zT_25 = (zT_D3EB6303_StringInterner*)&interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "abc";
    zT_33 = 3;
    zT_32.ptr = (unsigned char*)zT_31;
    zT_32.len = zT_33;
    test_src = zT_32;
    zT_35 = test_src;
    zT_40 = 0;
    zT_37 = (zT_D3EB6303_StringInterner*)&interner;
    zT_38 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_39 = (zT_3E40CD83_Sand*)&sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    lexer = zT_45;
    zT_49 = (zT_138FFB41_Lexer*)&lexer;
    zT_51 = zF_07BC1EA1_lexerIsAtEnd(zT_49);
    zT_46 = zT_51;
    zF_F0A50871_assertEqBool(zT_46, (unsigned char)(0), (unsigned int)(0));
    zT_57 = lexer.pos;
    zT_59 = 0;
    zF_EFB8936D_assertEqU32((unsigned int)((unsigned int)zT_57), (unsigned int)((unsigned int)zT_59), (unsigned int)(0));
    zT_62 = lexer.line;
    zT_66 = 1;
    zF_EFB8936D_assertEqU32(zT_62, (unsigned int)((unsigned int)zT_66), (unsigned int)(0));
    zT_69 = lexer.col;
    zT_73 = 1;
    zF_EFB8936D_assertEqU32(zT_69, (unsigned int)((unsigned int)zT_73), (unsigned int)(0));
    zT_79 = (zT_138FFB41_Lexer*)&lexer;
    zT_81 = zF_7C2FDD01_lexerAdvance(zT_79);
    zT_76 = zT_81;
    zF_8856257C_assertEqU8(zT_76, (unsigned char)(97), (unsigned int)(0));
    zT_87 = (zT_138FFB41_Lexer*)&lexer;
    zT_89 = zF_6ACB12FA_lexerPeek(zT_87);
    zT_84 = zT_89;
    zF_8856257C_assertEqU8(zT_84, (unsigned char)(98), (unsigned int)(0));
    zT_95 = (zT_138FFB41_Lexer*)&lexer;
    zT_98 = 1;
    zT_100 = zF_D1AE715C_lexerPeekN(zT_95, (unsigned int)((unsigned int)zT_98));
    zT_92 = zT_100;
    zF_8856257C_assertEqU8(zT_92, (unsigned char)(99), (unsigned int)(0));
    zT_106 = (zT_138FFB41_Lexer*)&lexer;
    zT_108 = zF_07BC1EA1_lexerIsAtEnd(zT_106);
    zT_103 = zT_108;
    zF_F0A50871_assertEqBool(zT_103, (unsigned char)(0), (unsigned int)(0));
    zT_114 = (zT_138FFB41_Lexer*)&lexer;
    zT_116 = zF_7C2FDD01_lexerAdvance(zT_114);
    zT_111 = zT_116;
    zF_8856257C_assertEqU8(zT_111, (unsigned char)(98), (unsigned int)(0));
    zT_122 = (zT_138FFB41_Lexer*)&lexer;
    zT_124 = zF_7C2FDD01_lexerAdvance(zT_122);
    zT_119 = zT_124;
    zF_8856257C_assertEqU8(zT_119, (unsigned char)(99), (unsigned int)(0));
    zT_130 = (zT_138FFB41_Lexer*)&lexer;
    zT_132 = zF_07BC1EA1_lexerIsAtEnd(zT_130);
    zT_127 = zT_132;
    zF_F0A50871_assertEqBool(zT_127, (unsigned char)(1), (unsigned int)(0));
    zT_138 = (zT_138FFB41_Lexer*)&lexer;
    zT_140 = zF_7C2FDD01_lexerAdvance(zT_138);
    zT_135 = zT_140;
    zT_141 = 0;
    zF_8856257C_assertEqU8(zT_135, (unsigned char)((unsigned char)zT_141), (unsigned int)(0));
    zT_147 = (zT_138FFB41_Lexer*)&lexer;
    zT_149 = zF_6ACB12FA_lexerPeek(zT_147);
    zT_144 = zT_149;
    zT_150 = 0;
    zF_8856257C_assertEqU8(zT_144, (unsigned char)((unsigned char)zT_150), (unsigned int)(0));
    zT_154 = "ab";
    zT_156 = 2;
    zT_155.ptr = (unsigned char*)zT_154;
    zT_155.len = zT_156;
    s_ab = zT_155;
    zT_158 = s_ab;
    zT_163 = 0;
    zT_160 = (zT_D3EB6303_StringInterner*)&interner;
    zT_161 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_162 = (zT_3E40CD83_Sand*)&sand;
    zT_168 = zF_151E643F_lexerInit(zT_158, (unsigned int)((unsigned int)zT_163), zT_160, zT_161, zT_162);
    lexer2 = zT_168;
    zT_172 = (zT_138FFB41_Lexer*)&lexer2;
    zT_176 = zF_8A07967A_lexerMatch(zT_172, (unsigned char)(97));
    zT_169 = zT_176;
    zF_F0A50871_assertEqBool(zT_169, (unsigned char)(1), (unsigned int)(0));
    zT_182 = (zT_138FFB41_Lexer*)&lexer2;
    zT_186 = zF_8A07967A_lexerMatch(zT_182, (unsigned char)(120));
    zT_179 = zT_186;
    zF_F0A50871_assertEqBool(zT_179, (unsigned char)(0), (unsigned int)(0));
    zT_192 = (zT_138FFB41_Lexer*)&lexer2;
    zT_196 = zF_8A07967A_lexerMatch(zT_192, (unsigned char)(98));
    zT_189 = zT_196;
    zF_F0A50871_assertEqBool(zT_189, (unsigned char)(1), (unsigned int)(0));
    zT_200 = "\n";
    zT_202 = 1;
    zT_201.ptr = (unsigned char*)zT_200;
    zT_201.len = zT_202;
    s_nl = zT_201;
    zT_204 = s_nl;
    zT_209 = 0;
    zT_206 = (zT_D3EB6303_StringInterner*)&interner;
    zT_207 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_208 = (zT_3E40CD83_Sand*)&sand;
    zT_214 = zF_151E643F_lexerInit(zT_204, (unsigned int)((unsigned int)zT_209), zT_206, zT_207, zT_208);
    lexer3 = zT_214;
    zT_215 = (zT_138FFB41_Lexer*)&lexer3;
    zT_217 = zF_7C2FDD01_lexerAdvance(zT_215);
    (void)zT_217;
    zT_218 = lexer3.line;
    zT_222 = 2;
    zF_EFB8936D_assertEqU32(zT_218, (unsigned int)((unsigned int)zT_222), (unsigned int)(0));
    zT_225 = lexer3.col;
    zT_229 = 1;
    zF_EFB8936D_assertEqU32(zT_225, (unsigned int)((unsigned int)zT_229), (unsigned int)(0));
    return;
}

/* lexerTestSkipWhitespaceAndComments */
void zF_BF88F19A_lexerTestSkipWhites(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10;
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17;
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21;
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45;
    zT_138FFB41_Lexer* zT_46;
    unsigned char zT_48;
    zT_138FFB41_Lexer* zT_51;
    unsigned char zT_53;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_53, (unsigned int)sizeof zT_53);
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_spaces;
    zT_138FFB41_Lexer lexer;
    zig_poison_fill((void*)&zT_1, (unsigned int)sizeof zT_1);
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = (unsigned char*)zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = (zT_3E40CD83_Sand*)&sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = (zT_3E40CD83_Sand*)&sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = (zT_3E40CD83_Sand*)&sand;
    zT_24 = (zT_227EDE07_SourceManager*)&source_man;
    zT_25 = (zT_D3EB6303_StringInterner*)&interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "  \t  abc";
    zT_33 = 8;
    zT_32.ptr = (unsigned char*)zT_31;
    zT_32.len = zT_33;
    s_spaces = zT_32;
    zT_35 = s_spaces;
    zT_40 = 0;
    zT_37 = (zT_D3EB6303_StringInterner*)&interner;
    zT_38 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_39 = (zT_3E40CD83_Sand*)&sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    lexer = zT_45;
    zT_46 = (zT_138FFB41_Lexer*)&lexer;
    zF_F7949B41_lexerSkipWSC(zT_46);
    zT_51 = (zT_138FFB41_Lexer*)&lexer;
    zT_53 = zF_6ACB12FA_lexerPeek(zT_51);
    zT_48 = zT_53;
    zF_8856257C_assertEqU8(zT_48, (unsigned char)(97), (unsigned int)(0));
    return;
}

/* lexerTestOperators */
void zF_9AA3D1F6_lexerTestOperators(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10;
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17;
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21;
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45;
    zT_EAC3E484_TokenKind zT_46;
    zT_138FFB41_Lexer* zT_49;
    zT_3A355BD2_Token zT_51;
    zT_EAC3E484_TokenKind zT_56;
    zT_138FFB41_Lexer* zT_59;
    zT_3A355BD2_Token zT_61;
    zT_EAC3E484_TokenKind zT_66;
    zT_138FFB41_Lexer* zT_69;
    zT_3A355BD2_Token zT_71;
    zT_EAC3E484_TokenKind zT_76;
    zT_138FFB41_Lexer* zT_79;
    zT_3A355BD2_Token zT_81;
    zT_EAC3E484_TokenKind zT_86;
    zT_138FFB41_Lexer* zT_89;
    zT_3A355BD2_Token zT_91;
    zT_EAC3E484_TokenKind zT_96;
    zT_138FFB41_Lexer* zT_99;
    zT_3A355BD2_Token zT_101;
    zT_EAC3E484_TokenKind zT_106;
    zT_138FFB41_Lexer* zT_109;
    zT_3A355BD2_Token zT_111;
    unsigned char* zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned int zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    zT_D3EB6303_StringInterner* zT_123;
    zT_F85C5DED_DiagnosticCollector* zT_124;
    zT_3E40CD83_Sand* zT_125;
    int zT_126;
    zT_138FFB41_Lexer zT_131;
    zT_EAC3E484_TokenKind zT_132;
    zT_138FFB41_Lexer* zT_135;
    zT_3A355BD2_Token zT_137;
    zT_EAC3E484_TokenKind zT_142;
    zT_138FFB41_Lexer* zT_145;
    zT_3A355BD2_Token zT_147;
    zT_EAC3E484_TokenKind zT_152;
    zT_138FFB41_Lexer* zT_155;
    zT_3A355BD2_Token zT_157;
    zT_EAC3E484_TokenKind zT_162;
    zT_138FFB41_Lexer* zT_165;
    zT_3A355BD2_Token zT_167;
    zT_EAC3E484_TokenKind zT_172;
    zT_138FFB41_Lexer* zT_175;
    zT_3A355BD2_Token zT_177;
    zT_EAC3E484_TokenKind zT_182;
    zT_138FFB41_Lexer* zT_185;
    zT_3A355BD2_Token zT_187;
    zT_EAC3E484_TokenKind zT_192;
    zT_138FFB41_Lexer* zT_195;
    zT_3A355BD2_Token zT_197;
    zT_EAC3E484_TokenKind zT_202;
    zT_138FFB41_Lexer* zT_205;
    zT_3A355BD2_Token zT_207;
    zT_EAC3E484_TokenKind zT_212;
    zT_138FFB41_Lexer* zT_215;
    zT_3A355BD2_Token zT_217;
    zT_EAC3E484_TokenKind zT_222;
    zT_138FFB41_Lexer* zT_225;
    zT_3A355BD2_Token zT_227;
    zT_EAC3E484_TokenKind zT_232;
    zT_138FFB41_Lexer* zT_235;
    zT_3A355BD2_Token zT_237;
    zT_EAC3E484_TokenKind zT_242;
    zT_138FFB41_Lexer* zT_245;
    zT_3A355BD2_Token zT_247;
    zT_EAC3E484_TokenKind zT_252;
    zT_138FFB41_Lexer* zT_255;
    zT_3A355BD2_Token zT_257;
    zT_EAC3E484_TokenKind zT_262;
    zT_138FFB41_Lexer* zT_265;
    zT_3A355BD2_Token zT_267;
    unsigned char* zT_273;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    unsigned int zT_275;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_277;
    zT_D3EB6303_StringInterner* zT_279;
    zT_F85C5DED_DiagnosticCollector* zT_280;
    zT_3E40CD83_Sand* zT_281;
    int zT_282;
    zT_138FFB41_Lexer zT_287;
    zT_EAC3E484_TokenKind zT_288;
    zT_138FFB41_Lexer* zT_291;
    zT_3A355BD2_Token zT_293;
    zT_EAC3E484_TokenKind zT_298;
    zT_138FFB41_Lexer* zT_301;
    zT_3A355BD2_Token zT_303;
    zT_EAC3E484_TokenKind zT_308;
    zT_138FFB41_Lexer* zT_311;
    zT_3A355BD2_Token zT_313;
    zT_EAC3E484_TokenKind zT_318;
    zT_138FFB41_Lexer* zT_321;
    zT_3A355BD2_Token zT_323;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_51, (unsigned int)sizeof zT_51);
    zig_poison_fill((void*)&zT_61, (unsigned int)sizeof zT_61);
    zig_poison_fill((void*)&zT_71, (unsigned int)sizeof zT_71);
    zig_poison_fill((void*)&zT_81, (unsigned int)sizeof zT_81);
    zig_poison_fill((void*)&zT_91, (unsigned int)sizeof zT_91);
    zig_poison_fill((void*)&zT_101, (unsigned int)sizeof zT_101);
    zig_poison_fill((void*)&zT_111, (unsigned int)sizeof zT_111);
    zig_poison_fill((void*)&zT_131, (unsigned int)sizeof zT_131);
    zig_poison_fill((void*)&zT_137, (unsigned int)sizeof zT_137);
    zig_poison_fill((void*)&zT_147, (unsigned int)sizeof zT_147);
    zig_poison_fill((void*)&zT_157, (unsigned int)sizeof zT_157);
    zig_poison_fill((void*)&zT_167, (unsigned int)sizeof zT_167);
    zig_poison_fill((void*)&zT_177, (unsigned int)sizeof zT_177);
    zig_poison_fill((void*)&zT_187, (unsigned int)sizeof zT_187);
    zig_poison_fill((void*)&zT_197, (unsigned int)sizeof zT_197);
    zig_poison_fill((void*)&zT_207, (unsigned int)sizeof zT_207);
    zig_poison_fill((void*)&zT_217, (unsigned int)sizeof zT_217);
    zig_poison_fill((void*)&zT_227, (unsigned int)sizeof zT_227);
    zig_poison_fill((void*)&zT_237, (unsigned int)sizeof zT_237);
    zig_poison_fill((void*)&zT_247, (unsigned int)sizeof zT_247);
    zig_poison_fill((void*)&zT_257, (unsigned int)sizeof zT_257);
    zig_poison_fill((void*)&zT_267, (unsigned int)sizeof zT_267);
    zig_poison_fill((void*)&zT_287, (unsigned int)sizeof zT_287);
    zig_poison_fill((void*)&zT_293, (unsigned int)sizeof zT_293);
    zig_poison_fill((void*)&zT_303, (unsigned int)sizeof zT_303);
    zig_poison_fill((void*)&zT_313, (unsigned int)sizeof zT_313);
    zig_poison_fill((void*)&zT_323, (unsigned int)sizeof zT_323);
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_parens;
    zT_138FFB41_Lexer l1;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ops;
    zT_138FFB41_Lexer l2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_compound;
    zT_138FFB41_Lexer l3;
    zig_poison_fill((void*)&zT_1, (unsigned int)sizeof zT_1);
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = (unsigned char*)zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = (zT_3E40CD83_Sand*)&sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = (zT_3E40CD83_Sand*)&sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = (zT_3E40CD83_Sand*)&sand;
    zT_24 = (zT_227EDE07_SourceManager*)&source_man;
    zT_25 = (zT_D3EB6303_StringInterner*)&interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "()[]{}";
    zT_33 = 6;
    zT_32.ptr = (unsigned char*)zT_31;
    zT_32.len = zT_33;
    s_parens = zT_32;
    zT_35 = s_parens;
    zT_40 = 0;
    zT_37 = (zT_D3EB6303_StringInterner*)&interner;
    zT_38 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_39 = (zT_3E40CD83_Sand*)&sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    l1 = zT_45;
    zT_49 = (zT_138FFB41_Lexer*)&l1;
    zT_51 = zF_B976BEC9_lexerNextToken(zT_49);
    zT_46 = zT_51.kind;
    zF_1058D9A8_assertEqTokenKind(zT_46, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen), (unsigned int)(0));
    zT_59 = (zT_138FFB41_Lexer*)&l1;
    zT_61 = zF_B976BEC9_lexerNextToken(zT_59);
    zT_56 = zT_61.kind;
    zF_1058D9A8_assertEqTokenKind(zT_56, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen), (unsigned int)(0));
    zT_69 = (zT_138FFB41_Lexer*)&l1;
    zT_71 = zF_B976BEC9_lexerNextToken(zT_69);
    zT_66 = zT_71.kind;
    zF_1058D9A8_assertEqTokenKind(zT_66, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbracket), (unsigned int)(0));
    zT_79 = (zT_138FFB41_Lexer*)&l1;
    zT_81 = zF_B976BEC9_lexerNextToken(zT_79);
    zT_76 = zT_81.kind;
    zF_1058D9A8_assertEqTokenKind(zT_76, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket), (unsigned int)(0));
    zT_89 = (zT_138FFB41_Lexer*)&l1;
    zT_91 = zF_B976BEC9_lexerNextToken(zT_89);
    zT_86 = zT_91.kind;
    zF_1058D9A8_assertEqTokenKind(zT_86, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace), (unsigned int)(0));
    zT_99 = (zT_138FFB41_Lexer*)&l1;
    zT_101 = zF_B976BEC9_lexerNextToken(zT_99);
    zT_96 = zT_101.kind;
    zF_1058D9A8_assertEqTokenKind(zT_96, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace), (unsigned int)(0));
    zT_109 = (zT_138FFB41_Lexer*)&l1;
    zT_111 = zF_B976BEC9_lexerNextToken(zT_109);
    zT_106 = zT_111.kind;
    zF_1058D9A8_assertEqTokenKind(zT_106, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof), (unsigned int)(0));
    zT_117 = "+-*/%&|^~!?;:,";
    zT_119 = 14;
    zT_118.ptr = (unsigned char*)zT_117;
    zT_118.len = zT_119;
    s_ops = zT_118;
    zT_121 = s_ops;
    zT_126 = 0;
    zT_123 = (zT_D3EB6303_StringInterner*)&interner;
    zT_124 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_125 = (zT_3E40CD83_Sand*)&sand;
    zT_131 = zF_151E643F_lexerInit(zT_121, (unsigned int)((unsigned int)zT_126), zT_123, zT_124, zT_125);
    l2 = zT_131;
    zT_135 = (zT_138FFB41_Lexer*)&l2;
    zT_137 = zF_B976BEC9_lexerNextToken(zT_135);
    zT_132 = zT_137.kind;
    zF_1058D9A8_assertEqTokenKind(zT_132, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus), (unsigned int)(0));
    zT_145 = (zT_138FFB41_Lexer*)&l2;
    zT_147 = zF_B976BEC9_lexerNextToken(zT_145);
    zT_142 = zT_147.kind;
    zF_1058D9A8_assertEqTokenKind(zT_142, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus), (unsigned int)(0));
    zT_155 = (zT_138FFB41_Lexer*)&l2;
    zT_157 = zF_B976BEC9_lexerNextToken(zT_155);
    zT_152 = zT_157.kind;
    zF_1058D9A8_assertEqTokenKind(zT_152, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star), (unsigned int)(0));
    zT_165 = (zT_138FFB41_Lexer*)&l2;
    zT_167 = zF_B976BEC9_lexerNextToken(zT_165);
    zT_162 = zT_167.kind;
    zF_1058D9A8_assertEqTokenKind(zT_162, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_slash), (unsigned int)(0));
    zT_175 = (zT_138FFB41_Lexer*)&l2;
    zT_177 = zF_B976BEC9_lexerNextToken(zT_175);
    zT_172 = zT_177.kind;
    zF_1058D9A8_assertEqTokenKind(zT_172, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_percent), (unsigned int)(0));
    zT_185 = (zT_138FFB41_Lexer*)&l2;
    zT_187 = zF_B976BEC9_lexerNextToken(zT_185);
    zT_182 = zT_187.kind;
    zF_1058D9A8_assertEqTokenKind(zT_182, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_ampersand), (unsigned int)(0));
    zT_195 = (zT_138FFB41_Lexer*)&l2;
    zT_197 = zF_B976BEC9_lexerNextToken(zT_195);
    zT_192 = zT_197.kind;
    zF_1058D9A8_assertEqTokenKind(zT_192, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe), (unsigned int)(0));
    zT_205 = (zT_138FFB41_Lexer*)&l2;
    zT_207 = zF_B976BEC9_lexerNextToken(zT_205);
    zT_202 = zT_207.kind;
    zF_1058D9A8_assertEqTokenKind(zT_202, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_caret), (unsigned int)(0));
    zT_215 = (zT_138FFB41_Lexer*)&l2;
    zT_217 = zF_B976BEC9_lexerNextToken(zT_215);
    zT_212 = zT_217.kind;
    zF_1058D9A8_assertEqTokenKind(zT_212, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_tilde), (unsigned int)(0));
    zT_225 = (zT_138FFB41_Lexer*)&l2;
    zT_227 = zF_B976BEC9_lexerNextToken(zT_225);
    zT_222 = zT_227.kind;
    zF_1058D9A8_assertEqTokenKind(zT_222, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang), (unsigned int)(0));
    zT_235 = (zT_138FFB41_Lexer*)&l2;
    zT_237 = zF_B976BEC9_lexerNextToken(zT_235);
    zT_232 = zT_237.kind;
    zF_1058D9A8_assertEqTokenKind(zT_232, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_question_mark), (unsigned int)(0));
    zT_245 = (zT_138FFB41_Lexer*)&l2;
    zT_247 = zF_B976BEC9_lexerNextToken(zT_245);
    zT_242 = zT_247.kind;
    zF_1058D9A8_assertEqTokenKind(zT_242, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon), (unsigned int)(0));
    zT_255 = (zT_138FFB41_Lexer*)&l2;
    zT_257 = zF_B976BEC9_lexerNextToken(zT_255);
    zT_252 = zT_257.kind;
    zF_1058D9A8_assertEqTokenKind(zT_252, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon), (unsigned int)(0));
    zT_265 = (zT_138FFB41_Lexer*)&l2;
    zT_267 = zF_B976BEC9_lexerNextToken(zT_265);
    zT_262 = zT_267.kind;
    zF_1058D9A8_assertEqTokenKind(zT_262, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma), (unsigned int)(0));
    zT_273 = ".. ... .{ .* == => != <= >= << >> += -= *= /= %= &= |= ^= <<= >>=";
    zT_275 = 65;
    zT_274.ptr = (unsigned char*)zT_273;
    zT_274.len = zT_275;
    s_compound = zT_274;
    zT_277 = s_compound;
    zT_282 = 0;
    zT_279 = (zT_D3EB6303_StringInterner*)&interner;
    zT_280 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_281 = (zT_3E40CD83_Sand*)&sand;
    zT_287 = zF_151E643F_lexerInit(zT_277, (unsigned int)((unsigned int)zT_282), zT_279, zT_280, zT_281);
    l3 = zT_287;
    zT_291 = (zT_138FFB41_Lexer*)&l3;
    zT_293 = zF_B976BEC9_lexerNextToken(zT_291);
    zT_288 = zT_293.kind;
    zF_1058D9A8_assertEqTokenKind(zT_288, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot), (unsigned int)(0));
    zT_301 = (zT_138FFB41_Lexer*)&l3;
    zT_303 = zF_B976BEC9_lexerNextToken(zT_301);
    zT_298 = zT_303.kind;
    zF_1058D9A8_assertEqTokenKind(zT_298, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot_dot), (unsigned int)(0));
    zT_311 = (zT_138FFB41_Lexer*)&l3;
    zT_313 = zF_B976BEC9_lexerNextToken(zT_311);
    zT_308 = zT_313.kind;
    zF_1058D9A8_assertEqTokenKind(zT_308, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_lbrace), (unsigned int)(0));
    zT_321 = (zT_138FFB41_Lexer*)&l3;
    zT_323 = zF_B976BEC9_lexerNextToken(zT_321);
    zT_318 = zT_323.kind;
    zF_1058D9A8_assertEqTokenKind(zT_318, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_star), (unsigned int)(0));
    return;
}

/* lexerTestScanNumber */
void zF_4CB82885_lexerTestScanNumber(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10;
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17;
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21;
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45;
    zT_138FFB41_Lexer* zT_47;
    zT_3A355BD2_Token zT_49;
    zT_EAC3E484_TokenKind zT_50;
    unsigned int zT_60;
    int zT_62;
    unsigned short zT_68;
    int zT_70;
    unsigned char* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    zT_D3EB6303_StringInterner* zT_80;
    zT_F85C5DED_DiagnosticCollector* zT_81;
    zT_3E40CD83_Sand* zT_82;
    int zT_83;
    zT_138FFB41_Lexer zT_88;
    zT_138FFB41_Lexer* zT_90;
    zT_3A355BD2_Token zT_92;
    zT_EAC3E484_TokenKind zT_93;
    unsigned char* zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    zT_D3EB6303_StringInterner* zT_107;
    zT_F85C5DED_DiagnosticCollector* zT_108;
    zT_3E40CD83_Sand* zT_109;
    int zT_110;
    zT_138FFB41_Lexer zT_115;
    zT_138FFB41_Lexer* zT_117;
    zT_3A355BD2_Token zT_119;
    zT_EAC3E484_TokenKind zT_120;
    unsigned char* zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    unsigned int zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    zT_D3EB6303_StringInterner* zT_134;
    zT_F85C5DED_DiagnosticCollector* zT_135;
    zT_3E40CD83_Sand* zT_136;
    int zT_137;
    zT_138FFB41_Lexer zT_142;
    zT_138FFB41_Lexer* zT_144;
    zT_3A355BD2_Token zT_146;
    zT_EAC3E484_TokenKind zT_147;
    unsigned char* zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    unsigned int zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    zT_D3EB6303_StringInterner* zT_161;
    zT_F85C5DED_DiagnosticCollector* zT_162;
    zT_3E40CD83_Sand* zT_163;
    int zT_164;
    zT_138FFB41_Lexer zT_169;
    zT_138FFB41_Lexer* zT_171;
    zT_3A355BD2_Token zT_173;
    zT_EAC3E484_TokenKind zT_174;
    unsigned char* zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    zT_D3EB6303_StringInterner* zT_188;
    zT_F85C5DED_DiagnosticCollector* zT_189;
    zT_3E40CD83_Sand* zT_190;
    int zT_191;
    zT_138FFB41_Lexer zT_196;
    zT_138FFB41_Lexer* zT_198;
    zT_3A355BD2_Token zT_200;
    zT_EAC3E484_TokenKind zT_201;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_49, (unsigned int)sizeof zT_49);
    zig_poison_fill((void*)&zT_88, (unsigned int)sizeof zT_88);
    zig_poison_fill((void*)&zT_92, (unsigned int)sizeof zT_92);
    zig_poison_fill((void*)&zT_115, (unsigned int)sizeof zT_115);
    zig_poison_fill((void*)&zT_119, (unsigned int)sizeof zT_119);
    zig_poison_fill((void*)&zT_142, (unsigned int)sizeof zT_142);
    zig_poison_fill((void*)&zT_146, (unsigned int)sizeof zT_146);
    zig_poison_fill((void*)&zT_169, (unsigned int)sizeof zT_169);
    zig_poison_fill((void*)&zT_173, (unsigned int)sizeof zT_173);
    zig_poison_fill((void*)&zT_196, (unsigned int)sizeof zT_196);
    zig_poison_fill((void*)&zT_200, (unsigned int)sizeof zT_200);
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_dec;
    zT_138FFB41_Lexer l1;
    zT_3A355BD2_Token t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_hex;
    zT_138FFB41_Lexer l2;
    zT_3A355BD2_Token t2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bin;
    zT_138FFB41_Lexer l3;
    zT_3A355BD2_Token t3;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_oct;
    zT_138FFB41_Lexer l4;
    zT_3A355BD2_Token t4;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_float;
    zT_138FFB41_Lexer l5;
    zT_3A355BD2_Token t5;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sci;
    zT_138FFB41_Lexer l6;
    zT_3A355BD2_Token t6;
    zig_poison_fill((void*)&zT_1, (unsigned int)sizeof zT_1);
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = (unsigned char*)zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = (zT_3E40CD83_Sand*)&sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = (zT_3E40CD83_Sand*)&sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = (zT_3E40CD83_Sand*)&sand;
    zT_24 = (zT_227EDE07_SourceManager*)&source_man;
    zT_25 = (zT_D3EB6303_StringInterner*)&interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "42";
    zT_33 = 2;
    zT_32.ptr = (unsigned char*)zT_31;
    zT_32.len = zT_33;
    s_dec = zT_32;
    zT_35 = s_dec;
    zT_40 = 0;
    zT_37 = (zT_D3EB6303_StringInterner*)&interner;
    zT_38 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_39 = (zT_3E40CD83_Sand*)&sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    l1 = zT_45;
    zT_47 = (zT_138FFB41_Lexer*)&l1;
    zT_49 = zF_B976BEC9_lexerNextToken(zT_47);
    t1 = zT_49;
    zT_50 = t1.kind;
    zF_1058D9A8_assertEqTokenKind(zT_50, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_integer_literal), (unsigned int)(0));
    zT_60 = t1.span_start;
    zT_62 = 0;
    zF_EFB8936D_assertEqU32((unsigned int)((unsigned int)zT_60), (unsigned int)((unsigned int)zT_62), (unsigned int)(0));
    zT_68 = t1.span_len;
    zT_70 = 2;
    zF_EFB8936D_assertEqU32((unsigned int)((unsigned int)zT_68), (unsigned int)((unsigned int)zT_70), (unsigned int)(0));
    zT_74 = "0xFF";
    zT_76 = 4;
    zT_75.ptr = (unsigned char*)zT_74;
    zT_75.len = zT_76;
    s_hex = zT_75;
    zT_78 = s_hex;
    zT_83 = 0;
    zT_80 = (zT_D3EB6303_StringInterner*)&interner;
    zT_81 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_82 = (zT_3E40CD83_Sand*)&sand;
    zT_88 = zF_151E643F_lexerInit(zT_78, (unsigned int)((unsigned int)zT_83), zT_80, zT_81, zT_82);
    l2 = zT_88;
    zT_90 = (zT_138FFB41_Lexer*)&l2;
    zT_92 = zF_B976BEC9_lexerNextToken(zT_90);
    t2 = zT_92;
    zT_93 = t2.kind;
    zF_1058D9A8_assertEqTokenKind(zT_93, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_integer_literal), (unsigned int)(0));
    zT_101 = "0b1010";
    zT_103 = 6;
    zT_102.ptr = (unsigned char*)zT_101;
    zT_102.len = zT_103;
    s_bin = zT_102;
    zT_105 = s_bin;
    zT_110 = 0;
    zT_107 = (zT_D3EB6303_StringInterner*)&interner;
    zT_108 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_109 = (zT_3E40CD83_Sand*)&sand;
    zT_115 = zF_151E643F_lexerInit(zT_105, (unsigned int)((unsigned int)zT_110), zT_107, zT_108, zT_109);
    l3 = zT_115;
    zT_117 = (zT_138FFB41_Lexer*)&l3;
    zT_119 = zF_B976BEC9_lexerNextToken(zT_117);
    t3 = zT_119;
    zT_120 = t3.kind;
    zF_1058D9A8_assertEqTokenKind(zT_120, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_integer_literal), (unsigned int)(0));
    zT_128 = "0o77";
    zT_130 = 4;
    zT_129.ptr = (unsigned char*)zT_128;
    zT_129.len = zT_130;
    s_oct = zT_129;
    zT_132 = s_oct;
    zT_137 = 0;
    zT_134 = (zT_D3EB6303_StringInterner*)&interner;
    zT_135 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_136 = (zT_3E40CD83_Sand*)&sand;
    zT_142 = zF_151E643F_lexerInit(zT_132, (unsigned int)((unsigned int)zT_137), zT_134, zT_135, zT_136);
    l4 = zT_142;
    zT_144 = (zT_138FFB41_Lexer*)&l4;
    zT_146 = zF_B976BEC9_lexerNextToken(zT_144);
    t4 = zT_146;
    zT_147 = t4.kind;
    zF_1058D9A8_assertEqTokenKind(zT_147, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_integer_literal), (unsigned int)(0));
    zT_155 = "3.14";
    zT_157 = 4;
    zT_156.ptr = (unsigned char*)zT_155;
    zT_156.len = zT_157;
    s_float = zT_156;
    zT_159 = s_float;
    zT_164 = 0;
    zT_161 = (zT_D3EB6303_StringInterner*)&interner;
    zT_162 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_163 = (zT_3E40CD83_Sand*)&sand;
    zT_169 = zF_151E643F_lexerInit(zT_159, (unsigned int)((unsigned int)zT_164), zT_161, zT_162, zT_163);
    l5 = zT_169;
    zT_171 = (zT_138FFB41_Lexer*)&l5;
    zT_173 = zF_B976BEC9_lexerNextToken(zT_171);
    t5 = zT_173;
    zT_174 = t5.kind;
    zF_1058D9A8_assertEqTokenKind(zT_174, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_float_literal), (unsigned int)(0));
    zT_182 = "1.5e10";
    zT_184 = 6;
    zT_183.ptr = (unsigned char*)zT_182;
    zT_183.len = zT_184;
    s_sci = zT_183;
    zT_186 = s_sci;
    zT_191 = 0;
    zT_188 = (zT_D3EB6303_StringInterner*)&interner;
    zT_189 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_190 = (zT_3E40CD83_Sand*)&sand;
    zT_196 = zF_151E643F_lexerInit(zT_186, (unsigned int)((unsigned int)zT_191), zT_188, zT_189, zT_190);
    l6 = zT_196;
    zT_198 = (zT_138FFB41_Lexer*)&l6;
    zT_200 = zF_B976BEC9_lexerNextToken(zT_198);
    t6 = zT_200;
    zT_201 = t6.kind;
    zF_1058D9A8_assertEqTokenKind(zT_201, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_float_literal), (unsigned int)(0));
    return;
}

/* lexerTestScanString */
void zF_A76AF035_lexerTestScanString(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10;
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17;
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21;
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45;
    zT_138FFB41_Lexer* zT_47;
    zT_3A355BD2_Token zT_49;
    zT_EAC3E484_TokenKind zT_50;
    unsigned char* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    zT_D3EB6303_StringInterner* zT_64;
    zT_F85C5DED_DiagnosticCollector* zT_65;
    zT_3E40CD83_Sand* zT_66;
    int zT_67;
    zT_138FFB41_Lexer zT_72;
    zT_138FFB41_Lexer* zT_74;
    zT_3A355BD2_Token zT_76;
    zT_EAC3E484_TokenKind zT_77;
    unsigned char* zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    zT_D3EB6303_StringInterner* zT_91;
    zT_F85C5DED_DiagnosticCollector* zT_92;
    zT_3E40CD83_Sand* zT_93;
    int zT_94;
    zT_138FFB41_Lexer zT_99;
    zT_138FFB41_Lexer* zT_101;
    zT_3A355BD2_Token zT_103;
    zT_EAC3E484_TokenKind zT_104;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_49, (unsigned int)sizeof zT_49);
    zig_poison_fill((void*)&zT_72, (unsigned int)sizeof zT_72);
    zig_poison_fill((void*)&zT_76, (unsigned int)sizeof zT_76);
    zig_poison_fill((void*)&zT_99, (unsigned int)sizeof zT_99);
    zig_poison_fill((void*)&zT_103, (unsigned int)sizeof zT_103);
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_hello;
    zT_138FFB41_Lexer l1;
    zT_3A355BD2_Token t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_esc;
    zT_138FFB41_Lexer l2;
    zT_3A355BD2_Token t2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_unterm;
    zT_138FFB41_Lexer l3;
    zT_3A355BD2_Token t3;
    zig_poison_fill((void*)&zT_1, (unsigned int)sizeof zT_1);
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = (unsigned char*)zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = (zT_3E40CD83_Sand*)&sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = (zT_3E40CD83_Sand*)&sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = (zT_3E40CD83_Sand*)&sand;
    zT_24 = (zT_227EDE07_SourceManager*)&source_man;
    zT_25 = (zT_D3EB6303_StringInterner*)&interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "\"hello\"";
    zT_33 = 7;
    zT_32.ptr = (unsigned char*)zT_31;
    zT_32.len = zT_33;
    s_hello = zT_32;
    zT_35 = s_hello;
    zT_40 = 0;
    zT_37 = (zT_D3EB6303_StringInterner*)&interner;
    zT_38 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_39 = (zT_3E40CD83_Sand*)&sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    l1 = zT_45;
    zT_47 = (zT_138FFB41_Lexer*)&l1;
    zT_49 = zF_B976BEC9_lexerNextToken(zT_47);
    t1 = zT_49;
    zT_50 = t1.kind;
    zF_1058D9A8_assertEqTokenKind(zT_50, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal), (unsigned int)(0));
    zT_58 = "\"hello\\nworld\"";
    zT_60 = 14;
    zT_59.ptr = (unsigned char*)zT_58;
    zT_59.len = zT_60;
    s_esc = zT_59;
    zT_62 = s_esc;
    zT_67 = 0;
    zT_64 = (zT_D3EB6303_StringInterner*)&interner;
    zT_65 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_66 = (zT_3E40CD83_Sand*)&sand;
    zT_72 = zF_151E643F_lexerInit(zT_62, (unsigned int)((unsigned int)zT_67), zT_64, zT_65, zT_66);
    l2 = zT_72;
    zT_74 = (zT_138FFB41_Lexer*)&l2;
    zT_76 = zF_B976BEC9_lexerNextToken(zT_74);
    t2 = zT_76;
    zT_77 = t2.kind;
    zF_1058D9A8_assertEqTokenKind(zT_77, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal), (unsigned int)(0));
    zT_85 = "\"unterminated";
    zT_87 = 13;
    zT_86.ptr = (unsigned char*)zT_85;
    zT_86.len = zT_87;
    s_unterm = zT_86;
    zT_89 = s_unterm;
    zT_94 = 0;
    zT_91 = (zT_D3EB6303_StringInterner*)&interner;
    zT_92 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_93 = (zT_3E40CD83_Sand*)&sand;
    zT_99 = zF_151E643F_lexerInit(zT_89, (unsigned int)((unsigned int)zT_94), zT_91, zT_92, zT_93);
    l3 = zT_99;
    zT_101 = (zT_138FFB41_Lexer*)&l3;
    zT_103 = zF_B976BEC9_lexerNextToken(zT_101);
    t3 = zT_103;
    zT_104 = t3.kind;
    zF_1058D9A8_assertEqTokenKind(zT_104, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_err_token), (unsigned int)(0));
    return;
}

/* lexerTestScanChar */
void zF_13791BA0_lexerTestScanChar(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10;
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17;
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21;
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45;
    zT_138FFB41_Lexer* zT_47;
    zT_3A355BD2_Token zT_49;
    zT_EAC3E484_TokenKind zT_50;
    unsigned char* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    zT_D3EB6303_StringInterner* zT_64;
    zT_F85C5DED_DiagnosticCollector* zT_65;
    zT_3E40CD83_Sand* zT_66;
    int zT_67;
    zT_138FFB41_Lexer zT_72;
    zT_138FFB41_Lexer* zT_74;
    zT_3A355BD2_Token zT_76;
    zT_EAC3E484_TokenKind zT_77;
    unsigned char* zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    zT_D3EB6303_StringInterner* zT_91;
    zT_F85C5DED_DiagnosticCollector* zT_92;
    zT_3E40CD83_Sand* zT_93;
    int zT_94;
    zT_138FFB41_Lexer zT_99;
    zT_138FFB41_Lexer* zT_101;
    zT_3A355BD2_Token zT_103;
    zT_EAC3E484_TokenKind zT_104;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_49, (unsigned int)sizeof zT_49);
    zig_poison_fill((void*)&zT_72, (unsigned int)sizeof zT_72);
    zig_poison_fill((void*)&zT_76, (unsigned int)sizeof zT_76);
    zig_poison_fill((void*)&zT_99, (unsigned int)sizeof zT_99);
    zig_poison_fill((void*)&zT_103, (unsigned int)sizeof zT_103);
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_char;
    zT_138FFB41_Lexer l1;
    zT_3A355BD2_Token t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_cesc;
    zT_138FFB41_Lexer l2;
    zT_3A355BD2_Token t2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_cempty;
    zT_138FFB41_Lexer l3;
    zT_3A355BD2_Token t3;
    zig_poison_fill((void*)&zT_1, (unsigned int)sizeof zT_1);
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = (unsigned char*)zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = (zT_3E40CD83_Sand*)&sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = (zT_3E40CD83_Sand*)&sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = (zT_3E40CD83_Sand*)&sand;
    zT_24 = (zT_227EDE07_SourceManager*)&source_man;
    zT_25 = (zT_D3EB6303_StringInterner*)&interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "'a'";
    zT_33 = 3;
    zT_32.ptr = (unsigned char*)zT_31;
    zT_32.len = zT_33;
    s_char = zT_32;
    zT_35 = s_char;
    zT_40 = 0;
    zT_37 = (zT_D3EB6303_StringInterner*)&interner;
    zT_38 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_39 = (zT_3E40CD83_Sand*)&sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    l1 = zT_45;
    zT_47 = (zT_138FFB41_Lexer*)&l1;
    zT_49 = zF_B976BEC9_lexerNextToken(zT_47);
    t1 = zT_49;
    zT_50 = t1.kind;
    zF_1058D9A8_assertEqTokenKind(zT_50, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_char_literal), (unsigned int)(0));
    zT_58 = "'\\n'";
    zT_60 = 4;
    zT_59.ptr = (unsigned char*)zT_58;
    zT_59.len = zT_60;
    s_cesc = zT_59;
    zT_62 = s_cesc;
    zT_67 = 0;
    zT_64 = (zT_D3EB6303_StringInterner*)&interner;
    zT_65 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_66 = (zT_3E40CD83_Sand*)&sand;
    zT_72 = zF_151E643F_lexerInit(zT_62, (unsigned int)((unsigned int)zT_67), zT_64, zT_65, zT_66);
    l2 = zT_72;
    zT_74 = (zT_138FFB41_Lexer*)&l2;
    zT_76 = zF_B976BEC9_lexerNextToken(zT_74);
    t2 = zT_76;
    zT_77 = t2.kind;
    zF_1058D9A8_assertEqTokenKind(zT_77, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_char_literal), (unsigned int)(0));
    zT_85 = "''";
    zT_87 = 2;
    zT_86.ptr = (unsigned char*)zT_85;
    zT_86.len = zT_87;
    s_cempty = zT_86;
    zT_89 = s_cempty;
    zT_94 = 0;
    zT_91 = (zT_D3EB6303_StringInterner*)&interner;
    zT_92 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_93 = (zT_3E40CD83_Sand*)&sand;
    zT_99 = zF_151E643F_lexerInit(zT_89, (unsigned int)((unsigned int)zT_94), zT_91, zT_92, zT_93);
    l3 = zT_99;
    zT_101 = (zT_138FFB41_Lexer*)&l3;
    zT_103 = zF_B976BEC9_lexerNextToken(zT_101);
    t3 = zT_103;
    zT_104 = t3.kind;
    zF_1058D9A8_assertEqTokenKind(zT_104, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_char_literal), (unsigned int)(0));
    return;
}

/* lexerTestIdentifierKeywords */
void zF_B8F07D3E_lexerTestIdentifier(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10;
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17;
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21;
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45;
    zT_138FFB41_Lexer* zT_47;
    zT_3A355BD2_Token zT_49;
    zT_EAC3E484_TokenKind zT_50;
    unsigned char* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    zT_D3EB6303_StringInterner* zT_64;
    zT_F85C5DED_DiagnosticCollector* zT_65;
    zT_3E40CD83_Sand* zT_66;
    int zT_67;
    zT_138FFB41_Lexer zT_72;
    zT_138FFB41_Lexer* zT_74;
    zT_3A355BD2_Token zT_76;
    zT_EAC3E484_TokenKind zT_77;
    unsigned char* zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    zT_D3EB6303_StringInterner* zT_91;
    zT_F85C5DED_DiagnosticCollector* zT_92;
    zT_3E40CD83_Sand* zT_93;
    int zT_94;
    zT_138FFB41_Lexer zT_99;
    zT_138FFB41_Lexer* zT_101;
    zT_3A355BD2_Token zT_103;
    zT_EAC3E484_TokenKind zT_104;
    unsigned char* zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    zT_D3EB6303_StringInterner* zT_118;
    zT_F85C5DED_DiagnosticCollector* zT_119;
    zT_3E40CD83_Sand* zT_120;
    int zT_121;
    zT_138FFB41_Lexer zT_126;
    zT_138FFB41_Lexer* zT_128;
    zT_3A355BD2_Token zT_130;
    zT_EAC3E484_TokenKind zT_131;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_49, (unsigned int)sizeof zT_49);
    zig_poison_fill((void*)&zT_72, (unsigned int)sizeof zT_72);
    zig_poison_fill((void*)&zT_76, (unsigned int)sizeof zT_76);
    zig_poison_fill((void*)&zT_99, (unsigned int)sizeof zT_99);
    zig_poison_fill((void*)&zT_103, (unsigned int)sizeof zT_103);
    zig_poison_fill((void*)&zT_126, (unsigned int)sizeof zT_126);
    zig_poison_fill((void*)&zT_130, (unsigned int)sizeof zT_130);
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_under;
    zT_138FFB41_Lexer l1;
    zT_3A355BD2_Token t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ident;
    zT_138FFB41_Lexer l2;
    zT_3A355BD2_Token t2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_kw_const;
    zT_138FFB41_Lexer l3;
    zT_3A355BD2_Token t3;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_kw_fn;
    zT_138FFB41_Lexer l4;
    zT_3A355BD2_Token t4;
    zig_poison_fill((void*)&zT_1, (unsigned int)sizeof zT_1);
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = (unsigned char*)zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = (zT_3E40CD83_Sand*)&sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = (zT_3E40CD83_Sand*)&sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = (zT_3E40CD83_Sand*)&sand;
    zT_24 = (zT_227EDE07_SourceManager*)&source_man;
    zT_25 = (zT_D3EB6303_StringInterner*)&interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "_";
    zT_33 = 1;
    zT_32.ptr = (unsigned char*)zT_31;
    zT_32.len = zT_33;
    s_under = zT_32;
    zT_35 = s_under;
    zT_40 = 0;
    zT_37 = (zT_D3EB6303_StringInterner*)&interner;
    zT_38 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_39 = (zT_3E40CD83_Sand*)&sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    l1 = zT_45;
    zT_47 = (zT_138FFB41_Lexer*)&l1;
    zT_49 = zF_B976BEC9_lexerNextToken(zT_47);
    t1 = zT_49;
    zT_50 = t1.kind;
    zF_1058D9A8_assertEqTokenKind(zT_50, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore), (unsigned int)(0));
    zT_58 = "myVar";
    zT_60 = 5;
    zT_59.ptr = (unsigned char*)zT_58;
    zT_59.len = zT_60;
    s_ident = zT_59;
    zT_62 = s_ident;
    zT_67 = 0;
    zT_64 = (zT_D3EB6303_StringInterner*)&interner;
    zT_65 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_66 = (zT_3E40CD83_Sand*)&sand;
    zT_72 = zF_151E643F_lexerInit(zT_62, (unsigned int)((unsigned int)zT_67), zT_64, zT_65, zT_66);
    l2 = zT_72;
    zT_74 = (zT_138FFB41_Lexer*)&l2;
    zT_76 = zF_B976BEC9_lexerNextToken(zT_74);
    t2 = zT_76;
    zT_77 = t2.kind;
    zF_1058D9A8_assertEqTokenKind(zT_77, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier), (unsigned int)(0));
    zT_85 = "const";
    zT_87 = 5;
    zT_86.ptr = (unsigned char*)zT_85;
    zT_86.len = zT_87;
    s_kw_const = zT_86;
    zT_89 = s_kw_const;
    zT_94 = 0;
    zT_91 = (zT_D3EB6303_StringInterner*)&interner;
    zT_92 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_93 = (zT_3E40CD83_Sand*)&sand;
    zT_99 = zF_151E643F_lexerInit(zT_89, (unsigned int)((unsigned int)zT_94), zT_91, zT_92, zT_93);
    l3 = zT_99;
    zT_101 = (zT_138FFB41_Lexer*)&l3;
    zT_103 = zF_B976BEC9_lexerNextToken(zT_101);
    t3 = zT_103;
    zT_104 = t3.kind;
    zF_1058D9A8_assertEqTokenKind(zT_104, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const), (unsigned int)(0));
    zT_112 = "fn";
    zT_114 = 2;
    zT_113.ptr = (unsigned char*)zT_112;
    zT_113.len = zT_114;
    s_kw_fn = zT_113;
    zT_116 = s_kw_fn;
    zT_121 = 0;
    zT_118 = (zT_D3EB6303_StringInterner*)&interner;
    zT_119 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_120 = (zT_3E40CD83_Sand*)&sand;
    zT_126 = zF_151E643F_lexerInit(zT_116, (unsigned int)((unsigned int)zT_121), zT_118, zT_119, zT_120);
    l4 = zT_126;
    zT_128 = (zT_138FFB41_Lexer*)&l4;
    zT_130 = zF_B976BEC9_lexerNextToken(zT_128);
    t4 = zT_130;
    zT_131 = t4.kind;
    zF_1058D9A8_assertEqTokenKind(zT_131, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn), (unsigned int)(0));
    return;
}

/* lexerTestBuiltinIdentifier */
void zF_1C8729CF_lexerTestBuiltinIde(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10;
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17;
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21;
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45;
    zT_138FFB41_Lexer* zT_47;
    zT_3A355BD2_Token zT_49;
    zT_EAC3E484_TokenKind zT_50;
    unsigned char* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    zT_D3EB6303_StringInterner* zT_64;
    zT_F85C5DED_DiagnosticCollector* zT_65;
    zT_3E40CD83_Sand* zT_66;
    int zT_67;
    zT_138FFB41_Lexer zT_72;
    zT_138FFB41_Lexer* zT_74;
    zT_3A355BD2_Token zT_76;
    zT_EAC3E484_TokenKind zT_77;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_49, (unsigned int)sizeof zT_49);
    zig_poison_fill((void*)&zT_72, (unsigned int)sizeof zT_72);
    zig_poison_fill((void*)&zT_76, (unsigned int)sizeof zT_76);
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sizeof;
    zT_138FFB41_Lexer l1;
    zT_3A355BD2_Token t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bare_at;
    zT_138FFB41_Lexer l2;
    zT_3A355BD2_Token t2;
    zig_poison_fill((void*)&zT_1, (unsigned int)sizeof zT_1);
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = (unsigned char*)zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = (zT_3E40CD83_Sand*)&sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = (zT_3E40CD83_Sand*)&sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = (zT_3E40CD83_Sand*)&sand;
    zT_24 = (zT_227EDE07_SourceManager*)&source_man;
    zT_25 = (zT_D3EB6303_StringInterner*)&interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "@sizeOf";
    zT_33 = 7;
    zT_32.ptr = (unsigned char*)zT_31;
    zT_32.len = zT_33;
    s_sizeof = zT_32;
    zT_35 = s_sizeof;
    zT_40 = 0;
    zT_37 = (zT_D3EB6303_StringInterner*)&interner;
    zT_38 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_39 = (zT_3E40CD83_Sand*)&sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    l1 = zT_45;
    zT_47 = (zT_138FFB41_Lexer*)&l1;
    zT_49 = zF_B976BEC9_lexerNextToken(zT_47);
    t1 = zT_49;
    zT_50 = t1.kind;
    zF_1058D9A8_assertEqTokenKind(zT_50, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_builtin_identifier), (unsigned int)(0));
    zT_58 = "@";
    zT_60 = 1;
    zT_59.ptr = (unsigned char*)zT_58;
    zT_59.len = zT_60;
    s_bare_at = zT_59;
    zT_62 = s_bare_at;
    zT_67 = 0;
    zT_64 = (zT_D3EB6303_StringInterner*)&interner;
    zT_65 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_66 = (zT_3E40CD83_Sand*)&sand;
    zT_72 = zF_151E643F_lexerInit(zT_62, (unsigned int)((unsigned int)zT_67), zT_64, zT_65, zT_66);
    l2 = zT_72;
    zT_74 = (zT_138FFB41_Lexer*)&l2;
    zT_76 = zF_B976BEC9_lexerNextToken(zT_74);
    t2 = zT_76;
    zT_77 = t2.kind;
    zF_1058D9A8_assertEqTokenKind(zT_77, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_err_token), (unsigned int)(0));
    return;
}

/* lexerTestDiagnostics */
void zF_6836167B_lexerTestDiagnostic(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10;
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17;
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21;
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45;
    zT_138FFB41_Lexer* zT_47;
    zT_3A355BD2_Token zT_49;
    zT_EAC3E484_TokenKind zT_50;
    unsigned char* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    zT_D3EB6303_StringInterner* zT_64;
    zT_F85C5DED_DiagnosticCollector* zT_65;
    zT_3E40CD83_Sand* zT_66;
    int zT_67;
    zT_138FFB41_Lexer zT_72;
    zT_138FFB41_Lexer* zT_74;
    zT_3A355BD2_Token zT_76;
    zT_EAC3E484_TokenKind zT_77;
    zig_poison_fill((void*)&zT_10, (unsigned int)sizeof zT_10);
    zig_poison_fill((void*)&zT_17, (unsigned int)sizeof zT_17);
    zig_poison_fill((void*)&zT_21, (unsigned int)sizeof zT_21);
    zig_poison_fill((void*)&zT_29, (unsigned int)sizeof zT_29);
    zig_poison_fill((void*)&zT_45, (unsigned int)sizeof zT_45);
    zig_poison_fill((void*)&zT_49, (unsigned int)sizeof zT_49);
    zig_poison_fill((void*)&zT_72, (unsigned int)sizeof zT_72);
    zig_poison_fill((void*)&zT_76, (unsigned int)sizeof zT_76);
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_backtick;
    zT_138FFB41_Lexer l1;
    zT_3A355BD2_Token t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_at_backtick;
    zT_138FFB41_Lexer l2;
    zT_3A355BD2_Token t2;
    zig_poison_fill((void*)&zT_1, (unsigned int)sizeof zT_1);
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = (unsigned char*)zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = (zT_3E40CD83_Sand*)&sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = (zT_3E40CD83_Sand*)&sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = (zT_3E40CD83_Sand*)&sand;
    zT_24 = (zT_227EDE07_SourceManager*)&source_man;
    zT_25 = (zT_D3EB6303_StringInterner*)&interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "`";
    zT_33 = 1;
    zT_32.ptr = (unsigned char*)zT_31;
    zT_32.len = zT_33;
    s_backtick = zT_32;
    zT_35 = s_backtick;
    zT_40 = 0;
    zT_37 = (zT_D3EB6303_StringInterner*)&interner;
    zT_38 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_39 = (zT_3E40CD83_Sand*)&sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    l1 = zT_45;
    zT_47 = (zT_138FFB41_Lexer*)&l1;
    zT_49 = zF_B976BEC9_lexerNextToken(zT_47);
    t1 = zT_49;
    zT_50 = t1.kind;
    zF_1058D9A8_assertEqTokenKind(zT_50, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_err_token), (unsigned int)(0));
    zT_58 = "@`";
    zT_60 = 2;
    zT_59.ptr = (unsigned char*)zT_58;
    zT_59.len = zT_60;
    s_at_backtick = zT_59;
    zT_62 = s_at_backtick;
    zT_67 = 0;
    zT_64 = (zT_D3EB6303_StringInterner*)&interner;
    zT_65 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_66 = (zT_3E40CD83_Sand*)&sand;
    zT_72 = zF_151E643F_lexerInit(zT_62, (unsigned int)((unsigned int)zT_67), zT_64, zT_65, zT_66);
    l2 = zT_72;
    zT_74 = (zT_138FFB41_Lexer*)&l2;
    zT_76 = zF_B976BEC9_lexerNextToken(zT_74);
    t2 = zT_76;
    zT_77 = t2.kind;
    zF_1058D9A8_assertEqTokenKind(zT_77, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_err_token), (unsigned int)(0));
    return;
}

/* __module_init */
void zF_780653D2___module_init_5(void) {
    zT_3A355BD2_Token zT_0;
    zT_EAC3E484_TokenKind zT_1;
    zT_85CBA4DB_TokenValue zT_2;
    zT_47B162D1_U8ArrayList zT_3;
    zig_poison_fill((void*)&zT_0, (unsigned int)sizeof zT_0);
    zig_poison_fill((void*)&zT_1, (unsigned int)sizeof zT_1);
    zig_poison_fill((void*)&zT_2, (unsigned int)sizeof zT_2);
    zig_poison_fill((void*)&zT_3, (unsigned int)sizeof zT_3);
    zG_3A355BD2_Token = zT_0;
    zG_EAC3E484_TokenKind = zT_1;
    zG_85CBA4DB_TokenValue = zT_2;
    zG_47B162D1_U8ArrayList = zT_3;
    return;
}

/* EOF */
