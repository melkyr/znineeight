Z98 Win9x companion seed (v141)
========================================

Pinned HEAD: 1f3baae3
Capture date: 2026-11-06

This is the Windows-target companion to the Linux seed
release/seed/zig1-seed.tgz. It contains no prebuilt compiler executable.
win/ is a zig1 -osw compiler dump: the compiler's Windows-target C89,
runtime support, the two static-CRT build scripts the compiler emitted, and
the MinGW fallback pair (build_mingw_crt.bat/build_mingw_nocrt.bat). It ships
no MSVC/OpenWatcom no-CRT compiler scripts: that build is deferred to the
asm_x86 backend. Do not use the Linux gen/ C for Win9x.

Build the compiler on the Win9x machine
---------------------------------------
cd win
Each script writes its full command/output log to 00.txt in win/; the final
log line is Built: prog.exe on success or BUILD FAILED otherwise.
Win9x command.com redirects stdout only: no stream-merge redirection is used.
00.txt holds the executed commands plus stdout; OWC writes per-TU *.err files,
and MinGW gcc stderr appears on the console.

OpenWatcom (build_owc_crt.bat):
    rem run C:\WATCOM\OWSETENV.BAT in this window first (sets INCLUDE/LIB)
    build_owc_crt.bat
    copy prog.exe ..\zig1.exe
  wcc386 reads its flags from z98_cc.rsp (/fpc /bt=nt /ox and the /d /i
  flags), and wlink reads z98_link.lnk (system nt, stack 2097152, file
  *.obj, library kernel32,winmm).

MSVC 6 (build_target_crt.bat):
    rem fresh window; do not keep the Watcom env in it
    C:\PROGRA~1\MICROS~1\VC98\BIN\VCVARS32.BAT
    build_target_crt.bat
    copy prog.exe ..\zig1.exe
  cl reads /c /Op /nologo /O2 /W3 /MT from z98_cc.rsp (plus the /D and /I
  flags), and link reads z98_link.rsp. Keep CL_EXE/LINK_EXE unquoted.

MinGW fallback (Windows-hosted gcc), if MSVC 6 / OpenWatcom are unavailable:
    rem put the MinGW bin directory on PATH first
    build_mingw_crt.bat
    copy prog.exe ..\zig1.exe
    build_mingw_nocrt.bat
    copy prog.exe ..\zig1.exe
  The MinGW scripts are response-file-free: gcc 3.4.5 has no @file support.
  Every source is compiled by an explicit gcc line; objects are linked in
  explicit partial `gcc -r` chunks (at most 18 objects each) plus one short
  final link. The CRT script defines no ZIG_NO_CRT; the no-CRT script adds
  -DZIG_NO_CRT and links -nostdlib -Wl,-e,_mainCRTStartup -lgcc.

The MSVC/OpenWatcom scripts use a static CRT (/MT for MSVC 6, OpenWatcom
static CLIB): a single EXE with no msvcrt.dll. They may import KERNEL32 names
beyond the strict 9x whitelist; validate the result on the era machine.
build_mingw_nocrt.bat is the -nostdlib single-EXE fallback; build_mingw_crt.bat
is CRT-linked.

The copied ..\zig1.exe sits beside ..\lib\. That lib/ is the compiler's
standard library. Run zig1.exe with no arguments to see usage.

CRT note
--------
The compiler build here is CRT-only: build_target_crt.bat / build_owc_crt.bat
use a static CRT (/MT or OpenWatcom static CLIB), producing a single EXE with
no msvcrt.dll. The compiler's own no-CRT build is deferred until the asm_x86
backend; emitted programs still default to no-CRT.

Compiler status
---------------
The compiler source in win/ is -fsafe-clean (all intentional wraps and the
three real safe-mode defects fixed). The Windows-hosted compiler previously
rejected std-using programs at std_async.zig:259 (field resolution); that was
root-caused to a C89 update-stream fseek elision in spill_store.zig and fixed,
so the Windows-hosted compiler matches the Linux one on the 1188-dir corpus
(1186/1188 identical classes) and this CRT build is app-ready.

Build a program
---------------
zig1.exe -osw -o out hello.z98
then run out\build_owc_crt.bat (or build_target_crt.bat), or the emitted
_nocrt variant; the program is out\prog.exe (rename it if desired).

If a toolchain rejects the C, report the exact error.
