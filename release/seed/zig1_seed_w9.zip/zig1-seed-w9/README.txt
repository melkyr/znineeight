Z98 Win9x companion seed (v129)
========================================

Pinned HEAD: 1e7b303a
Capture date: 2026-10-29

This is the Windows-target companion to the Linux seed
release/seed/zig1-seed.tgz. It contains no prebuilt compiler executable.
win/ is a zig1 -osw compiler dump: the compiler's Windows-target C89,
runtime support, the two static-CRT build scripts the compiler emitted, and
the MinGW fallback pair (build_mingw_crt.bat/build_mingw_nocrt.bat). It ships
no MSVC/OpenWatcom no-CRT compiler scripts: that build is deferred to the
asm_x86 backend. Do not use the Linux gen/ C for Win9x.

Build the compiler on the Win9x machine
---------------------------------------
cd win
then run one of (the scripts hardcode the output name prog.exe):

  build_owc_crt.bat
  copy prog.exe ..\zig1.exe
  build_target_crt.bat
  copy prog.exe ..\zig1.exe

MinGW fallback (Windows-hosted gcc), if MSVC 6 / OpenWatcom are unavailable:

  build_mingw_crt.bat
  copy prog.exe ..\zig1.exe
  build_mingw_nocrt.bat
  copy prog.exe ..\zig1.exe

The MSVC/OpenWatcom scripts use a static CRT (/MT for MSVC 6, OpenWatcom
static CLIB): a single EXE with no msvcrt.dll. They may import KERNEL32 names
beyond the strict 9x whitelist; validate the result on the era machine.
build_mingw_nocrt.bat is the -nostdlib single-EXE fallback; build_mingw_crt.bat
is CRT-linked.

The copied ..\zig1.exe sits beside ..\lib\. That lib/ is the compiler's
standard library. Run zig1.exe with no arguments to see usage.

CRT note
--------
The compiler build here is CRT-only: build_target_crt.bat / build_owc_crt.bat
use a static CRT (/MT or OpenWatcom static CLIB), producing a single EXE with
no msvcrt.dll. The compiler's own no-CRT build is deferred until the asm_x86
backend; emitted programs still default to no-CRT.

Compiler status
---------------
The compiler source in win/ is -fsafe-clean (all intentional wraps and the
three real safe-mode defects fixed). The Windows-hosted compiler previously
rejected std-using programs at std_async.zig:259 (field resolution); that was
root-caused to a C89 update-stream fseek elision in spill_store.zig and fixed,
so the Windows-hosted compiler matches the Linux one on the 1188-dir corpus
(1186/1188 identical classes) and this CRT build is app-ready.

Build a program
---------------
zig1.exe -osw -o out hello.z98
then run out\build_owc_crt.bat (or build_target_crt.bat), or the emitted
_nocrt variant; the program is out\prog.exe (rename it if desired).

If a toolchain rejects the C, report the exact error.
