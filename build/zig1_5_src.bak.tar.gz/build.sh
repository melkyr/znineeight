#!/usr/bin/env bash
# Emergency rebuild of zig1_5_clean from the emitted C (no Zig compiler needed).
# This reproduces the compiler binary from the plain C89 source in ./gen,
# linking only the hand-written runtime files in ./include + ./c_exit.c.
# Run from this bundle directory:  bash build.sh
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR/gen"
gcc -m32 -std=c89 -O0 -Wall \
    -Wno-long-long -Wno-pointer-sign -Wno-implicit-function-declaration \
    -I "$DIR/include" -c *.c
gcc -m32 -O0 *.o \
    "$DIR/include/zig_runtime.c" "$DIR/include/zig_pal.c" "$DIR/c_exit.c" \
    -o "$DIR/zig1_5_clean"
echo "=== rebuilt $DIR/zig1_5_clean ==="
