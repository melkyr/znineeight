#include "config_F61490AC.h"
int zG_09E621EA_host_is_windows;
/* __module_init */
void zF_780653D2___module_init_22(void) {
    int zT_0;
    zT_0 = 0;
    zG_09E621EA_host_is_windows = zT_0;
    return;
}

/* EOF */
