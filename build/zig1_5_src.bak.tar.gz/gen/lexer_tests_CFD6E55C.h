#ifndef ZIG_MODULE_LEXER_TESTS_CFD6E55C_H
#define ZIG_MODULE_LEXER_TESTS_CFD6E55C_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "pal_388A8A1B.h"
#include "allocator_E75B7A0B.h"
#include "string_interner_51340A9F.h"
#include "mem_19CC4C40.h"
#include "source_manager_0C564FCF.h"
#include "diagnostics_B9C6175E.h"
#include "token_76C7CBBF.h"
#include "lexer_23F0DAD4.h"


/* Forward declarations */
void zF_13C3C6B9_initTestHarness(void);
zT_138FFB41_Lexer zF_72634CB3_makeLexer(zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_EBABC12E_assertEqU64(zT_79FAE712_u64, zT_79FAE712_u64, unsigned int);
void zF_AC2ADFEC_assertEqString(zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_C3E62EC7_formatU64_1(zT_79FAE712_u64, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int);
void zF_1058D9A8_assertEqTokenKind_1(zT_EAC3E484_TokenKind, zT_EAC3E484_TokenKind, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_2FED9490_formatU32_3(unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int);
zT_EAC3E484_TokenKind zF_7539755A_nextKind(zT_138FFB41_Lexer*);
zT_3A355BD2_Token zF_86E7799D_nextToken(zT_138FFB41_Lexer*);
void zF_4B029FD3_runLexerUnitTests(void);
void zF_CD74FE0B_testIntegerOverflow(void);
void zF_1613B19D_testFloatBasic(void);
void zF_78B53108_testFloatScientific(void);
void zF_78F063DE_testFloatNoFrac(void);
void zF_C8155E11_testShiftOps(void);
void zF_9D9CEC95_testFatArrow(void);
void zF_D0875FA5_testEqVariants(void);
void zF_B255817D_testBuiltinImport(void);
void zF_2E6F9110_testBareAt(void);
void zF_8C7EC385_testBareUnderscore(void);
void zF_8887267D_testUnderscoreIdent(void);
void zF_D4C9AF12_testWhitespaceOnly(void);
void zF_9170B517_testNestedComment(void);
void zF_6EDB119C_testUnterminatedCom(void);
void zF_AB737E0E_testStringBasic(void);
void zF_23CED836_testCharEmpty(void);
void zF_F838D22E_testStringUntermina(void);
void zF_40CBC754_testStringEscapeHex(void);
void zF_46007984_testBlockComments(void);
void zF_7723C349_testLineComments(void);
void zF_F69D323C_testNumberSeparator(void);
void zF_D9EE9D99_testIntegerEdgeCase(void);
void zF_8D85FCD9_testFloatEdgeCases(void);
void zF_EF6B25EB_testStringEscapeSeq(void);
void zF_608032D4_testCharEscapeSeque(void);
void zF_82D08453_testEofBoundary(void);
void zF_B175C7C4_testAllKeywords(void);
void zF_86BCD086_testDotVariants(void);
void zF_B024490C_testMultiTokenRecov(void);
void zF_2960DF23_testUnrecognizedCha(void);
void zF_C91FE56A_testSwitchMultiPron(void);
void zF_7089B32D_testSwitchCapture(void);
void zF_38E58669_testTryExpr(void);
void zF_1A243078_testErrorLiteral(void);
void zF_443A9F12_testNestedSwitch(void);
void zF_1C7CF0B1_testIfExpr(void);
void zF_8B8BE98F_testBuiltinCast(void);
void zF_9F3F0A8E_testSliceSyntax(void);
void zF_E9D65A05_testOptionalCapture(void);
void zF_92FE6BF5_testDerefField(void);
void zF_AE149E7F_testIntegrationMand(void);
void zF_6B1BFD38_testIntegrationGame(void);
void zF_1DC02C51_testIntegrationMud(void);
void zF_780653D2___module_init_23(void);
/* Storage globals (extern decls) */
extern zT_69AC43E8_Arr_unsigned_char_3 zG_767EC772_arena_buf;
extern zT_3E40CD83_Sand zG_BE148163_sand;
extern zT_D3EB6303_StringInterner zG_A0707C16_interner;
extern zT_227EDE07_SourceManager zG_BAB7A62F_source_man;
extern zT_F85C5DED_DiagnosticCollector zG_693DE70E_diag;

#endif /* ZIG_MODULE_LEXER_TESTS_CFD6E55C_H */
