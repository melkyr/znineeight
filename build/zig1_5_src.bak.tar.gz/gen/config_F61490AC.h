#ifndef ZIG_MODULE_CONFIG_F61490AC_H
#define ZIG_MODULE_CONFIG_F61490AC_H

#include "zig_compat.h"
#include "zig_special_types.h"


/* Forward declarations */
void zF_780653D2___module_init_22(void);
/* Storage globals (extern decls) */
extern int zG_09E621EA_host_is_windows;

#endif /* ZIG_MODULE_CONFIG_F61490AC_H */
