#include "coercion_F654E5FA.h"
zT_66E7D2EF_CoercionTable zG_66E7D2EF_CoercionTable;
zT_0FB7FB13_CoercionKind zG_0FB7FB13_CoercionKind;
/* coercionTableEnsureCapacity */
void zF_E837F929_coercionTableEnsure(zT_66E7D2EF_CoercionTable* self, unsigned int new_cap) {
    unsigned int zT_2;
    int zT_3;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    int zT_8;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    int zT_17;
    int zT_18;
    zT_3E40CD83_Sand* zT_20;
    unsigned char* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_3E40CD83_Sand* zT_25;
    zT_9CDC9863_CoercionEntry* zT_26;
    unsigned char* zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    zT_7834FCDD_Opt_220 zT_34 = {0};
    unsigned char zT_35;
    zT_3E40CD83_Sand* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_3E40CD83_Sand* zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    zT_A62CFBCC_EU_022 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    unsigned char* zT_47;
    zT_9CDC9863_CoercionEntry* zT_49;
    zT_9CDC9863_CoercionEntry* zT_50;
    unsigned int zT_51;
    int zT_52;
    zT_9CDC9863_CoercionEntry* zT_53;
    unsigned int zT_54;
    zT_5B0DCA45_Slice_zT_9CDC9863_C zT_55;
    zT_9CDC9863_CoercionEntry* zT_56;
    unsigned int zT_57;
    int zT_59;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int nc;
    zT_7834FCDD_Opt_220 grown;
    unsigned char* raw;
    zT_9CDC9863_CoercionEntry* new_items;
    zT_9CDC9863_CoercionEntry item;
    unsigned int i;
    zT_2 = self->entries_cap;
    zT_3 = new_cap <= zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    nc = new_cap;
    nc = new_cap;
    zT_5 = self->entries_cap;
    zT_6 = 2;
    zT_7 = zT_5 * zT_6;
    zT_8 = nc < zT_7;
    if (zT_8) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->entries_cap;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    nc = zT_11;
    nc = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 8;
    zT_13 = nc < (unsigned int)zT_12;
    if (zT_13) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    zT_15 = (unsigned int)zT_14;
    nc = zT_15;
    nc = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->entries_cap;
    zT_17 = 0;
    zT_18 = zT_16 > (unsigned int)zT_17;
    if (zT_18) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_25 = self->entries_alloc;
    zT_20 = zT_25;
    zT_26 = self->entries_items;
    zT_27 = (unsigned char*)zT_26;
    zT_21 = zT_27;
    zT_28 = self->entries_cap;
    zT_29 = 12;
    zT_30 = zT_28 * zT_29;
    zT_22 = zT_30;
    zT_31 = 12;
    zT_32 = nc * zT_31;
    zT_23 = zT_32;
    zT_33 = 4;
    zT_24 = zT_33;
    zT_34 = zF_33A3D4F8_sandTryReallocInPla(zT_20, zT_21, zT_22, zT_23, zT_24);
    grown = zT_34;
    grown = zT_34;
    grown = zT_34;
    zT_35 = grown.has_value;
    if (zT_35) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_40 = self->entries_alloc;
    zT_37 = zT_40;
    zT_41 = 12;
    zT_42 = zT_41 * nc;
    zT_38 = zT_42;
    zT_43 = 4;
    zT_39 = zT_43;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, zT_38, zT_39);
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    self->entries_cap = nc;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    z_bb_12:
    zT_47 = zT_44.data.payload;
    zT_46 = zT_47;
    goto z_bb_13;
    z_bb_13:
    raw = zT_46;
    raw = zT_46;
    raw = zT_46;
    zT_49 = (zT_9CDC9863_CoercionEntry*)raw;
    new_items = zT_49;
    new_items = zT_49;
    new_items = zT_49;
    zT_50 = self->entries_items;
    zT_51 = self->entries_len;
    zT_52 = 0;
    zT_53 = zT_50 + zT_52;
    zT_54 = zT_51 - zT_52;
    zT_55.ptr = zT_53;
    zT_55.len = zT_54;
    zT_56 = zT_55.ptr;
    zT_57 = zT_55.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    zT_59 = i < zT_57;
    if (zT_59) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_56[i];
    new_items[i] = item;
    zT_61 = 1;
    zT_62 = i + zT_61;
    i = zT_62;
    goto z_bb_14;
    z_bb_16:
    self->entries_items = new_items;
    self->entries_cap = nc;
    return;
}

/* coercionTableInit */
zT_66E7D2EF_CoercionTable zF_26B6D809_coercionTableInit(zT_3E40CD83_Sand* alloc) {
    zT_66E7D2EF_CoercionTable zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_21D3708C_U32ToU32Map zT_6 = {0};
    zT_2 = 0;
    zT_1.entries_items = (zT_9CDC9863_CoercionEntry*)zT_2;
    zT_3 = 0;
    zT_1.entries_len = zT_3;
    zT_4 = 0;
    zT_1.entries_cap = zT_4;
    zT_1.entries_alloc = alloc;
    zT_5 = alloc;
    zT_6 = zF_58BDA2DE_u32ToU32MapInit(zT_5);
    zT_1.index = zT_6;
    return zT_1;
}

/* coercionTableAdd */
void zF_D21AE60A_coercionTableAdd(zT_66E7D2EF_CoercionTable* self, unsigned int node_idx, zT_0FB7FB13_CoercionKind kind, unsigned int target_type) {
    zT_9CDC9863_CoercionEntry zT_5;
    zT_21D3708C_U32ToU32Map* zT_7;
    unsigned int zT_8;
    zT_21D3708C_U32ToU32Map* zT_9;
    zT_BAEE192E_Opt_10 zT_10 = {0};
    unsigned char zT_11;
    zT_9CDC9863_CoercionEntry* zT_13;
    unsigned int zT_14;
    zT_66E7D2EF_CoercionTable* zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_9CDC9863_CoercionEntry* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    zT_21D3708C_U32ToU32Map* zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    zT_21D3708C_U32ToU32Map* zT_32;
    zT_9CDC9863_CoercionEntry entry;
    zT_BAEE192E_Opt_10 existing;
    unsigned int idx;
    zT_5.node_idx = node_idx;
    zT_5.kind = kind;
    zT_5.target_type = target_type;
    entry = zT_5;
    entry = zT_5;
    entry = zT_5;
    zT_9 = &self->index;
    zT_7 = zT_9;
    zT_8 = node_idx;
    zT_10 = zF_F3EE5998_u32ToU32MapGet(zT_7, zT_8);
    existing = zT_10;
    existing = zT_10;
    existing = zT_10;
    zT_11 = existing.has_value;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    idx = existing.value;
    zT_13 = self->entries_items;
    zT_14 = (unsigned int)idx;
    zT_13[zT_14] = entry;
    return;
    z_bb_2:
    zT_15 = self;
    zT_17 = self->entries_len;
    zT_18 = 1;
    zT_19 = zT_17 + zT_18;
    zT_16 = zT_19;
    zF_E837F929_coercionTableEnsure(zT_15, zT_16);
    zT_21 = self->entries_len;
    zT_22 = (unsigned int)zT_21;
    idx = zT_22;
    idx = zT_22;
    idx = zT_22;
    zT_23 = self->entries_items;
    zT_24 = (unsigned int)idx;
    zT_23[zT_24] = entry;
    zT_25 = self->entries_len;
    zT_26 = 1;
    zT_27 = (unsigned int)zT_26;
    zT_28 = zT_25 + zT_27;
    self->entries_len = zT_28;
    zT_32 = &self->index;
    zT_29 = zT_32;
    zT_30 = node_idx;
    zT_31 = idx;
    zF_26476265_u32ToU32MapPut(zT_29, zT_30, zT_31);
    return;
}

/* coercionTableGet */
zT_50BDE62C_Opt_182 zF_46B66789_coercionTableGet(zT_66E7D2EF_CoercionTable* self, unsigned int node_idx) {
    zT_21D3708C_U32ToU32Map* zT_3;
    unsigned int zT_4;
    zT_21D3708C_U32ToU32Map* zT_5;
    zT_BAEE192E_Opt_10 zT_6 = {0};
    unsigned char zT_7;
    zT_9CDC9863_CoercionEntry* zT_9;
    unsigned int zT_10;
    zT_9CDC9863_CoercionEntry zT_11;
    zT_50BDE62C_Opt_182 zT_12;
    zT_50BDE62C_Opt_182 zT_13 = {0};
    zT_BAEE192E_Opt_10 entry_idx;
    unsigned int idx;
    zT_5 = &self->index;
    zT_3 = zT_5;
    zT_4 = node_idx;
    zT_6 = zF_F3EE5998_u32ToU32MapGet(zT_3, zT_4);
    entry_idx = zT_6;
    entry_idx = zT_6;
    entry_idx = zT_6;
    zT_7 = entry_idx.has_value;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    idx = entry_idx.value;
    zT_9 = self->entries_items;
    zT_10 = (unsigned int)idx;
    zT_11 = zT_9[zT_10];
    zT_12.has_value = 1;
    zT_12.value = zT_11;
    return zT_12;
    z_bb_2:
    zT_13.has_value = 0;
    return zT_13;
}

/* classifyCoercion */
zT_0FB7FB13_CoercionKind zF_713658BF_classifyCoercion(zT_338B7C76_TypeRegistry* reg, unsigned int source, unsigned int target) {
    int zT_3;
    zT_0FB7FB13_CoercionKind zT_4;
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    zT_D155D06D_Type zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    zT_33EF6BFB_TypeKind zT_16;
    int zT_17;
    int zT_18;
    zT_338B7C76_TypeRegistry* zT_19;
    unsigned int zT_20;
    int zT_21 = 0;
    zT_0FB7FB13_CoercionKind zT_22;
    zT_338B7C76_TypeRegistry* zT_23;
    unsigned int zT_24;
    int zT_25 = 0;
    int zT_26;
    zT_338B7C76_TypeRegistry* zT_27;
    unsigned int zT_28;
    int zT_29 = 0;
    int zT_30;
    unsigned int zT_31;
    int zT_32;
    zT_338B7C76_TypeRegistry* zT_33;
    unsigned int zT_34;
    int zT_35 = 0;
    zT_338B7C76_TypeRegistry* zT_36;
    unsigned int zT_37;
    int zT_38 = 0;
    int zT_39;
    int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    int zT_43;
    zT_0FB7FB13_CoercionKind zT_44;
    unsigned int zT_45;
    int zT_46;
    int zT_47;
    unsigned int zT_48;
    int zT_49;
    zT_0FB7FB13_CoercionKind zT_50;
    zT_33EF6BFB_TypeKind zT_51;
    zT_33EF6BFB_TypeKind zT_54;
    int zT_55;
    char* zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned int zT_61;
    zT_338B7C76_TypeRegistry* zT_62;
    unsigned int zT_63;
    int zT_64 = 0;
    zT_0FB7FB13_CoercionKind zT_65;
    zT_33EF6BFB_TypeKind zT_66;
    zT_33EF6BFB_TypeKind zT_69;
    int zT_70;
    zT_0FB7FB13_CoercionKind zT_71;
    zT_33EF6BFB_TypeKind zT_72;
    zT_33EF6BFB_TypeKind zT_75;
    int zT_76;
    zT_0FB7FB13_CoercionKind zT_77;
    zT_33EF6BFB_TypeKind zT_78;
    zT_33EF6BFB_TypeKind zT_81;
    int zT_82;
    zT_0B10E8E9_OptionalPayload* zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    zT_0B10E8E9_OptionalPayload zT_87;
    zT_338B7C76_TypeRegistry* zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    int zT_92 = 0;
    zT_0FB7FB13_CoercionKind zT_93;
    zT_33EF6BFB_TypeKind zT_94;
    zT_33EF6BFB_TypeKind zT_97;
    int zT_98;
    zT_0FB7FB13_CoercionKind zT_99;
    zT_33EF6BFB_TypeKind zT_100;
    zT_33EF6BFB_TypeKind zT_103;
    int zT_104;
    zT_42C2D6BF_EUPayload* zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    zT_42C2D6BF_EUPayload zT_109;
    zT_338B7C76_TypeRegistry* zT_110;
    unsigned int zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    int zT_114 = 0;
    zT_0FB7FB13_CoercionKind zT_115;
    zT_33EF6BFB_TypeKind zT_116;
    zT_33EF6BFB_TypeKind zT_119;
    int zT_120;
    int zT_121;
    zT_33EF6BFB_TypeKind zT_122;
    zT_33EF6BFB_TypeKind zT_125;
    int zT_126;
    zT_0FB7FB13_CoercionKind zT_127;
    zT_33EF6BFB_TypeKind zT_128;
    zT_33EF6BFB_TypeKind zT_131;
    int zT_132;
    int zT_133;
    zT_33EF6BFB_TypeKind zT_134;
    zT_33EF6BFB_TypeKind zT_137;
    int zT_138;
    zT_112BF819_PtrPayload* zT_140;
    unsigned int zT_141;
    unsigned int zT_142;
    zT_112BF819_PtrPayload zT_143;
    zT_112BF819_PtrPayload* zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    zT_112BF819_PtrPayload zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    int zT_151;
    zT_0FB7FB13_CoercionKind zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    int zT_155;
    zT_0FB7FB13_CoercionKind zT_156;
    unsigned char zT_157;
    unsigned char zT_158;
    unsigned char zT_159;
    unsigned char zT_160;
    int zT_161;
    int zT_162;
    unsigned char zT_163;
    unsigned char zT_164;
    unsigned char zT_165;
    unsigned char zT_166;
    int zT_167;
    unsigned int zT_168;
    unsigned int zT_169;
    int zT_170;
    zT_0FB7FB13_CoercionKind zT_171;
    zT_33EF6BFB_TypeKind zT_172;
    zT_33EF6BFB_TypeKind zT_175;
    int zT_176;
    int zT_177;
    zT_33EF6BFB_TypeKind zT_178;
    zT_33EF6BFB_TypeKind zT_181;
    int zT_182;
    unsigned char zT_183;
    unsigned char zT_184;
    unsigned char zT_185;
    unsigned char zT_186;
    int zT_187;
    int zT_188;
    unsigned char zT_189;
    unsigned char zT_190;
    unsigned char zT_191;
    unsigned char zT_192;
    int zT_193;
    zT_0BB2A741_SlicePayload* zT_195;
    unsigned int zT_196;
    unsigned int zT_197;
    zT_0BB2A741_SlicePayload zT_198;
    zT_0BB2A741_SlicePayload* zT_200;
    unsigned int zT_201;
    unsigned int zT_202;
    zT_0BB2A741_SlicePayload zT_203;
    unsigned int zT_204;
    unsigned int zT_205;
    int zT_206;
    zT_0FB7FB13_CoercionKind zT_207;
    zT_33EF6BFB_TypeKind zT_208;
    zT_33EF6BFB_TypeKind zT_211;
    int zT_212;
    int zT_213;
    zT_33EF6BFB_TypeKind zT_214;
    zT_33EF6BFB_TypeKind zT_217;
    int zT_218;
    unsigned char zT_219;
    unsigned char zT_220;
    unsigned char zT_221;
    unsigned char zT_222;
    int zT_223;
    int zT_224;
    unsigned char zT_225;
    unsigned char zT_226;
    unsigned char zT_227;
    unsigned char zT_228;
    int zT_229;
    zT_112BF819_PtrPayload* zT_231;
    unsigned int zT_232;
    unsigned int zT_233;
    zT_112BF819_PtrPayload zT_234;
    zT_112BF819_PtrPayload* zT_236;
    unsigned int zT_237;
    unsigned int zT_238;
    zT_112BF819_PtrPayload zT_239;
    unsigned int zT_240;
    unsigned int zT_241;
    int zT_242;
    zT_0FB7FB13_CoercionKind zT_243;
    zT_33EF6BFB_TypeKind zT_244;
    zT_33EF6BFB_TypeKind zT_247;
    int zT_248;
    int zT_249;
    zT_33EF6BFB_TypeKind zT_250;
    zT_33EF6BFB_TypeKind zT_253;
    int zT_254;
    zT_E834303C_ArrayPayload* zT_256;
    unsigned int zT_257;
    unsigned int zT_258;
    zT_E834303C_ArrayPayload zT_259;
    zT_0BB2A741_SlicePayload* zT_261;
    unsigned int zT_262;
    unsigned int zT_263;
    zT_0BB2A741_SlicePayload zT_264;
    unsigned int zT_265;
    unsigned int zT_266;
    int zT_267;
    zT_0FB7FB13_CoercionKind zT_268;
    unsigned char zT_269;
    unsigned char zT_270;
    unsigned char zT_271;
    unsigned char zT_272;
    int zT_273;
    int zT_274;
    unsigned int zT_275;
    unsigned int zT_276;
    int zT_277;
    zT_0FB7FB13_CoercionKind zT_278;
    zT_33EF6BFB_TypeKind zT_279;
    zT_33EF6BFB_TypeKind zT_282;
    int zT_283;
    int zT_284;
    zT_33EF6BFB_TypeKind zT_285;
    zT_33EF6BFB_TypeKind zT_288;
    int zT_289;
    zT_E834303C_ArrayPayload* zT_291;
    unsigned int zT_292;
    unsigned int zT_293;
    zT_E834303C_ArrayPayload zT_294;
    zT_112BF819_PtrPayload* zT_296;
    unsigned int zT_297;
    unsigned int zT_298;
    zT_112BF819_PtrPayload zT_299;
    unsigned int zT_300;
    unsigned int zT_301;
    int zT_302;
    zT_0FB7FB13_CoercionKind zT_303;
    zT_33EF6BFB_TypeKind zT_304;
    zT_33EF6BFB_TypeKind zT_307;
    int zT_308;
    int zT_309;
    zT_33EF6BFB_TypeKind zT_310;
    zT_33EF6BFB_TypeKind zT_313;
    int zT_314;
    zT_0BB2A741_SlicePayload* zT_316;
    unsigned int zT_317;
    unsigned int zT_318;
    zT_0BB2A741_SlicePayload zT_319;
    zT_112BF819_PtrPayload* zT_321;
    unsigned int zT_322;
    unsigned int zT_323;
    zT_112BF819_PtrPayload zT_324;
    unsigned int zT_325;
    unsigned int zT_326;
    int zT_327;
    zT_0FB7FB13_CoercionKind zT_328;
    zT_33EF6BFB_TypeKind zT_329;
    zT_33EF6BFB_TypeKind zT_332;
    int zT_333;
    int zT_334;
    zT_33EF6BFB_TypeKind zT_335;
    zT_33EF6BFB_TypeKind zT_338;
    int zT_339;
    zT_0B10E8E9_OptionalPayload* zT_341;
    unsigned int zT_342;
    unsigned int zT_343;
    zT_0B10E8E9_OptionalPayload zT_344;
    zT_D155D06D_Type* zT_346;
    unsigned int zT_347;
    unsigned int zT_348;
    zT_D155D06D_Type zT_349;
    zT_33EF6BFB_TypeKind zT_350;
    zT_33EF6BFB_TypeKind zT_353;
    int zT_354;
    zT_338B7C76_TypeRegistry* zT_355;
    unsigned int zT_356;
    unsigned int zT_357;
    unsigned int zT_358;
    int zT_359 = 0;
    zT_0FB7FB13_CoercionKind zT_360;
    unsigned int zT_361;
    int zT_362;
    int zT_363;
    unsigned int zT_364;
    int zT_365;
    int zT_366;
    unsigned int zT_367;
    int zT_368;
    int zT_369;
    unsigned int zT_370;
    int zT_371;
    zT_0FB7FB13_CoercionKind zT_372;
    zT_33EF6BFB_TypeKind zT_373;
    zT_33EF6BFB_TypeKind zT_376;
    int zT_377;
    int zT_378;
    zT_33EF6BFB_TypeKind zT_379;
    zT_33EF6BFB_TypeKind zT_382;
    int zT_383;
    zT_112BF819_PtrPayload* zT_385;
    unsigned int zT_386;
    unsigned int zT_387;
    zT_112BF819_PtrPayload zT_388;
    zT_0BB2A741_SlicePayload* zT_390;
    unsigned int zT_391;
    unsigned int zT_392;
    zT_0BB2A741_SlicePayload zT_393;
    char* zT_395;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_396;
    unsigned int zT_397;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_398;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_400;
    unsigned int zT_402;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_403;
    unsigned int zT_404;
    unsigned char* zT_405;
    unsigned int zT_406;
    int zT_407;
    unsigned char* zT_408;
    unsigned int zT_409;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_410;
    unsigned int zT_411 = 0;
    unsigned int zT_413;
    unsigned int zT_414;
    unsigned int zT_415;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_416;
    unsigned char* zT_417;
    unsigned int zT_419;
    unsigned char* zT_420;
    unsigned int zT_421;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_422;
    char* zT_424;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_425;
    unsigned int zT_426;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_427;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_429;
    unsigned int zT_431;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_432;
    unsigned int zT_433;
    unsigned char* zT_434;
    unsigned int zT_435;
    int zT_436;
    unsigned char* zT_437;
    unsigned int zT_438;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_439;
    unsigned int zT_440 = 0;
    unsigned int zT_442;
    unsigned int zT_443;
    unsigned int zT_444;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_445;
    unsigned char* zT_446;
    unsigned int zT_448;
    unsigned char* zT_449;
    unsigned int zT_450;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_451;
    char* zT_453;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_454;
    unsigned int zT_455;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_456;
    unsigned int zT_457;
    unsigned int zT_458;
    int zT_459;
    zT_0FB7FB13_CoercionKind zT_460;
    unsigned int zT_461;
    unsigned int zT_462;
    int zT_463;
    int zT_464;
    unsigned int zT_465;
    unsigned int zT_466;
    int zT_467;
    zT_0FB7FB13_CoercionKind zT_468;
    unsigned int zT_469;
    unsigned int zT_470;
    int zT_471;
    int zT_472;
    unsigned int zT_473;
    unsigned int zT_474;
    int zT_475;
    zT_0FB7FB13_CoercionKind zT_476;
    zT_D155D06D_Type* zT_478;
    unsigned int zT_479;
    unsigned int zT_480;
    zT_D155D06D_Type zT_481;
    zT_33EF6BFB_TypeKind zT_482;
    zT_33EF6BFB_TypeKind zT_485;
    int zT_486;
    zT_E834303C_ArrayPayload* zT_488;
    unsigned int zT_489;
    unsigned int zT_490;
    zT_E834303C_ArrayPayload zT_491;
    unsigned int zT_492;
    unsigned int zT_493;
    int zT_494;
    zT_0FB7FB13_CoercionKind zT_495;
    zT_0FB7FB13_CoercionKind zT_496;
    zT_D155D06D_Type src;
    zT_D155D06D_Type tgt;
    zT_8F083A69_Slice_zT_0B42B2F8_u ccn_m;
    zT_0B10E8E9_OptionalPayload opt;
    zT_42C2D6BF_EUPayload eu;
    zT_112BF819_PtrPayload tgt_pp;
    zT_112BF819_PtrPayload src_pp;
    zT_0BB2A741_SlicePayload s_sl;
    zT_0BB2A741_SlicePayload t_sl;
    zT_112BF819_PtrPayload s_pp;
    zT_112BF819_PtrPayload t_pp;
    zT_E834303C_ArrayPayload arr;
    zT_0BB2A741_SlicePayload sl;
    zT_112BF819_PtrPayload pp;
    zT_0B10E8E9_OptionalPayload opt2;
    zT_D155D06D_Type opt_ty;
    zT_112BF819_PtrPayload sp2;
    zT_0BB2A741_SlicePayload ts2;
    zT_8F083A69_Slice_zT_0B42B2F8_u clsb;
    zT_5A26C2ED_Arr_unsigned_char_1 clsb2;
    unsigned int clsb2l;
    unsigned int clsb2s;
    zT_8F083A69_Slice_zT_0B42B2F8_u clse;
    zT_5A26C2ED_Arr_unsigned_char_1 clsb3;
    unsigned int clsb3l;
    unsigned int clsb3s;
    zT_8F083A69_Slice_zT_0B42B2F8_u clsnl;
    zT_D155D06D_Type src_pointee;
    zT_3 = source == target;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = zT_0FB7FB13_CoercionKind_none;
    return zT_4;
    z_bb_2:
    zT_6 = reg->types_items;
    zT_7 = (unsigned int)source;
    zT_8 = zT_6[zT_7];
    src = zT_8;
    src = zT_8;
    src = zT_8;
    zT_10 = reg->types_items;
    zT_11 = (unsigned int)target;
    zT_12 = zT_10[zT_11];
    tgt = zT_12;
    tgt = zT_12;
    tgt = zT_12;
    zT_13 = src.kind;
    zT_16 = zT_33EF6BFB_TypeKind_integer_literal_type;
    zT_17 = zT_13 == zT_16;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_19 = reg;
    zT_20 = target;
    zT_21 = zF_3087E0A5_typeRegistryIsNumer(zT_19, zT_20);
    zT_18 = zT_21;
    goto z_bb_5;
    z_bb_4:
    zT_18 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_18) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_22 = zT_0FB7FB13_CoercionKind_int_literal_coerce;
    return zT_22;
    z_bb_7:
    zT_23 = reg;
    zT_24 = source;
    zT_25 = zF_3290E9C4_typeRegistryIsInteg(zT_23, zT_24);
    if (zT_25) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_27 = reg;
    zT_28 = target;
    zT_29 = zF_3290E9C4_typeRegistryIsInteg(zT_27, zT_28);
    zT_26 = zT_29;
    goto z_bb_10;
    z_bb_9:
    zT_26 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_26) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_31 = 19;
    zT_32 = source != zT_31;
    zT_30 = zT_32;
    goto z_bb_13;
    z_bb_12:
    zT_30 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_30) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_33 = reg;
    zT_34 = source;
    zT_35 = zF_B664AC19_typeRegistryIsUnsig(zT_33, zT_34);
    zT_36 = reg;
    zT_37 = target;
    zT_38 = zF_B664AC19_typeRegistryIsUnsig(zT_36, zT_37);
    zT_39 = zT_35 == zT_38;
    if (zT_39) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    zT_45 = 15;
    zT_46 = source == zT_45;
    if (zT_46) goto z_bb_21; else goto z_bb_22;
    z_bb_16:
    zT_41 = src.size;
    zT_42 = tgt.size;
    zT_43 = zT_41 < zT_42;
    zT_40 = zT_43;
    goto z_bb_18;
    z_bb_17:
    zT_40 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_40) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_44 = zT_0FB7FB13_CoercionKind_int_widen;
    return zT_44;
    z_bb_20:
    goto z_bb_15;
    z_bb_21:
    zT_48 = 16;
    zT_49 = target == zT_48;
    zT_47 = zT_49;
    goto z_bb_23;
    z_bb_22:
    zT_47 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_47) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_50 = zT_0FB7FB13_CoercionKind_float_widen;
    return zT_50;
    z_bb_25:
    zT_51 = src.kind;
    zT_54 = zT_33EF6BFB_TypeKind_null_type;
    zT_55 = zT_51 == zT_54;
    if (zT_55) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_57 = "CC:nul";
    zT_59 = 6;
    zT_58.ptr = zT_57;
    zT_58.len = zT_59;
    ccn_m = zT_58;
    ccn_m = zT_58;
    ccn_m = zT_58;
    zT_60 = ccn_m;
    zT_61 = target;
    zF_C914CB83_markerWriteInt(zT_60, zT_61);
    zT_62 = reg;
    zT_63 = target;
    zT_64 = zF_AD61DB1B_typeRegistryIsPoint(zT_62, zT_63);
    if (zT_64) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    zT_78 = tgt.kind;
    zT_81 = zT_33EF6BFB_TypeKind_optional_type;
    zT_82 = zT_78 == zT_81;
    if (zT_82) goto z_bb_34; else goto z_bb_35;
    z_bb_28:
    zT_65 = zT_0FB7FB13_CoercionKind_none;
    return zT_65;
    z_bb_29:
    zT_66 = tgt.kind;
    zT_69 = zT_33EF6BFB_TypeKind_optional_type;
    zT_70 = zT_66 == zT_69;
    if (zT_70) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_71 = zT_0FB7FB13_CoercionKind_wrap_optional_null;
    return zT_71;
    z_bb_31:
    zT_72 = tgt.kind;
    zT_75 = zT_33EF6BFB_TypeKind_fn_type;
    zT_76 = zT_72 == zT_75;
    if (zT_76) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_77 = zT_0FB7FB13_CoercionKind_none;
    return zT_77;
    z_bb_33:
    goto z_bb_27;
    z_bb_34:
    zT_84 = reg->opt_items;
    zT_85 = tgt.payload_idx;
    zT_86 = (unsigned int)zT_85;
    zT_87 = zT_84[zT_86];
    opt = zT_87;
    opt = zT_87;
    opt = zT_87;
    zT_88 = reg;
    zT_89 = source;
    zT_91 = opt.payload;
    zT_90 = zT_91;
    zT_92 = zF_683AEB7F_typeRegistryIsAssig(zT_88, zT_89, zT_90);
    if (zT_92) goto z_bb_36; else goto z_bb_37;
    z_bb_35:
    zT_100 = tgt.kind;
    zT_103 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_104 = zT_100 == zT_103;
    if (zT_104) goto z_bb_40; else goto z_bb_41;
    z_bb_36:
    zT_93 = zT_0FB7FB13_CoercionKind_wrap_optional;
    return zT_93;
    z_bb_37:
    zT_94 = src.kind;
    zT_97 = zT_33EF6BFB_TypeKind_null_type;
    zT_98 = zT_94 == zT_97;
    if (zT_98) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_99 = zT_0FB7FB13_CoercionKind_none;
    return zT_99;
    z_bb_39:
    goto z_bb_35;
    z_bb_40:
    zT_106 = reg->eu_items;
    zT_107 = tgt.payload_idx;
    zT_108 = (unsigned int)zT_107;
    zT_109 = zT_106[zT_108];
    eu = zT_109;
    eu = zT_109;
    eu = zT_109;
    zT_110 = reg;
    zT_111 = source;
    zT_113 = eu.payload;
    zT_112 = zT_113;
    zT_114 = zF_683AEB7F_typeRegistryIsAssig(zT_110, zT_111, zT_112);
    if (zT_114) goto z_bb_42; else goto z_bb_43;
    z_bb_41:
    zT_116 = src.kind;
    zT_119 = zT_33EF6BFB_TypeKind_error_set_type;
    zT_120 = zT_116 == zT_119;
    if (zT_120) goto z_bb_44; else goto z_bb_45;
    z_bb_42:
    zT_115 = zT_0FB7FB13_CoercionKind_wrap_error_success;
    return zT_115;
    z_bb_43:
    goto z_bb_41;
    z_bb_44:
    zT_122 = tgt.kind;
    zT_125 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_126 = zT_122 == zT_125;
    zT_121 = zT_126;
    goto z_bb_46;
    z_bb_45:
    zT_121 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_121) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_127 = zT_0FB7FB13_CoercionKind_wrap_error_err;
    return zT_127;
    z_bb_48:
    zT_128 = src.kind;
    zT_131 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_132 = zT_128 == zT_131;
    if (zT_132) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_134 = tgt.kind;
    zT_137 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_138 = zT_134 == zT_137;
    zT_133 = zT_138;
    goto z_bb_51;
    z_bb_50:
    zT_133 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_133) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_140 = reg->ptr_items;
    zT_141 = tgt.payload_idx;
    zT_142 = (unsigned int)zT_141;
    zT_143 = zT_140[zT_142];
    tgt_pp = zT_143;
    tgt_pp = zT_143;
    tgt_pp = zT_143;
    zT_145 = reg->ptr_items;
    zT_146 = src.payload_idx;
    zT_147 = (unsigned int)zT_146;
    zT_148 = zT_145[zT_147];
    src_pp = zT_148;
    src_pp = zT_148;
    src_pp = zT_148;
    zT_149 = tgt_pp.base;
    zT_150 = 1;
    zT_151 = zT_149 == zT_150;
    if (zT_151) goto z_bb_54; else goto z_bb_55;
    z_bb_53:
    zT_172 = tgt.kind;
    zT_175 = zT_33EF6BFB_TypeKind_slice_type;
    zT_176 = zT_172 == zT_175;
    if (zT_176) goto z_bb_65; else goto z_bb_66;
    z_bb_54:
    zT_152 = zT_0FB7FB13_CoercionKind_none;
    return zT_152;
    z_bb_55:
    zT_153 = src_pp.base;
    zT_154 = 1;
    zT_155 = zT_153 == zT_154;
    if (zT_155) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_156 = zT_0FB7FB13_CoercionKind_none;
    return zT_156;
    z_bb_57:
    zT_157 = tgt.flags;
    zT_158 = 1;
    zT_159 = zT_157 & zT_158;
    zT_160 = 0;
    zT_161 = zT_159 != zT_160;
    if (zT_161) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_163 = src.flags;
    zT_164 = 1;
    zT_165 = zT_163 & zT_164;
    zT_166 = 0;
    zT_167 = zT_165 == zT_166;
    zT_162 = zT_167;
    goto z_bb_60;
    z_bb_59:
    zT_162 = 0;
    goto z_bb_60;
    z_bb_60:
    if (zT_162) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_168 = src_pp.base;
    zT_169 = tgt_pp.base;
    zT_170 = zT_168 == zT_169;
    if (zT_170) goto z_bb_63; else goto z_bb_64;
    z_bb_62:
    goto z_bb_53;
    z_bb_63:
    zT_171 = zT_0FB7FB13_CoercionKind_const_qualify;
    return zT_171;
    z_bb_64:
    goto z_bb_62;
    z_bb_65:
    zT_178 = src.kind;
    zT_181 = zT_33EF6BFB_TypeKind_slice_type;
    zT_182 = zT_178 == zT_181;
    zT_177 = zT_182;
    goto z_bb_67;
    z_bb_66:
    zT_177 = 0;
    goto z_bb_67;
    z_bb_67:
    if (zT_177) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_183 = tgt.flags;
    zT_184 = 1;
    zT_185 = zT_183 & zT_184;
    zT_186 = 0;
    zT_187 = zT_185 != zT_186;
    if (zT_187) goto z_bb_70; else goto z_bb_71;
    z_bb_69:
    zT_208 = tgt.kind;
    zT_211 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_212 = zT_208 == zT_211;
    if (zT_212) goto z_bb_77; else goto z_bb_78;
    z_bb_70:
    zT_189 = src.flags;
    zT_190 = 1;
    zT_191 = zT_189 & zT_190;
    zT_192 = 0;
    zT_193 = zT_191 == zT_192;
    zT_188 = zT_193;
    goto z_bb_72;
    z_bb_71:
    zT_188 = 0;
    goto z_bb_72;
    z_bb_72:
    if (zT_188) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_195 = reg->slice_items;
    zT_196 = src.payload_idx;
    zT_197 = (unsigned int)zT_196;
    zT_198 = zT_195[zT_197];
    s_sl = zT_198;
    s_sl = zT_198;
    s_sl = zT_198;
    zT_200 = reg->slice_items;
    zT_201 = tgt.payload_idx;
    zT_202 = (unsigned int)zT_201;
    zT_203 = zT_200[zT_202];
    t_sl = zT_203;
    t_sl = zT_203;
    t_sl = zT_203;
    zT_204 = s_sl.elem;
    zT_205 = t_sl.elem;
    zT_206 = zT_204 == zT_205;
    if (zT_206) goto z_bb_75; else goto z_bb_76;
    z_bb_74:
    goto z_bb_69;
    z_bb_75:
    zT_207 = zT_0FB7FB13_CoercionKind_const_qualify;
    return zT_207;
    z_bb_76:
    goto z_bb_74;
    z_bb_77:
    zT_214 = src.kind;
    zT_217 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_218 = zT_214 == zT_217;
    zT_213 = zT_218;
    goto z_bb_79;
    z_bb_78:
    zT_213 = 0;
    goto z_bb_79;
    z_bb_79:
    if (zT_213) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_219 = tgt.flags;
    zT_220 = 1;
    zT_221 = zT_219 & zT_220;
    zT_222 = 0;
    zT_223 = zT_221 != zT_222;
    if (zT_223) goto z_bb_82; else goto z_bb_83;
    z_bb_81:
    zT_244 = src.kind;
    zT_247 = zT_33EF6BFB_TypeKind_array_type;
    zT_248 = zT_244 == zT_247;
    if (zT_248) goto z_bb_89; else goto z_bb_90;
    z_bb_82:
    zT_225 = src.flags;
    zT_226 = 1;
    zT_227 = zT_225 & zT_226;
    zT_228 = 0;
    zT_229 = zT_227 == zT_228;
    zT_224 = zT_229;
    goto z_bb_84;
    z_bb_83:
    zT_224 = 0;
    goto z_bb_84;
    z_bb_84:
    if (zT_224) goto z_bb_85; else goto z_bb_86;
    z_bb_85:
    zT_231 = reg->ptr_items;
    zT_232 = src.payload_idx;
    zT_233 = (unsigned int)zT_232;
    zT_234 = zT_231[zT_233];
    s_pp = zT_234;
    s_pp = zT_234;
    s_pp = zT_234;
    zT_236 = reg->ptr_items;
    zT_237 = tgt.payload_idx;
    zT_238 = (unsigned int)zT_237;
    zT_239 = zT_236[zT_238];
    t_pp = zT_239;
    t_pp = zT_239;
    t_pp = zT_239;
    zT_240 = s_pp.base;
    zT_241 = t_pp.base;
    zT_242 = zT_240 == zT_241;
    if (zT_242) goto z_bb_87; else goto z_bb_88;
    z_bb_86:
    goto z_bb_81;
    z_bb_87:
    zT_243 = zT_0FB7FB13_CoercionKind_const_qualify;
    return zT_243;
    z_bb_88:
    goto z_bb_86;
    z_bb_89:
    zT_250 = tgt.kind;
    zT_253 = zT_33EF6BFB_TypeKind_slice_type;
    zT_254 = zT_250 == zT_253;
    zT_249 = zT_254;
    goto z_bb_91;
    z_bb_90:
    zT_249 = 0;
    goto z_bb_91;
    z_bb_91:
    if (zT_249) goto z_bb_92; else goto z_bb_93;
    z_bb_92:
    zT_256 = reg->array_items;
    zT_257 = src.payload_idx;
    zT_258 = (unsigned int)zT_257;
    zT_259 = zT_256[zT_258];
    arr = zT_259;
    arr = zT_259;
    arr = zT_259;
    zT_261 = reg->slice_items;
    zT_262 = tgt.payload_idx;
    zT_263 = (unsigned int)zT_262;
    zT_264 = zT_261[zT_263];
    sl = zT_264;
    sl = zT_264;
    sl = zT_264;
    zT_265 = arr.elem;
    zT_266 = sl.elem;
    zT_267 = zT_265 == zT_266;
    if (zT_267) goto z_bb_94; else goto z_bb_95;
    z_bb_93:
    zT_279 = src.kind;
    zT_282 = zT_33EF6BFB_TypeKind_array_type;
    zT_283 = zT_279 == zT_282;
    if (zT_283) goto z_bb_101; else goto z_bb_102;
    z_bb_94:
    zT_268 = zT_0FB7FB13_CoercionKind_array_to_slice;
    return zT_268;
    z_bb_95:
    zT_269 = tgt.flags;
    zT_270 = 1;
    zT_271 = zT_269 & zT_270;
    zT_272 = 0;
    zT_273 = zT_271 != zT_272;
    if (zT_273) goto z_bb_96; else goto z_bb_97;
    z_bb_96:
    zT_275 = arr.elem;
    zT_276 = sl.elem;
    zT_277 = zT_275 == zT_276;
    zT_274 = zT_277;
    goto z_bb_98;
    z_bb_97:
    zT_274 = 0;
    goto z_bb_98;
    z_bb_98:
    if (zT_274) goto z_bb_99; else goto z_bb_100;
    z_bb_99:
    zT_278 = zT_0FB7FB13_CoercionKind_array_to_slice;
    return zT_278;
    z_bb_100:
    goto z_bb_93;
    z_bb_101:
    zT_285 = tgt.kind;
    zT_288 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_289 = zT_285 == zT_288;
    zT_284 = zT_289;
    goto z_bb_103;
    z_bb_102:
    zT_284 = 0;
    goto z_bb_103;
    z_bb_103:
    if (zT_284) goto z_bb_104; else goto z_bb_105;
    z_bb_104:
    zT_291 = reg->array_items;
    zT_292 = src.payload_idx;
    zT_293 = (unsigned int)zT_292;
    zT_294 = zT_291[zT_293];
    arr = zT_294;
    arr = zT_294;
    arr = zT_294;
    zT_296 = reg->ptr_items;
    zT_297 = tgt.payload_idx;
    zT_298 = (unsigned int)zT_297;
    zT_299 = zT_296[zT_298];
    pp = zT_299;
    pp = zT_299;
    pp = zT_299;
    zT_300 = arr.elem;
    zT_301 = pp.base;
    zT_302 = zT_300 == zT_301;
    if (zT_302) goto z_bb_106; else goto z_bb_107;
    z_bb_105:
    zT_304 = src.kind;
    zT_307 = zT_33EF6BFB_TypeKind_slice_type;
    zT_308 = zT_304 == zT_307;
    if (zT_308) goto z_bb_108; else goto z_bb_109;
    z_bb_106:
    zT_303 = zT_0FB7FB13_CoercionKind_array_to_many_ptr;
    return zT_303;
    z_bb_107:
    goto z_bb_105;
    z_bb_108:
    zT_310 = tgt.kind;
    zT_313 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_314 = zT_310 == zT_313;
    zT_309 = zT_314;
    goto z_bb_110;
    z_bb_109:
    zT_309 = 0;
    goto z_bb_110;
    z_bb_110:
    if (zT_309) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_316 = reg->slice_items;
    zT_317 = src.payload_idx;
    zT_318 = (unsigned int)zT_317;
    zT_319 = zT_316[zT_318];
    sl = zT_319;
    sl = zT_319;
    sl = zT_319;
    zT_321 = reg->ptr_items;
    zT_322 = tgt.payload_idx;
    zT_323 = (unsigned int)zT_322;
    zT_324 = zT_321[zT_323];
    pp = zT_324;
    pp = zT_324;
    pp = zT_324;
    zT_325 = sl.elem;
    zT_326 = pp.base;
    zT_327 = zT_325 == zT_326;
    if (zT_327) goto z_bb_113; else goto z_bb_114;
    z_bb_112:
    zT_329 = src.kind;
    zT_332 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_333 = zT_329 == zT_332;
    if (zT_333) goto z_bb_115; else goto z_bb_116;
    z_bb_113:
    zT_328 = zT_0FB7FB13_CoercionKind_slice_to_many_ptr;
    return zT_328;
    z_bb_114:
    goto z_bb_112;
    z_bb_115:
    zT_335 = tgt.kind;
    zT_338 = zT_33EF6BFB_TypeKind_optional_type;
    zT_339 = zT_335 == zT_338;
    zT_334 = zT_339;
    goto z_bb_117;
    z_bb_116:
    zT_334 = 0;
    goto z_bb_117;
    z_bb_117:
    if (zT_334) goto z_bb_118; else goto z_bb_119;
    z_bb_118:
    zT_341 = reg->opt_items;
    zT_342 = tgt.payload_idx;
    zT_343 = (unsigned int)zT_342;
    zT_344 = zT_341[zT_343];
    opt2 = zT_344;
    opt2 = zT_344;
    opt2 = zT_344;
    zT_346 = reg->types_items;
    zT_347 = opt2.payload;
    zT_348 = (unsigned int)zT_347;
    zT_349 = zT_346[zT_348];
    opt_ty = zT_349;
    opt_ty = zT_349;
    opt_ty = zT_349;
    zT_350 = opt_ty.kind;
    zT_353 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_354 = zT_350 == zT_353;
    if (zT_354) goto z_bb_120; else goto z_bb_121;
    z_bb_119:
    zT_361 = 8;
    zT_362 = source == zT_361;
    if (zT_362) goto z_bb_124; else goto z_bb_125;
    z_bb_120:
    zT_355 = reg;
    zT_356 = source;
    zT_358 = opt2.payload;
    zT_357 = zT_358;
    zT_359 = zF_683AEB7F_typeRegistryIsAssig(zT_355, zT_356, zT_357);
    if (zT_359) goto z_bb_122; else goto z_bb_123;
    z_bb_121:
    goto z_bb_119;
    z_bb_122:
    zT_360 = zT_0FB7FB13_CoercionKind_ptr_to_optional_ptr;
    return zT_360;
    z_bb_123:
    goto z_bb_121;
    z_bb_124:
    zT_364 = 14;
    zT_365 = target == zT_364;
    zT_363 = zT_365;
    goto z_bb_126;
    z_bb_125:
    zT_363 = 0;
    goto z_bb_126;
    z_bb_126:
    if (zT_363) goto z_bb_128; else goto z_bb_127;
    z_bb_127:
    zT_367 = 14;
    zT_368 = source == zT_367;
    if (zT_368) goto z_bb_130; else goto z_bb_131;
    z_bb_128:
    zT_366 = 1;
    goto z_bb_129;
    z_bb_129:
    if (zT_366) goto z_bb_133; else goto z_bb_134;
    z_bb_130:
    zT_370 = 8;
    zT_371 = target == zT_370;
    zT_369 = zT_371;
    goto z_bb_132;
    z_bb_131:
    zT_369 = 0;
    goto z_bb_132;
    z_bb_132:
    zT_366 = zT_369;
    goto z_bb_129;
    z_bb_133:
    zT_372 = zT_0FB7FB13_CoercionKind_none;
    return zT_372;
    z_bb_134:
    zT_373 = src.kind;
    zT_376 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_377 = zT_373 == zT_376;
    if (zT_377) goto z_bb_135; else goto z_bb_136;
    z_bb_135:
    zT_379 = tgt.kind;
    zT_382 = zT_33EF6BFB_TypeKind_slice_type;
    zT_383 = zT_379 == zT_382;
    zT_378 = zT_383;
    goto z_bb_137;
    z_bb_136:
    zT_378 = 0;
    goto z_bb_137;
    z_bb_137:
    if (zT_378) goto z_bb_138; else goto z_bb_139;
    z_bb_138:
    zT_385 = reg->ptr_items;
    zT_386 = src.payload_idx;
    zT_387 = (unsigned int)zT_386;
    zT_388 = zT_385[zT_387];
    sp2 = zT_388;
    sp2 = zT_388;
    sp2 = zT_388;
    zT_390 = reg->slice_items;
    zT_391 = tgt.payload_idx;
    zT_392 = (unsigned int)zT_391;
    zT_393 = zT_390[zT_392];
    ts2 = zT_393;
    ts2 = zT_393;
    ts2 = zT_393;
    zT_395 = "CLS:p";
    zT_397 = 5;
    zT_396.ptr = zT_395;
    zT_396.len = zT_397;
    clsb = zT_396;
    clsb = zT_396;
    clsb = zT_396;
    zT_398 = clsb;
    zF_48AC7B3A_markerWrite(zT_398);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_400[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        clsb2[_i] = zT_400[_i];
        _i++;
    }
}
    zT_404 = sp2.base;
    zT_402 = zT_404;
    zT_405 = (unsigned char*)clsb2;
    zT_406 = 10;
    zT_407 = 0;
    zT_408 = zT_405 + zT_407;
    zT_409 = zT_406 - zT_407;
    zT_410.ptr = zT_408;
    zT_410.len = zT_409;
    zT_403 = zT_410;
    zT_411 = zF_A7504564_itoa(zT_402, zT_403);
    clsb2l = zT_411;
    clsb2l = zT_411;
    clsb2l = zT_411;
    zT_413 = 9;
    zT_414 = (unsigned int)clsb2l;
    zT_415 = zT_413 - zT_414;
    clsb2s = zT_415;
    clsb2s = zT_415;
    clsb2s = zT_415;
    zT_417 = (unsigned char*)clsb2;
    zT_419 = 9;
    zT_420 = zT_417 + clsb2s;
    zT_421 = zT_419 - clsb2s;
    zT_422.ptr = zT_420;
    zT_422.len = zT_421;
    zT_416 = zT_422;
    zF_48AC7B3A_markerWrite(zT_416);
    zT_424 = "e";
    zT_426 = 1;
    zT_425.ptr = zT_424;
    zT_425.len = zT_426;
    clse = zT_425;
    clse = zT_425;
    clse = zT_425;
    zT_427 = clse;
    zF_48AC7B3A_markerWrite(zT_427);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_429[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        clsb3[_i] = zT_429[_i];
        _i++;
    }
}
    zT_433 = ts2.elem;
    zT_431 = zT_433;
    zT_434 = (unsigned char*)clsb3;
    zT_435 = 10;
    zT_436 = 0;
    zT_437 = zT_434 + zT_436;
    zT_438 = zT_435 - zT_436;
    zT_439.ptr = zT_437;
    zT_439.len = zT_438;
    zT_432 = zT_439;
    zT_440 = zF_A7504564_itoa(zT_431, zT_432);
    clsb3l = zT_440;
    clsb3l = zT_440;
    clsb3l = zT_440;
    zT_442 = 9;
    zT_443 = (unsigned int)clsb3l;
    zT_444 = zT_442 - zT_443;
    clsb3s = zT_444;
    clsb3s = zT_444;
    clsb3s = zT_444;
    zT_446 = (unsigned char*)clsb3;
    zT_448 = 9;
    zT_449 = zT_446 + clsb3s;
    zT_450 = zT_448 - clsb3s;
    zT_451.ptr = zT_449;
    zT_451.len = zT_450;
    zT_445 = zT_451;
    zF_48AC7B3A_markerWrite(zT_445);
    zT_453 = "\n";
    zT_455 = 1;
    zT_454.ptr = zT_453;
    zT_454.len = zT_455;
    clsnl = zT_454;
    clsnl = zT_454;
    clsnl = zT_454;
    zT_456 = clsnl;
    zF_48AC7B3A_markerWrite(zT_456);
    zT_457 = sp2.base;
    zT_458 = ts2.elem;
    zT_459 = zT_457 == zT_458;
    if (zT_459) goto z_bb_140; else goto z_bb_141;
    z_bb_139:
    zT_496 = zT_0FB7FB13_CoercionKind_none;
    return zT_496;
    z_bb_140:
    zT_460 = zT_0FB7FB13_CoercionKind_string_to_slice;
    return zT_460;
    z_bb_141:
    zT_461 = sp2.base;
    zT_462 = 14;
    zT_463 = zT_461 == zT_462;
    if (zT_463) goto z_bb_142; else goto z_bb_143;
    z_bb_142:
    zT_465 = ts2.elem;
    zT_466 = 8;
    zT_467 = zT_465 == zT_466;
    zT_464 = zT_467;
    goto z_bb_144;
    z_bb_143:
    zT_464 = 0;
    goto z_bb_144;
    z_bb_144:
    if (zT_464) goto z_bb_145; else goto z_bb_146;
    z_bb_145:
    zT_468 = zT_0FB7FB13_CoercionKind_string_to_slice;
    return zT_468;
    z_bb_146:
    zT_469 = sp2.base;
    zT_470 = 8;
    zT_471 = zT_469 == zT_470;
    if (zT_471) goto z_bb_147; else goto z_bb_148;
    z_bb_147:
    zT_473 = ts2.elem;
    zT_474 = 14;
    zT_475 = zT_473 == zT_474;
    zT_472 = zT_475;
    goto z_bb_149;
    z_bb_148:
    zT_472 = 0;
    goto z_bb_149;
    z_bb_149:
    if (zT_472) goto z_bb_150; else goto z_bb_151;
    z_bb_150:
    zT_476 = zT_0FB7FB13_CoercionKind_string_to_slice;
    return zT_476;
    z_bb_151:
    zT_478 = reg->types_items;
    zT_479 = sp2.base;
    zT_480 = (unsigned int)zT_479;
    zT_481 = zT_478[zT_480];
    src_pointee = zT_481;
    src_pointee = zT_481;
    src_pointee = zT_481;
    zT_482 = src_pointee.kind;
    zT_485 = zT_33EF6BFB_TypeKind_array_type;
    zT_486 = zT_482 == zT_485;
    if (zT_486) goto z_bb_152; else goto z_bb_153;
    z_bb_152:
    zT_488 = reg->array_items;
    zT_489 = src_pointee.payload_idx;
    zT_490 = (unsigned int)zT_489;
    zT_491 = zT_488[zT_490];
    arr = zT_491;
    arr = zT_491;
    arr = zT_491;
    zT_492 = arr.elem;
    zT_493 = ts2.elem;
    zT_494 = zT_492 == zT_493;
    if (zT_494) goto z_bb_154; else goto z_bb_155;
    z_bb_153:
    goto z_bb_139;
    z_bb_154:
    zT_495 = zT_0FB7FB13_CoercionKind_array_to_slice;
    return zT_495;
    z_bb_155:
    goto z_bb_153;
}

/* EOF */
