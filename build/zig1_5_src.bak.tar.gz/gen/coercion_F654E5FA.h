#ifndef ZIG_MODULE_COERCION_F654E5FA_H
#define ZIG_MODULE_COERCION_F654E5FA_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "allocator_E75B7A0B.h"
#include "type_registry_8EE489B8.h"
#include "type_registry_8EE489B8.h"
#include "hash_02AFCD13.h"
#include "pal_388A8A1B.h"
#include "itoa_4E677A6A.h"


/* Forward declarations */
void zF_E837F929_coercionTableEnsure(zT_66E7D2EF_CoercionTable*, unsigned int);
zT_66E7D2EF_CoercionTable zF_26B6D809_coercionTableInit(zT_3E40CD83_Sand*);
void zF_D21AE60A_coercionTableAdd(zT_66E7D2EF_CoercionTable*, unsigned int, zT_0FB7FB13_CoercionKind, unsigned int);
zT_50BDE62C_Opt_182 zF_46B66789_coercionTableGet(zT_66E7D2EF_CoercionTable*, unsigned int);
zT_0FB7FB13_CoercionKind zF_713658BF_classifyCoercion(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int);
/* Storage globals (extern decls) */
extern zT_66E7D2EF_CoercionTable zG_66E7D2EF_CoercionTable;
extern zT_0FB7FB13_CoercionKind zG_0FB7FB13_CoercionKind;

#endif /* ZIG_MODULE_COERCION_F654E5FA_H */
