#include "type_resolver_7446D285.h"
zT_C890C8CB_TypeResolver zG_C890C8CB_TypeResolver;
unsigned int zG_E6DB2ACE_MODULE_ID_NONE;
/* dependEnsureCapacity */
void zF_A2DE06A5_dependEnsureCapacit(zT_C890C8CB_TypeResolver* self) {
    unsigned int zT_1;
    unsigned int zT_2;
    int zT_3;
    unsigned int zT_5;
    int zT_6;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    int zT_15;
    zT_3E40CD83_Sand* zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_3E40CD83_Sand* zT_22;
    zT_52CDA6EF_DepEdge* zT_23;
    unsigned char* zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    zT_7834FCDD_Opt_220 zT_31 = {0};
    unsigned char zT_32;
    zT_3E40CD83_Sand* zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    zT_3E40CD83_Sand* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    zT_A62CFBCC_EU_022 zT_41 = {0};
    unsigned char zT_42;
    unsigned char* zT_43;
    unsigned char* zT_44;
    zT_52CDA6EF_DepEdge* zT_46;
    zT_52CDA6EF_DepEdge* zT_47;
    unsigned int zT_48;
    int zT_49;
    zT_52CDA6EF_DepEdge* zT_50;
    unsigned int zT_51;
    zT_D868CF46_Slice_zT_52CDA6EF_D zT_52;
    zT_52CDA6EF_DepEdge* zT_53;
    unsigned int zT_54;
    int zT_56;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int nc;
    zT_7834FCDD_Opt_220 grown;
    unsigned char* raw;
    zT_52CDA6EF_DepEdge* new_items;
    zT_52CDA6EF_DepEdge item;
    unsigned int i;
    zT_1 = self->depend_len;
    zT_2 = self->depend_cap;
    zT_3 = zT_1 < zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->depend_cap;
    zT_6 = 8;
    zT_7 = zT_5 < (unsigned int)zT_6;
    if (zT_7) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = 8;
    zT_8 = zT_9;
    goto z_bb_5;
    z_bb_4:
    zT_10 = self->depend_cap;
    zT_11 = 2;
    zT_12 = zT_10 * zT_11;
    zT_8 = zT_12;
    goto z_bb_5;
    z_bb_5:
    nc = zT_8;
    nc = zT_8;
    nc = zT_8;
    zT_13 = self->depend_cap;
    zT_14 = 0;
    zT_15 = zT_13 > (unsigned int)zT_14;
    if (zT_15) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_22 = self->alloc;
    zT_17 = zT_22;
    zT_23 = self->depend_items;
    zT_24 = (unsigned char*)zT_23;
    zT_18 = zT_24;
    zT_25 = self->depend_cap;
    zT_26 = 8;
    zT_27 = zT_25 * zT_26;
    zT_19 = zT_27;
    zT_28 = 8;
    zT_29 = nc * zT_28;
    zT_20 = zT_29;
    zT_30 = 4;
    zT_21 = zT_30;
    zT_31 = zF_33A3D4F8_sandTryReallocInPla(zT_17, zT_18, zT_19, zT_20, zT_21);
    grown = zT_31;
    grown = zT_31;
    grown = zT_31;
    zT_32 = grown.has_value;
    if (zT_32) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_37 = self->alloc;
    zT_34 = zT_37;
    zT_38 = 8;
    zT_39 = nc * zT_38;
    zT_35 = zT_39;
    zT_40 = 4;
    zT_36 = zT_40;
    zT_41 = zF_1395EB68_sandAlloc(zT_34, zT_35, zT_36);
    zT_42 = zT_41.is_error;
    if (zT_42) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    self->depend_cap = nc;
    return;
    z_bb_9:
    goto z_bb_7;
    z_bb_10:
    z_bb_11:
    zT_44 = zT_41.data.payload;
    zT_43 = zT_44;
    goto z_bb_12;
    z_bb_12:
    raw = zT_43;
    raw = zT_43;
    raw = zT_43;
    zT_46 = (zT_52CDA6EF_DepEdge*)raw;
    new_items = zT_46;
    new_items = zT_46;
    new_items = zT_46;
    zT_47 = self->depend_items;
    zT_48 = self->depend_len;
    zT_49 = 0;
    zT_50 = zT_47 + zT_49;
    zT_51 = zT_48 - zT_49;
    zT_52.ptr = zT_50;
    zT_52.len = zT_51;
    zT_53 = zT_52.ptr;
    zT_54 = zT_52.len;
    i = 0;
    goto z_bb_13;
    z_bb_13:
    zT_56 = i < zT_54;
    if (zT_56) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    item = zT_53[i];
    new_items[i] = item;
    zT_58 = 1;
    zT_59 = i + zT_58;
    i = zT_59;
    goto z_bb_13;
    z_bb_15:
    self->depend_items = new_items;
    self->depend_cap = nc;
    return;
}

/* typeResolverAddEdge */
void zF_F1D68957_typeResolverAddEdge(zT_C890C8CB_TypeResolver* self, unsigned int from, unsigned int to) {
    zT_C890C8CB_TypeResolver* zT_3;
    zT_52CDA6EF_DepEdge zT_4;
    zT_52CDA6EF_DepEdge* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    zT_3 = self;
    zF_A2DE06A5_dependEnsureCapacit(zT_3);
    zT_4.from = from;
    zT_4.to = to;
    zT_5 = self->depend_items;
    zT_6 = self->depend_len;
    zT_5[zT_6] = zT_4;
    zT_7 = self->depend_len;
    zT_8 = 1;
    zT_9 = (unsigned int)zT_8;
    zT_10 = zT_7 + zT_9;
    self->depend_len = zT_10;
    return;
}

/* worklistEnsureCapacity */
void zF_0FC458B2_worklistEnsureCapac(zT_C890C8CB_TypeResolver* self) {
    unsigned int zT_1;
    unsigned int zT_2;
    int zT_3;
    unsigned int zT_5;
    int zT_6;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    int zT_15;
    zT_3E40CD83_Sand* zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_3E40CD83_Sand* zT_22;
    unsigned int* zT_23;
    unsigned char* zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    zT_7834FCDD_Opt_220 zT_31 = {0};
    unsigned char zT_32;
    zT_3E40CD83_Sand* zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    zT_3E40CD83_Sand* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    zT_A62CFBCC_EU_022 zT_41 = {0};
    unsigned char zT_42;
    unsigned char* zT_43;
    unsigned char* zT_44;
    unsigned int* zT_46;
    unsigned int* zT_47;
    unsigned int zT_48;
    int zT_49;
    unsigned int* zT_50;
    unsigned int zT_51;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_52;
    unsigned int* zT_53;
    unsigned int zT_54;
    int zT_56;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int nc;
    zT_7834FCDD_Opt_220 grown;
    unsigned char* raw;
    unsigned int* new_items;
    unsigned int item;
    unsigned int i;
    zT_1 = self->worklist_len;
    zT_2 = self->worklist_cap;
    zT_3 = zT_1 < zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->worklist_cap;
    zT_6 = 64;
    zT_7 = zT_5 < (unsigned int)zT_6;
    if (zT_7) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = 64;
    zT_8 = zT_9;
    goto z_bb_5;
    z_bb_4:
    zT_10 = self->worklist_cap;
    zT_11 = 2;
    zT_12 = zT_10 * zT_11;
    zT_8 = zT_12;
    goto z_bb_5;
    z_bb_5:
    nc = zT_8;
    nc = zT_8;
    nc = zT_8;
    zT_13 = self->worklist_cap;
    zT_14 = 0;
    zT_15 = zT_13 > (unsigned int)zT_14;
    if (zT_15) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_22 = self->alloc;
    zT_17 = zT_22;
    zT_23 = self->worklist_items;
    zT_24 = (unsigned char*)zT_23;
    zT_18 = zT_24;
    zT_25 = self->worklist_cap;
    zT_26 = 4;
    zT_27 = zT_25 * zT_26;
    zT_19 = zT_27;
    zT_28 = 4;
    zT_29 = nc * zT_28;
    zT_20 = zT_29;
    zT_30 = 4;
    zT_21 = zT_30;
    zT_31 = zF_33A3D4F8_sandTryReallocInPla(zT_17, zT_18, zT_19, zT_20, zT_21);
    grown = zT_31;
    grown = zT_31;
    grown = zT_31;
    zT_32 = grown.has_value;
    if (zT_32) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_37 = self->alloc;
    zT_34 = zT_37;
    zT_38 = 4;
    zT_39 = nc * zT_38;
    zT_35 = zT_39;
    zT_40 = 4;
    zT_36 = zT_40;
    zT_41 = zF_1395EB68_sandAlloc(zT_34, zT_35, zT_36);
    zT_42 = zT_41.is_error;
    if (zT_42) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    self->worklist_cap = nc;
    return;
    z_bb_9:
    goto z_bb_7;
    z_bb_10:
    z_bb_11:
    zT_44 = zT_41.data.payload;
    zT_43 = zT_44;
    goto z_bb_12;
    z_bb_12:
    raw = zT_43;
    raw = zT_43;
    raw = zT_43;
    zT_46 = (unsigned int*)raw;
    new_items = zT_46;
    new_items = zT_46;
    new_items = zT_46;
    zT_47 = self->worklist_items;
    zT_48 = self->worklist_len;
    zT_49 = 0;
    zT_50 = zT_47 + zT_49;
    zT_51 = zT_48 - zT_49;
    zT_52.ptr = zT_50;
    zT_52.len = zT_51;
    zT_53 = zT_52.ptr;
    zT_54 = zT_52.len;
    i = 0;
    goto z_bb_13;
    z_bb_13:
    zT_56 = i < zT_54;
    if (zT_56) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    item = zT_53[i];
    new_items[i] = item;
    zT_58 = 1;
    zT_59 = i + zT_58;
    i = zT_59;
    goto z_bb_13;
    z_bb_15:
    self->worklist_items = new_items;
    self->worklist_cap = nc;
    return;
}

/* worklistPush */
void zF_352BC6BC_worklistPush(zT_C890C8CB_TypeResolver* self, unsigned int id) {
    zT_C890C8CB_TypeResolver* zT_2;
    unsigned int* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_2 = self;
    zF_0FC458B2_worklistEnsureCapac(zT_2);
    zT_3 = self->worklist_items;
    zT_4 = self->worklist_len;
    zT_3[zT_4] = id;
    zT_5 = self->worklist_len;
    zT_6 = 1;
    zT_7 = (unsigned int)zT_6;
    zT_8 = zT_5 + zT_7;
    self->worklist_len = zT_8;
    return;
}

/* worklistPop */
zT_BAEE192E_Opt_10 zF_D7A5282F_worklistPop(zT_C890C8CB_TypeResolver* self) {
    unsigned int zT_1;
    int zT_2;
    int zT_3;
    zT_BAEE192E_Opt_10 zT_4 = {0};
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_BAEE192E_Opt_10 zT_12;
    zT_1 = self->worklist_len;
    zT_2 = 0;
    zT_3 = zT_1 == (unsigned int)zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_5 = self->worklist_len;
    zT_6 = 1;
    zT_7 = (unsigned int)zT_6;
    zT_8 = zT_5 - zT_7;
    self->worklist_len = zT_8;
    zT_9 = self->worklist_items;
    zT_10 = self->worklist_len;
    zT_11 = zT_9[zT_10];
    zT_12.has_value = 1;
    zT_12.value = zT_11;
    return zT_12;
}

/* inDegreeEnsureCapacity */
void zF_959DB1DC_inDegreeEnsureCapac(zT_C890C8CB_TypeResolver* self, unsigned int capacity) {
    unsigned int zT_2;
    int zT_3;
    int zT_5;
    int zT_6;
    int zT_7;
    unsigned int zT_8;
    zT_3E40CD83_Sand* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_3E40CD83_Sand* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    zT_A62CFBCC_EU_022 zT_17 = {0};
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned char* zT_20;
    unsigned int* zT_21;
    unsigned int nc;
    unsigned char* raw;
    zT_2 = self->in_degree_cap;
    zT_3 = capacity <= zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = capacity;
    nc = capacity;
    nc = capacity;
    zT_5 = 64;
    zT_6 = nc < (unsigned int)zT_5;
    if (zT_6) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_7 = 64;
    zT_8 = (unsigned int)zT_7;
    nc = zT_8;
    nc = zT_8;
    goto z_bb_4;
    z_bb_4:
    zT_13 = self->alloc;
    zT_10 = zT_13;
    zT_14 = 4;
    zT_15 = nc * zT_14;
    zT_11 = zT_15;
    zT_16 = 4;
    zT_12 = zT_16;
    zT_17 = zF_1395EB68_sandAlloc(zT_10, zT_11, zT_12);
    zT_18 = zT_17.is_error;
    if (zT_18) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    z_bb_6:
    zT_20 = zT_17.data.payload;
    zT_19 = zT_20;
    goto z_bb_7;
    z_bb_7:
    raw = zT_19;
    raw = zT_19;
    raw = zT_19;
    zT_21 = (unsigned int*)raw;
    self->in_degree_items = zT_21;
    self->in_degree_cap = nc;
    return;
}

/* alignUp */
unsigned int zF_D2BAC673_alignUp_1(unsigned int v, unsigned int a) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_2 = v + a;
    zT_3 = 1;
    zT_4 = zT_2 - zT_3;
    zT_5 = 1;
    zT_6 = a - zT_5;
    zT_7 = ~zT_6;
    zT_8 = zT_4 & zT_7;
    return zT_8;
}

/* typeResolverResolveLayout */
void zF_3957E0DF_typeResolverResolve(zT_C890C8CB_TypeResolver* self, unsigned int tid) {
    unsigned int zT_3;
    zT_338B7C76_TypeRegistry* zT_5;
    zT_D155D06D_Type* zT_6;
    zT_D155D06D_Type zT_7;
    zT_33EF6BFB_TypeKind zT_8;
    zT_33EF6BFB_TypeKind zT_11;
    int zT_12;
    zT_338B7C76_TypeRegistry* zT_14;
    zT_406493CE_StructPayload* zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_406493CE_StructPayload zT_18;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned short zT_23;
    unsigned int zT_24;
    int zT_26;
    unsigned int zT_27;
    int zT_29;
    unsigned int zT_30;
    int zT_32;
    unsigned int zT_33;
    int zT_34;
    zT_338B7C76_TypeRegistry* zT_36;
    zT_2DF01B61_FieldEntry* zT_37;
    unsigned int zT_38;
    zT_2DF01B61_FieldEntry zT_39;
    zT_338B7C76_TypeRegistry* zT_41;
    zT_D155D06D_Type* zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    zT_D155D06D_Type zT_45;
    zT_33EF6BFB_TypeKind zT_46;
    zT_33EF6BFB_TypeKind zT_49;
    int zT_50;
    zT_338B7C76_TypeRegistry* zT_51;
    zT_2DF01B61_FieldEntry* zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57 = 0;
    zT_338B7C76_TypeRegistry* zT_58;
    zT_2DF01B61_FieldEntry* zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    int zT_64;
    unsigned int zT_65;
    int zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned int zT_70 = 0;
    unsigned int zT_71;
    unsigned int zT_72;
    int zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    zT_338B7C76_TypeRegistry* zT_76;
    zT_D155D06D_Type* zT_77;
    zT_33EF6BFB_TypeKind zT_78;
    zT_33EF6BFB_TypeKind zT_81;
    int zT_82;
    zT_338B7C76_TypeRegistry* zT_84;
    zT_457ECFEE_EnumPayload* zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    zT_457ECFEE_EnumPayload zT_88;
    zT_338B7C76_TypeRegistry* zT_90;
    zT_D155D06D_Type* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    zT_D155D06D_Type zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    zT_338B7C76_TypeRegistry* zT_97;
    zT_D155D06D_Type* zT_98;
    zT_33EF6BFB_TypeKind zT_99;
    zT_33EF6BFB_TypeKind zT_102;
    int zT_103;
    zT_338B7C76_TypeRegistry* zT_105;
    zT_AF9231A2_UnionPayload* zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    zT_AF9231A2_UnionPayload zT_109;
    unsigned int zT_111;
    unsigned int zT_112;
    unsigned short zT_114;
    unsigned int zT_115;
    int zT_117;
    unsigned int zT_118;
    int zT_120;
    unsigned int zT_121;
    int zT_123;
    unsigned int zT_124;
    int zT_125;
    zT_338B7C76_TypeRegistry* zT_127;
    zT_2DF01B61_FieldEntry* zT_128;
    unsigned int zT_129;
    zT_2DF01B61_FieldEntry zT_130;
    zT_338B7C76_TypeRegistry* zT_132;
    zT_D155D06D_Type* zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    zT_D155D06D_Type zT_136;
    zT_33EF6BFB_TypeKind zT_137;
    zT_33EF6BFB_TypeKind zT_140;
    int zT_141;
    unsigned int zT_142;
    int zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    int zT_146;
    unsigned int zT_147;
    int zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    unsigned int zT_152 = 0;
    unsigned int zT_153;
    unsigned int zT_154;
    int zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    zT_338B7C76_TypeRegistry* zT_158;
    zT_D155D06D_Type* zT_159;
    zT_33EF6BFB_TypeKind zT_160;
    zT_33EF6BFB_TypeKind zT_163;
    int zT_164;
    zT_338B7C76_TypeRegistry* zT_166;
    zT_54FF90FA_TaggedUnionPayload* zT_167;
    unsigned int zT_168;
    unsigned int zT_169;
    zT_54FF90FA_TaggedUnionPayload zT_170;
    zT_338B7C76_TypeRegistry* zT_172;
    zT_D155D06D_Type* zT_173;
    unsigned int zT_174;
    unsigned int zT_175;
    zT_D155D06D_Type zT_176;
    unsigned int zT_178;
    unsigned int zT_179;
    unsigned short zT_181;
    unsigned int zT_182;
    int zT_184;
    unsigned int zT_185;
    int zT_187;
    unsigned int zT_188;
    int zT_190;
    unsigned int zT_191;
    int zT_192;
    zT_338B7C76_TypeRegistry* zT_194;
    zT_2DF01B61_FieldEntry* zT_195;
    unsigned int zT_196;
    zT_2DF01B61_FieldEntry zT_197;
    char* zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    unsigned int zT_201;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    unsigned int zT_205;
    char* zT_207;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_208;
    unsigned int zT_209;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_210;
    unsigned int zT_211;
    unsigned int zT_212;
    zT_338B7C76_TypeRegistry* zT_214;
    zT_D155D06D_Type* zT_215;
    unsigned int zT_216;
    unsigned int zT_217;
    zT_D155D06D_Type zT_218;
    zT_33EF6BFB_TypeKind zT_219;
    zT_33EF6BFB_TypeKind zT_222;
    int zT_223;
    unsigned int zT_224;
    int zT_225;
    unsigned int zT_226;
    unsigned int zT_227;
    int zT_228;
    unsigned int zT_229;
    int zT_230;
    unsigned int zT_231;
    unsigned int zT_233;
    int zT_234;
    unsigned int zT_235;
    unsigned int zT_236;
    unsigned int zT_238;
    unsigned int zT_239;
    unsigned int zT_240;
    unsigned int zT_241 = 0;
    unsigned int zT_242;
    unsigned int zT_243;
    unsigned int zT_244 = 0;
    unsigned int zT_245;
    unsigned int zT_246;
    unsigned int zT_247;
    unsigned int zT_248 = 0;
    zT_338B7C76_TypeRegistry* zT_249;
    zT_D155D06D_Type* zT_250;
    zT_33EF6BFB_TypeKind zT_251;
    zT_33EF6BFB_TypeKind zT_254;
    int zT_255;
    zT_338B7C76_TypeRegistry* zT_257;
    zT_0B10E8E9_OptionalPayload* zT_258;
    unsigned int zT_259;
    unsigned int zT_260;
    zT_0B10E8E9_OptionalPayload zT_261;
    zT_338B7C76_TypeRegistry* zT_263;
    zT_D155D06D_Type* zT_264;
    unsigned int zT_265;
    unsigned int zT_266;
    zT_D155D06D_Type zT_267;
    unsigned int zT_269;
    unsigned int zT_270;
    int zT_271;
    unsigned int zT_272;
    unsigned int zT_273;
    unsigned int zT_274;
    unsigned int zT_275;
    unsigned int zT_276;
    unsigned int zT_277;
    unsigned int zT_278;
    unsigned int zT_279;
    unsigned int zT_280;
    unsigned int zT_281 = 0;
    unsigned int zT_282;
    unsigned int zT_283;
    unsigned int zT_284 = 0;
    zT_338B7C76_TypeRegistry* zT_285;
    zT_D155D06D_Type* zT_286;
    zT_33EF6BFB_TypeKind zT_287;
    zT_33EF6BFB_TypeKind zT_290;
    int zT_291;
    zT_338B7C76_TypeRegistry* zT_293;
    zT_42C2D6BF_EUPayload* zT_294;
    unsigned int zT_295;
    unsigned int zT_296;
    zT_42C2D6BF_EUPayload zT_297;
    zT_338B7C76_TypeRegistry* zT_299;
    zT_D155D06D_Type* zT_300;
    unsigned int zT_301;
    unsigned int zT_302;
    zT_D155D06D_Type zT_303;
    unsigned int zT_305;
    unsigned int zT_306;
    int zT_307;
    unsigned int zT_308;
    unsigned int zT_309;
    unsigned int zT_310;
    unsigned int zT_312;
    unsigned int zT_313;
    int zT_314;
    unsigned int zT_315;
    unsigned int zT_316;
    unsigned int zT_317;
    unsigned int zT_319;
    unsigned int zT_320;
    unsigned int zT_321 = 0;
    unsigned int zT_322;
    unsigned int zT_323;
    unsigned int zT_324;
    unsigned int zT_325 = 0;
    unsigned int zT_326;
    unsigned int zT_327;
    unsigned int zT_328;
    unsigned int zT_329;
    unsigned int zT_330 = 0;
    zT_338B7C76_TypeRegistry* zT_331;
    zT_D155D06D_Type* zT_332;
    zT_33EF6BFB_TypeKind zT_333;
    zT_33EF6BFB_TypeKind zT_336;
    int zT_337;
    zT_338B7C76_TypeRegistry* zT_339;
    zT_E834303C_ArrayPayload* zT_340;
    unsigned int zT_341;
    unsigned int zT_342;
    zT_E834303C_ArrayPayload zT_343;
    zT_338B7C76_TypeRegistry* zT_345;
    zT_D155D06D_Type* zT_346;
    unsigned int zT_347;
    unsigned int zT_348;
    zT_D155D06D_Type zT_349;
    unsigned int zT_350;
    unsigned int zT_351;
    unsigned int zT_352;
    unsigned int zT_353;
    zT_338B7C76_TypeRegistry* zT_354;
    zT_D155D06D_Type* zT_355;
    zT_33EF6BFB_TypeKind zT_356;
    zT_33EF6BFB_TypeKind zT_359;
    int zT_360;
    zT_338B7C76_TypeRegistry* zT_362;
    zT_666DC2E1_TuplePayload* zT_363;
    unsigned int zT_364;
    unsigned int zT_365;
    zT_666DC2E1_TuplePayload zT_366;
    unsigned int zT_368;
    unsigned int zT_369;
    unsigned short zT_371;
    unsigned int zT_372;
    int zT_374;
    unsigned int zT_375;
    int zT_377;
    unsigned int zT_378;
    int zT_380;
    unsigned int zT_381;
    int zT_382;
    zT_338B7C76_TypeRegistry* zT_384;
    unsigned int* zT_385;
    unsigned int zT_386;
    unsigned int zT_387;
    zT_338B7C76_TypeRegistry* zT_389;
    zT_D155D06D_Type* zT_390;
    unsigned int zT_391;
    zT_D155D06D_Type zT_392;
    unsigned int zT_393;
    unsigned int zT_394;
    unsigned int zT_395;
    unsigned int zT_396 = 0;
    unsigned int zT_397;
    unsigned int zT_398;
    unsigned int zT_399;
    int zT_400;
    unsigned int zT_401;
    int zT_402;
    unsigned int zT_403;
    unsigned int zT_404;
    unsigned int zT_405;
    unsigned int zT_406 = 0;
    unsigned int zT_407;
    unsigned int zT_408;
    int zT_409;
    unsigned int zT_410;
    unsigned int zT_411;
    zT_338B7C76_TypeRegistry* zT_412;
    zT_D155D06D_Type* zT_413;
    unsigned int idx;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload sp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int offset;
    unsigned int max_align;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    zT_D155D06D_Type ft;
    zT_457ECFEE_EnumPayload ep;
    zT_D155D06D_Type bt;
    zT_AF9231A2_UnionPayload up;
    unsigned int max_sz;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_D155D06D_Type tag_ty;
    unsigned int max_ps;
    unsigned int max_pa;
    zT_8F083A69_Slice_zT_0B42B2F8_u fer_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u fer_tm;
    unsigned int overall_align;
    unsigned int total;
    zT_0B10E8E9_OptionalPayload op;
    zT_D155D06D_Type pt;
    unsigned int pay_align;
    zT_42C2D6BF_EUPayload ep_1;
    unsigned int union_sz;
    unsigned int union_align;
    zT_E834303C_ArrayPayload ap;
    zT_D155D06D_Type et;
    zT_666DC2E1_TuplePayload tp_2;
    unsigned int estr;
    unsigned int ecount;
    unsigned int ei;
    unsigned int elem_tid;
    zT_3 = (unsigned int)tid;
    idx = zT_3;
    idx = zT_3;
    idx = zT_3;
    zT_5 = self->registry;
    zT_6 = zT_5->types_items;
    zT_7 = zT_6[idx];
    ty = zT_7;
    ty = zT_7;
    ty = zT_7;
    zT_8 = ty.kind;
    zT_11 = zT_33EF6BFB_TypeKind_struct_type;
    zT_12 = zT_8 == zT_11;
    if (zT_12) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_14 = self->registry;
    zT_15 = zT_14->st_items;
    zT_16 = ty.payload_idx;
    zT_17 = (unsigned int)zT_16;
    zT_18 = zT_15[zT_17];
    sp = zT_18;
    sp = zT_18;
    sp = zT_18;
    zT_20 = sp.fields_start;
    zT_21 = (unsigned int)zT_20;
    fstart = zT_21;
    fstart = zT_21;
    fstart = zT_21;
    zT_23 = sp.fields_count;
    zT_24 = (unsigned int)zT_23;
    fcount = zT_24;
    fcount = zT_24;
    fcount = zT_24;
    zT_26 = 0;
    zT_27 = (unsigned int)zT_26;
    offset = zT_27;
    offset = zT_27;
    offset = zT_27;
    zT_29 = 1;
    zT_30 = (unsigned int)zT_29;
    max_align = zT_30;
    max_align = zT_30;
    max_align = zT_30;
    zT_32 = 0;
    zT_33 = (unsigned int)zT_32;
    fi = zT_33;
    fi = zT_33;
    fi = zT_33;
    goto z_bb_4;
    z_bb_2:
    return;
    z_bb_3:
    zT_78 = ty.kind;
    zT_81 = zT_33EF6BFB_TypeKind_enum_type;
    zT_82 = zT_78 == zT_81;
    if (zT_82) goto z_bb_15; else goto z_bb_17;
    z_bb_4:
    zT_34 = fi < fcount;
    if (zT_34) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_36 = self->registry;
    zT_37 = zT_36->fe_items;
    zT_38 = fstart + fi;
    zT_39 = zT_37[zT_38];
    fe = zT_39;
    fe = zT_39;
    fe = zT_39;
    zT_41 = self->registry;
    zT_42 = zT_41->types_items;
    zT_43 = fe.type_id;
    zT_44 = (unsigned int)zT_43;
    zT_45 = zT_42[zT_44];
    ft = zT_45;
    ft = zT_45;
    ft = zT_45;
    zT_46 = ft.kind;
    zT_49 = zT_33EF6BFB_TypeKind_void_type;
    zT_50 = zT_46 == zT_49;
    if (zT_50) goto z_bb_8; else goto z_bb_10;
    z_bb_6:
    zT_68 = offset;
    zT_69 = max_align;
    zT_70 = zF_D2BAC673_alignUp_1(zT_68, zT_69);
    ty.size = zT_70;
    ty.alignment = max_align;
    zT_71 = ty.size;
    zT_72 = 0;
    zT_73 = zT_71 == zT_72;
    if (zT_73) goto z_bb_13; else goto z_bb_14;
    z_bb_7:
    zT_66 = 1;
    zT_67 = fi + zT_66;
    fi = zT_67;
    fi = zT_67;
    goto z_bb_4;
    z_bb_8:
    fe.offset = offset;
    zT_51 = self->registry;
    zT_52 = zT_51->fe_items;
    zT_53 = fstart + fi;
    zT_52[zT_53] = fe;
    goto z_bb_9;
    z_bb_9:
    goto z_bb_7;
    z_bb_10:
    zT_54 = offset;
    zT_56 = ft.alignment;
    zT_55 = zT_56;
    zT_57 = zF_D2BAC673_alignUp_1(zT_54, zT_55);
    offset = zT_57;
    offset = zT_57;
    fe.offset = offset;
    zT_58 = self->registry;
    zT_59 = zT_58->fe_items;
    zT_60 = fstart + fi;
    zT_59[zT_60] = fe;
    zT_61 = ft.size;
    zT_62 = offset + zT_61;
    offset = zT_62;
    offset = zT_62;
    zT_63 = ft.alignment;
    zT_64 = zT_63 > max_align;
    if (zT_64) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_65 = ft.alignment;
    max_align = zT_65;
    max_align = zT_65;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_74 = 1;
    ty.size = zT_74;
    zT_75 = 1;
    ty.alignment = zT_75;
    goto z_bb_14;
    z_bb_14:
    zT_76 = self->registry;
    zT_77 = zT_76->types_items;
    zT_77[idx] = ty;
    goto z_bb_2;
    z_bb_15:
    zT_84 = self->registry;
    zT_85 = zT_84->en_items;
    zT_86 = ty.payload_idx;
    zT_87 = (unsigned int)zT_86;
    zT_88 = zT_85[zT_87];
    ep = zT_88;
    ep = zT_88;
    ep = zT_88;
    zT_90 = self->registry;
    zT_91 = zT_90->types_items;
    zT_92 = ep.backing_type;
    zT_93 = (unsigned int)zT_92;
    zT_94 = zT_91[zT_93];
    bt = zT_94;
    bt = zT_94;
    bt = zT_94;
    zT_95 = bt.size;
    ty.size = zT_95;
    zT_96 = bt.alignment;
    ty.alignment = zT_96;
    zT_97 = self->registry;
    zT_98 = zT_97->types_items;
    zT_98[idx] = ty;
    goto z_bb_16;
    z_bb_16:
    goto z_bb_2;
    z_bb_17:
    zT_99 = ty.kind;
    zT_102 = zT_33EF6BFB_TypeKind_union_type;
    zT_103 = zT_99 == zT_102;
    if (zT_103) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_105 = self->registry;
    zT_106 = zT_105->un_items;
    zT_107 = ty.payload_idx;
    zT_108 = (unsigned int)zT_107;
    zT_109 = zT_106[zT_108];
    up = zT_109;
    up = zT_109;
    up = zT_109;
    zT_111 = up.fields_start;
    zT_112 = (unsigned int)zT_111;
    fstart = zT_112;
    fstart = zT_112;
    fstart = zT_112;
    zT_114 = up.fields_count;
    zT_115 = (unsigned int)zT_114;
    fcount = zT_115;
    fcount = zT_115;
    fcount = zT_115;
    zT_117 = 0;
    zT_118 = (unsigned int)zT_117;
    max_sz = zT_118;
    max_sz = zT_118;
    max_sz = zT_118;
    zT_120 = 1;
    zT_121 = (unsigned int)zT_120;
    max_align = zT_121;
    max_align = zT_121;
    max_align = zT_121;
    zT_123 = 0;
    zT_124 = (unsigned int)zT_123;
    fi = zT_124;
    fi = zT_124;
    fi = zT_124;
    goto z_bb_21;
    z_bb_19:
    goto z_bb_16;
    z_bb_20:
    zT_160 = ty.kind;
    zT_163 = zT_33EF6BFB_TypeKind_tagged_union_type;
    zT_164 = zT_160 == zT_163;
    if (zT_164) goto z_bb_33; else goto z_bb_35;
    z_bb_21:
    zT_125 = fi < fcount;
    if (zT_125) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_127 = self->registry;
    zT_128 = zT_127->fe_items;
    zT_129 = fstart + fi;
    zT_130 = zT_128[zT_129];
    fe = zT_130;
    fe = zT_130;
    fe = zT_130;
    zT_132 = self->registry;
    zT_133 = zT_132->types_items;
    zT_134 = fe.type_id;
    zT_135 = (unsigned int)zT_134;
    zT_136 = zT_133[zT_135];
    ft = zT_136;
    ft = zT_136;
    ft = zT_136;
    zT_137 = ft.kind;
    zT_140 = zT_33EF6BFB_TypeKind_void_type;
    zT_141 = zT_137 != zT_140;
    if (zT_141) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    zT_150 = max_sz;
    zT_151 = max_align;
    zT_152 = zF_D2BAC673_alignUp_1(zT_150, zT_151);
    ty.size = zT_152;
    ty.alignment = max_align;
    zT_153 = ty.size;
    zT_154 = 0;
    zT_155 = zT_153 == zT_154;
    if (zT_155) goto z_bb_31; else goto z_bb_32;
    z_bb_24:
    zT_148 = 1;
    zT_149 = fi + zT_148;
    fi = zT_149;
    fi = zT_149;
    goto z_bb_21;
    z_bb_25:
    zT_142 = ft.size;
    zT_143 = zT_142 > max_sz;
    if (zT_143) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    zT_144 = ft.size;
    max_sz = zT_144;
    max_sz = zT_144;
    goto z_bb_28;
    z_bb_28:
    zT_145 = ft.alignment;
    zT_146 = zT_145 > max_align;
    if (zT_146) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_147 = ft.alignment;
    max_align = zT_147;
    max_align = zT_147;
    goto z_bb_30;
    z_bb_30:
    goto z_bb_26;
    z_bb_31:
    zT_156 = 1;
    ty.size = zT_156;
    zT_157 = 1;
    ty.alignment = zT_157;
    goto z_bb_32;
    z_bb_32:
    zT_158 = self->registry;
    zT_159 = zT_158->types_items;
    zT_159[idx] = ty;
    goto z_bb_19;
    z_bb_33:
    zT_166 = self->registry;
    zT_167 = zT_166->tu_items;
    zT_168 = ty.payload_idx;
    zT_169 = (unsigned int)zT_168;
    zT_170 = zT_167[zT_169];
    tp = zT_170;
    tp = zT_170;
    tp = zT_170;
    zT_172 = self->registry;
    zT_173 = zT_172->types_items;
    zT_174 = tp.tag_type;
    zT_175 = (unsigned int)zT_174;
    zT_176 = zT_173[zT_175];
    tag_ty = zT_176;
    tag_ty = zT_176;
    tag_ty = zT_176;
    zT_178 = tp.fields_start;
    zT_179 = (unsigned int)zT_178;
    fstart = zT_179;
    fstart = zT_179;
    fstart = zT_179;
    zT_181 = tp.fields_count;
    zT_182 = (unsigned int)zT_181;
    fcount = zT_182;
    fcount = zT_182;
    fcount = zT_182;
    zT_184 = 0;
    zT_185 = (unsigned int)zT_184;
    max_ps = zT_185;
    max_ps = zT_185;
    max_ps = zT_185;
    zT_187 = 1;
    zT_188 = (unsigned int)zT_187;
    max_pa = zT_188;
    max_pa = zT_188;
    max_pa = zT_188;
    zT_190 = 0;
    zT_191 = (unsigned int)zT_190;
    fi = zT_191;
    fi = zT_191;
    fi = zT_191;
    goto z_bb_36;
    z_bb_34:
    goto z_bb_19;
    z_bb_35:
    zT_251 = ty.kind;
    zT_254 = zT_33EF6BFB_TypeKind_optional_type;
    zT_255 = zT_251 == zT_254;
    if (zT_255) goto z_bb_49; else goto z_bb_51;
    z_bb_36:
    zT_192 = fi < fcount;
    if (zT_192) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_194 = self->registry;
    zT_195 = zT_194->fe_items;
    zT_196 = fstart + fi;
    zT_197 = zT_195[zT_196];
    fe = zT_197;
    fe = zT_197;
    fe = zT_197;
    zT_199 = "FER:n";
    zT_201 = 5;
    zT_200.ptr = zT_199;
    zT_200.len = zT_201;
    fer_nm = zT_200;
    fer_nm = zT_200;
    fer_nm = zT_200;
    zT_202 = fer_nm;
    zT_204 = fstart + fi;
    zT_205 = (unsigned int)zT_204;
    zT_203 = zT_205;
    zF_C914CB83_markerWriteInt(zT_202, zT_203);
    zT_207 = "FER:t";
    zT_209 = 5;
    zT_208.ptr = zT_207;
    zT_208.len = zT_209;
    fer_tm = zT_208;
    fer_tm = zT_208;
    fer_tm = zT_208;
    zT_210 = fer_tm;
    zT_212 = fe.type_id;
    zT_211 = zT_212;
    zF_C914CB83_markerWriteInt(zT_210, zT_211);
    zT_214 = self->registry;
    zT_215 = zT_214->types_items;
    zT_216 = fe.type_id;
    zT_217 = (unsigned int)zT_216;
    zT_218 = zT_215[zT_217];
    ft = zT_218;
    ft = zT_218;
    ft = zT_218;
    zT_219 = ft.kind;
    zT_222 = zT_33EF6BFB_TypeKind_void_type;
    zT_223 = zT_219 != zT_222;
    if (zT_223) goto z_bb_40; else goto z_bb_41;
    z_bb_38:
    zT_233 = tag_ty.alignment;
    zT_234 = zT_233 > max_pa;
    if (zT_234) goto z_bb_46; else goto z_bb_47;
    z_bb_39:
    zT_230 = 1;
    zT_231 = fi + zT_230;
    fi = zT_231;
    fi = zT_231;
    goto z_bb_36;
    z_bb_40:
    zT_224 = ft.size;
    zT_225 = zT_224 > max_ps;
    if (zT_225) goto z_bb_42; else goto z_bb_43;
    z_bb_41:
    goto z_bb_39;
    z_bb_42:
    zT_226 = ft.size;
    max_ps = zT_226;
    max_ps = zT_226;
    goto z_bb_43;
    z_bb_43:
    zT_227 = ft.alignment;
    zT_228 = zT_227 > max_pa;
    if (zT_228) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_229 = ft.alignment;
    max_pa = zT_229;
    max_pa = zT_229;
    goto z_bb_45;
    z_bb_45:
    goto z_bb_41;
    z_bb_46:
    zT_236 = tag_ty.alignment;
    zT_235 = zT_236;
    goto z_bb_48;
    z_bb_47:
    zT_235 = max_pa;
    goto z_bb_48;
    z_bb_48:
    overall_align = zT_235;
    overall_align = zT_235;
    overall_align = zT_235;
    zT_238 = tag_ty.size;
    total = zT_238;
    total = zT_238;
    total = zT_238;
    zT_239 = total;
    zT_240 = max_pa;
    zT_241 = zF_D2BAC673_alignUp_1(zT_239, zT_240);
    total = zT_241;
    total = zT_241;
    zT_242 = max_ps;
    zT_243 = max_pa;
    zT_244 = zF_D2BAC673_alignUp_1(zT_242, zT_243);
    zT_245 = total + zT_244;
    total = zT_245;
    total = zT_245;
    zT_246 = total;
    zT_247 = overall_align;
    zT_248 = zF_D2BAC673_alignUp_1(zT_246, zT_247);
    ty.size = zT_248;
    ty.alignment = overall_align;
    zT_249 = self->registry;
    zT_250 = zT_249->types_items;
    zT_250[idx] = ty;
    goto z_bb_34;
    z_bb_49:
    zT_257 = self->registry;
    zT_258 = zT_257->opt_items;
    zT_259 = ty.payload_idx;
    zT_260 = (unsigned int)zT_259;
    zT_261 = zT_258[zT_260];
    op = zT_261;
    op = zT_261;
    op = zT_261;
    zT_263 = self->registry;
    zT_264 = zT_263->types_items;
    zT_265 = op.payload;
    zT_266 = (unsigned int)zT_265;
    zT_267 = zT_264[zT_266];
    pt = zT_267;
    pt = zT_267;
    pt = zT_267;
    zT_269 = pt.alignment;
    zT_270 = 4;
    zT_271 = zT_269 > zT_270;
    if (zT_271) goto z_bb_52; else goto z_bb_53;
    z_bb_50:
    goto z_bb_34;
    z_bb_51:
    zT_287 = ty.kind;
    zT_290 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_291 = zT_287 == zT_290;
    if (zT_291) goto z_bb_55; else goto z_bb_57;
    z_bb_52:
    zT_273 = pt.alignment;
    zT_272 = zT_273;
    goto z_bb_54;
    z_bb_53:
    zT_274 = 4;
    zT_272 = zT_274;
    goto z_bb_54;
    z_bb_54:
    pay_align = zT_272;
    pay_align = zT_272;
    pay_align = zT_272;
    zT_279 = pt.size;
    zT_277 = zT_279;
    zT_280 = 4;
    zT_278 = zT_280;
    zT_281 = zF_D2BAC673_alignUp_1(zT_277, zT_278);
    zT_282 = 4;
    zT_283 = zT_281 + zT_282;
    zT_275 = zT_283;
    zT_276 = pay_align;
    zT_284 = zF_D2BAC673_alignUp_1(zT_275, zT_276);
    ty.size = zT_284;
    ty.alignment = pay_align;
    zT_285 = self->registry;
    zT_286 = zT_285->types_items;
    zT_286[idx] = ty;
    goto z_bb_50;
    z_bb_55:
    zT_293 = self->registry;
    zT_294 = zT_293->eu_items;
    zT_295 = ty.payload_idx;
    zT_296 = (unsigned int)zT_295;
    zT_297 = zT_294[zT_296];
    ep_1 = zT_297;
    ep_1 = zT_297;
    ep_1 = zT_297;
    zT_299 = self->registry;
    zT_300 = zT_299->types_items;
    zT_301 = ep_1.payload;
    zT_302 = (unsigned int)zT_301;
    zT_303 = zT_300[zT_302];
    pt = zT_303;
    pt = zT_303;
    pt = zT_303;
    zT_305 = pt.size;
    zT_306 = 4;
    zT_307 = zT_305 > zT_306;
    if (zT_307) goto z_bb_58; else goto z_bb_59;
    z_bb_56:
    goto z_bb_50;
    z_bb_57:
    zT_333 = ty.kind;
    zT_336 = zT_33EF6BFB_TypeKind_array_type;
    zT_337 = zT_333 == zT_336;
    if (zT_337) goto z_bb_64; else goto z_bb_66;
    z_bb_58:
    zT_309 = pt.size;
    zT_308 = zT_309;
    goto z_bb_60;
    z_bb_59:
    zT_310 = 4;
    zT_308 = zT_310;
    goto z_bb_60;
    z_bb_60:
    union_sz = zT_308;
    union_sz = zT_308;
    union_sz = zT_308;
    zT_312 = pt.alignment;
    zT_313 = 4;
    zT_314 = zT_312 > zT_313;
    if (zT_314) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_316 = pt.alignment;
    zT_315 = zT_316;
    goto z_bb_63;
    z_bb_62:
    zT_317 = 4;
    zT_315 = zT_317;
    goto z_bb_63;
    z_bb_63:
    union_align = zT_315;
    union_align = zT_315;
    union_align = zT_315;
    zT_319 = union_sz;
    zT_320 = union_align;
    zT_321 = zF_D2BAC673_alignUp_1(zT_319, zT_320);
    total = zT_321;
    total = zT_321;
    total = zT_321;
    zT_322 = total;
    zT_324 = 4;
    zT_323 = zT_324;
    zT_325 = zF_D2BAC673_alignUp_1(zT_322, zT_323);
    zT_326 = 4;
    zT_327 = zT_325 + zT_326;
    total = zT_327;
    total = zT_327;
    zT_328 = total;
    zT_329 = union_align;
    zT_330 = zF_D2BAC673_alignUp_1(zT_328, zT_329);
    ty.size = zT_330;
    ty.alignment = union_align;
    zT_331 = self->registry;
    zT_332 = zT_331->types_items;
    zT_332[idx] = ty;
    goto z_bb_56;
    z_bb_64:
    zT_339 = self->registry;
    zT_340 = zT_339->array_items;
    zT_341 = ty.payload_idx;
    zT_342 = (unsigned int)zT_341;
    zT_343 = zT_340[zT_342];
    ap = zT_343;
    ap = zT_343;
    ap = zT_343;
    zT_345 = self->registry;
    zT_346 = zT_345->types_items;
    zT_347 = ap.elem;
    zT_348 = (unsigned int)zT_347;
    zT_349 = zT_346[zT_348];
    et = zT_349;
    et = zT_349;
    et = zT_349;
    zT_350 = et.size;
    zT_351 = ap.length;
    zT_352 = zT_350 * zT_351;
    ty.size = zT_352;
    zT_353 = et.alignment;
    ty.alignment = zT_353;
    zT_354 = self->registry;
    zT_355 = zT_354->types_items;
    zT_355[idx] = ty;
    goto z_bb_65;
    z_bb_65:
    goto z_bb_56;
    z_bb_66:
    zT_356 = ty.kind;
    zT_359 = zT_33EF6BFB_TypeKind_tuple_type;
    zT_360 = zT_356 == zT_359;
    if (zT_360) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    zT_362 = self->registry;
    zT_363 = zT_362->tup_items;
    zT_364 = ty.payload_idx;
    zT_365 = (unsigned int)zT_364;
    zT_366 = zT_363[zT_365];
    tp_2 = zT_366;
    tp_2 = zT_366;
    tp_2 = zT_366;
    zT_368 = tp_2.elems_start;
    zT_369 = (unsigned int)zT_368;
    estr = zT_369;
    estr = zT_369;
    estr = zT_369;
    zT_371 = tp_2.elems_count;
    zT_372 = (unsigned int)zT_371;
    ecount = zT_372;
    ecount = zT_372;
    ecount = zT_372;
    zT_374 = 0;
    zT_375 = (unsigned int)zT_374;
    offset = zT_375;
    offset = zT_375;
    offset = zT_375;
    zT_377 = 1;
    zT_378 = (unsigned int)zT_377;
    max_align = zT_378;
    max_align = zT_378;
    max_align = zT_378;
    zT_380 = 0;
    zT_381 = (unsigned int)zT_380;
    ei = zT_381;
    ei = zT_381;
    ei = zT_381;
    goto z_bb_69;
    z_bb_68:
    goto z_bb_65;
    z_bb_69:
    zT_382 = ei < ecount;
    if (zT_382) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_384 = self->registry;
    zT_385 = zT_384->xt_items;
    zT_386 = estr + ei;
    zT_387 = zT_385[zT_386];
    elem_tid = zT_387;
    elem_tid = zT_387;
    elem_tid = zT_387;
    zT_389 = self->registry;
    zT_390 = zT_389->types_items;
    zT_391 = (unsigned int)elem_tid;
    zT_392 = zT_390[zT_391];
    et = zT_392;
    et = zT_392;
    et = zT_392;
    zT_393 = offset;
    zT_395 = et.alignment;
    zT_394 = zT_395;
    zT_396 = zF_D2BAC673_alignUp_1(zT_393, zT_394);
    offset = zT_396;
    offset = zT_396;
    zT_397 = et.size;
    zT_398 = offset + zT_397;
    offset = zT_398;
    offset = zT_398;
    zT_399 = et.alignment;
    zT_400 = zT_399 > max_align;
    if (zT_400) goto z_bb_73; else goto z_bb_74;
    z_bb_71:
    zT_404 = offset;
    zT_405 = max_align;
    zT_406 = zF_D2BAC673_alignUp_1(zT_404, zT_405);
    ty.size = zT_406;
    ty.alignment = max_align;
    zT_407 = ty.size;
    zT_408 = 0;
    zT_409 = zT_407 == zT_408;
    if (zT_409) goto z_bb_75; else goto z_bb_76;
    z_bb_72:
    zT_402 = 1;
    zT_403 = ei + zT_402;
    ei = zT_403;
    ei = zT_403;
    goto z_bb_69;
    z_bb_73:
    zT_401 = et.alignment;
    max_align = zT_401;
    max_align = zT_401;
    goto z_bb_74;
    z_bb_74:
    goto z_bb_72;
    z_bb_75:
    zT_410 = 1;
    ty.size = zT_410;
    zT_411 = 1;
    ty.alignment = zT_411;
    goto z_bb_76;
    z_bb_76:
    zT_412 = self->registry;
    zT_413 = zT_412->types_items;
    zT_413[idx] = ty;
    goto z_bb_68;
}

/* typeResolverInit */
zT_C890C8CB_TypeResolver zF_5BFAC855_typeResolverInit(zT_338B7C76_TypeRegistry* registry, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* alloc) {
    zT_C890C8CB_TypeResolver zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7;
    unsigned int zT_8;
    int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_3.registry = registry;
    zT_4 = 0;
    zT_3.depend_items = (zT_52CDA6EF_DepEdge*)zT_4;
    zT_5 = 0;
    zT_3.depend_len = zT_5;
    zT_6 = 0;
    zT_3.depend_cap = zT_6;
    zT_7 = 0;
    zT_3.in_degree_items = (unsigned int*)zT_7;
    zT_8 = 0;
    zT_3.in_degree_cap = zT_8;
    zT_9 = 0;
    zT_3.sorted_items = (unsigned int*)zT_9;
    zT_10 = 0;
    zT_3.sorted_len = zT_10;
    zT_11 = 0;
    zT_3.worklist_items = (unsigned int*)zT_11;
    zT_12 = 0;
    zT_3.worklist_len = zT_12;
    zT_13 = 0;
    zT_3.worklist_cap = zT_13;
    zT_3.diag = diag;
    zT_3.alloc = alloc;
    return zT_3;
}

/* typeResolverBuild */
void zF_33272F41_typeResolverBuild(zT_C890C8CB_TypeResolver* self, zT_4D61441E_DepGraph* g) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    int zT_6;
    zT_C890C8CB_TypeResolver* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_52CDA6EF_DepEdge* zT_10;
    zT_52CDA6EF_DepEdge zT_11;
    unsigned int zT_12;
    zT_52CDA6EF_DepEdge* zT_13;
    zT_52CDA6EF_DepEdge zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_338B7C76_TypeRegistry* zT_20;
    unsigned int zT_21;
    zT_C890C8CB_TypeResolver* zT_22;
    unsigned int zT_23;
    zT_3E40CD83_Sand* zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    zT_3E40CD83_Sand* zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    zT_A62CFBCC_EU_022 zT_32 = {0};
    unsigned char zT_33;
    unsigned char* zT_34;
    unsigned char* zT_35;
    unsigned int* zT_36;
    int zT_38;
    unsigned int zT_39;
    int zT_40;
    unsigned int zT_41;
    unsigned int* zT_42;
    int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    int zT_50;
    zT_52CDA6EF_DepEdge* zT_52;
    zT_52CDA6EF_DepEdge zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    int zT_56;
    unsigned int* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int* zT_63;
    unsigned int zT_64;
    int zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned int i;
    unsigned int type_count;
    unsigned char* raw_sorted;
    unsigned int zi;
    unsigned int ei;
    unsigned int target;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    i = zT_4;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = g->len;
    zT_6 = i < zT_5;
    if (zT_6) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self;
    zT_10 = g->items;
    zT_11 = zT_10[i];
    zT_12 = zT_11.from;
    zT_8 = zT_12;
    zT_13 = g->items;
    zT_14 = zT_13[i];
    zT_15 = zT_14.to;
    zT_9 = zT_15;
    zF_F1D68957_typeResolverAddEdge(zT_7, zT_8, zT_9);
    zT_16 = 1;
    zT_17 = (unsigned int)zT_16;
    zT_18 = i + zT_17;
    i = zT_18;
    i = zT_18;
    goto z_bb_4;
    z_bb_3:
    zT_20 = self->registry;
    zT_21 = zT_20->types_len;
    type_count = zT_21;
    type_count = zT_21;
    type_count = zT_21;
    zT_22 = self;
    zT_23 = type_count;
    zF_959DB1DC_inDegreeEnsureCapac(zT_22, zT_23);
    zT_28 = self->alloc;
    zT_25 = zT_28;
    zT_29 = 4;
    zT_30 = type_count * zT_29;
    zT_26 = zT_30;
    zT_31 = 4;
    zT_27 = zT_31;
    zT_32 = zF_1395EB68_sandAlloc(zT_25, zT_26, zT_27);
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    z_bb_6:
    zT_35 = zT_32.data.payload;
    zT_34 = zT_35;
    goto z_bb_7;
    z_bb_7:
    raw_sorted = zT_34;
    raw_sorted = zT_34;
    raw_sorted = zT_34;
    zT_36 = (unsigned int*)raw_sorted;
    self->sorted_items = zT_36;
    zT_38 = 0;
    zT_39 = (unsigned int)zT_38;
    zi = zT_39;
    zi = zT_39;
    zi = zT_39;
    goto z_bb_8;
    z_bb_8:
    zT_40 = zi < type_count;
    if (zT_40) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_41 = 0;
    zT_42 = self->in_degree_items;
    zT_42[zi] = zT_41;
    zT_43 = 1;
    zT_44 = (unsigned int)zT_43;
    zT_45 = zi + zT_44;
    zi = zT_45;
    zi = zT_45;
    goto z_bb_11;
    z_bb_10:
    zT_47 = 0;
    zT_48 = (unsigned int)zT_47;
    ei = zT_48;
    ei = zT_48;
    ei = zT_48;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_49 = self->depend_len;
    zT_50 = ei < zT_49;
    if (zT_50) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_52 = self->depend_items;
    zT_53 = zT_52[ei];
    zT_54 = zT_53.to;
    target = zT_54;
    target = zT_54;
    target = zT_54;
    zT_55 = (unsigned int)target;
    zT_56 = zT_55 < type_count;
    if (zT_56) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    return;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_57 = self->in_degree_items;
    zT_58 = (unsigned int)target;
    zT_59 = zT_57[zT_58];
    zT_60 = 1;
    zT_61 = (unsigned int)zT_60;
    zT_62 = zT_59 + zT_61;
    zT_63 = self->in_degree_items;
    zT_64 = (unsigned int)target;
    zT_63[zT_64] = zT_62;
    goto z_bb_17;
    z_bb_17:
    zT_65 = 1;
    zT_66 = (unsigned int)zT_65;
    zT_67 = ei + zT_66;
    ei = zT_67;
    ei = zT_67;
    goto z_bb_15;
}

/* typeResolverResolve */
void zF_30BE7185_typeResolverResolve(zT_C890C8CB_TypeResolver* self) {
    zT_338B7C76_TypeRegistry* zT_2;
    unsigned int zT_3;
    int zT_4;
    int zT_5;
    int zT_7;
    unsigned int zT_8;
    int zT_9;
    unsigned int* zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_13;
    zT_C890C8CB_TypeResolver* zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    int zT_22;
    zT_C890C8CB_TypeResolver* zT_24;
    zT_BAEE192E_Opt_10 zT_25 = {0};
    unsigned char zT_26;
    unsigned int* zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_C890C8CB_TypeResolver* zT_33;
    unsigned int zT_34;
    unsigned char zT_35;
    zT_338B7C76_TypeRegistry* zT_36;
    zT_D155D06D_Type* zT_37;
    unsigned int zT_38;
    zT_D155D06D_Type* zT_39;
    int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    int zT_44;
    zT_52CDA6EF_DepEdge* zT_45;
    zT_52CDA6EF_DepEdge zT_46;
    unsigned int zT_47;
    int zT_48;
    zT_52CDA6EF_DepEdge* zT_50;
    zT_52CDA6EF_DepEdge zT_51;
    unsigned int zT_52;
    unsigned int zT_54;
    int zT_55;
    unsigned int* zT_56;
    unsigned int zT_57;
    int zT_58;
    int zT_59;
    unsigned int* zT_60;
    unsigned int zT_61;
    int zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int* zT_65;
    unsigned int* zT_66;
    unsigned int zT_67;
    int zT_68;
    int zT_69;
    zT_C890C8CB_TypeResolver* zT_70;
    unsigned int zT_71;
    int zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    int zT_76;
    unsigned int zT_77;
    int zT_78;
    zT_338B7C76_TypeRegistry* zT_80;
    zT_D155D06D_Type* zT_81;
    zT_D155D06D_Type zT_82;
    unsigned char zT_83;
    unsigned char zT_84;
    int zT_85;
    int zT_86;
    unsigned int* zT_87;
    unsigned int zT_88;
    int zT_89;
    int zT_90;
    char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    zT_F85C5DED_DiagnosticCollector* zT_95;
    unsigned char zT_96;
    unsigned short zT_97;
    unsigned int zT_98;
    unsigned int zT_99;
    unsigned int zT_100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    zT_F85C5DED_DiagnosticCollector* zT_102;
    unsigned char zT_103;
    zT_A210EB18_ErrorCode zT_106;
    unsigned short zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    zT_33EF6BFB_TypeKind zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    unsigned char zT_117;
    zT_338B7C76_TypeRegistry* zT_118;
    zT_D155D06D_Type* zT_119;
    int zT_120;
    unsigned int zT_121;
    unsigned int type_count;
    unsigned int ti;
    zT_BAEE192E_Opt_10 tid_val;
    unsigned int ci;
    unsigned int tid;
    unsigned int ei;
    unsigned int dep;
    unsigned int dep_idx;
    zT_D155D06D_Type ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_2 = self->registry;
    zT_3 = zT_2->types_len;
    type_count = zT_3;
    type_count = zT_3;
    type_count = zT_3;
    zT_4 = 0;
    zT_5 = type_count == (unsigned int)zT_4;
    if (zT_5) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    ti = zT_8;
    ti = zT_8;
    ti = zT_8;
    goto z_bb_3;
    z_bb_3:
    zT_9 = ti < type_count;
    if (zT_9) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_10 = self->in_degree_items;
    zT_11 = zT_10[ti];
    zT_12 = 0;
    zT_13 = zT_11 == (unsigned int)zT_12;
    if (zT_13) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    goto z_bb_9;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_14 = self;
    zT_16 = (unsigned int)ti;
    zT_15 = zT_16;
    zF_352BC6BC_worklistPush(zT_14, zT_15);
    goto z_bb_8;
    z_bb_8:
    zT_17 = 1;
    zT_18 = (unsigned int)zT_17;
    zT_19 = ti + zT_18;
    ti = zT_19;
    ti = zT_19;
    goto z_bb_6;
    z_bb_9:
    zT_20 = self->worklist_len;
    zT_21 = 0;
    zT_22 = zT_20 > (unsigned int)zT_21;
    if (zT_22) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_24 = self;
    zT_25 = zF_D7A5282F_worklistPop(zT_24);
    tid_val = zT_25;
    tid_val = zT_25;
    tid_val = zT_25;
    zT_26 = tid_val.has_value;
    if (zT_26) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_76 = 0;
    zT_77 = (unsigned int)zT_76;
    ci = zT_77;
    ci = zT_77;
    ci = zT_77;
    goto z_bb_27;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    tid = tid_val.value;
    zT_28 = self->sorted_items;
    zT_29 = self->sorted_len;
    zT_28[zT_29] = tid;
    zT_30 = self->sorted_len;
    zT_31 = 1;
    zT_32 = zT_30 + zT_31;
    self->sorted_len = zT_32;
    zT_33 = self;
    zT_34 = tid;
    zF_3957E0DF_typeResolverResolve(zT_33, zT_34);
    zT_35 = 2;
    zT_36 = self->registry;
    zT_37 = zT_36->types_items;
    zT_38 = (unsigned int)tid;
    zT_39 = zT_37 + zT_38;
    zT_39->state = zT_35;
    zT_41 = 0;
    zT_42 = (unsigned int)zT_41;
    ei = zT_42;
    ei = zT_42;
    ei = zT_42;
    goto z_bb_15;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_43 = self->depend_len;
    zT_44 = ei < zT_43;
    if (zT_44) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_45 = self->depend_items;
    zT_46 = zT_45[ei];
    zT_47 = zT_46.from;
    zT_48 = zT_47 == tid;
    if (zT_48) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_50 = self->depend_items;
    zT_51 = zT_50[ei];
    zT_52 = zT_51.to;
    dep = zT_52;
    dep = zT_52;
    dep = zT_52;
    zT_54 = (unsigned int)dep;
    dep_idx = zT_54;
    dep_idx = zT_54;
    dep_idx = zT_54;
    zT_55 = dep_idx < type_count;
    if (zT_55) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_72 = 1;
    zT_73 = (unsigned int)zT_72;
    zT_74 = ei + zT_73;
    ei = zT_74;
    ei = zT_74;
    goto z_bb_18;
    z_bb_21:
    zT_56 = self->in_degree_items;
    zT_57 = zT_56[dep_idx];
    zT_58 = 0;
    zT_59 = zT_57 > (unsigned int)zT_58;
    if (zT_59) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_60 = self->in_degree_items;
    zT_61 = zT_60[dep_idx];
    zT_62 = 1;
    zT_63 = (unsigned int)zT_62;
    zT_64 = zT_61 - zT_63;
    zT_65 = self->in_degree_items;
    zT_65[dep_idx] = zT_64;
    zT_66 = self->in_degree_items;
    zT_67 = zT_66[dep_idx];
    zT_68 = 0;
    zT_69 = zT_67 == (unsigned int)zT_68;
    if (zT_69) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_70 = self;
    zT_71 = dep;
    zF_352BC6BC_worklistPush(zT_70, zT_71);
    goto z_bb_26;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    zT_78 = ci < type_count;
    if (zT_78) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_80 = self->registry;
    zT_81 = zT_80->types_items;
    zT_82 = zT_81[ci];
    ty = zT_82;
    ty = zT_82;
    ty = zT_82;
    zT_83 = ty.state;
    zT_84 = 2;
    zT_85 = zT_83 != zT_84;
    if (zT_85) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    return;
    z_bb_30:
    zT_120 = 1;
    zT_121 = ci + zT_120;
    ci = zT_121;
    ci = zT_121;
    goto z_bb_27;
    z_bb_31:
    zT_87 = self->in_degree_items;
    zT_88 = zT_87[ci];
    zT_89 = 0;
    zT_90 = zT_88 > (unsigned int)zT_89;
    zT_86 = zT_90;
    goto z_bb_33;
    z_bb_32:
    zT_86 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_86) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_92 = "circular type dependency detected (type refers to itself)";
    zT_94 = 57;
    zT_93.ptr = zT_92;
    zT_93.len = zT_94;
    msg = zT_93;
    msg = zT_93;
    msg = zT_93;
    zT_102 = self->diag;
    zT_95 = zT_102;
    zT_103 = 0;
    zT_96 = zT_103;
    zT_106 = zT_A210EB18_ErrorCode_ERR_3005_CIRCULAR_TYPE_DEPENDENCY;
    zT_107 = (unsigned short)zT_106;
    zT_97 = zT_107;
    zT_108 = 0;
    zT_98 = zT_108;
    zT_109 = 0;
    zT_99 = zT_109;
    zT_110 = 0;
    zT_100 = zT_110;
    zT_101 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_95, zT_96, zT_97, zT_98, zT_99, zT_100, zT_101);
    zT_114 = zT_33EF6BFB_TypeKind_void_type;
    ty.kind = zT_114;
    zT_115 = 0;
    ty.size = zT_115;
    zT_116 = 1;
    ty.alignment = zT_116;
    zT_117 = 2;
    ty.state = zT_117;
    zT_118 = self->registry;
    zT_119 = zT_118->types_items;
    zT_119[ci] = ty;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_30;
}

/* fieldEmbedsByValue */
int zF_A47239A9_fieldEmbedsByValue(zT_33EF6BFB_TypeKind kind) {
    zT_33EF6BFB_TypeKind zT_3;
    int zT_4;
    int zT_5;
    zT_33EF6BFB_TypeKind zT_8;
    int zT_9;
    int zT_10;
    zT_33EF6BFB_TypeKind zT_13;
    int zT_14;
    int zT_15;
    zT_33EF6BFB_TypeKind zT_18;
    int zT_19;
    int zT_20;
    zT_33EF6BFB_TypeKind zT_23;
    int zT_24;
    int zT_25;
    zT_33EF6BFB_TypeKind zT_28;
    int zT_29;
    int zT_30;
    zT_33EF6BFB_TypeKind zT_33;
    int zT_34;
    int zT_35;
    int zT_36;
    zT_3 = zT_33EF6BFB_TypeKind_struct_type;
    zT_4 = kind == zT_3;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    return zT_5;
    z_bb_2:
    zT_8 = zT_33EF6BFB_TypeKind_tagged_union_type;
    zT_9 = kind == zT_8;
    if (zT_9) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_10 = 1;
    return zT_10;
    z_bb_4:
    zT_13 = zT_33EF6BFB_TypeKind_union_type;
    zT_14 = kind == zT_13;
    if (zT_14) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_15 = 1;
    return zT_15;
    z_bb_6:
    zT_18 = zT_33EF6BFB_TypeKind_array_type;
    zT_19 = kind == zT_18;
    if (zT_19) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_20 = 1;
    return zT_20;
    z_bb_8:
    zT_23 = zT_33EF6BFB_TypeKind_tuple_type;
    zT_24 = kind == zT_23;
    if (zT_24) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_25 = 1;
    return zT_25;
    z_bb_10:
    zT_28 = zT_33EF6BFB_TypeKind_enum_type;
    zT_29 = kind == zT_28;
    if (zT_29) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_30 = 1;
    return zT_30;
    z_bb_12:
    zT_33 = zT_33EF6BFB_TypeKind_error_set_type;
    zT_34 = kind == zT_33;
    if (zT_34) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_35 = 1;
    return zT_35;
    z_bb_14:
    zT_36 = 0;
    return zT_36;
}

/* requiresFullDef */
int zF_EA3ED3F3_requiresFullDef(zT_33EF6BFB_TypeKind kind) {
    zT_33EF6BFB_TypeKind zT_3;
    int zT_4;
    int zT_5;
    zT_33EF6BFB_TypeKind zT_8;
    int zT_9;
    int zT_10;
    zT_33EF6BFB_TypeKind zT_13;
    int zT_14;
    int zT_15;
    zT_33EF6BFB_TypeKind zT_18;
    int zT_19;
    int zT_20;
    zT_33EF6BFB_TypeKind zT_23;
    int zT_24;
    int zT_25;
    zT_33EF6BFB_TypeKind zT_28;
    int zT_29;
    int zT_30;
    zT_33EF6BFB_TypeKind zT_33;
    int zT_34;
    int zT_35;
    int zT_36;
    zT_3 = zT_33EF6BFB_TypeKind_struct_type;
    zT_4 = kind == zT_3;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    return zT_5;
    z_bb_2:
    zT_8 = zT_33EF6BFB_TypeKind_tagged_union_type;
    zT_9 = kind == zT_8;
    if (zT_9) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_10 = 1;
    return zT_10;
    z_bb_4:
    zT_13 = zT_33EF6BFB_TypeKind_union_type;
    zT_14 = kind == zT_13;
    if (zT_14) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_15 = 1;
    return zT_15;
    z_bb_6:
    zT_18 = zT_33EF6BFB_TypeKind_array_type;
    zT_19 = kind == zT_18;
    if (zT_19) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_20 = 1;
    return zT_20;
    z_bb_8:
    zT_23 = zT_33EF6BFB_TypeKind_tuple_type;
    zT_24 = kind == zT_23;
    if (zT_24) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_25 = 1;
    return zT_25;
    z_bb_10:
    zT_28 = zT_33EF6BFB_TypeKind_optional_type;
    zT_29 = kind == zT_28;
    if (zT_29) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_30 = 1;
    return zT_30;
    z_bb_12:
    zT_33 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_34 = kind == zT_33;
    if (zT_34) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_35 = 1;
    return zT_35;
    z_bb_14:
    zT_36 = 0;
    return zT_36;
}

/* layoutFieldNeedsEdge */
int zF_47951EE7_layoutFieldNeedsEdg(zT_33EF6BFB_TypeKind kind) {
    zT_33EF6BFB_TypeKind zT_3;
    int zT_4;
    int zT_5;
    zT_33EF6BFB_TypeKind zT_8;
    int zT_9;
    int zT_10;
    zT_33EF6BFB_TypeKind zT_13;
    int zT_14;
    int zT_15;
    zT_33EF6BFB_TypeKind zT_18;
    int zT_19;
    int zT_20;
    zT_33EF6BFB_TypeKind zT_23;
    int zT_24;
    int zT_25;
    zT_33EF6BFB_TypeKind zT_28;
    int zT_29;
    int zT_30;
    zT_33EF6BFB_TypeKind zT_33;
    int zT_34;
    int zT_35;
    zT_33EF6BFB_TypeKind zT_38;
    int zT_39;
    int zT_40;
    int zT_41;
    zT_3 = zT_33EF6BFB_TypeKind_struct_type;
    zT_4 = kind == zT_3;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    return zT_5;
    z_bb_2:
    zT_8 = zT_33EF6BFB_TypeKind_tagged_union_type;
    zT_9 = kind == zT_8;
    if (zT_9) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_10 = 1;
    return zT_10;
    z_bb_4:
    zT_13 = zT_33EF6BFB_TypeKind_union_type;
    zT_14 = kind == zT_13;
    if (zT_14) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_15 = 1;
    return zT_15;
    z_bb_6:
    zT_18 = zT_33EF6BFB_TypeKind_enum_type;
    zT_19 = kind == zT_18;
    if (zT_19) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_20 = 1;
    return zT_20;
    z_bb_8:
    zT_23 = zT_33EF6BFB_TypeKind_array_type;
    zT_24 = kind == zT_23;
    if (zT_24) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_25 = 1;
    return zT_25;
    z_bb_10:
    zT_28 = zT_33EF6BFB_TypeKind_tuple_type;
    zT_29 = kind == zT_28;
    if (zT_29) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_30 = 1;
    return zT_30;
    z_bb_12:
    zT_33 = zT_33EF6BFB_TypeKind_optional_type;
    zT_34 = kind == zT_33;
    if (zT_34) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_35 = 1;
    return zT_35;
    z_bb_14:
    zT_38 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_39 = kind == zT_38;
    if (zT_39) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_40 = 1;
    return zT_40;
    z_bb_16:
    zT_41 = 0;
    return zT_41;
}

/* layoutAddTypeEdge */
void zF_0E16D693_layoutAddTypeEdge(zT_C890C8CB_TypeResolver* self, unsigned int field_type, unsigned int container_tid) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    int zT_6;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_D155D06D_Type* zT_9;
    unsigned int zT_10;
    zT_D155D06D_Type zT_11;
    zT_33EF6BFB_TypeKind zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    int zT_14 = 0;
    zT_C890C8CB_TypeResolver* zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_D155D06D_Type ft;
    zT_3 = self->registry;
    zT_4 = zT_3->types_len;
    zT_5 = (unsigned int)zT_4;
    zT_6 = field_type >= zT_5;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = self->registry;
    zT_9 = zT_8->types_items;
    zT_10 = (unsigned int)field_type;
    zT_11 = zT_9[zT_10];
    ft = zT_11;
    ft = zT_11;
    ft = zT_11;
    zT_13 = ft.kind;
    zT_12 = zT_13;
    zT_14 = zF_47951EE7_layoutFieldNeedsEdg(zT_12);
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = self;
    zT_16 = field_type;
    zT_17 = container_tid;
    zF_F1D68957_typeResolverAddEdge(zT_15, zT_16, zT_17);
    goto z_bb_4;
    z_bb_4:
    return;
}

/* layoutAddFieldEdges */
void zF_0D59859C_layoutAddFieldEdges(zT_C890C8CB_TypeResolver* self, unsigned int fstart, unsigned short fcount, unsigned int container_tid) {
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_8;
    zT_C890C8CB_TypeResolver* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_338B7C76_TypeRegistry* zT_12;
    zT_2DF01B61_FieldEntry* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_2DF01B61_FieldEntry zT_16;
    unsigned int zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned int fi;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    fi = zT_6;
    fi = zT_6;
    fi = zT_6;
    goto z_bb_1;
    z_bb_1:
    zT_7 = (unsigned int)fcount;
    zT_8 = fi < zT_7;
    if (zT_8) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = self;
    zT_12 = self->registry;
    zT_13 = zT_12->fe_items;
    zT_14 = (unsigned int)fstart;
    zT_15 = zT_14 + fi;
    zT_16 = zT_13[zT_15];
    zT_17 = zT_16.type_id;
    zT_10 = zT_17;
    zT_11 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_9, zT_10, zT_11);
    goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_18 = 1;
    zT_19 = fi + zT_18;
    fi = zT_19;
    fi = zT_19;
    goto z_bb_1;
}

/* typeResolverBuildDependencyGraph */
void zF_D5C4530C_typeResolverBuildDe(zT_C890C8CB_TypeResolver* self) {
    int zT_2;
    unsigned int zT_3;
    zT_338B7C76_TypeRegistry* zT_4;
    unsigned int zT_5;
    int zT_6;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_D155D06D_Type* zT_9;
    zT_D155D06D_Type zT_10;
    unsigned int zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    zT_33EF6BFB_TypeKind zT_16;
    int zT_17;
    zT_338B7C76_TypeRegistry* zT_19;
    zT_406493CE_StructPayload* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_406493CE_StructPayload zT_23;
    zT_C890C8CB_TypeResolver* zT_24;
    unsigned int zT_25;
    unsigned short zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned short zT_29;
    zT_33EF6BFB_TypeKind zT_30;
    zT_33EF6BFB_TypeKind zT_33;
    int zT_34;
    zT_338B7C76_TypeRegistry* zT_36;
    zT_54FF90FA_TaggedUnionPayload* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_54FF90FA_TaggedUnionPayload zT_40;
    zT_C890C8CB_TypeResolver* zT_41;
    unsigned int zT_42;
    unsigned short zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned short zT_46;
    zT_33EF6BFB_TypeKind zT_47;
    zT_33EF6BFB_TypeKind zT_50;
    int zT_51;
    zT_338B7C76_TypeRegistry* zT_53;
    zT_AF9231A2_UnionPayload* zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_AF9231A2_UnionPayload zT_57;
    zT_C890C8CB_TypeResolver* zT_58;
    unsigned int zT_59;
    unsigned short zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned short zT_63;
    zT_33EF6BFB_TypeKind zT_64;
    zT_33EF6BFB_TypeKind zT_67;
    int zT_68;
    zT_C890C8CB_TypeResolver* zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    zT_338B7C76_TypeRegistry* zT_72;
    zT_E834303C_ArrayPayload* zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    zT_E834303C_ArrayPayload zT_76;
    unsigned int zT_77;
    zT_33EF6BFB_TypeKind zT_78;
    zT_33EF6BFB_TypeKind zT_81;
    int zT_82;
    zT_338B7C76_TypeRegistry* zT_84;
    zT_666DC2E1_TuplePayload* zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    zT_666DC2E1_TuplePayload zT_88;
    int zT_90;
    unsigned int zT_91;
    unsigned short zT_92;
    unsigned int zT_93;
    int zT_94;
    zT_C890C8CB_TypeResolver* zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    zT_338B7C76_TypeRegistry* zT_98;
    unsigned int* zT_99;
    unsigned int zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    int zT_104;
    unsigned int zT_105;
    zT_33EF6BFB_TypeKind zT_106;
    zT_33EF6BFB_TypeKind zT_109;
    int zT_110;
    zT_C890C8CB_TypeResolver* zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    zT_338B7C76_TypeRegistry* zT_114;
    zT_0B10E8E9_OptionalPayload* zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    zT_0B10E8E9_OptionalPayload zT_118;
    unsigned int zT_119;
    zT_33EF6BFB_TypeKind zT_120;
    zT_33EF6BFB_TypeKind zT_123;
    int zT_124;
    zT_C890C8CB_TypeResolver* zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    zT_338B7C76_TypeRegistry* zT_128;
    zT_42C2D6BF_EUPayload* zT_129;
    unsigned int zT_130;
    unsigned int zT_131;
    zT_42C2D6BF_EUPayload zT_132;
    unsigned int zT_133;
    int zT_134;
    unsigned int zT_135;
    unsigned int ti;
    zT_D155D06D_Type ty;
    unsigned int container_tid;
    zT_406493CE_StructPayload sp;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_AF9231A2_UnionPayload up;
    zT_666DC2E1_TuplePayload tp_1;
    unsigned int ei;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    ti = zT_3;
    ti = zT_3;
    ti = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = self->registry;
    zT_5 = zT_4->types_len;
    zT_6 = ti < zT_5;
    if (zT_6) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = self->registry;
    zT_9 = zT_8->types_items;
    zT_10 = zT_9[ti];
    ty = zT_10;
    ty = zT_10;
    ty = zT_10;
    zT_12 = (unsigned int)ti;
    container_tid = zT_12;
    container_tid = zT_12;
    container_tid = zT_12;
    zT_13 = ty.kind;
    zT_16 = zT_33EF6BFB_TypeKind_struct_type;
    zT_17 = zT_13 == zT_16;
    if (zT_17) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    return;
    z_bb_4:
    zT_134 = 1;
    zT_135 = ti + zT_134;
    ti = zT_135;
    ti = zT_135;
    goto z_bb_1;
    z_bb_5:
    zT_19 = self->registry;
    zT_20 = zT_19->st_items;
    zT_21 = ty.payload_idx;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20[zT_22];
    sp = zT_23;
    sp = zT_23;
    sp = zT_23;
    zT_24 = self;
    zT_28 = sp.fields_start;
    zT_25 = zT_28;
    zT_29 = sp.fields_count;
    zT_26 = zT_29;
    zT_27 = container_tid;
    zF_0D59859C_layoutAddFieldEdges(zT_24, zT_25, zT_26, zT_27);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_30 = ty.kind;
    zT_33 = zT_33EF6BFB_TypeKind_tagged_union_type;
    zT_34 = zT_30 == zT_33;
    if (zT_34) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_36 = self->registry;
    zT_37 = zT_36->tu_items;
    zT_38 = ty.payload_idx;
    zT_39 = (unsigned int)zT_38;
    zT_40 = zT_37[zT_39];
    tp = zT_40;
    tp = zT_40;
    tp = zT_40;
    zT_41 = self;
    zT_45 = tp.fields_start;
    zT_42 = zT_45;
    zT_46 = tp.fields_count;
    zT_43 = zT_46;
    zT_44 = container_tid;
    zF_0D59859C_layoutAddFieldEdges(zT_41, zT_42, zT_43, zT_44);
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_47 = ty.kind;
    zT_50 = zT_33EF6BFB_TypeKind_union_type;
    zT_51 = zT_47 == zT_50;
    if (zT_51) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    zT_53 = self->registry;
    zT_54 = zT_53->un_items;
    zT_55 = ty.payload_idx;
    zT_56 = (unsigned int)zT_55;
    zT_57 = zT_54[zT_56];
    up = zT_57;
    up = zT_57;
    up = zT_57;
    zT_58 = self;
    zT_62 = up.fields_start;
    zT_59 = zT_62;
    zT_63 = up.fields_count;
    zT_60 = zT_63;
    zT_61 = container_tid;
    zF_0D59859C_layoutAddFieldEdges(zT_58, zT_59, zT_60, zT_61);
    goto z_bb_12;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_64 = ty.kind;
    zT_67 = zT_33EF6BFB_TypeKind_array_type;
    zT_68 = zT_64 == zT_67;
    if (zT_68) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    zT_69 = self;
    zT_72 = self->registry;
    zT_73 = zT_72->array_items;
    zT_74 = ty.payload_idx;
    zT_75 = (unsigned int)zT_74;
    zT_76 = zT_73[zT_75];
    zT_77 = zT_76.elem;
    zT_70 = zT_77;
    zT_71 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_69, zT_70, zT_71);
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_78 = ty.kind;
    zT_81 = zT_33EF6BFB_TypeKind_tuple_type;
    zT_82 = zT_78 == zT_81;
    if (zT_82) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    zT_84 = self->registry;
    zT_85 = zT_84->tup_items;
    zT_86 = ty.payload_idx;
    zT_87 = (unsigned int)zT_86;
    zT_88 = zT_85[zT_87];
    tp_1 = zT_88;
    tp_1 = zT_88;
    tp_1 = zT_88;
    zT_90 = 0;
    zT_91 = (unsigned int)zT_90;
    ei = zT_91;
    ei = zT_91;
    ei = zT_91;
    goto z_bb_20;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_106 = ty.kind;
    zT_109 = zT_33EF6BFB_TypeKind_optional_type;
    zT_110 = zT_106 == zT_109;
    if (zT_110) goto z_bb_24; else goto z_bb_26;
    z_bb_20:
    zT_92 = tp_1.elems_count;
    zT_93 = (unsigned int)zT_92;
    zT_94 = ei < zT_93;
    if (zT_94) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_95 = self;
    zT_98 = self->registry;
    zT_99 = zT_98->xt_items;
    zT_100 = tp_1.elems_start;
    zT_101 = (unsigned int)zT_100;
    zT_102 = zT_101 + ei;
    zT_103 = zT_99[zT_102];
    zT_96 = zT_103;
    zT_97 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_95, zT_96, zT_97);
    goto z_bb_23;
    z_bb_22:
    goto z_bb_18;
    z_bb_23:
    zT_104 = 1;
    zT_105 = ei + zT_104;
    ei = zT_105;
    ei = zT_105;
    goto z_bb_20;
    z_bb_24:
    zT_111 = self;
    zT_114 = self->registry;
    zT_115 = zT_114->opt_items;
    zT_116 = ty.payload_idx;
    zT_117 = (unsigned int)zT_116;
    zT_118 = zT_115[zT_117];
    zT_119 = zT_118.payload;
    zT_112 = zT_119;
    zT_113 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_111, zT_112, zT_113);
    goto z_bb_25;
    z_bb_25:
    goto z_bb_18;
    z_bb_26:
    zT_120 = ty.kind;
    zT_123 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_124 = zT_120 == zT_123;
    if (zT_124) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_125 = self;
    zT_128 = self->registry;
    zT_129 = zT_128->eu_items;
    zT_130 = ty.payload_idx;
    zT_131 = (unsigned int)zT_130;
    zT_132 = zT_129[zT_131];
    zT_133 = zT_132.payload;
    zT_126 = zT_133;
    zT_127 = container_tid;
    zF_0E16D693_layoutAddTypeEdge(zT_125, zT_126, zT_127);
    goto z_bb_28;
    z_bb_28:
    goto z_bb_25;
}

/* classifyTypeEmissionGroups */
zT_010C8DF0_ClassificationResul zF_ACC002C8_classifyTypeEmissio(zT_C890C8CB_TypeResolver* self, zT_3E40CD83_Sand* perm_alloc) {
    zT_338B7C76_TypeRegistry* zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    zT_A62CFBCC_EU_022 zT_13 = {0};
    unsigned char zT_14;
    unsigned char* zT_15;
    unsigned char* zT_16;
    unsigned char* zT_18;
    int zT_20;
    unsigned int zT_21;
    zT_3E40CD83_Sand* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    int zT_26;
    unsigned int zT_27;
    int zT_28;
    unsigned int zT_29;
    zT_A62CFBCC_EU_022 zT_30 = {0};
    unsigned char zT_31;
    unsigned char* zT_32;
    unsigned char* zT_33;
    unsigned int* zT_35;
    zT_3E40CD83_Sand* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    int zT_40;
    unsigned int zT_41;
    int zT_42;
    unsigned int zT_43;
    zT_A62CFBCC_EU_022 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    unsigned char* zT_47;
    unsigned int* zT_49;
    zT_3E40CD83_Sand* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    int zT_54;
    unsigned int zT_55;
    int zT_56;
    unsigned int zT_57;
    zT_A62CFBCC_EU_022 zT_58 = {0};
    unsigned char zT_59;
    unsigned char* zT_60;
    unsigned char* zT_61;
    unsigned int* zT_63;
    int zT_65;
    unsigned int zT_66;
    int zT_67;
    unsigned int zT_68;
    int zT_69;
    unsigned int zT_70;
    unsigned int zT_72;
    zT_3E40CD83_Sand* zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    int zT_77;
    unsigned int zT_78;
    int zT_79;
    unsigned int zT_80;
    zT_A62CFBCC_EU_022 zT_81 = {0};
    unsigned char zT_82;
    unsigned char* zT_83;
    unsigned char* zT_84;
    unsigned int* zT_86;
    unsigned int zT_88;
    unsigned int zT_90;
    int zT_92;
    unsigned int zT_93;
    int zT_94;
    zT_338B7C76_TypeRegistry* zT_96;
    zT_D155D06D_Type* zT_97;
    zT_D155D06D_Type zT_98;
    unsigned char zT_100;
    zT_33EF6BFB_TypeKind zT_101;
    zT_33EF6BFB_TypeKind zT_104;
    int zT_105;
    zT_338B7C76_TypeRegistry* zT_107;
    zT_406493CE_StructPayload* zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    zT_406493CE_StructPayload zT_111;
    int zT_113;
    unsigned int zT_114;
    unsigned short zT_115;
    unsigned int zT_116;
    int zT_117;
    int zT_118;
    int zT_119;
    int zT_120;
    zT_338B7C76_TypeRegistry* zT_122;
    zT_2DF01B61_FieldEntry* zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned int zT_126;
    zT_2DF01B61_FieldEntry zT_127;
    unsigned int zT_128;
    zT_338B7C76_TypeRegistry* zT_130;
    zT_D155D06D_Type* zT_131;
    unsigned int zT_132;
    zT_D155D06D_Type zT_133;
    zT_33EF6BFB_TypeKind zT_134;
    zT_33EF6BFB_TypeKind zT_135;
    int zT_136 = 0;
    unsigned char zT_137;
    zT_33EF6BFB_TypeKind zT_138;
    zT_33EF6BFB_TypeKind zT_141;
    int zT_142;
    zT_3E40CD83_Sand* zT_143;
    unsigned int** zT_144;
    unsigned int** zT_145;
    unsigned int* zT_146;
    unsigned int zT_147;
    unsigned int** zT_148;
    unsigned int** zT_149;
    unsigned int* zT_150;
    unsigned int zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    zT_33EF6BFB_TypeKind zT_159;
    zT_33EF6BFB_TypeKind zT_162;
    int zT_163;
    zT_3E40CD83_Sand* zT_164;
    unsigned int** zT_165;
    unsigned int** zT_166;
    unsigned int* zT_167;
    unsigned int zT_168;
    unsigned int** zT_169;
    unsigned int** zT_170;
    unsigned int* zT_171;
    unsigned int zT_172;
    unsigned int zT_173;
    unsigned int zT_174;
    unsigned int zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    unsigned int zT_178;
    unsigned int zT_179;
    int zT_180;
    unsigned int zT_181;
    zT_33EF6BFB_TypeKind zT_182;
    zT_33EF6BFB_TypeKind zT_185;
    int zT_186;
    zT_338B7C76_TypeRegistry* zT_188;
    zT_54FF90FA_TaggedUnionPayload* zT_189;
    unsigned int zT_190;
    unsigned int zT_191;
    zT_54FF90FA_TaggedUnionPayload zT_192;
    int zT_194;
    unsigned int zT_195;
    unsigned short zT_196;
    unsigned int zT_197;
    int zT_198;
    int zT_199;
    int zT_200;
    int zT_201;
    zT_338B7C76_TypeRegistry* zT_203;
    zT_2DF01B61_FieldEntry* zT_204;
    unsigned int zT_205;
    unsigned int zT_206;
    unsigned int zT_207;
    zT_2DF01B61_FieldEntry zT_208;
    unsigned int zT_209;
    zT_338B7C76_TypeRegistry* zT_211;
    zT_D155D06D_Type* zT_212;
    unsigned int zT_213;
    zT_D155D06D_Type zT_214;
    zT_33EF6BFB_TypeKind zT_215;
    zT_33EF6BFB_TypeKind zT_216;
    int zT_217 = 0;
    unsigned char zT_218;
    zT_33EF6BFB_TypeKind zT_219;
    zT_33EF6BFB_TypeKind zT_222;
    int zT_223;
    zT_3E40CD83_Sand* zT_224;
    unsigned int** zT_225;
    unsigned int** zT_226;
    unsigned int* zT_227;
    unsigned int zT_228;
    unsigned int** zT_229;
    unsigned int** zT_230;
    unsigned int* zT_231;
    unsigned int zT_232;
    unsigned int zT_233;
    unsigned int zT_234;
    unsigned int zT_235;
    unsigned int zT_236;
    unsigned int zT_237;
    unsigned int zT_238;
    unsigned int zT_239;
    zT_33EF6BFB_TypeKind zT_240;
    zT_33EF6BFB_TypeKind zT_243;
    int zT_244;
    zT_3E40CD83_Sand* zT_245;
    unsigned int** zT_246;
    unsigned int** zT_247;
    unsigned int* zT_248;
    unsigned int zT_249;
    unsigned int** zT_250;
    unsigned int** zT_251;
    unsigned int* zT_252;
    unsigned int zT_253;
    unsigned int zT_254;
    unsigned int zT_255;
    unsigned int zT_256;
    unsigned int zT_257;
    unsigned int zT_258;
    unsigned int zT_259;
    unsigned int zT_260;
    int zT_261;
    unsigned int zT_262;
    zT_33EF6BFB_TypeKind zT_263;
    zT_33EF6BFB_TypeKind zT_266;
    int zT_267;
    zT_338B7C76_TypeRegistry* zT_269;
    zT_AF9231A2_UnionPayload* zT_270;
    unsigned int zT_271;
    unsigned int zT_272;
    zT_AF9231A2_UnionPayload zT_273;
    int zT_275;
    unsigned int zT_276;
    unsigned short zT_277;
    unsigned int zT_278;
    int zT_279;
    int zT_280;
    int zT_281;
    int zT_282;
    zT_338B7C76_TypeRegistry* zT_284;
    zT_2DF01B61_FieldEntry* zT_285;
    unsigned int zT_286;
    unsigned int zT_287;
    unsigned int zT_288;
    zT_2DF01B61_FieldEntry zT_289;
    unsigned int zT_290;
    zT_338B7C76_TypeRegistry* zT_292;
    zT_D155D06D_Type* zT_293;
    unsigned int zT_294;
    zT_D155D06D_Type zT_295;
    zT_33EF6BFB_TypeKind zT_296;
    zT_33EF6BFB_TypeKind zT_297;
    int zT_298 = 0;
    unsigned char zT_299;
    zT_33EF6BFB_TypeKind zT_300;
    zT_33EF6BFB_TypeKind zT_303;
    int zT_304;
    zT_3E40CD83_Sand* zT_305;
    unsigned int** zT_306;
    unsigned int** zT_307;
    unsigned int* zT_308;
    unsigned int zT_309;
    unsigned int** zT_310;
    unsigned int** zT_311;
    unsigned int* zT_312;
    unsigned int zT_313;
    unsigned int zT_314;
    unsigned int zT_315;
    unsigned int zT_316;
    unsigned int zT_317;
    unsigned int zT_318;
    unsigned int zT_319;
    unsigned int zT_320;
    zT_33EF6BFB_TypeKind zT_321;
    zT_33EF6BFB_TypeKind zT_324;
    int zT_325;
    zT_3E40CD83_Sand* zT_326;
    unsigned int** zT_327;
    unsigned int** zT_328;
    unsigned int* zT_329;
    unsigned int zT_330;
    unsigned int** zT_331;
    unsigned int** zT_332;
    unsigned int* zT_333;
    unsigned int zT_334;
    unsigned int zT_335;
    unsigned int zT_336;
    unsigned int zT_337;
    unsigned int zT_338;
    unsigned int zT_339;
    unsigned int zT_340;
    unsigned int zT_341;
    int zT_342;
    unsigned int zT_343;
    zT_33EF6BFB_TypeKind zT_344;
    zT_33EF6BFB_TypeKind zT_347;
    int zT_348;
    zT_338B7C76_TypeRegistry* zT_350;
    zT_E834303C_ArrayPayload* zT_351;
    unsigned int zT_352;
    unsigned int zT_353;
    zT_E834303C_ArrayPayload zT_354;
    unsigned int zT_355;
    zT_338B7C76_TypeRegistry* zT_357;
    zT_D155D06D_Type* zT_358;
    unsigned int zT_359;
    zT_D155D06D_Type zT_360;
    zT_33EF6BFB_TypeKind zT_361;
    zT_33EF6BFB_TypeKind zT_362;
    int zT_363 = 0;
    unsigned char zT_364;
    zT_33EF6BFB_TypeKind zT_365;
    zT_33EF6BFB_TypeKind zT_368;
    int zT_369;
    zT_3E40CD83_Sand* zT_370;
    unsigned int** zT_371;
    unsigned int** zT_372;
    unsigned int* zT_373;
    unsigned int zT_374;
    unsigned int** zT_375;
    unsigned int** zT_376;
    unsigned int* zT_377;
    unsigned int zT_378;
    unsigned int zT_379;
    unsigned int zT_380;
    unsigned int zT_381;
    unsigned int zT_382;
    unsigned int zT_383;
    unsigned int zT_384;
    unsigned int zT_385;
    zT_33EF6BFB_TypeKind zT_386;
    zT_33EF6BFB_TypeKind zT_389;
    int zT_390;
    zT_3E40CD83_Sand* zT_391;
    unsigned int** zT_392;
    unsigned int** zT_393;
    unsigned int* zT_394;
    unsigned int zT_395;
    unsigned int** zT_396;
    unsigned int** zT_397;
    unsigned int* zT_398;
    unsigned int zT_399;
    unsigned int zT_400;
    unsigned int zT_401;
    unsigned int zT_402;
    unsigned int zT_403;
    unsigned int zT_404;
    unsigned int zT_405;
    unsigned int zT_406;
    zT_33EF6BFB_TypeKind zT_407;
    zT_33EF6BFB_TypeKind zT_410;
    int zT_411;
    zT_338B7C76_TypeRegistry* zT_413;
    zT_42C2D6BF_EUPayload* zT_414;
    unsigned int zT_415;
    unsigned int zT_416;
    zT_42C2D6BF_EUPayload zT_417;
    unsigned int zT_418;
    zT_338B7C76_TypeRegistry* zT_420;
    zT_D155D06D_Type* zT_421;
    unsigned int zT_422;
    zT_D155D06D_Type zT_423;
    zT_33EF6BFB_TypeKind zT_424;
    zT_33EF6BFB_TypeKind zT_425;
    int zT_426 = 0;
    unsigned char zT_427;
    zT_33EF6BFB_TypeKind zT_428;
    zT_33EF6BFB_TypeKind zT_431;
    int zT_432;
    zT_3E40CD83_Sand* zT_433;
    unsigned int** zT_434;
    unsigned int** zT_435;
    unsigned int* zT_436;
    unsigned int zT_437;
    unsigned int** zT_438;
    unsigned int** zT_439;
    unsigned int* zT_440;
    unsigned int zT_441;
    unsigned int zT_442;
    unsigned int zT_443;
    unsigned int zT_444;
    unsigned int zT_445;
    unsigned int zT_446;
    unsigned int zT_447;
    unsigned int zT_448;
    zT_33EF6BFB_TypeKind zT_449;
    zT_33EF6BFB_TypeKind zT_452;
    int zT_453;
    zT_3E40CD83_Sand* zT_454;
    unsigned int** zT_455;
    unsigned int** zT_456;
    unsigned int* zT_457;
    unsigned int zT_458;
    unsigned int** zT_459;
    unsigned int** zT_460;
    unsigned int* zT_461;
    unsigned int zT_462;
    unsigned int zT_463;
    unsigned int zT_464;
    unsigned int zT_465;
    unsigned int zT_466;
    unsigned int zT_467;
    unsigned int zT_468;
    unsigned int zT_469;
    zT_33EF6BFB_TypeKind zT_470;
    zT_33EF6BFB_TypeKind zT_473;
    int zT_474;
    zT_338B7C76_TypeRegistry* zT_476;
    zT_0B10E8E9_OptionalPayload* zT_477;
    unsigned int zT_478;
    unsigned int zT_479;
    zT_0B10E8E9_OptionalPayload zT_480;
    unsigned int zT_481;
    zT_338B7C76_TypeRegistry* zT_483;
    zT_D155D06D_Type* zT_484;
    unsigned int zT_485;
    zT_D155D06D_Type zT_486;
    zT_33EF6BFB_TypeKind zT_487;
    zT_33EF6BFB_TypeKind zT_488;
    int zT_489 = 0;
    unsigned char zT_490;
    zT_33EF6BFB_TypeKind zT_491;
    zT_33EF6BFB_TypeKind zT_494;
    int zT_495;
    zT_3E40CD83_Sand* zT_496;
    unsigned int** zT_497;
    unsigned int** zT_498;
    unsigned int* zT_499;
    unsigned int zT_500;
    unsigned int** zT_501;
    unsigned int** zT_502;
    unsigned int* zT_503;
    unsigned int zT_504;
    unsigned int zT_505;
    unsigned int zT_506;
    unsigned int zT_507;
    unsigned int zT_508;
    unsigned int zT_509;
    unsigned int zT_510;
    unsigned int zT_511;
    zT_33EF6BFB_TypeKind zT_512;
    zT_33EF6BFB_TypeKind zT_515;
    int zT_516;
    zT_3E40CD83_Sand* zT_517;
    unsigned int** zT_518;
    unsigned int** zT_519;
    unsigned int* zT_520;
    unsigned int zT_521;
    unsigned int** zT_522;
    unsigned int** zT_523;
    unsigned int* zT_524;
    unsigned int zT_525;
    unsigned int zT_526;
    unsigned int zT_527;
    unsigned int zT_528;
    unsigned int zT_529;
    unsigned int zT_530;
    unsigned int zT_531;
    unsigned int zT_532;
    unsigned char zT_533;
    int zT_534;
    unsigned int zT_535;
    unsigned int zT_536;
    unsigned int zT_537;
    unsigned int zT_538;
    int zT_539;
    unsigned int zT_540;
    int zT_541;
    unsigned int zT_543;
    unsigned int zT_544;
    unsigned int zT_545;
    unsigned int zT_546;
    unsigned int zT_548;
    unsigned int zT_549;
    unsigned int zT_550;
    int zT_551;
    unsigned int zT_553;
    unsigned int zT_554;
    unsigned int zT_555;
    unsigned char zT_556;
    unsigned char zT_557;
    int zT_558;
    unsigned char zT_559;
    unsigned int zT_560;
    unsigned int zT_561;
    unsigned int zT_562;
    unsigned int zT_563;
    unsigned int zT_564;
    unsigned int zT_565;
    zT_3E40CD83_Sand* zT_567;
    unsigned int zT_568;
    unsigned int zT_569;
    int zT_570;
    unsigned int zT_571;
    int zT_572;
    unsigned int zT_573;
    zT_A62CFBCC_EU_022 zT_574 = {0};
    unsigned char zT_575;
    unsigned char* zT_576;
    unsigned char* zT_577;
    unsigned int* zT_579;
    unsigned int zT_581;
    int zT_582;
    unsigned int zT_583;
    int zT_584;
    unsigned char zT_585;
    unsigned char zT_586;
    int zT_587;
    unsigned int zT_588;
    unsigned int zT_589;
    unsigned int zT_590;
    unsigned int zT_591;
    int zT_592;
    unsigned int zT_593;
    char* zT_595;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_596;
    unsigned int zT_597;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_598;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_600;
    unsigned int zT_602;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_603;
    unsigned char* zT_604;
    unsigned int zT_605;
    int zT_606;
    unsigned char* zT_607;
    unsigned int zT_608;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_609;
    unsigned int zT_610 = 0;
    unsigned int zT_612;
    unsigned int zT_613;
    unsigned int zT_614;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_615;
    unsigned char* zT_616;
    unsigned int zT_618;
    unsigned char* zT_619;
    unsigned int zT_620;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_621;
    char* zT_623;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_624;
    unsigned int zT_625;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_626;
    int zT_627;
    unsigned int zT_628;
    int zT_629;
    unsigned char zT_630;
    unsigned char zT_631;
    int zT_632;
    char* zT_634;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_635;
    unsigned int zT_636;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_637;
    char* zT_639;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_640;
    unsigned int zT_641;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_642;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_644;
    unsigned int zT_646;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_647;
    unsigned int zT_648;
    unsigned char* zT_649;
    unsigned int zT_650;
    int zT_651;
    unsigned char* zT_652;
    unsigned int zT_653;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_654;
    unsigned int zT_655 = 0;
    unsigned int zT_657;
    unsigned int zT_658;
    unsigned int zT_659;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_660;
    unsigned char* zT_661;
    unsigned int zT_663;
    unsigned char* zT_664;
    unsigned int zT_665;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_666;
    char* zT_668;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_669;
    unsigned int zT_670;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_671;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_673;
    unsigned int zT_675;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_676;
    zT_338B7C76_TypeRegistry* zT_677;
    zT_D155D06D_Type* zT_678;
    zT_D155D06D_Type zT_679;
    zT_33EF6BFB_TypeKind zT_680;
    unsigned int zT_681;
    unsigned char* zT_682;
    unsigned int zT_683;
    int zT_684;
    unsigned char* zT_685;
    unsigned int zT_686;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_687;
    unsigned int zT_688 = 0;
    unsigned int zT_690;
    unsigned int zT_691;
    unsigned int zT_692;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_693;
    unsigned char* zT_694;
    unsigned int zT_696;
    unsigned char* zT_697;
    unsigned int zT_698;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_699;
    char* zT_701;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_702;
    unsigned int zT_703;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_704;
    int zT_705;
    unsigned int zT_706;
    zT_010C8DF0_ClassificationResul zT_707;
    unsigned int tl;
    unsigned char* po_raw;
    unsigned char* pointer_only;
    unsigned int wp_edge_cap;
    unsigned char* wp_to_raw;
    unsigned int* wp_to;
    unsigned char* wp_next_raw;
    unsigned int* wp_next;
    unsigned char* wp_head_raw;
    unsigned int* wp_head;
    unsigned int whi;
    unsigned int wp_count;
    unsigned char* wl_raw;
    unsigned int* worklist;
    unsigned int wl_head;
    unsigned int wl_tail;
    unsigned int ti;
    zT_D155D06D_Type ty;
    unsigned char is_po;
    zT_406493CE_StructPayload sp;
    unsigned int fi;
    unsigned int ft_id;
    zT_D155D06D_Type ft;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_AF9231A2_UnionPayload up;
    unsigned int et;
    zT_D155D06D_Type et_ty;
    unsigned int eup;
    zT_D155D06D_Type eup_ty;
    unsigned int op_p;
    zT_D155D06D_Type op_ty;
    unsigned int cur;
    unsigned int e;
    unsigned char* ids_raw;
    unsigned int parent_tid;
    unsigned int* ids;
    unsigned int plen;
    zT_8F083A69_Slice_zT_0B42B2F8_u cls_m;
    zT_5A26C2ED_Arr_unsigned_char_1 cls_b;
    unsigned int cls_l;
    unsigned int cls_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u cls_nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfx;
    zT_5A26C2ED_Arr_unsigned_char_1 ctb;
    unsigned int ctl;
    unsigned int cts;
    zT_8F083A69_Slice_zT_0B42B2F8_u ck;
    zT_5A26C2ED_Arr_unsigned_char_1 ckb;
    unsigned int ckl;
    unsigned int cks;
    zT_8F083A69_Slice_zT_0B42B2F8_u cnl;
    zT_3 = self->registry;
    zT_4 = zT_3->types_len;
    tl = zT_4;
    tl = zT_4;
    tl = zT_4;
    zT_6 = perm_alloc;
    zT_9 = 1;
    zT_10 = zT_9 * tl;
    zT_7 = zT_10;
    zT_11 = 1;
    zT_12 = (unsigned int)zT_11;
    zT_8 = zT_12;
    zT_13 = zF_1395EB68_sandAlloc(zT_6, zT_7, zT_8);
    zT_14 = zT_13.is_error;
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    z_bb_2:
    zT_16 = zT_13.data.payload;
    zT_15 = zT_16;
    goto z_bb_3;
    z_bb_3:
    po_raw = zT_15;
    po_raw = zT_15;
    po_raw = zT_15;
    zT_18 = (unsigned char*)po_raw;
    pointer_only = zT_18;
    pointer_only = zT_18;
    pointer_only = zT_18;
    zT_20 = 4;
    zT_21 = tl * zT_20;
    wp_edge_cap = zT_21;
    wp_edge_cap = zT_21;
    wp_edge_cap = zT_21;
    zT_23 = perm_alloc;
    zT_26 = 4;
    zT_27 = zT_26 * wp_edge_cap;
    zT_24 = zT_27;
    zT_28 = 4;
    zT_29 = (unsigned int)zT_28;
    zT_25 = zT_29;
    zT_30 = zF_1395EB68_sandAlloc(zT_23, zT_24, zT_25);
    zT_31 = zT_30.is_error;
    if (zT_31) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    z_bb_5:
    zT_33 = zT_30.data.payload;
    zT_32 = zT_33;
    goto z_bb_6;
    z_bb_6:
    wp_to_raw = zT_32;
    wp_to_raw = zT_32;
    wp_to_raw = zT_32;
    zT_35 = (unsigned int*)wp_to_raw;
    wp_to = zT_35;
    wp_to = zT_35;
    wp_to = zT_35;
    zT_37 = perm_alloc;
    zT_40 = 4;
    zT_41 = zT_40 * wp_edge_cap;
    zT_38 = zT_41;
    zT_42 = 4;
    zT_43 = (unsigned int)zT_42;
    zT_39 = zT_43;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, zT_38, zT_39);
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    z_bb_8:
    zT_47 = zT_44.data.payload;
    zT_46 = zT_47;
    goto z_bb_9;
    z_bb_9:
    wp_next_raw = zT_46;
    wp_next_raw = zT_46;
    wp_next_raw = zT_46;
    zT_49 = (unsigned int*)wp_next_raw;
    wp_next = zT_49;
    wp_next = zT_49;
    wp_next = zT_49;
    zT_51 = perm_alloc;
    zT_54 = 4;
    zT_55 = zT_54 * tl;
    zT_52 = zT_55;
    zT_56 = 4;
    zT_57 = (unsigned int)zT_56;
    zT_53 = zT_57;
    zT_58 = zF_1395EB68_sandAlloc(zT_51, zT_52, zT_53);
    zT_59 = zT_58.is_error;
    if (zT_59) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    z_bb_11:
    zT_61 = zT_58.data.payload;
    zT_60 = zT_61;
    goto z_bb_12;
    z_bb_12:
    wp_head_raw = zT_60;
    wp_head_raw = zT_60;
    wp_head_raw = zT_60;
    zT_63 = (unsigned int*)wp_head_raw;
    wp_head = zT_63;
    wp_head = zT_63;
    wp_head = zT_63;
    zT_65 = 0;
    zT_66 = (unsigned int)zT_65;
    whi = zT_66;
    whi = zT_66;
    whi = zT_66;
    goto z_bb_13;
    z_bb_13:
    zT_67 = whi < tl;
    if (zT_67) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_68 = 4294967295u;
    wp_head[whi] = zT_68;
    goto z_bb_16;
    z_bb_15:
    zT_72 = 0;
    wp_count = zT_72;
    wp_count = zT_72;
    wp_count = zT_72;
    zT_74 = perm_alloc;
    zT_77 = 4;
    zT_78 = zT_77 * tl;
    zT_75 = zT_78;
    zT_79 = 4;
    zT_80 = (unsigned int)zT_79;
    zT_76 = zT_80;
    zT_81 = zF_1395EB68_sandAlloc(zT_74, zT_75, zT_76);
    zT_82 = zT_81.is_error;
    if (zT_82) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_69 = 1;
    zT_70 = whi + zT_69;
    whi = zT_70;
    whi = zT_70;
    goto z_bb_13;
    z_bb_17:
    z_bb_18:
    zT_84 = zT_81.data.payload;
    zT_83 = zT_84;
    goto z_bb_19;
    z_bb_19:
    wl_raw = zT_83;
    wl_raw = zT_83;
    wl_raw = zT_83;
    zT_86 = (unsigned int*)wl_raw;
    worklist = zT_86;
    worklist = zT_86;
    worklist = zT_86;
    zT_88 = 0;
    wl_head = zT_88;
    wl_head = zT_88;
    wl_head = zT_88;
    zT_90 = 0;
    wl_tail = zT_90;
    wl_tail = zT_90;
    wl_tail = zT_90;
    zT_92 = 0;
    zT_93 = (unsigned int)zT_92;
    ti = zT_93;
    ti = zT_93;
    ti = zT_93;
    goto z_bb_20;
    z_bb_20:
    zT_94 = ti < tl;
    if (zT_94) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_96 = self->registry;
    zT_97 = zT_96->types_items;
    zT_98 = zT_97[ti];
    ty = zT_98;
    ty = zT_98;
    ty = zT_98;
    zT_100 = 1;
    is_po = zT_100;
    is_po = zT_100;
    is_po = zT_100;
    zT_101 = ty.kind;
    zT_104 = zT_33EF6BFB_TypeKind_struct_type;
    zT_105 = zT_101 == zT_104;
    if (zT_105) goto z_bb_24; else goto z_bb_26;
    z_bb_22:
    goto z_bb_112;
    z_bb_23:
    zT_539 = 1;
    zT_540 = ti + zT_539;
    ti = zT_540;
    ti = zT_540;
    goto z_bb_20;
    z_bb_24:
    zT_107 = self->registry;
    zT_108 = zT_107->st_items;
    zT_109 = ty.payload_idx;
    zT_110 = (unsigned int)zT_109;
    zT_111 = zT_108[zT_110];
    sp = zT_111;
    sp = zT_111;
    sp = zT_111;
    zT_113 = 0;
    zT_114 = (unsigned int)zT_113;
    fi = zT_114;
    fi = zT_114;
    fi = zT_114;
    goto z_bb_27;
    z_bb_25:
    pointer_only[ti] = is_po;
    zT_533 = 0;
    zT_534 = is_po == zT_533;
    if (zT_534) goto z_bb_110; else goto z_bb_111;
    z_bb_26:
    zT_182 = ty.kind;
    zT_185 = zT_33EF6BFB_TypeKind_tagged_union_type;
    zT_186 = zT_182 == zT_185;
    if (zT_186) goto z_bb_42; else goto z_bb_44;
    z_bb_27:
    zT_115 = sp.fields_count;
    zT_116 = (unsigned int)zT_115;
    zT_117 = fi < zT_116;
    if (zT_117) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_122 = self->registry;
    zT_123 = zT_122->fe_items;
    zT_124 = sp.fields_start;
    zT_125 = (unsigned int)zT_124;
    zT_126 = zT_125 + fi;
    zT_127 = zT_123[zT_126];
    zT_128 = zT_127.type_id;
    ft_id = zT_128;
    ft_id = zT_128;
    ft_id = zT_128;
    zT_130 = self->registry;
    zT_131 = zT_130->types_items;
    zT_132 = (unsigned int)ft_id;
    zT_133 = zT_131[zT_132];
    ft = zT_133;
    ft = zT_133;
    ft = zT_133;
    zT_135 = ft.kind;
    zT_134 = zT_135;
    zT_136 = zF_A47239A9_fieldEmbedsByValue(zT_134);
    if (zT_136) goto z_bb_34; else goto z_bb_36;
    z_bb_29:
    goto z_bb_25;
    z_bb_30:
    zT_180 = 1;
    zT_181 = fi + zT_180;
    fi = zT_181;
    fi = zT_181;
    goto z_bb_27;
    z_bb_31:
    zT_119 = 0;
    zT_120 = is_po != zT_119;
    zT_118 = zT_120;
    goto z_bb_33;
    z_bb_32:
    zT_118 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_118) goto z_bb_28; else goto z_bb_29;
    z_bb_34:
    zT_137 = 0;
    is_po = zT_137;
    is_po = zT_137;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_30;
    z_bb_36:
    zT_138 = ft.kind;
    zT_141 = zT_33EF6BFB_TypeKind_optional_type;
    zT_142 = zT_138 == zT_141;
    if (zT_142) goto z_bb_37; else goto z_bb_39;
    z_bb_37:
    zT_143 = perm_alloc;
    zT_148 = &wp_to;
    zT_144 = zT_148;
    zT_149 = &wp_next;
    zT_145 = zT_149;
    zT_150 = &wp_edge_cap;
    zT_146 = zT_150;
    zT_147 = wp_count;
    zF_25C377BD_growWpEdges(zT_143, zT_144, zT_145, zT_146, zT_147);
    zT_151 = (unsigned int)ti;
    zT_152 = (unsigned int)wp_count;
    wp_to[zT_152] = zT_151;
    zT_153 = (unsigned int)ft_id;
    zT_154 = wp_head[zT_153];
    zT_155 = (unsigned int)wp_count;
    wp_next[zT_155] = zT_154;
    zT_156 = (unsigned int)ft_id;
    wp_head[zT_156] = wp_count;
    zT_157 = 1;
    zT_158 = wp_count + zT_157;
    wp_count = zT_158;
    wp_count = zT_158;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_159 = ft.kind;
    zT_162 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_163 = zT_159 == zT_162;
    if (zT_163) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_164 = perm_alloc;
    zT_169 = &wp_to;
    zT_165 = zT_169;
    zT_170 = &wp_next;
    zT_166 = zT_170;
    zT_171 = &wp_edge_cap;
    zT_167 = zT_171;
    zT_168 = wp_count;
    zF_25C377BD_growWpEdges(zT_164, zT_165, zT_166, zT_167, zT_168);
    zT_172 = (unsigned int)ti;
    zT_173 = (unsigned int)wp_count;
    wp_to[zT_173] = zT_172;
    zT_174 = (unsigned int)ft_id;
    zT_175 = wp_head[zT_174];
    zT_176 = (unsigned int)wp_count;
    wp_next[zT_176] = zT_175;
    zT_177 = (unsigned int)ft_id;
    wp_head[zT_177] = wp_count;
    zT_178 = 1;
    zT_179 = wp_count + zT_178;
    wp_count = zT_179;
    wp_count = zT_179;
    goto z_bb_41;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_188 = self->registry;
    zT_189 = zT_188->tu_items;
    zT_190 = ty.payload_idx;
    zT_191 = (unsigned int)zT_190;
    zT_192 = zT_189[zT_191];
    tp = zT_192;
    tp = zT_192;
    tp = zT_192;
    zT_194 = 0;
    zT_195 = (unsigned int)zT_194;
    fi = zT_195;
    fi = zT_195;
    fi = zT_195;
    goto z_bb_45;
    z_bb_43:
    goto z_bb_25;
    z_bb_44:
    zT_263 = ty.kind;
    zT_266 = zT_33EF6BFB_TypeKind_union_type;
    zT_267 = zT_263 == zT_266;
    if (zT_267) goto z_bb_60; else goto z_bb_62;
    z_bb_45:
    zT_196 = tp.fields_count;
    zT_197 = (unsigned int)zT_196;
    zT_198 = fi < zT_197;
    if (zT_198) goto z_bb_49; else goto z_bb_50;
    z_bb_46:
    zT_203 = self->registry;
    zT_204 = zT_203->fe_items;
    zT_205 = tp.fields_start;
    zT_206 = (unsigned int)zT_205;
    zT_207 = zT_206 + fi;
    zT_208 = zT_204[zT_207];
    zT_209 = zT_208.type_id;
    ft_id = zT_209;
    ft_id = zT_209;
    ft_id = zT_209;
    zT_211 = self->registry;
    zT_212 = zT_211->types_items;
    zT_213 = (unsigned int)ft_id;
    zT_214 = zT_212[zT_213];
    ft = zT_214;
    ft = zT_214;
    ft = zT_214;
    zT_216 = ft.kind;
    zT_215 = zT_216;
    zT_217 = zF_A47239A9_fieldEmbedsByValue(zT_215);
    if (zT_217) goto z_bb_52; else goto z_bb_54;
    z_bb_47:
    goto z_bb_43;
    z_bb_48:
    zT_261 = 1;
    zT_262 = fi + zT_261;
    fi = zT_262;
    fi = zT_262;
    goto z_bb_45;
    z_bb_49:
    zT_200 = 0;
    zT_201 = is_po != zT_200;
    zT_199 = zT_201;
    goto z_bb_51;
    z_bb_50:
    zT_199 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_199) goto z_bb_46; else goto z_bb_47;
    z_bb_52:
    zT_218 = 0;
    is_po = zT_218;
    is_po = zT_218;
    goto z_bb_53;
    z_bb_53:
    goto z_bb_48;
    z_bb_54:
    zT_219 = ft.kind;
    zT_222 = zT_33EF6BFB_TypeKind_optional_type;
    zT_223 = zT_219 == zT_222;
    if (zT_223) goto z_bb_55; else goto z_bb_57;
    z_bb_55:
    zT_224 = perm_alloc;
    zT_229 = &wp_to;
    zT_225 = zT_229;
    zT_230 = &wp_next;
    zT_226 = zT_230;
    zT_231 = &wp_edge_cap;
    zT_227 = zT_231;
    zT_228 = wp_count;
    zF_25C377BD_growWpEdges(zT_224, zT_225, zT_226, zT_227, zT_228);
    zT_232 = (unsigned int)ti;
    zT_233 = (unsigned int)wp_count;
    wp_to[zT_233] = zT_232;
    zT_234 = (unsigned int)ft_id;
    zT_235 = wp_head[zT_234];
    zT_236 = (unsigned int)wp_count;
    wp_next[zT_236] = zT_235;
    zT_237 = (unsigned int)ft_id;
    wp_head[zT_237] = wp_count;
    zT_238 = 1;
    zT_239 = wp_count + zT_238;
    wp_count = zT_239;
    wp_count = zT_239;
    goto z_bb_56;
    z_bb_56:
    goto z_bb_53;
    z_bb_57:
    zT_240 = ft.kind;
    zT_243 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_244 = zT_240 == zT_243;
    if (zT_244) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_245 = perm_alloc;
    zT_250 = &wp_to;
    zT_246 = zT_250;
    zT_251 = &wp_next;
    zT_247 = zT_251;
    zT_252 = &wp_edge_cap;
    zT_248 = zT_252;
    zT_249 = wp_count;
    zF_25C377BD_growWpEdges(zT_245, zT_246, zT_247, zT_248, zT_249);
    zT_253 = (unsigned int)ti;
    zT_254 = (unsigned int)wp_count;
    wp_to[zT_254] = zT_253;
    zT_255 = (unsigned int)ft_id;
    zT_256 = wp_head[zT_255];
    zT_257 = (unsigned int)wp_count;
    wp_next[zT_257] = zT_256;
    zT_258 = (unsigned int)ft_id;
    wp_head[zT_258] = wp_count;
    zT_259 = 1;
    zT_260 = wp_count + zT_259;
    wp_count = zT_260;
    wp_count = zT_260;
    goto z_bb_59;
    z_bb_59:
    goto z_bb_56;
    z_bb_60:
    zT_269 = self->registry;
    zT_270 = zT_269->un_items;
    zT_271 = ty.payload_idx;
    zT_272 = (unsigned int)zT_271;
    zT_273 = zT_270[zT_272];
    up = zT_273;
    up = zT_273;
    up = zT_273;
    zT_275 = 0;
    zT_276 = (unsigned int)zT_275;
    fi = zT_276;
    fi = zT_276;
    fi = zT_276;
    goto z_bb_63;
    z_bb_61:
    goto z_bb_43;
    z_bb_62:
    zT_344 = ty.kind;
    zT_347 = zT_33EF6BFB_TypeKind_array_type;
    zT_348 = zT_344 == zT_347;
    if (zT_348) goto z_bb_78; else goto z_bb_80;
    z_bb_63:
    zT_277 = up.fields_count;
    zT_278 = (unsigned int)zT_277;
    zT_279 = fi < zT_278;
    if (zT_279) goto z_bb_67; else goto z_bb_68;
    z_bb_64:
    zT_284 = self->registry;
    zT_285 = zT_284->fe_items;
    zT_286 = up.fields_start;
    zT_287 = (unsigned int)zT_286;
    zT_288 = zT_287 + fi;
    zT_289 = zT_285[zT_288];
    zT_290 = zT_289.type_id;
    ft_id = zT_290;
    ft_id = zT_290;
    ft_id = zT_290;
    zT_292 = self->registry;
    zT_293 = zT_292->types_items;
    zT_294 = (unsigned int)ft_id;
    zT_295 = zT_293[zT_294];
    ft = zT_295;
    ft = zT_295;
    ft = zT_295;
    zT_297 = ft.kind;
    zT_296 = zT_297;
    zT_298 = zF_A47239A9_fieldEmbedsByValue(zT_296);
    if (zT_298) goto z_bb_70; else goto z_bb_72;
    z_bb_65:
    goto z_bb_61;
    z_bb_66:
    zT_342 = 1;
    zT_343 = fi + zT_342;
    fi = zT_343;
    fi = zT_343;
    goto z_bb_63;
    z_bb_67:
    zT_281 = 0;
    zT_282 = is_po != zT_281;
    zT_280 = zT_282;
    goto z_bb_69;
    z_bb_68:
    zT_280 = 0;
    goto z_bb_69;
    z_bb_69:
    if (zT_280) goto z_bb_64; else goto z_bb_65;
    z_bb_70:
    zT_299 = 0;
    is_po = zT_299;
    is_po = zT_299;
    goto z_bb_71;
    z_bb_71:
    goto z_bb_66;
    z_bb_72:
    zT_300 = ft.kind;
    zT_303 = zT_33EF6BFB_TypeKind_optional_type;
    zT_304 = zT_300 == zT_303;
    if (zT_304) goto z_bb_73; else goto z_bb_75;
    z_bb_73:
    zT_305 = perm_alloc;
    zT_310 = &wp_to;
    zT_306 = zT_310;
    zT_311 = &wp_next;
    zT_307 = zT_311;
    zT_312 = &wp_edge_cap;
    zT_308 = zT_312;
    zT_309 = wp_count;
    zF_25C377BD_growWpEdges(zT_305, zT_306, zT_307, zT_308, zT_309);
    zT_313 = (unsigned int)ti;
    zT_314 = (unsigned int)wp_count;
    wp_to[zT_314] = zT_313;
    zT_315 = (unsigned int)ft_id;
    zT_316 = wp_head[zT_315];
    zT_317 = (unsigned int)wp_count;
    wp_next[zT_317] = zT_316;
    zT_318 = (unsigned int)ft_id;
    wp_head[zT_318] = wp_count;
    zT_319 = 1;
    zT_320 = wp_count + zT_319;
    wp_count = zT_320;
    wp_count = zT_320;
    goto z_bb_74;
    z_bb_74:
    goto z_bb_71;
    z_bb_75:
    zT_321 = ft.kind;
    zT_324 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_325 = zT_321 == zT_324;
    if (zT_325) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_326 = perm_alloc;
    zT_331 = &wp_to;
    zT_327 = zT_331;
    zT_332 = &wp_next;
    zT_328 = zT_332;
    zT_333 = &wp_edge_cap;
    zT_329 = zT_333;
    zT_330 = wp_count;
    zF_25C377BD_growWpEdges(zT_326, zT_327, zT_328, zT_329, zT_330);
    zT_334 = (unsigned int)ti;
    zT_335 = (unsigned int)wp_count;
    wp_to[zT_335] = zT_334;
    zT_336 = (unsigned int)ft_id;
    zT_337 = wp_head[zT_336];
    zT_338 = (unsigned int)wp_count;
    wp_next[zT_338] = zT_337;
    zT_339 = (unsigned int)ft_id;
    wp_head[zT_339] = wp_count;
    zT_340 = 1;
    zT_341 = wp_count + zT_340;
    wp_count = zT_341;
    wp_count = zT_341;
    goto z_bb_77;
    z_bb_77:
    goto z_bb_74;
    z_bb_78:
    zT_350 = self->registry;
    zT_351 = zT_350->array_items;
    zT_352 = ty.payload_idx;
    zT_353 = (unsigned int)zT_352;
    zT_354 = zT_351[zT_353];
    zT_355 = zT_354.elem;
    et = zT_355;
    et = zT_355;
    et = zT_355;
    zT_357 = self->registry;
    zT_358 = zT_357->types_items;
    zT_359 = (unsigned int)et;
    zT_360 = zT_358[zT_359];
    et_ty = zT_360;
    et_ty = zT_360;
    et_ty = zT_360;
    zT_362 = et_ty.kind;
    zT_361 = zT_362;
    zT_363 = zF_A47239A9_fieldEmbedsByValue(zT_361);
    if (zT_363) goto z_bb_81; else goto z_bb_83;
    z_bb_79:
    goto z_bb_61;
    z_bb_80:
    zT_407 = ty.kind;
    zT_410 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_411 = zT_407 == zT_410;
    if (zT_411) goto z_bb_89; else goto z_bb_91;
    z_bb_81:
    zT_364 = 0;
    is_po = zT_364;
    is_po = zT_364;
    goto z_bb_82;
    z_bb_82:
    goto z_bb_79;
    z_bb_83:
    zT_365 = et_ty.kind;
    zT_368 = zT_33EF6BFB_TypeKind_optional_type;
    zT_369 = zT_365 == zT_368;
    if (zT_369) goto z_bb_84; else goto z_bb_86;
    z_bb_84:
    zT_370 = perm_alloc;
    zT_375 = &wp_to;
    zT_371 = zT_375;
    zT_376 = &wp_next;
    zT_372 = zT_376;
    zT_377 = &wp_edge_cap;
    zT_373 = zT_377;
    zT_374 = wp_count;
    zF_25C377BD_growWpEdges(zT_370, zT_371, zT_372, zT_373, zT_374);
    zT_378 = (unsigned int)ti;
    zT_379 = (unsigned int)wp_count;
    wp_to[zT_379] = zT_378;
    zT_380 = (unsigned int)et;
    zT_381 = wp_head[zT_380];
    zT_382 = (unsigned int)wp_count;
    wp_next[zT_382] = zT_381;
    zT_383 = (unsigned int)et;
    wp_head[zT_383] = wp_count;
    zT_384 = 1;
    zT_385 = wp_count + zT_384;
    wp_count = zT_385;
    wp_count = zT_385;
    goto z_bb_85;
    z_bb_85:
    goto z_bb_82;
    z_bb_86:
    zT_386 = et_ty.kind;
    zT_389 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_390 = zT_386 == zT_389;
    if (zT_390) goto z_bb_87; else goto z_bb_88;
    z_bb_87:
    zT_391 = perm_alloc;
    zT_396 = &wp_to;
    zT_392 = zT_396;
    zT_397 = &wp_next;
    zT_393 = zT_397;
    zT_398 = &wp_edge_cap;
    zT_394 = zT_398;
    zT_395 = wp_count;
    zF_25C377BD_growWpEdges(zT_391, zT_392, zT_393, zT_394, zT_395);
    zT_399 = (unsigned int)ti;
    zT_400 = (unsigned int)wp_count;
    wp_to[zT_400] = zT_399;
    zT_401 = (unsigned int)et;
    zT_402 = wp_head[zT_401];
    zT_403 = (unsigned int)wp_count;
    wp_next[zT_403] = zT_402;
    zT_404 = (unsigned int)et;
    wp_head[zT_404] = wp_count;
    zT_405 = 1;
    zT_406 = wp_count + zT_405;
    wp_count = zT_406;
    wp_count = zT_406;
    goto z_bb_88;
    z_bb_88:
    goto z_bb_85;
    z_bb_89:
    zT_413 = self->registry;
    zT_414 = zT_413->eu_items;
    zT_415 = ty.payload_idx;
    zT_416 = (unsigned int)zT_415;
    zT_417 = zT_414[zT_416];
    zT_418 = zT_417.payload;
    eup = zT_418;
    eup = zT_418;
    eup = zT_418;
    zT_420 = self->registry;
    zT_421 = zT_420->types_items;
    zT_422 = (unsigned int)eup;
    zT_423 = zT_421[zT_422];
    eup_ty = zT_423;
    eup_ty = zT_423;
    eup_ty = zT_423;
    zT_425 = eup_ty.kind;
    zT_424 = zT_425;
    zT_426 = zF_A47239A9_fieldEmbedsByValue(zT_424);
    if (zT_426) goto z_bb_92; else goto z_bb_94;
    z_bb_90:
    goto z_bb_79;
    z_bb_91:
    zT_470 = ty.kind;
    zT_473 = zT_33EF6BFB_TypeKind_optional_type;
    zT_474 = zT_470 == zT_473;
    if (zT_474) goto z_bb_100; else goto z_bb_101;
    z_bb_92:
    zT_427 = 0;
    is_po = zT_427;
    is_po = zT_427;
    goto z_bb_93;
    z_bb_93:
    goto z_bb_90;
    z_bb_94:
    zT_428 = eup_ty.kind;
    zT_431 = zT_33EF6BFB_TypeKind_optional_type;
    zT_432 = zT_428 == zT_431;
    if (zT_432) goto z_bb_95; else goto z_bb_97;
    z_bb_95:
    zT_433 = perm_alloc;
    zT_438 = &wp_to;
    zT_434 = zT_438;
    zT_439 = &wp_next;
    zT_435 = zT_439;
    zT_440 = &wp_edge_cap;
    zT_436 = zT_440;
    zT_437 = wp_count;
    zF_25C377BD_growWpEdges(zT_433, zT_434, zT_435, zT_436, zT_437);
    zT_441 = (unsigned int)ti;
    zT_442 = (unsigned int)wp_count;
    wp_to[zT_442] = zT_441;
    zT_443 = (unsigned int)eup;
    zT_444 = wp_head[zT_443];
    zT_445 = (unsigned int)wp_count;
    wp_next[zT_445] = zT_444;
    zT_446 = (unsigned int)eup;
    wp_head[zT_446] = wp_count;
    zT_447 = 1;
    zT_448 = wp_count + zT_447;
    wp_count = zT_448;
    wp_count = zT_448;
    goto z_bb_96;
    z_bb_96:
    goto z_bb_93;
    z_bb_97:
    zT_449 = eup_ty.kind;
    zT_452 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_453 = zT_449 == zT_452;
    if (zT_453) goto z_bb_98; else goto z_bb_99;
    z_bb_98:
    zT_454 = perm_alloc;
    zT_459 = &wp_to;
    zT_455 = zT_459;
    zT_460 = &wp_next;
    zT_456 = zT_460;
    zT_461 = &wp_edge_cap;
    zT_457 = zT_461;
    zT_458 = wp_count;
    zF_25C377BD_growWpEdges(zT_454, zT_455, zT_456, zT_457, zT_458);
    zT_462 = (unsigned int)ti;
    zT_463 = (unsigned int)wp_count;
    wp_to[zT_463] = zT_462;
    zT_464 = (unsigned int)eup;
    zT_465 = wp_head[zT_464];
    zT_466 = (unsigned int)wp_count;
    wp_next[zT_466] = zT_465;
    zT_467 = (unsigned int)eup;
    wp_head[zT_467] = wp_count;
    zT_468 = 1;
    zT_469 = wp_count + zT_468;
    wp_count = zT_469;
    wp_count = zT_469;
    goto z_bb_99;
    z_bb_99:
    goto z_bb_96;
    z_bb_100:
    zT_476 = self->registry;
    zT_477 = zT_476->opt_items;
    zT_478 = ty.payload_idx;
    zT_479 = (unsigned int)zT_478;
    zT_480 = zT_477[zT_479];
    zT_481 = zT_480.payload;
    op_p = zT_481;
    op_p = zT_481;
    op_p = zT_481;
    zT_483 = self->registry;
    zT_484 = zT_483->types_items;
    zT_485 = (unsigned int)op_p;
    zT_486 = zT_484[zT_485];
    op_ty = zT_486;
    op_ty = zT_486;
    op_ty = zT_486;
    zT_488 = op_ty.kind;
    zT_487 = zT_488;
    zT_489 = zF_EA3ED3F3_requiresFullDef(zT_487);
    if (zT_489) goto z_bb_102; else goto z_bb_104;
    z_bb_101:
    goto z_bb_90;
    z_bb_102:
    zT_490 = 0;
    is_po = zT_490;
    is_po = zT_490;
    goto z_bb_103;
    z_bb_103:
    goto z_bb_101;
    z_bb_104:
    zT_491 = op_ty.kind;
    zT_494 = zT_33EF6BFB_TypeKind_optional_type;
    zT_495 = zT_491 == zT_494;
    if (zT_495) goto z_bb_105; else goto z_bb_107;
    z_bb_105:
    zT_496 = perm_alloc;
    zT_501 = &wp_to;
    zT_497 = zT_501;
    zT_502 = &wp_next;
    zT_498 = zT_502;
    zT_503 = &wp_edge_cap;
    zT_499 = zT_503;
    zT_500 = wp_count;
    zF_25C377BD_growWpEdges(zT_496, zT_497, zT_498, zT_499, zT_500);
    zT_504 = (unsigned int)ti;
    zT_505 = (unsigned int)wp_count;
    wp_to[zT_505] = zT_504;
    zT_506 = (unsigned int)op_p;
    zT_507 = wp_head[zT_506];
    zT_508 = (unsigned int)wp_count;
    wp_next[zT_508] = zT_507;
    zT_509 = (unsigned int)op_p;
    wp_head[zT_509] = wp_count;
    zT_510 = 1;
    zT_511 = wp_count + zT_510;
    wp_count = zT_511;
    wp_count = zT_511;
    goto z_bb_106;
    z_bb_106:
    goto z_bb_103;
    z_bb_107:
    zT_512 = op_ty.kind;
    zT_515 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_516 = zT_512 == zT_515;
    if (zT_516) goto z_bb_108; else goto z_bb_109;
    z_bb_108:
    zT_517 = perm_alloc;
    zT_522 = &wp_to;
    zT_518 = zT_522;
    zT_523 = &wp_next;
    zT_519 = zT_523;
    zT_524 = &wp_edge_cap;
    zT_520 = zT_524;
    zT_521 = wp_count;
    zF_25C377BD_growWpEdges(zT_517, zT_518, zT_519, zT_520, zT_521);
    zT_525 = (unsigned int)ti;
    zT_526 = (unsigned int)wp_count;
    wp_to[zT_526] = zT_525;
    zT_527 = (unsigned int)op_p;
    zT_528 = wp_head[zT_527];
    zT_529 = (unsigned int)wp_count;
    wp_next[zT_529] = zT_528;
    zT_530 = (unsigned int)op_p;
    wp_head[zT_530] = wp_count;
    zT_531 = 1;
    zT_532 = wp_count + zT_531;
    wp_count = zT_532;
    wp_count = zT_532;
    goto z_bb_109;
    z_bb_109:
    goto z_bb_106;
    z_bb_110:
    zT_535 = (unsigned int)ti;
    zT_536 = (unsigned int)wl_tail;
    worklist[zT_536] = zT_535;
    zT_537 = 1;
    zT_538 = wl_tail + zT_537;
    wl_tail = zT_538;
    wl_tail = zT_538;
    goto z_bb_111;
    z_bb_111:
    goto z_bb_23;
    z_bb_112:
    zT_541 = wl_head < wl_tail;
    if (zT_541) goto z_bb_113; else goto z_bb_114;
    z_bb_113:
    zT_543 = (unsigned int)wl_head;
    zT_544 = worklist[zT_543];
    cur = zT_544;
    cur = zT_544;
    cur = zT_544;
    zT_545 = 1;
    zT_546 = wl_head + zT_545;
    wl_head = zT_546;
    wl_head = zT_546;
    zT_548 = (unsigned int)cur;
    zT_549 = wp_head[zT_548];
    e = zT_549;
    e = zT_549;
    e = zT_549;
    goto z_bb_116;
    z_bb_114:
    zT_567 = perm_alloc;
    zT_570 = 4;
    zT_571 = zT_570 * tl;
    zT_568 = zT_571;
    zT_572 = 4;
    zT_573 = (unsigned int)zT_572;
    zT_569 = zT_573;
    zT_574 = zF_1395EB68_sandAlloc(zT_567, zT_568, zT_569);
    zT_575 = zT_574.is_error;
    if (zT_575) goto z_bb_122; else goto z_bb_123;
    z_bb_115:
    goto z_bb_112;
    z_bb_116:
    zT_550 = 4294967295u;
    zT_551 = e != zT_550;
    if (zT_551) goto z_bb_117; else goto z_bb_118;
    z_bb_117:
    zT_553 = (unsigned int)e;
    zT_554 = wp_to[zT_553];
    parent_tid = zT_554;
    parent_tid = zT_554;
    parent_tid = zT_554;
    zT_555 = (unsigned int)parent_tid;
    zT_556 = pointer_only[zT_555];
    zT_557 = 0;
    zT_558 = zT_556 != zT_557;
    if (zT_558) goto z_bb_120; else goto z_bb_121;
    z_bb_118:
    goto z_bb_115;
    z_bb_119:
    goto z_bb_116;
    z_bb_120:
    zT_559 = 0;
    zT_560 = (unsigned int)parent_tid;
    pointer_only[zT_560] = zT_559;
    zT_561 = (unsigned int)wl_tail;
    worklist[zT_561] = parent_tid;
    zT_562 = 1;
    zT_563 = wl_tail + zT_562;
    wl_tail = zT_563;
    wl_tail = zT_563;
    goto z_bb_121;
    z_bb_121:
    zT_564 = (unsigned int)e;
    zT_565 = wp_next[zT_564];
    e = zT_565;
    e = zT_565;
    goto z_bb_119;
    z_bb_122:
    z_bb_123:
    zT_577 = zT_574.data.payload;
    zT_576 = zT_577;
    goto z_bb_124;
    z_bb_124:
    ids_raw = zT_576;
    ids_raw = zT_576;
    ids_raw = zT_576;
    zT_579 = (unsigned int*)ids_raw;
    ids = zT_579;
    ids = zT_579;
    ids = zT_579;
    zT_581 = 0;
    plen = zT_581;
    plen = zT_581;
    plen = zT_581;
    zT_582 = 0;
    zT_583 = (unsigned int)zT_582;
    ti = zT_583;
    ti = zT_583;
    goto z_bb_125;
    z_bb_125:
    zT_584 = ti < tl;
    if (zT_584) goto z_bb_126; else goto z_bb_127;
    z_bb_126:
    zT_585 = pointer_only[ti];
    zT_586 = 0;
    zT_587 = zT_585 != zT_586;
    if (zT_587) goto z_bb_129; else goto z_bb_130;
    z_bb_127:
    zT_595 = "CLS:c";
    zT_597 = 5;
    zT_596.ptr = zT_595;
    zT_596.len = zT_597;
    cls_m = zT_596;
    cls_m = zT_596;
    cls_m = zT_596;
    zT_598 = cls_m;
    zF_48AC7B3A_markerWrite(zT_598);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_600[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        cls_b[_i] = zT_600[_i];
        _i++;
    }
}
    zT_602 = plen;
    zT_604 = (unsigned char*)cls_b;
    zT_605 = 10;
    zT_606 = 0;
    zT_607 = zT_604 + zT_606;
    zT_608 = zT_605 - zT_606;
    zT_609.ptr = zT_607;
    zT_609.len = zT_608;
    zT_603 = zT_609;
    zT_610 = zF_A7504564_itoa(zT_602, zT_603);
    cls_l = zT_610;
    cls_l = zT_610;
    cls_l = zT_610;
    zT_612 = 9;
    zT_613 = (unsigned int)cls_l;
    zT_614 = zT_612 - zT_613;
    cls_s = zT_614;
    cls_s = zT_614;
    cls_s = zT_614;
    zT_616 = (unsigned char*)cls_b;
    zT_618 = 9;
    zT_619 = zT_616 + cls_s;
    zT_620 = zT_618 - cls_s;
    zT_621.ptr = zT_619;
    zT_621.len = zT_620;
    zT_615 = zT_621;
    zF_48AC7B3A_markerWrite(zT_615);
    zT_623 = "\n";
    zT_625 = 1;
    zT_624.ptr = zT_623;
    zT_624.len = zT_625;
    cls_nl = zT_624;
    cls_nl = zT_624;
    cls_nl = zT_624;
    zT_626 = cls_nl;
    zF_48AC7B3A_markerWrite(zT_626);
    zT_627 = 0;
    zT_628 = (unsigned int)zT_627;
    ti = zT_628;
    ti = zT_628;
    goto z_bb_131;
    z_bb_128:
    zT_592 = 1;
    zT_593 = ti + zT_592;
    ti = zT_593;
    ti = zT_593;
    goto z_bb_125;
    z_bb_129:
    zT_588 = (unsigned int)ti;
    zT_589 = (unsigned int)plen;
    ids[zT_589] = zT_588;
    zT_590 = 1;
    zT_591 = plen + zT_590;
    plen = zT_591;
    plen = zT_591;
    goto z_bb_130;
    z_bb_130:
    goto z_bb_128;
    z_bb_131:
    zT_629 = ti < tl;
    if (zT_629) goto z_bb_132; else goto z_bb_133;
    z_bb_132:
    zT_630 = pointer_only[ti];
    zT_631 = 0;
    zT_632 = zT_630 != zT_631;
    if (zT_632) goto z_bb_135; else goto z_bb_137;
    z_bb_133:
    zT_707.ids = ids;
    zT_707.len = plen;
    return zT_707;
    z_bb_134:
    zT_705 = 1;
    zT_706 = ti + zT_705;
    ti = zT_706;
    ti = zT_706;
    goto z_bb_131;
    z_bb_135:
    zT_634 = "CLS:p";
    zT_636 = 5;
    zT_635.ptr = zT_634;
    zT_635.len = zT_636;
    pfx = zT_635;
    pfx = zT_635;
    pfx = zT_635;
    zT_637 = pfx;
    zF_48AC7B3A_markerWrite(zT_637);
    goto z_bb_136;
    z_bb_136:
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_644[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ctb[_i] = zT_644[_i];
        _i++;
    }
}
    zT_648 = (unsigned int)ti;
    zT_646 = zT_648;
    zT_649 = (unsigned char*)ctb;
    zT_650 = 10;
    zT_651 = 0;
    zT_652 = zT_649 + zT_651;
    zT_653 = zT_650 - zT_651;
    zT_654.ptr = zT_652;
    zT_654.len = zT_653;
    zT_647 = zT_654;
    zT_655 = zF_A7504564_itoa(zT_646, zT_647);
    ctl = zT_655;
    ctl = zT_655;
    ctl = zT_655;
    zT_657 = 9;
    zT_658 = (unsigned int)ctl;
    zT_659 = zT_657 - zT_658;
    cts = zT_659;
    cts = zT_659;
    cts = zT_659;
    zT_661 = (unsigned char*)ctb;
    zT_663 = 9;
    zT_664 = zT_661 + cts;
    zT_665 = zT_663 - cts;
    zT_666.ptr = zT_664;
    zT_666.len = zT_665;
    zT_660 = zT_666;
    zF_48AC7B3A_markerWrite(zT_660);
    zT_668 = "k";
    zT_670 = 1;
    zT_669.ptr = zT_668;
    zT_669.len = zT_670;
    ck = zT_669;
    ck = zT_669;
    ck = zT_669;
    zT_671 = ck;
    zF_48AC7B3A_markerWrite(zT_671);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_673[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ckb[_i] = zT_673[_i];
        _i++;
    }
}
    zT_677 = self->registry;
    zT_678 = zT_677->types_items;
    zT_679 = zT_678[ti];
    zT_680 = zT_679.kind;
    zT_681 = (unsigned int)zT_680;
    zT_675 = zT_681;
    zT_682 = (unsigned char*)ckb;
    zT_683 = 10;
    zT_684 = 0;
    zT_685 = zT_682 + zT_684;
    zT_686 = zT_683 - zT_684;
    zT_687.ptr = zT_685;
    zT_687.len = zT_686;
    zT_676 = zT_687;
    zT_688 = zF_A7504564_itoa(zT_675, zT_676);
    ckl = zT_688;
    ckl = zT_688;
    ckl = zT_688;
    zT_690 = 9;
    zT_691 = (unsigned int)ckl;
    zT_692 = zT_690 - zT_691;
    cks = zT_692;
    cks = zT_692;
    cks = zT_692;
    zT_694 = (unsigned char*)ckb;
    zT_696 = 9;
    zT_697 = zT_694 + cks;
    zT_698 = zT_696 - cks;
    zT_699.ptr = zT_697;
    zT_699.len = zT_698;
    zT_693 = zT_699;
    zF_48AC7B3A_markerWrite(zT_693);
    zT_701 = "\n";
    zT_703 = 1;
    zT_702.ptr = zT_701;
    zT_702.len = zT_703;
    cnl = zT_702;
    cnl = zT_702;
    cnl = zT_702;
    zT_704 = cnl;
    zF_48AC7B3A_markerWrite(zT_704);
    goto z_bb_134;
    z_bb_137:
    zT_639 = "CLS:v";
    zT_641 = 5;
    zT_640.ptr = zT_639;
    zT_640.len = zT_641;
    pfx = zT_640;
    pfx = zT_640;
    pfx = zT_640;
    zT_642 = pfx;
    zF_48AC7B3A_markerWrite(zT_642);
    goto z_bb_136;
}

/* growWpEdges */
void zF_25C377BD_growWpEdges(zT_3E40CD83_Sand* perm_a, unsigned int** wp_to_ptr, unsigned int** wp_next_ptr, unsigned int* cap_ptr, unsigned int count) {
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7;
    unsigned int zT_9;
    int zT_11;
    unsigned int zT_12;
    zT_3E40CD83_Sand* zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    int zT_17;
    unsigned int zT_18;
    int zT_19;
    unsigned int zT_20;
    zT_A62CFBCC_EU_022 zT_21 = {0};
    unsigned char zT_22;
    unsigned char* zT_23;
    unsigned char* zT_24;
    zT_3E40CD83_Sand* zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    int zT_29;
    unsigned int zT_30;
    int zT_31;
    unsigned int zT_32;
    zT_A62CFBCC_EU_022 zT_33 = {0};
    unsigned char zT_34;
    unsigned char* zT_35;
    unsigned char* zT_36;
    unsigned int* zT_38;
    unsigned int* zT_40;
    int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    int zT_45;
    unsigned int* zT_46;
    unsigned int zT_47;
    unsigned int* zT_48;
    unsigned int zT_49;
    int zT_50;
    unsigned int zT_51;
    unsigned int old_cap;
    unsigned int new_cap;
    unsigned char* new_to_raw;
    unsigned char* new_nx_raw;
    unsigned int* new_to;
    unsigned int* new_nx;
    unsigned int ci;
    zT_5 = (unsigned int)count;
    zT_6 = *cap_ptr;
    zT_7 = zT_5 < zT_6;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_9 = *cap_ptr;
    old_cap = zT_9;
    old_cap = zT_9;
    old_cap = zT_9;
    zT_11 = 2;
    zT_12 = old_cap * zT_11;
    new_cap = zT_12;
    new_cap = zT_12;
    new_cap = zT_12;
    zT_14 = perm_a;
    zT_17 = 4;
    zT_18 = zT_17 * new_cap;
    zT_15 = zT_18;
    zT_19 = 4;
    zT_20 = (unsigned int)zT_19;
    zT_16 = zT_20;
    zT_21 = zF_1395EB68_sandAlloc(zT_14, zT_15, zT_16);
    zT_22 = zT_21.is_error;
    if (zT_22) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    z_bb_4:
    zT_24 = zT_21.data.payload;
    zT_23 = zT_24;
    goto z_bb_5;
    z_bb_5:
    new_to_raw = zT_23;
    new_to_raw = zT_23;
    new_to_raw = zT_23;
    zT_26 = perm_a;
    zT_29 = 4;
    zT_30 = zT_29 * new_cap;
    zT_27 = zT_30;
    zT_31 = 4;
    zT_32 = (unsigned int)zT_31;
    zT_28 = zT_32;
    zT_33 = zF_1395EB68_sandAlloc(zT_26, zT_27, zT_28);
    zT_34 = zT_33.is_error;
    if (zT_34) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    z_bb_7:
    zT_36 = zT_33.data.payload;
    zT_35 = zT_36;
    goto z_bb_8;
    z_bb_8:
    new_nx_raw = zT_35;
    new_nx_raw = zT_35;
    new_nx_raw = zT_35;
    zT_38 = (unsigned int*)new_to_raw;
    new_to = zT_38;
    new_to = zT_38;
    new_to = zT_38;
    zT_40 = (unsigned int*)new_nx_raw;
    new_nx = zT_40;
    new_nx = zT_40;
    new_nx = zT_40;
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    ci = zT_43;
    ci = zT_43;
    ci = zT_43;
    goto z_bb_9;
    z_bb_9:
    zT_44 = (unsigned int)count;
    zT_45 = ci < zT_44;
    if (zT_45) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_46 = *wp_to_ptr;
    zT_47 = zT_46[ci];
    new_to[ci] = zT_47;
    zT_48 = *wp_next_ptr;
    zT_49 = zT_48[ci];
    new_nx[ci] = zT_49;
    goto z_bb_12;
    z_bb_11:
    *wp_to_ptr = new_to;
    *wp_next_ptr = new_nx;
    *cap_ptr = new_cap;
    return;
    z_bb_12:
    zT_50 = 1;
    zT_51 = ci + zT_50;
    ci = zT_51;
    ci = zT_51;
    goto z_bb_9;
}

/* typeResolverGetSorted */
zT_3CB0179A_Slice_zT_05F374B1_u zF_026BA788_typeResolverGetSort(zT_C890C8CB_TypeResolver* self) {
    unsigned int* zT_1;
    unsigned int zT_2;
    int zT_3;
    unsigned int* zT_4;
    unsigned int zT_5;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_6;
    zT_1 = self->sorted_items;
    zT_2 = self->sorted_len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* evalConstU32Full */
unsigned int zF_6D0DD27D_evalConstU32Full(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx) {
    unsigned int zT_2;
    int zT_3;
    unsigned int zT_4;
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_6B0A7D14_AstStore* zT_8;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_8143F551_AstKind zT_13;
    int zT_14;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_17;
    zT_79FAE712_u64 zT_18 = 0;
    unsigned int zT_19;
    zT_8143F551_AstKind zT_20;
    zT_8143F551_AstKind zT_23;
    int zT_24;
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_28;
    unsigned int zT_29 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_31;
    unsigned int zT_32;
    zT_E68301A1_Opt_804 zT_33 = {0};
    unsigned char zT_34;
    unsigned short zT_36;
    unsigned short zT_37;
    unsigned short zT_38;
    unsigned short zT_39;
    int zT_40;
    zT_6B0A7D14_AstStore* zT_42;
    unsigned int zT_43;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_45;
    zT_22A7C88B_AstNode zT_46 = {0};
    unsigned int zT_47;
    int zT_48;
    int zT_49;
    zT_ABC1EBBE_TypeResolveEnv* zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int zT_54;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    zT_E68301A1_Opt_804 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    z_bb_0:
    zT_2 = 0;
    zT_3 = node_idx == zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = 4294967295u;
    return zT_4;
    z_bb_2:
    zT_8 = env->store;
    zT_6 = zT_8;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    node = zT_9;
    node = zT_9;
    zT_10 = node.kind;
    zT_13 = zT_8143F551_AstKind_int_literal;
    zT_14 = zT_10 == zT_13;
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = env->store;
    zT_15 = zT_17;
    zT_16 = node_idx;
    zT_18 = zF_678B9A72_astStoreIntValue(zT_15, zT_16);
    zT_19 = __bootstrap_u32_from_u64(zT_18);
    return zT_19;
    z_bb_4:
    zT_20 = node.kind;
    zT_23 = zT_8143F551_AstKind_ident_expr;
    zT_24 = zT_20 == zT_23;
    if (zT_24) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_28 = env->store;
    zT_26 = zT_28;
    zT_27 = node_idx;
    zT_29 = zF_53458827_astStoreIdentifier(zT_26, zT_27);
    name_id = zT_29;
    name_id = zT_29;
    name_id = zT_29;
    zT_31 = env;
    zT_32 = name_id;
    zT_33 = zF_04FED007_symbolLookupAllModu(zT_31, zT_32);
    c_sym = zT_33;
    c_sym = zT_33;
    c_sym = zT_33;
    zT_34 = c_sym.has_value;
    if (zT_34) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_54 = 4294967295u;
    return zT_54;
    z_bb_7:
    cs = c_sym.value;
    zT_36 = cs->flags;
    zT_37 = 1;
    zT_38 = zT_36 & zT_37;
    zT_39 = 0;
    zT_40 = zT_38 == zT_39;
    if (zT_40) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_44 = env->store;
    zT_42 = zT_44;
    zT_45 = cs->decl_node;
    zT_43 = zT_45;
    zT_46 = zF_FCDD1D35_astStoreNodeAt(zT_42, zT_43);
    c_decl = zT_46;
    c_decl = zT_46;
    c_decl = zT_46;
    zT_47 = c_decl.child_1;
    zT_48 = 0;
    zT_49 = zT_47 != (unsigned int)zT_48;
    if (zT_49) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    zT_50 = env;
    zT_52 = c_decl.child_1;
    zT_51 = zT_52;
    env = zT_50;
    node_idx = zT_51;
    goto z_bb_0;
    z_bb_12:
    goto z_bb_10;
}

/* symbolLookupAllModules */
zT_E68301A1_Opt_804 zF_04FED007_symbolLookupAllModu(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int name_id) {
    int zT_3;
    unsigned int zT_4;
    zT_3D7259E2_SymbolRegistry* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_8;
    zT_3D7259E2_SymbolRegistry* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_3D7259E2_SymbolRegistry* zT_13;
    unsigned int zT_14;
    zT_E68301A1_Opt_804 zT_15 = {0};
    unsigned char zT_16;
    int zT_17;
    unsigned int zT_18;
    zT_E68301A1_Opt_804 zT_19 = {0};
    unsigned int si;
    zT_E68301A1_Opt_804 sym;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    si = zT_4;
    si = zT_4;
    si = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = env->symbol_reg;
    zT_6 = zT_5->tables_len;
    zT_7 = (unsigned int)zT_6;
    zT_8 = si < zT_7;
    if (zT_8) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_13 = env->symbol_reg;
    zT_10 = zT_13;
    zT_14 = (unsigned int)si;
    zT_11 = zT_14;
    zT_12 = name_id;
    zT_15 = zF_A398987E_symbolRegistryQuali(zT_10, zT_11, zT_12);
    sym = zT_15;
    sym = zT_15;
    sym = zT_15;
    zT_16 = sym.has_value;
    if (zT_16) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_19.has_value = 0;
    return zT_19;
    z_bb_4:
    zT_17 = 1;
    zT_18 = si + zT_17;
    si = zT_18;
    si = zT_18;
    goto z_bb_1;
    z_bb_5:
    return sym;
    z_bb_6:
    goto z_bb_4;
}

/* resolveTypeExprFull */
unsigned int zF_F2107C15_resolveTypeExprFull(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    unsigned int zT_3;
    int zT_4;
    unsigned int zT_5;
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_9;
    zT_22A7C88B_AstNode zT_10 = {0};
    char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned int zT_22;
    zT_8143F551_AstKind zT_23;
    unsigned int zT_24;
    zT_8143F551_AstKind zT_25;
    zT_8143F551_AstKind zT_28;
    int zT_29;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34 = 0;
    char* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned int zT_40;
    zT_D3EB6303_StringInterner* zT_42;
    unsigned int zT_43;
    zT_D3EB6303_StringInterner* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45 = {0};
    zT_D3EB6303_StringInterner* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    zT_D3EB6303_StringInterner* zT_49;
    unsigned int zT_50 = 0;
    unsigned int zT_51;
    int zT_53;
    unsigned int zT_55;
    zT_79FAE712_u64 zT_56;
    zT_79FAE712_u64 zT_57;
    zT_79FAE712_u64 zT_58;
    zT_79FAE712_u64 zT_59;
    zT_79FAE712_u64 zT_60;
    zT_338B7C76_TypeRegistry* zT_62;
    zT_79FAE712_u64 zT_63;
    zT_338B7C76_TypeRegistry* zT_64;
    zT_BAEE192E_Opt_10 zT_65 = {0};
    unsigned char zT_66;
    zT_338B7C76_TypeRegistry* zT_69;
    zT_79FAE712_u64 zT_70;
    zT_338B7C76_TypeRegistry* zT_71;
    zT_79FAE712_u64 zT_72;
    zT_BAEE192E_Opt_10 zT_73 = {0};
    char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    unsigned int zT_79;
    unsigned char zT_80;
    char* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    int zT_88;
    unsigned int zT_89;
    zT_3D7259E2_SymbolRegistry* zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    int zT_93;
    zT_79FAE712_u64 zT_95;
    zT_79FAE712_u64 zT_96;
    zT_79FAE712_u64 zT_97;
    zT_79FAE712_u64 zT_98;
    zT_79FAE712_u64 zT_99;
    zT_338B7C76_TypeRegistry* zT_101;
    zT_79FAE712_u64 zT_102;
    zT_338B7C76_TypeRegistry* zT_103;
    zT_BAEE192E_Opt_10 zT_104 = {0};
    unsigned char zT_105;
    int zT_107;
    unsigned int zT_108;
    char* zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    int zT_116;
    zT_3D7259E2_SymbolRegistry* zT_118;
    unsigned int zT_119;
    unsigned int zT_120;
    zT_3D7259E2_SymbolRegistry* zT_121;
    unsigned int zT_122;
    zT_E68301A1_Opt_804 zT_123 = {0};
    unsigned char zT_124;
    unsigned int zT_126;
    unsigned int zT_127;
    int zT_128;
    unsigned int zT_129;
    int zT_131;
    unsigned int zT_132;
    zT_3D7259E2_SymbolRegistry* zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    int zT_136;
    zT_3D7259E2_SymbolRegistry* zT_138;
    unsigned int zT_139;
    unsigned int zT_140;
    zT_3D7259E2_SymbolRegistry* zT_141;
    unsigned int zT_142;
    zT_E68301A1_Opt_804 zT_143 = {0};
    unsigned char zT_144;
    unsigned int zT_146;
    unsigned int zT_147;
    int zT_148;
    char* zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned int zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    int zT_157;
    unsigned int zT_158;
    char* zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    unsigned int zT_165;
    zT_8143F551_AstKind zT_166;
    zT_8143F551_AstKind zT_169;
    int zT_170;
    zT_5826BFC7_Arr_unsigned_char_1 zT_172;
    unsigned int zT_174;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_175;
    unsigned char* zT_176;
    unsigned int zT_177;
    int zT_178;
    unsigned char* zT_179;
    unsigned int zT_180;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_181;
    unsigned int zT_182 = 0;
    unsigned int zT_184;
    unsigned int zT_185;
    unsigned int zT_186;
    zT_4428DEE2_Arr_unsigned_char_2 zT_188;
    unsigned char zT_189;
    int zT_190;
    unsigned char zT_191;
    int zT_192;
    unsigned char zT_193;
    int zT_194;
    unsigned char zT_195;
    int zT_196;
    unsigned char zT_197;
    int zT_198;
    int zT_200;
    unsigned int zT_201;
    unsigned int zT_202;
    int zT_203;
    unsigned int zT_204;
    unsigned char zT_205;
    unsigned int zT_206;
    unsigned int zT_207;
    int zT_208;
    unsigned int zT_209;
    unsigned int zT_211;
    unsigned int zT_212;
    unsigned int zT_213;
    zT_D3EB6303_StringInterner* zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    zT_D3EB6303_StringInterner* zT_217;
    unsigned char* zT_218;
    int zT_220;
    unsigned char* zT_221;
    unsigned int zT_222;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    unsigned int zT_224 = 0;
    zT_338B7C76_TypeRegistry* zT_226;
    zT_79FAE712_u64 zT_227;
    zT_338B7C76_TypeRegistry* zT_228;
    zT_79FAE712_u64 zT_229;
    zT_BAEE192E_Opt_10 zT_230 = {0};
    unsigned char zT_231;
    zT_338B7C76_TypeRegistry* zT_234;
    unsigned int zT_235;
    unsigned int zT_236;
    zT_33EF6BFB_TypeKind zT_237;
    zT_338B7C76_TypeRegistry* zT_238;
    unsigned int zT_239;
    zT_33EF6BFB_TypeKind zT_242;
    unsigned int zT_243 = 0;
    zT_6B0A7D14_AstStore* zT_244;
    unsigned int zT_245;
    zT_6B0A7D14_AstStore* zT_246;
    unsigned int zT_247 = 0;
    unsigned int zT_248;
    int zT_249;
    zT_6B0A7D14_AstStore* zT_251;
    unsigned int zT_252;
    zT_6B0A7D14_AstStore* zT_253;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_254 = {0};
    zT_9D2DA37C_Arr_unsigned_int_32 zT_256;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_258;
    int zT_260;
    unsigned int zT_261;
    int zT_263;
    unsigned int zT_264;
    unsigned int zT_266;
    int zT_267;
    int zT_268;
    unsigned int zT_269;
    int zT_270;
    zT_6B0A7D14_AstStore* zT_272;
    unsigned int zT_273;
    zT_6B0A7D14_AstStore* zT_274;
    unsigned int* zT_275;
    unsigned int zT_276;
    zT_22A7C88B_AstNode zT_277 = {0};
    zT_8143F551_AstKind zT_278;
    zT_8143F551_AstKind zT_281;
    int zT_282;
    zT_ABC1EBBE_TypeResolveEnv* zT_284;
    unsigned int zT_285;
    unsigned int zT_286;
    unsigned int zT_287;
    unsigned int zT_288;
    unsigned int zT_289;
    unsigned int zT_290 = 0;
    zT_6B0A7D14_AstStore* zT_291;
    unsigned int zT_292;
    zT_6B0A7D14_AstStore* zT_293;
    unsigned int* zT_294;
    unsigned int zT_295;
    unsigned int zT_296 = 0;
    int zT_297;
    unsigned int zT_298;
    unsigned int zT_299;
    int zT_300;
    unsigned int zT_301;
    unsigned int zT_302;
    int zT_303;
    zT_338B7C76_TypeRegistry* zT_305;
    unsigned int zT_306;
    unsigned int zT_307;
    int zT_309;
    unsigned int zT_310;
    int zT_311;
    zT_338B7C76_TypeRegistry* zT_312;
    zT_2DF01B61_FieldEntry zT_313;
    zT_338B7C76_TypeRegistry* zT_314;
    zT_2DF01B61_FieldEntry zT_315;
    unsigned int zT_316;
    unsigned int zT_317;
    unsigned int zT_318;
    int zT_319;
    unsigned int zT_320;
    zT_338B7C76_TypeRegistry* zT_321;
    zT_406493CE_StructPayload zT_322;
    zT_338B7C76_TypeRegistry* zT_323;
    zT_406493CE_StructPayload zT_324;
    unsigned int zT_325;
    unsigned short zT_326;
    zT_338B7C76_TypeRegistry* zT_328;
    unsigned int zT_329;
    unsigned int zT_330;
    unsigned int zT_331;
    unsigned int zT_332;
    zT_338B7C76_TypeRegistry* zT_334;
    zT_D155D06D_Type* zT_335;
    unsigned int zT_336;
    zT_D155D06D_Type zT_337;
    zT_338B7C76_TypeRegistry* zT_338;
    zT_D155D06D_Type* zT_339;
    unsigned int zT_340;
    zT_8143F551_AstKind zT_341;
    zT_8143F551_AstKind zT_344;
    int zT_345;
    unsigned char zT_347;
    zT_ABC1EBBE_TypeResolveEnv* zT_349;
    unsigned int zT_350;
    unsigned int zT_351;
    unsigned int zT_352;
    unsigned int zT_353;
    unsigned int zT_354;
    unsigned int zT_355 = 0;
    unsigned int zT_356;
    int zT_357;
    zT_6B0A7D14_AstStore* zT_359;
    unsigned int zT_360;
    zT_6B0A7D14_AstStore* zT_361;
    unsigned int zT_362;
    zT_22A7C88B_AstNode zT_363 = {0};
    zT_8143F551_AstKind zT_364;
    zT_8143F551_AstKind zT_367;
    int zT_368;
    zT_6B0A7D14_AstStore* zT_370;
    unsigned int zT_371;
    zT_6B0A7D14_AstStore* zT_372;
    unsigned int zT_373;
    unsigned int zT_374 = 0;
    int zT_376;
    unsigned int zT_377;
    zT_3D7259E2_SymbolRegistry* zT_378;
    unsigned int zT_379;
    unsigned int zT_380;
    int zT_381;
    zT_3D7259E2_SymbolRegistry* zT_383;
    unsigned int zT_384;
    unsigned int zT_385;
    zT_3D7259E2_SymbolRegistry* zT_386;
    unsigned int zT_387;
    zT_E68301A1_Opt_804 zT_388 = {0};
    unsigned char zT_389;
    zT_3C598AEF_SymbolKind zT_391;
    zT_3C598AEF_SymbolKind zT_394;
    int zT_395;
    unsigned int zT_397;
    zT_3D7259E2_SymbolRegistry* zT_399;
    unsigned int zT_400;
    unsigned int zT_401;
    zT_3D7259E2_SymbolRegistry* zT_402;
    zT_6B0A7D14_AstStore* zT_403;
    unsigned int zT_404;
    zT_6B0A7D14_AstStore* zT_405;
    unsigned int zT_406 = 0;
    zT_E68301A1_Opt_804 zT_407 = {0};
    unsigned char zT_408;
    unsigned int zT_410;
    unsigned int zT_411;
    int zT_412;
    unsigned char zT_413;
    char* zT_415;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_416;
    unsigned int zT_417;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_418;
    unsigned int zT_419;
    unsigned int zT_420;
    unsigned int zT_421;
    int zT_422;
    unsigned int zT_423;
    char* zT_425;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_426;
    unsigned int zT_427;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_428;
    unsigned int zT_429;
    unsigned int zT_430;
    unsigned int zT_431;
    zT_338B7C76_TypeRegistry* zT_433;
    zT_D155D06D_Type* zT_434;
    unsigned int zT_435;
    zT_D155D06D_Type zT_436;
    zT_33EF6BFB_TypeKind zT_437;
    zT_33EF6BFB_TypeKind zT_440;
    int zT_441;
    unsigned int zT_443;
    zT_3D7259E2_SymbolRegistry* zT_445;
    unsigned int zT_446;
    unsigned int zT_447;
    zT_3D7259E2_SymbolRegistry* zT_448;
    zT_6B0A7D14_AstStore* zT_449;
    unsigned int zT_450;
    zT_6B0A7D14_AstStore* zT_451;
    unsigned int zT_452 = 0;
    zT_E68301A1_Opt_804 zT_453 = {0};
    unsigned char zT_454;
    unsigned int zT_456;
    unsigned int zT_457;
    int zT_458;
    unsigned char zT_459;
    char* zT_461;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_462;
    unsigned int zT_463;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_464;
    unsigned int zT_465;
    unsigned int zT_466;
    unsigned int zT_467;
    unsigned char zT_468;
    int zT_469;
    char* zT_471;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_472;
    unsigned int zT_473;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_474;
    unsigned int zT_475;
    zT_8143F551_AstKind zT_476;
    zT_8143F551_AstKind zT_479;
    int zT_480;
    zT_939EE900_Arr_unsigned_int_1 zT_482;
    zT_338B7C76_TypeRegistry* zT_483;
    unsigned int zT_484;
    unsigned int zT_485;
    unsigned int zT_486;
    zT_EDD37787_Arr_unsigned_short_ zT_488;
    unsigned short zT_489;
    unsigned int zT_490;
    zT_6B0A7D14_AstStore* zT_491;
    unsigned int zT_492;
    zT_6B0A7D14_AstStore* zT_493;
    unsigned int zT_494 = 0;
    unsigned int zT_495;
    int zT_496;
    zT_6B0A7D14_AstStore* zT_498;
    unsigned int zT_499;
    zT_6B0A7D14_AstStore* zT_500;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_501 = {0};
    unsigned int zT_503;
    unsigned short zT_504;
    int zT_505;
    int zT_507;
    unsigned int zT_508;
    unsigned int zT_510;
    int zT_511;
    zT_338B7C76_TypeRegistry* zT_512;
    unsigned int zT_513;
    zT_338B7C76_TypeRegistry* zT_514;
    unsigned int* zT_515;
    unsigned int zT_516;
    int zT_517;
    unsigned int zT_518;
    zT_338B7C76_TypeRegistry* zT_519;
    unsigned int zT_520;
    unsigned short zT_521;
    zT_338B7C76_TypeRegistry* zT_522;
    int zT_523;
    unsigned int zT_524;
    int zT_525;
    unsigned short zT_526;
    unsigned int zT_527 = 0;
    zT_8143F551_AstKind zT_528;
    zT_8143F551_AstKind zT_531;
    int zT_532;
    zT_ABC1EBBE_TypeResolveEnv* zT_534;
    unsigned int zT_535;
    unsigned int zT_536;
    unsigned int zT_537;
    unsigned int zT_538;
    unsigned int zT_539;
    unsigned int zT_540 = 0;
    unsigned int zT_541;
    int zT_542;
    unsigned int zT_543;
    zT_939EE900_Arr_unsigned_int_1 zT_545;
    unsigned int zT_546;
    unsigned int zT_547;
    unsigned int zT_548;
    int zT_549;
    int zT_550;
    zT_ABC1EBBE_TypeResolveEnv* zT_552;
    unsigned int zT_553;
    unsigned int zT_554;
    unsigned int zT_555;
    unsigned int zT_556;
    unsigned int zT_557;
    unsigned int zT_558 = 0;
    unsigned int zT_559;
    int zT_560;
    unsigned int zT_561;
    int zT_562;
    unsigned int zT_563;
    int zT_564;
    zT_338B7C76_TypeRegistry* zT_565;
    unsigned int zT_566;
    unsigned int zT_567;
    zT_338B7C76_TypeRegistry* zT_568;
    int zT_569;
    unsigned int zT_570;
    unsigned int zT_571 = 0;
    zT_8143F551_AstKind zT_572;
    zT_8143F551_AstKind zT_575;
    int zT_576;
    zT_939EE900_Arr_unsigned_int_1 zT_578;
    unsigned int zT_579;
    unsigned int zT_580;
    unsigned int zT_581;
    int zT_582;
    unsigned int zT_583;
    int zT_584;
    int zT_585;
    zT_ABC1EBBE_TypeResolveEnv* zT_586;
    unsigned int zT_587;
    unsigned int zT_588;
    unsigned int zT_589;
    unsigned int zT_590;
    unsigned int zT_591;
    unsigned int zT_592 = 0;
    int zT_593;
    char* zT_595;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_596;
    unsigned int zT_597;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_598;
    unsigned int zT_599;
    int zT_600;
    unsigned int zT_601;
    int zT_602;
    unsigned int zT_603;
    unsigned int zT_604;
    int zT_605;
    unsigned int zT_606;
    zT_99292002_Arr_unsigned_int_16 zT_608;
    unsigned int zT_610;
    zT_6B0A7D14_AstStore* zT_611;
    unsigned int zT_612;
    zT_6B0A7D14_AstStore* zT_613;
    unsigned int zT_614 = 0;
    unsigned int zT_615;
    int zT_616;
    zT_6B0A7D14_AstStore* zT_618;
    unsigned int zT_619;
    zT_6B0A7D14_AstStore* zT_620;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_621 = {0};
    unsigned int zT_623;
    unsigned int zT_625;
    int zT_626;
    int zT_627;
    unsigned int zT_628;
    int zT_629;
    zT_ABC1EBBE_TypeResolveEnv* zT_631;
    unsigned int zT_632;
    unsigned int zT_633;
    unsigned int* zT_634;
    unsigned int zT_635;
    unsigned int zT_636;
    unsigned int zT_637;
    unsigned int zT_638 = 0;
    unsigned int zT_639;
    int zT_640;
    unsigned int zT_641;
    unsigned int zT_642;
    unsigned int zT_643;
    unsigned int zT_644;
    unsigned int zT_645;
    zT_443A2803_Arr_unsigned_char_9 zT_647;
    unsigned int zT_649;
    char* zT_651;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_652;
    unsigned int zT_653;
    unsigned int zT_655;
    unsigned int zT_657;
    int zT_658;
    int zT_659;
    unsigned int zT_660;
    int zT_661;
    unsigned char* zT_662;
    unsigned char zT_663;
    unsigned int zT_664;
    unsigned int zT_665;
    unsigned int zT_666;
    unsigned int zT_667;
    zT_5826BFC7_Arr_unsigned_char_1 zT_669;
    unsigned int zT_671;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_672;
    int zT_673;
    unsigned int zT_674;
    unsigned char* zT_675;
    unsigned int zT_676;
    int zT_677;
    unsigned char* zT_678;
    unsigned int zT_679;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_680;
    unsigned int zT_681 = 0;
    unsigned int zT_683;
    unsigned int zT_684;
    unsigned int zT_685;
    unsigned int zT_686;
    int zT_687;
    int zT_688;
    unsigned int zT_689;
    int zT_690;
    unsigned char zT_691;
    unsigned int zT_692;
    unsigned int zT_693;
    unsigned int zT_694;
    unsigned int zT_695;
    unsigned int zT_697;
    int zT_698;
    int zT_699;
    unsigned int zT_700;
    int zT_701;
    unsigned int zT_702;
    int zT_703;
    unsigned char zT_704;
    unsigned int zT_705;
    unsigned int zT_706;
    zT_5826BFC7_Arr_unsigned_char_1 zT_708;
    unsigned int zT_710;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_711;
    unsigned int zT_712;
    unsigned char* zT_713;
    unsigned int zT_714;
    int zT_715;
    unsigned char* zT_716;
    unsigned int zT_717;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_718;
    unsigned int zT_719 = 0;
    unsigned int zT_721;
    unsigned int zT_722;
    unsigned int zT_723;
    unsigned int zT_724;
    int zT_725;
    int zT_726;
    unsigned int zT_727;
    int zT_728;
    unsigned char zT_729;
    unsigned int zT_730;
    unsigned int zT_731;
    unsigned int zT_732;
    unsigned int zT_733;
    unsigned int zT_734;
    unsigned int zT_735;
    zT_D3EB6303_StringInterner* zT_737;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_738;
    zT_D3EB6303_StringInterner* zT_739;
    unsigned char* zT_740;
    int zT_742;
    unsigned char* zT_743;
    unsigned int zT_744;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_745;
    unsigned int zT_746 = 0;
    zT_338B7C76_TypeRegistry* zT_748;
    unsigned int zT_749;
    unsigned int zT_750;
    unsigned int zT_752;
    int zT_753;
    zT_338B7C76_TypeRegistry* zT_754;
    unsigned int zT_755;
    zT_338B7C76_TypeRegistry* zT_756;
    unsigned int zT_757;
    unsigned int zT_758;
    unsigned int zT_759;
    zT_338B7C76_TypeRegistry* zT_761;
    unsigned int zT_762;
    unsigned int zT_763;
    unsigned char zT_764;
    unsigned char zT_765;
    unsigned int zT_766;
    unsigned short zT_767;
    unsigned int zT_768;
    zT_338B7C76_TypeRegistry* zT_769;
    unsigned int zT_770;
    unsigned char zT_771;
    unsigned char zT_772;
    unsigned int zT_773;
    unsigned short zT_774;
    int zT_775;
    unsigned int zT_776;
    unsigned int zT_777 = 0;
    char* zT_779;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_780;
    unsigned int zT_781;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_782;
    unsigned int zT_783;
    zT_338B7C76_TypeRegistry* zT_784;
    unsigned int zT_785;
    zT_338B7C76_TypeRegistry* zT_786;
    zT_338B7C76_TypeRegistry* zT_787;
    unsigned int zT_788;
    int zT_789;
    zT_338B7C76_TypeRegistry* zT_790;
    int zT_791;
    unsigned int zT_792 = 0;
    unsigned int zT_793;
    int zT_794;
    int zT_795;
    zT_ABC1EBBE_TypeResolveEnv* zT_797;
    unsigned int zT_798;
    unsigned int zT_799;
    unsigned int zT_800;
    unsigned int zT_801;
    unsigned int zT_802;
    unsigned int zT_803 = 0;
    unsigned int zT_804;
    int zT_805;
    unsigned int zT_806;
    zT_8143F551_AstKind zT_807;
    zT_8143F551_AstKind zT_810;
    int zT_811;
    int zT_812;
    zT_8143F551_AstKind zT_813;
    zT_8143F551_AstKind zT_816;
    int zT_817;
    char* zT_819;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_820;
    unsigned int zT_821;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_822;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_824;
    unsigned int zT_826;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_827;
    unsigned char* zT_828;
    unsigned int zT_829;
    int zT_830;
    unsigned char* zT_831;
    unsigned int zT_832;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_833;
    unsigned int zT_834 = 0;
    unsigned int zT_836;
    unsigned int zT_837;
    unsigned int zT_838;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_839;
    unsigned char* zT_840;
    unsigned int zT_842;
    unsigned char* zT_843;
    unsigned int zT_844;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_845;
    char* zT_847;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_848;
    unsigned int zT_849;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_850;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_852;
    unsigned int zT_854;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_855;
    zT_8143F551_AstKind zT_856;
    unsigned int zT_857;
    unsigned char* zT_858;
    unsigned int zT_859;
    int zT_860;
    unsigned char* zT_861;
    unsigned int zT_862;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_863;
    unsigned int zT_864 = 0;
    unsigned int zT_866;
    unsigned int zT_867;
    unsigned int zT_868;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_869;
    unsigned char* zT_870;
    unsigned int zT_872;
    unsigned char* zT_873;
    unsigned int zT_874;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_875;
    char* zT_877;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_878;
    unsigned int zT_879;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_880;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_882;
    unsigned int zT_884;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_885;
    unsigned char* zT_886;
    unsigned int zT_887;
    int zT_888;
    unsigned char* zT_889;
    unsigned int zT_890;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_891;
    unsigned int zT_892 = 0;
    unsigned int zT_894;
    unsigned int zT_895;
    unsigned int zT_896;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_897;
    unsigned char* zT_898;
    unsigned int zT_900;
    unsigned char* zT_901;
    unsigned int zT_902;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_903;
    unsigned char zT_905;
    unsigned char zT_906;
    unsigned char zT_907;
    unsigned char zT_908;
    int zT_909;
    zT_8143F551_AstKind zT_910;
    zT_8143F551_AstKind zT_913;
    int zT_914;
    zT_338B7C76_TypeRegistry* zT_916;
    unsigned int zT_917;
    int zT_918;
    zT_338B7C76_TypeRegistry* zT_919;
    unsigned int zT_920 = 0;
    char* zT_922;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_923;
    unsigned int zT_924;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_925;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_927;
    unsigned int zT_929;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_930;
    unsigned char* zT_931;
    unsigned int zT_932;
    int zT_933;
    unsigned char* zT_934;
    unsigned int zT_935;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_936;
    unsigned int zT_937 = 0;
    unsigned int zT_939;
    unsigned int zT_940;
    unsigned int zT_941;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_942;
    unsigned char* zT_943;
    unsigned int zT_945;
    unsigned char* zT_946;
    unsigned int zT_947;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_948;
    char* zT_950;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_951;
    unsigned int zT_952;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_953;
    zT_338B7C76_TypeRegistry* zT_955;
    unsigned int zT_956;
    int zT_957;
    zT_338B7C76_TypeRegistry* zT_958;
    unsigned int zT_959 = 0;
    char* zT_961;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_962;
    unsigned int zT_963;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_964;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_966;
    unsigned int zT_968;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_969;
    unsigned char* zT_970;
    unsigned int zT_971;
    int zT_972;
    unsigned char* zT_973;
    unsigned int zT_974;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_975;
    unsigned int zT_976 = 0;
    unsigned int zT_978;
    unsigned int zT_979;
    unsigned int zT_980;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_981;
    unsigned char* zT_982;
    unsigned int zT_984;
    unsigned char* zT_985;
    unsigned int zT_986;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_987;
    char* zT_989;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_990;
    unsigned int zT_991;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_992;
    zT_8143F551_AstKind zT_993;
    zT_8143F551_AstKind zT_996;
    int zT_997;
    unsigned char zT_999;
    unsigned char zT_1000;
    unsigned char zT_1001;
    unsigned char zT_1002;
    int zT_1003;
    zT_338B7C76_TypeRegistry* zT_1005;
    unsigned int zT_1006;
    int zT_1007;
    zT_338B7C76_TypeRegistry* zT_1008;
    unsigned int zT_1009 = 0;
    zT_4028D896_Arr_unsigned_char_2 zT_1011;
    unsigned int zT_1013;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1014;
    unsigned char* zT_1015;
    unsigned int zT_1016;
    int zT_1017;
    unsigned char* zT_1018;
    unsigned int zT_1019;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1020;
    unsigned int zT_1021 = 0;
    unsigned int zT_1023;
    unsigned int zT_1024;
    unsigned int zT_1025;
    char* zT_1027;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1028;
    unsigned int zT_1029;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1030;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1031;
    unsigned char* zT_1032;
    unsigned int zT_1034;
    unsigned char* zT_1035;
    unsigned int zT_1036;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1037;
    zT_4028D896_Arr_unsigned_char_2 zT_1039;
    unsigned int zT_1041;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1042;
    unsigned char* zT_1043;
    unsigned int zT_1044;
    int zT_1045;
    unsigned char* zT_1046;
    unsigned int zT_1047;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1048;
    unsigned int zT_1049 = 0;
    unsigned int zT_1051;
    unsigned int zT_1052;
    unsigned int zT_1053;
    char* zT_1055;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1056;
    unsigned int zT_1057;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1058;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1059;
    unsigned char* zT_1060;
    unsigned int zT_1062;
    unsigned char* zT_1063;
    unsigned int zT_1064;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1065;
    char* zT_1067;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1068;
    unsigned int zT_1069;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1070;
    zT_8143F551_AstKind zT_1071;
    zT_8143F551_AstKind zT_1074;
    int zT_1075;
    char* zT_1077;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1078;
    unsigned int zT_1079;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1080;
    unsigned int zT_1081;
    zT_338B7C76_TypeRegistry* zT_1083;
    unsigned int zT_1084;
    zT_338B7C76_TypeRegistry* zT_1085;
    unsigned int zT_1086 = 0;
    char* zT_1088;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1089;
    unsigned int zT_1090;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1091;
    unsigned int zT_1092;
    zT_8143F551_AstKind zT_1093;
    zT_8143F551_AstKind zT_1096;
    int zT_1097;
    char* zT_1099;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1100;
    unsigned int zT_1101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1102;
    char* zT_1104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1105;
    unsigned int zT_1106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1107;
    zT_4028D896_Arr_unsigned_char_2 zT_1109;
    unsigned int zT_1111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1112;
    unsigned char* zT_1113;
    unsigned int zT_1114;
    int zT_1115;
    unsigned char* zT_1116;
    unsigned int zT_1117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1118;
    unsigned int zT_1119 = 0;
    unsigned int zT_1121;
    unsigned int zT_1122;
    unsigned int zT_1123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1124;
    unsigned char* zT_1125;
    unsigned int zT_1127;
    unsigned char* zT_1128;
    unsigned int zT_1129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1130;
    unsigned int zT_1131;
    int zT_1132;
    int zT_1133;
    zT_6B0A7D14_AstStore* zT_1135;
    unsigned int zT_1136;
    zT_6B0A7D14_AstStore* zT_1137;
    unsigned int zT_1138;
    zT_22A7C88B_AstNode zT_1139 = {0};
    unsigned int zT_1141;
    int zT_1143;
    zT_8143F551_AstKind zT_1144;
    zT_8143F551_AstKind zT_1147;
    int zT_1148;
    zT_6B0A7D14_AstStore* zT_1149;
    unsigned int zT_1150;
    zT_6B0A7D14_AstStore* zT_1151;
    unsigned int zT_1152;
    zT_79FAE712_u64 zT_1153 = 0;
    unsigned int zT_1154;
    int zT_1155;
    zT_8143F551_AstKind zT_1156;
    zT_8143F551_AstKind zT_1159;
    int zT_1160;
    int zT_1161;
    zT_8143F551_AstKind zT_1162;
    zT_8143F551_AstKind zT_1165;
    int zT_1166;
    zT_ABC1EBBE_TypeResolveEnv* zT_1168;
    unsigned int zT_1169;
    unsigned int zT_1170;
    unsigned int zT_1171 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_1173;
    unsigned int zT_1174;
    unsigned int zT_1175;
    unsigned int zT_1176 = 0;
    unsigned int zT_1177;
    int zT_1178;
    int zT_1179;
    unsigned int zT_1180;
    int zT_1181;
    int zT_1182;
    zT_8143F551_AstKind zT_1183;
    zT_8143F551_AstKind zT_1186;
    int zT_1187;
    unsigned int zT_1188;
    unsigned int zT_1189;
    zT_8143F551_AstKind zT_1190;
    zT_8143F551_AstKind zT_1193;
    int zT_1194;
    int zT_1195;
    zT_8143F551_AstKind zT_1196;
    zT_8143F551_AstKind zT_1199;
    int zT_1200;
    int zT_1201;
    zT_8143F551_AstKind zT_1202;
    zT_8143F551_AstKind zT_1205;
    int zT_1206;
    zT_ABC1EBBE_TypeResolveEnv* zT_1208;
    unsigned int zT_1209;
    unsigned int zT_1210;
    unsigned int zT_1211 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_1213;
    unsigned int zT_1214;
    unsigned int zT_1215;
    unsigned int zT_1216 = 0;
    unsigned int zT_1217;
    int zT_1218;
    int zT_1219;
    unsigned int zT_1220;
    int zT_1221;
    int zT_1222;
    unsigned int zT_1223;
    int zT_1224;
    int zT_1225;
    zT_8143F551_AstKind zT_1226;
    zT_8143F551_AstKind zT_1229;
    int zT_1230;
    unsigned int zT_1231;
    zT_8143F551_AstKind zT_1232;
    zT_8143F551_AstKind zT_1235;
    int zT_1236;
    unsigned int zT_1237;
    unsigned int zT_1238;
    zT_8143F551_AstKind zT_1239;
    zT_8143F551_AstKind zT_1242;
    int zT_1243;
    zT_ABC1EBBE_TypeResolveEnv* zT_1245;
    unsigned int zT_1246;
    unsigned int zT_1247;
    unsigned int zT_1248 = 0;
    unsigned int zT_1249;
    int zT_1250;
    int zT_1251;
    char* zT_1253;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1254;
    unsigned int zT_1255;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1256;
    zT_4028D896_Arr_unsigned_char_2 zT_1258;
    unsigned int zT_1260;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1261;
    unsigned char* zT_1262;
    unsigned int zT_1263;
    int zT_1264;
    unsigned char* zT_1265;
    unsigned int zT_1266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1267;
    unsigned int zT_1268 = 0;
    unsigned int zT_1270;
    unsigned int zT_1271;
    unsigned int zT_1272;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1273;
    unsigned char* zT_1274;
    unsigned int zT_1276;
    unsigned char* zT_1277;
    unsigned int zT_1278;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1279;
    zT_338B7C76_TypeRegistry* zT_1281;
    unsigned int zT_1282;
    unsigned int zT_1283;
    zT_338B7C76_TypeRegistry* zT_1284;
    unsigned int zT_1285 = 0;
    char* zT_1287;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1288;
    unsigned int zT_1289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1290;
    zT_4028D896_Arr_unsigned_char_2 zT_1292;
    unsigned int zT_1294;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1295;
    unsigned char* zT_1296;
    unsigned int zT_1297;
    int zT_1298;
    unsigned char* zT_1299;
    unsigned int zT_1300;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1301;
    unsigned int zT_1302 = 0;
    unsigned int zT_1304;
    unsigned int zT_1305;
    unsigned int zT_1306;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1307;
    unsigned char* zT_1308;
    unsigned int zT_1310;
    unsigned char* zT_1311;
    unsigned int zT_1312;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1313;
    unsigned int zT_1314;
    int zT_1315;
    char* zT_1317;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1318;
    unsigned int zT_1319;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1320;
    char* zT_1322;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1323;
    unsigned int zT_1324;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1325;
    unsigned int zT_1326;
    char* zT_1328;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1329;
    unsigned int zT_1330;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1331;
    unsigned int zT_1332;
    char* zT_1334;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1335;
    unsigned int zT_1336;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1337;
    unsigned int zT_1338;
    zT_8143F551_AstKind zT_1339;
    unsigned int zT_1340;
    unsigned int zT_1341;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtd_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtd_km;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm4_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    unsigned int canonical_id;
    zT_79FAE712_u64 ck_cur;
    zT_BAEE192E_Opt_10 tc_cur;
    zT_BAEE192E_Opt_10 tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u opnc_m;
    unsigned int t;
    zT_8F083A69_Slice_zT_0B42B2F8_u nf;
    unsigned int mi;
    zT_79FAE712_u64 ck;
    zT_BAEE192E_Opt_10 tc;
    zT_8F083A69_Slice_zT_0B42B2F8_u n2;
    zT_E68301A1_Opt_804 sym_cur;
    unsigned int si;
    zT_3A105EF1_Symbol* s;
    zT_E68301A1_Opt_804 sym;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm4f_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u ops_m;
    zT_5826BFC7_Arr_unsigned_char_1 sd_id;
    unsigned int sd_idl;
    unsigned int sd_ids;
    zT_4428DEE2_Arr_unsigned_char_2 sd_nm;
    unsigned int sd_di;
    unsigned int sd_namelen;
    unsigned int sd_name_id;
    zT_BAEE192E_Opt_10 sd_existing;
    unsigned int se;
    unsigned int sd_tid;
    zT_3CB0179A_Slice_zT_05F374B1_u sd_children;
    zT_9D2DA37C_Arr_unsigned_int_32 sd_fty;
    zT_9D2DA37C_Arr_unsigned_int_32 sd_fnm;
    unsigned int sd_fc;
    unsigned int sd_i;
    zT_22A7C88B_AstNode sd_fd;
    unsigned int sd_ft;
    unsigned int sd_fstart;
    unsigned int sd_j;
    unsigned int sd_st_idx;
    zT_D155D06D_Type sd_ty;
    unsigned char fah_matched;
    unsigned int base_type;
    zT_22A7C88B_AstNode base_node;
    zT_D155D06D_Type base_ty;
    unsigned int base_name_id;
    unsigned int smi;
    zT_8F083A69_Slice_zT_0B42B2F8_u fam_m;
    zT_E68301A1_Opt_804 base_sym;
    zT_3A105EF1_Symbol* bs;
    unsigned int mod_id;
    zT_E68301A1_Opt_804 payload_sym;
    zT_3A105EF1_Symbol* ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u fam;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnm;
    zT_939EE900_Arr_unsigned_int_1 esd_start_box;
    zT_EDD37787_Arr_unsigned_short_ esd_count_box;
    zT_3CB0179A_Slice_zT_05F374B1_u esd_children;
    unsigned int esd_i;
    unsigned int eu_payload_type;
    zT_939EE900_Arr_unsigned_int_1 eu_es_box;
    unsigned int eu_resolved_es;
    zT_939EE900_Arr_unsigned_int_1 fnt_ret_box;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm2_m;
    zT_99292002_Arr_unsigned_int_16 fnt_ptypes;
    unsigned int fnt_pc;
    zT_3CB0179A_Slice_zT_05F374B1_u fnt_extra;
    unsigned int fnt_i;
    zT_443A2803_Arr_unsigned_char_9 fnt_nb;
    unsigned int fnt_np;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnt_pre;
    unsigned int fnt_pri;
    unsigned int fnt_pt;
    zT_5826BFC7_Arr_unsigned_char_1 fnt_rb;
    unsigned int fnt_rl;
    unsigned int fnt_rs;
    unsigned int fnt_k;
    unsigned int fnt_name_id;
    unsigned int fnt_pstart;
    unsigned int fnt_a;
    zT_5826BFC7_Arr_unsigned_char_1 fnt_pb;
    unsigned int fnt_pl;
    unsigned int fnt_ps;
    unsigned int fnt_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm3_m;
    unsigned int child_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u und_nm2;
    zT_8F083A69_Slice_zT_0B42B2F8_u und_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptm;
    zT_5A26C2ED_Arr_unsigned_char_1 ptib;
    unsigned int ptil;
    unsigned int ptis;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptkm;
    zT_5A26C2ED_Arr_unsigned_char_1 ptkb;
    unsigned int ptkl;
    unsigned int ptks;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptcm;
    zT_5A26C2ED_Arr_unsigned_char_1 ptcb;
    unsigned int ptcl;
    unsigned int ptcs;
    int is_const;
    unsigned int ptr_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppm;
    zT_5A26C2ED_Arr_unsigned_char_1 ppb;
    unsigned int ppl;
    unsigned int pps;
    zT_8F083A69_Slice_zT_0B42B2F8_u pnl;
    unsigned int ptr_tid2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppm2;
    zT_5A26C2ED_Arr_unsigned_char_1 ppb2;
    unsigned int ppl2;
    unsigned int pps2;
    zT_8F083A69_Slice_zT_0B42B2F8_u pnl2;
    unsigned int sl_tid;
    zT_4028D896_Arr_unsigned_char_2 sl_e;
    unsigned int sl_el;
    unsigned int sl_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u sm;
    zT_4028D896_Arr_unsigned_char_2 sl_r;
    unsigned int sl_rl;
    unsigned int sl_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u s2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s3;
    zT_8F083A69_Slice_zT_0B42B2F8_u optvd_m;
    unsigned int optvd_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u optvd_rm;
    zT_8F083A69_Slice_zT_0B42B2F8_u t0m;
    zT_8F083A69_Slice_zT_0B42B2F8_u t1m;
    zT_4028D896_Arr_unsigned_char_2 t1b;
    unsigned int t1l;
    unsigned int t1s;
    zT_22A7C88B_AstNode sz_node;
    unsigned int arr_len;
    int arr_resolved;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2m;
    zT_4028D896_Arr_unsigned_char_2 t2b;
    unsigned int t2l;
    unsigned int t2s;
    unsigned int lhs;
    unsigned int rhs;
    unsigned int al;
    unsigned int at;
    zT_8F083A69_Slice_zT_0B42B2F8_u t3m;
    zT_4028D896_Arr_unsigned_char_2 t3b;
    unsigned int t3l;
    unsigned int t3s;
    zT_8F083A69_Slice_zT_0B42B2F8_u am;
    zT_3 = 16;
    zT_4 = depth > zT_3;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 18;
    return zT_5;
    z_bb_2:
    zT_9 = env->store;
    zT_7 = zT_9;
    zT_8 = node_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    node = zT_10;
    node = zT_10;
    zT_12 = "RTD:n";
    zT_14 = 5;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    rtd_nm = zT_13;
    rtd_nm = zT_13;
    rtd_nm = zT_13;
    zT_15 = rtd_nm;
    zT_16 = node_idx;
    zF_C914CB83_markerWriteInt(zT_15, zT_16);
    zT_18 = "RTD:k";
    zT_20 = 5;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    rtd_km = zT_19;
    rtd_km = zT_19;
    rtd_km = zT_19;
    zT_21 = rtd_km;
    zT_23 = node.kind;
    zT_24 = (unsigned int)zT_23;
    zT_22 = zT_24;
    zF_C914CB83_markerWriteInt(zT_21, zT_22);
    zT_25 = node.kind;
    zT_28 = zT_8143F551_AstKind_ident_expr;
    zT_29 = zT_25 == zT_28;
    if (zT_29) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_33 = env->store;
    zT_31 = zT_33;
    zT_32 = node_idx;
    zT_34 = zF_53458827_astStoreIdentifier(zT_31, zT_32);
    name_id = zT_34;
    name_id = zT_34;
    name_id = zT_34;
    zT_36 = "OPTVOID:id";
    zT_38 = 10;
    zT_37.ptr = zT_36;
    zT_37.len = zT_38;
    opm4_m = zT_37;
    opm4_m = zT_37;
    opm4_m = zT_37;
    zT_39 = opm4_m;
    zT_40 = name_id;
    zF_C914CB83_markerWriteInt(zT_39, zT_40);
    zT_44 = env->interner;
    zT_42 = zT_44;
    zT_43 = name_id;
    zT_45 = zF_9134020D_stringInternerGet(zT_42, zT_43);
    text = zT_45;
    text = zT_45;
    text = zT_45;
    zT_49 = env->interner;
    zT_47 = zT_49;
    zT_48 = text;
    zT_50 = zF_50C274AF_stringInternerInter(zT_47, zT_48);
    canonical_id = zT_50;
    canonical_id = zT_50;
    canonical_id = zT_50;
    zT_51 = env->module_id;
    zT_53 = zT_51 != zG_E6DB2ACE_MODULE_ID_NONE;
    if (zT_53) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_166 = node.kind;
    zT_169 = zT_8143F551_AstKind_struct_decl;
    zT_170 = zT_166 == zT_169;
    if (zT_170) goto z_bb_31; else goto z_bb_32;
    z_bb_5:
    zT_55 = env->module_id;
    zT_56 = (zT_79FAE712_u64)zT_55;
    zT_57 = 4294967296ULL;
    zT_58 = zT_56 * zT_57;
    zT_59 = (zT_79FAE712_u64)canonical_id;
    zT_60 = zT_58 + zT_59;
    ck_cur = zT_60;
    ck_cur = zT_60;
    ck_cur = zT_60;
    zT_64 = env->typereg;
    zT_62 = zT_64;
    zT_63 = ck_cur;
    zT_65 = zF_0EB68360_nameCacheGet(zT_62, zT_63);
    tc_cur = zT_65;
    tc_cur = zT_65;
    tc_cur = zT_65;
    zT_66 = tc_cur.has_value;
    if (zT_66) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_71 = env->typereg;
    zT_69 = zT_71;
    zT_72 = (zT_79FAE712_u64)canonical_id;
    zT_70 = zT_72;
    zT_73 = zF_0EB68360_nameCacheGet(zT_69, zT_70);
    tid = zT_73;
    tid = zT_73;
    tid = zT_73;
    zT_75 = "OPTVOID:nc";
    zT_77 = 10;
    zT_76.ptr = zT_75;
    zT_76.len = zT_77;
    opnc_m = zT_76;
    opnc_m = zT_76;
    opnc_m = zT_76;
    zT_78 = opnc_m;
    zT_79 = canonical_id;
    zF_C914CB83_markerWriteInt(zT_78, zT_79);
    zT_80 = tid.has_value;
    if (zT_80) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    t = tc_cur.value;
    return t;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    t = tid.value;
    return t;
    z_bb_10:
    zT_83 = "NF";
    zT_85 = 2;
    zT_84.ptr = zT_83;
    zT_84.len = zT_85;
    nf = zT_84;
    nf = zT_84;
    nf = zT_84;
    zT_86 = nf;
    zF_48AC7B3A_markerWrite(zT_86);
    zT_88 = 0;
    zT_89 = (unsigned int)zT_88;
    mi = zT_89;
    mi = zT_89;
    mi = zT_89;
    goto z_bb_11;
    z_bb_11:
    zT_90 = env->symbol_reg;
    zT_91 = zT_90->tables_len;
    zT_92 = (unsigned int)zT_91;
    zT_93 = mi < zT_92;
    if (zT_93) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_95 = (zT_79FAE712_u64)mi;
    zT_96 = 4294967296ULL;
    zT_97 = zT_95 * zT_96;
    zT_98 = (zT_79FAE712_u64)canonical_id;
    zT_99 = zT_97 + zT_98;
    ck = zT_99;
    ck = zT_99;
    ck = zT_99;
    zT_103 = env->typereg;
    zT_101 = zT_103;
    zT_102 = ck;
    zT_104 = zF_0EB68360_nameCacheGet(zT_101, zT_102);
    tc = zT_104;
    tc = zT_104;
    tc = zT_104;
    zT_105 = tc.has_value;
    if (zT_105) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    zT_110 = "N2";
    zT_112 = 2;
    zT_111.ptr = zT_110;
    zT_111.len = zT_112;
    n2 = zT_111;
    n2 = zT_111;
    n2 = zT_111;
    zT_113 = n2;
    zF_48AC7B3A_markerWrite(zT_113);
    zT_114 = env->module_id;
    zT_116 = zT_114 != zG_E6DB2ACE_MODULE_ID_NONE;
    if (zT_116) goto z_bb_17; else goto z_bb_18;
    z_bb_14:
    zT_107 = 1;
    zT_108 = mi + zT_107;
    mi = zT_108;
    mi = zT_108;
    goto z_bb_11;
    z_bb_15:
    t = tc.value;
    return t;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_121 = env->symbol_reg;
    zT_118 = zT_121;
    zT_122 = env->module_id;
    zT_119 = zT_122;
    zT_120 = name_id;
    zT_123 = zF_A398987E_symbolRegistryQuali(zT_118, zT_119, zT_120);
    sym_cur = zT_123;
    sym_cur = zT_123;
    sym_cur = zT_123;
    zT_124 = sym_cur.has_value;
    if (zT_124) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_131 = 0;
    zT_132 = (unsigned int)zT_131;
    si = zT_132;
    si = zT_132;
    si = zT_132;
    goto z_bb_23;
    z_bb_19:
    s = sym_cur.value;
    zT_126 = s->type_id;
    zT_127 = 0;
    zT_128 = zT_126 != zT_127;
    if (zT_128) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_129 = s->type_id;
    return zT_129;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_133 = env->symbol_reg;
    zT_134 = zT_133->tables_len;
    zT_135 = (unsigned int)zT_134;
    zT_136 = si < zT_135;
    if (zT_136) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_141 = env->symbol_reg;
    zT_138 = zT_141;
    zT_142 = (unsigned int)si;
    zT_139 = zT_142;
    zT_140 = name_id;
    zT_143 = zF_A398987E_symbolRegistryQuali(zT_138, zT_139, zT_140);
    sym = zT_143;
    sym = zT_143;
    sym = zT_143;
    zT_144 = sym.has_value;
    if (zT_144) goto z_bb_27; else goto z_bb_28;
    z_bb_25:
    zT_160 = "OPTVOID:idF";
    zT_162 = 11;
    zT_161.ptr = zT_160;
    zT_161.len = zT_162;
    opm4f_m = zT_161;
    opm4f_m = zT_161;
    opm4f_m = zT_161;
    zT_163 = opm4f_m;
    zT_164 = name_id;
    zF_C914CB83_markerWriteInt(zT_163, zT_164);
    zT_165 = 18;
    return zT_165;
    z_bb_26:
    zT_157 = 1;
    zT_158 = si + zT_157;
    si = zT_158;
    si = zT_158;
    goto z_bb_23;
    z_bb_27:
    s = sym.value;
    zT_146 = s->type_id;
    zT_147 = 0;
    zT_148 = zT_146 != zT_147;
    if (zT_148) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_26;
    z_bb_29:
    zT_150 = "OPTVOID:ids";
    zT_152 = 11;
    zT_151.ptr = zT_150;
    zT_151.len = zT_152;
    ops_m = zT_151;
    ops_m = zT_151;
    ops_m = zT_151;
    zT_153 = ops_m;
    zT_155 = s->type_id;
    zT_154 = zT_155;
    zF_C914CB83_markerWriteInt(zT_153, zT_154);
    zT_156 = s->type_id;
    return zT_156;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_172[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        sd_id[_i] = zT_172[_i];
        _i++;
    }
}
    zT_174 = node_idx;
    zT_176 = (unsigned char*)sd_id;
    zT_177 = 12;
    zT_178 = 0;
    zT_179 = zT_176 + zT_178;
    zT_180 = zT_177 - zT_178;
    zT_181.ptr = zT_179;
    zT_181.len = zT_180;
    zT_175 = zT_181;
    zT_182 = zF_A7504564_itoa(zT_174, zT_175);
    sd_idl = zT_182;
    sd_idl = zT_182;
    sd_idl = zT_182;
    zT_184 = 11;
    zT_185 = (unsigned int)sd_idl;
    zT_186 = zT_184 - zT_185;
    sd_ids = zT_186;
    sd_ids = zT_186;
    sd_ids = zT_186;
    {
    unsigned int _i = 0;
    while (_i < 24) {
        zT_188[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 24) {
        sd_nm[_i] = zT_188[_i];
        _i++;
    }
}
    zT_189 = 97;
    zT_190 = 0;
    sd_nm[zT_190] = zT_189;
    zT_191 = 110;
    zT_192 = 1;
    sd_nm[zT_192] = zT_191;
    zT_193 = 111;
    zT_194 = 2;
    sd_nm[zT_194] = zT_193;
    zT_195 = 110;
    zT_196 = 3;
    sd_nm[zT_196] = zT_195;
    zT_197 = 95;
    zT_198 = 4;
    sd_nm[zT_198] = zT_197;
    zT_200 = 0;
    zT_201 = (unsigned int)zT_200;
    sd_di = zT_201;
    sd_di = zT_201;
    sd_di = zT_201;
    goto z_bb_33;
    z_bb_32:
    zT_341 = node.kind;
    zT_344 = zT_8143F551_AstKind_field_access;
    zT_345 = zT_341 == zT_344;
    if (zT_345) goto z_bb_56; else goto z_bb_57;
    z_bb_33:
    zT_202 = (unsigned int)sd_idl;
    zT_203 = sd_di < zT_202;
    if (zT_203) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_204 = sd_ids + sd_di;
    zT_205 = sd_id[zT_204];
    zT_206 = 5;
    zT_207 = zT_206 + sd_di;
    sd_nm[zT_207] = zT_205;
    goto z_bb_36;
    z_bb_35:
    zT_211 = 5;
    zT_212 = (unsigned int)sd_idl;
    zT_213 = zT_211 + zT_212;
    sd_namelen = zT_213;
    sd_namelen = zT_213;
    sd_namelen = zT_213;
    zT_217 = env->interner;
    zT_215 = zT_217;
    zT_218 = (unsigned char*)sd_nm;
    zT_220 = 0;
    zT_221 = zT_218 + zT_220;
    zT_222 = sd_namelen - zT_220;
    zT_223.ptr = zT_221;
    zT_223.len = zT_222;
    zT_216 = zT_223;
    zT_224 = zF_50C274AF_stringInternerInter(zT_215, zT_216);
    sd_name_id = zT_224;
    sd_name_id = zT_224;
    sd_name_id = zT_224;
    zT_228 = env->typereg;
    zT_226 = zT_228;
    zT_229 = (zT_79FAE712_u64)sd_name_id;
    zT_227 = zT_229;
    zT_230 = zF_0EB68360_nameCacheGet(zT_226, zT_227);
    sd_existing = zT_230;
    sd_existing = zT_230;
    sd_existing = zT_230;
    zT_231 = sd_existing.has_value;
    if (zT_231) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_208 = 1;
    zT_209 = sd_di + zT_208;
    sd_di = zT_209;
    sd_di = zT_209;
    goto z_bb_33;
    z_bb_37:
    se = sd_existing.value;
    return se;
    z_bb_38:
    zT_238 = env->typereg;
    zT_234 = zT_238;
    zT_239 = 0;
    zT_235 = zT_239;
    zT_236 = sd_name_id;
    zT_242 = zT_33EF6BFB_TypeKind_struct_type;
    zT_237 = zT_242;
    zT_243 = zF_3A64E2E0_typeRegistryRegiste(zT_234, zT_235, zT_236, zT_237);
    sd_tid = zT_243;
    sd_tid = zT_243;
    sd_tid = zT_243;
    zT_246 = env->store;
    zT_244 = zT_246;
    zT_245 = node_idx;
    zT_247 = zF_8BA26B9E_astStoreNodePayload(zT_244, zT_245);
    zT_248 = 0;
    zT_249 = zT_247 != zT_248;
    if (zT_249) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_253 = env->store;
    zT_251 = zT_253;
    zT_252 = node_idx;
    zT_254 = zF_850FDF81_astStoreNodeExtraCh(zT_251, zT_252);
    sd_children = zT_254;
    sd_children = zT_254;
    sd_children = zT_254;
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_256[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        sd_fty[_i] = zT_256[_i];
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_258[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        sd_fnm[_i] = zT_258[_i];
        _i++;
    }
}
    zT_260 = 0;
    zT_261 = (unsigned int)zT_260;
    sd_fc = zT_261;
    sd_fc = zT_261;
    sd_fc = zT_261;
    zT_263 = 0;
    zT_264 = (unsigned int)zT_263;
    sd_i = zT_264;
    sd_i = zT_264;
    sd_i = zT_264;
    goto z_bb_41;
    z_bb_40:
    return sd_tid;
    z_bb_41:
    zT_266 = sd_children.len;
    zT_267 = sd_i < zT_266;
    if (zT_267) goto z_bb_45; else goto z_bb_46;
    z_bb_42:
    zT_274 = env->store;
    zT_272 = zT_274;
    zT_275 = sd_children.ptr;
    zT_276 = zT_275[sd_i];
    zT_273 = zT_276;
    zT_277 = zF_FCDD1D35_astStoreNodeAt(zT_272, zT_273);
    sd_fd = zT_277;
    sd_fd = zT_277;
    sd_fd = zT_277;
    zT_278 = sd_fd.kind;
    zT_281 = zT_8143F551_AstKind_field_decl;
    zT_282 = zT_278 == zT_281;
    if (zT_282) goto z_bb_48; else goto z_bb_49;
    z_bb_43:
    zT_302 = 0;
    zT_303 = sd_fc > zT_302;
    if (zT_303) goto z_bb_50; else goto z_bb_51;
    z_bb_44:
    zT_300 = 1;
    zT_301 = sd_i + zT_300;
    sd_i = zT_301;
    sd_i = zT_301;
    goto z_bb_41;
    z_bb_45:
    zT_269 = 32;
    zT_270 = sd_fc < zT_269;
    zT_268 = zT_270;
    goto z_bb_47;
    z_bb_46:
    zT_268 = 0;
    goto z_bb_47;
    z_bb_47:
    if (zT_268) goto z_bb_42; else goto z_bb_43;
    z_bb_48:
    zT_284 = env;
    zT_287 = sd_fd.child_0;
    zT_285 = zT_287;
    zT_288 = 1;
    zT_289 = depth + zT_288;
    zT_286 = zT_289;
    zT_290 = zF_F2107C15_resolveTypeExprFull(zT_284, zT_285, zT_286);
    sd_ft = zT_290;
    sd_ft = zT_290;
    sd_ft = zT_290;
    sd_fty[sd_fc] = sd_ft;
    zT_293 = env->store;
    zT_291 = zT_293;
    zT_294 = sd_children.ptr;
    zT_295 = zT_294[sd_i];
    zT_292 = zT_295;
    zT_296 = zF_8BA26B9E_astStoreNodePayload(zT_291, zT_292);
    sd_fnm[sd_fc] = zT_296;
    zT_297 = 1;
    zT_298 = (unsigned int)zT_297;
    zT_299 = sd_fc + zT_298;
    sd_fc = zT_299;
    sd_fc = zT_299;
    goto z_bb_49;
    z_bb_49:
    goto z_bb_44;
    z_bb_50:
    zT_305 = env->typereg;
    zT_306 = zT_305->fe_len;
    zT_307 = (unsigned int)zT_306;
    sd_fstart = zT_307;
    sd_fstart = zT_307;
    sd_fstart = zT_307;
    zT_309 = 0;
    zT_310 = (unsigned int)zT_309;
    sd_j = zT_310;
    sd_j = zT_310;
    sd_j = zT_310;
    goto z_bb_52;
    z_bb_51:
    goto z_bb_40;
    z_bb_52:
    zT_311 = sd_j < sd_fc;
    if (zT_311) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_314 = env->typereg;
    zT_312 = zT_314;
    zT_316 = sd_fnm[sd_j];
    zT_315.name_id = zT_316;
    zT_317 = sd_fty[sd_j];
    zT_315.type_id = zT_317;
    zT_318 = 0;
    zT_315.offset = zT_318;
    zT_313 = zT_315;
    zF_701DF154_feAppend(zT_312, zT_313);
    goto z_bb_55;
    z_bb_54:
    zT_323 = env->typereg;
    zT_321 = zT_323;
    zT_325 = (unsigned int)sd_fstart;
    zT_324.fields_start = zT_325;
    zT_326 = (unsigned short)sd_fc;
    zT_324.fields_count = zT_326;
    zT_322 = zT_324;
    zF_CF849366_stAppend(zT_321, zT_322);
    zT_328 = env->typereg;
    zT_329 = zT_328->st_len;
    zT_330 = 1;
    zT_331 = zT_329 - zT_330;
    zT_332 = (unsigned int)zT_331;
    sd_st_idx = zT_332;
    sd_st_idx = zT_332;
    sd_st_idx = zT_332;
    zT_334 = env->typereg;
    zT_335 = zT_334->types_items;
    zT_336 = (unsigned int)sd_tid;
    zT_337 = zT_335[zT_336];
    sd_ty = zT_337;
    sd_ty = zT_337;
    sd_ty = zT_337;
    sd_ty.payload_idx = sd_st_idx;
    zT_338 = env->typereg;
    zT_339 = zT_338->types_items;
    zT_340 = (unsigned int)sd_tid;
    zT_339[zT_340] = sd_ty;
    goto z_bb_51;
    z_bb_55:
    zT_319 = 1;
    zT_320 = sd_j + zT_319;
    sd_j = zT_320;
    sd_j = zT_320;
    goto z_bb_52;
    z_bb_56:
    zT_347 = 0;
    fah_matched = zT_347;
    fah_matched = zT_347;
    fah_matched = zT_347;
    zT_349 = env;
    zT_352 = node.child_0;
    zT_350 = zT_352;
    zT_353 = 1;
    zT_354 = depth + zT_353;
    zT_351 = zT_354;
    zT_355 = zF_F2107C15_resolveTypeExprFull(zT_349, zT_350, zT_351);
    base_type = zT_355;
    base_type = zT_355;
    base_type = zT_355;
    zT_356 = 18;
    zT_357 = base_type == zT_356;
    if (zT_357) goto z_bb_58; else goto z_bb_59;
    z_bb_57:
    zT_476 = node.kind;
    zT_479 = zT_8143F551_AstKind_error_set_decl;
    zT_480 = zT_476 == zT_479;
    if (zT_480) goto z_bb_82; else goto z_bb_83;
    z_bb_58:
    zT_361 = env->store;
    zT_359 = zT_361;
    zT_362 = node.child_0;
    zT_360 = zT_362;
    zT_363 = zF_FCDD1D35_astStoreNodeAt(zT_359, zT_360);
    base_node = zT_363;
    base_node = zT_363;
    base_node = zT_363;
    zT_364 = base_node.kind;
    zT_367 = zT_8143F551_AstKind_ident_expr;
    zT_368 = zT_364 == zT_367;
    if (zT_368) goto z_bb_60; else goto z_bb_61;
    z_bb_59:
    zT_433 = env->typereg;
    zT_434 = zT_433->types_items;
    zT_435 = (unsigned int)base_type;
    zT_436 = zT_434[zT_435];
    base_ty = zT_436;
    base_ty = zT_436;
    base_ty = zT_436;
    zT_437 = base_ty.kind;
    zT_440 = zT_33EF6BFB_TypeKind_module_type;
    zT_441 = zT_437 == zT_440;
    if (zT_441) goto z_bb_74; else goto z_bb_75;
    z_bb_60:
    zT_372 = env->store;
    zT_370 = zT_372;
    zT_373 = node.child_0;
    zT_371 = zT_373;
    zT_374 = zF_53458827_astStoreIdentifier(zT_370, zT_371);
    base_name_id = zT_374;
    base_name_id = zT_374;
    base_name_id = zT_374;
    zT_376 = 0;
    zT_377 = (unsigned int)zT_376;
    smi = zT_377;
    smi = zT_377;
    smi = zT_377;
    goto z_bb_62;
    z_bb_61:
    zT_425 = "FAH:m";
    zT_427 = 5;
    zT_426.ptr = zT_425;
    zT_426.len = zT_427;
    fam_m = zT_426;
    fam_m = zT_426;
    fam_m = zT_426;
    zT_428 = fam_m;
    zT_430 = node.child_0;
    zT_429 = zT_430;
    zF_C914CB83_markerWriteInt(zT_428, zT_429);
    zT_431 = 18;
    return zT_431;
    z_bb_62:
    zT_378 = env->symbol_reg;
    zT_379 = zT_378->tables_len;
    zT_380 = (unsigned int)zT_379;
    zT_381 = smi < zT_380;
    if (zT_381) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_386 = env->symbol_reg;
    zT_383 = zT_386;
    zT_387 = (unsigned int)smi;
    zT_384 = zT_387;
    zT_385 = base_name_id;
    zT_388 = zF_A398987E_symbolRegistryQuali(zT_383, zT_384, zT_385);
    base_sym = zT_388;
    base_sym = zT_388;
    base_sym = zT_388;
    zT_389 = base_sym.has_value;
    if (zT_389) goto z_bb_66; else goto z_bb_67;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    zT_422 = 1;
    zT_423 = smi + zT_422;
    smi = zT_423;
    smi = zT_423;
    goto z_bb_62;
    z_bb_66:
    bs = base_sym.value;
    zT_391 = bs->kind;
    zT_394 = zT_3C598AEF_SymbolKind_module;
    zT_395 = zT_391 == zT_394;
    if (zT_395) goto z_bb_68; else goto z_bb_69;
    z_bb_67:
    goto z_bb_65;
    z_bb_68:
    zT_397 = bs->module_id;
    mod_id = zT_397;
    mod_id = zT_397;
    mod_id = zT_397;
    zT_402 = env->symbol_reg;
    zT_399 = zT_402;
    zT_400 = mod_id;
    zT_405 = env->store;
    zT_403 = zT_405;
    zT_404 = node_idx;
    zT_406 = zF_8BA26B9E_astStoreNodePayload(zT_403, zT_404);
    zT_401 = zT_406;
    zT_407 = zF_A398987E_symbolRegistryQuali(zT_399, zT_400, zT_401);
    payload_sym = zT_407;
    payload_sym = zT_407;
    payload_sym = zT_407;
    zT_408 = payload_sym.has_value;
    if (zT_408) goto z_bb_70; else goto z_bb_71;
    z_bb_69:
    goto z_bb_67;
    z_bb_70:
    ps = payload_sym.value;
    zT_410 = ps->type_id;
    zT_411 = 0;
    zT_412 = zT_410 != zT_411;
    if (zT_412) goto z_bb_72; else goto z_bb_73;
    z_bb_71:
    goto z_bb_69;
    z_bb_72:
    zT_413 = 1;
    fah_matched = zT_413;
    fah_matched = zT_413;
    zT_415 = "FAH:r";
    zT_417 = 5;
    zT_416.ptr = zT_415;
    zT_416.len = zT_417;
    fam = zT_416;
    fam = zT_416;
    fam = zT_416;
    zT_418 = fam;
    zT_420 = ps->type_id;
    zT_419 = zT_420;
    zF_C914CB83_markerWriteInt(zT_418, zT_419);
    zT_421 = ps->type_id;
    return zT_421;
    z_bb_73:
    goto z_bb_71;
    z_bb_74:
    zT_443 = base_ty.module_id;
    mod_id = zT_443;
    mod_id = zT_443;
    mod_id = zT_443;
    zT_448 = env->symbol_reg;
    zT_445 = zT_448;
    zT_446 = mod_id;
    zT_451 = env->store;
    zT_449 = zT_451;
    zT_450 = node_idx;
    zT_452 = zF_8BA26B9E_astStoreNodePayload(zT_449, zT_450);
    zT_447 = zT_452;
    zT_453 = zF_A398987E_symbolRegistryQuali(zT_445, zT_446, zT_447);
    sym = zT_453;
    sym = zT_453;
    sym = zT_453;
    zT_454 = sym.has_value;
    if (zT_454) goto z_bb_76; else goto z_bb_77;
    z_bb_75:
    zT_468 = 0;
    zT_469 = fah_matched == zT_468;
    if (zT_469) goto z_bb_80; else goto z_bb_81;
    z_bb_76:
    s = sym.value;
    zT_456 = s->type_id;
    zT_457 = 0;
    zT_458 = zT_456 != zT_457;
    if (zT_458) goto z_bb_78; else goto z_bb_79;
    z_bb_77:
    goto z_bb_75;
    z_bb_78:
    zT_459 = 1;
    fah_matched = zT_459;
    fah_matched = zT_459;
    zT_461 = "FAH:r";
    zT_463 = 5;
    zT_462.ptr = zT_461;
    zT_462.len = zT_463;
    fam = zT_462;
    fam = zT_462;
    fam = zT_462;
    zT_464 = fam;
    zT_466 = s->type_id;
    zT_465 = zT_466;
    zF_C914CB83_markerWriteInt(zT_464, zT_465);
    zT_467 = s->type_id;
    return zT_467;
    z_bb_79:
    goto z_bb_77;
    z_bb_80:
    zT_471 = "FAH:N";
    zT_473 = 5;
    zT_472.ptr = zT_471;
    zT_472.len = zT_473;
    fnm = zT_472;
    fnm = zT_472;
    fnm = zT_472;
    zT_474 = fnm;
    zT_475 = node_idx;
    zF_C914CB83_markerWriteInt(zT_474, zT_475);
    goto z_bb_81;
    z_bb_81:
    goto z_bb_57;
    z_bb_82:
    zT_483 = env->typereg;
    zT_484 = zT_483->xn_len;
    zT_485 = (unsigned int)zT_484;
    zT_486 = 0;
    zT_482[zT_486] = zT_485;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        esd_start_box[_i] = zT_482[_i];
        _i++;
    }
}
    zT_489 = 0;
    zT_490 = 0;
    zT_488[zT_490] = zT_489;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        esd_count_box[_i] = zT_488[_i];
        _i++;
    }
}
    zT_493 = env->store;
    zT_491 = zT_493;
    zT_492 = node_idx;
    zT_494 = zF_8BA26B9E_astStoreNodePayload(zT_491, zT_492);
    zT_495 = 0;
    zT_496 = zT_494 != zT_495;
    if (zT_496) goto z_bb_84; else goto z_bb_85;
    z_bb_83:
    zT_528 = node.kind;
    zT_531 = zT_8143F551_AstKind_error_union_type;
    zT_532 = zT_528 == zT_531;
    if (zT_532) goto z_bb_90; else goto z_bb_91;
    z_bb_84:
    zT_500 = env->store;
    zT_498 = zT_500;
    zT_499 = node_idx;
    zT_501 = zF_850FDF81_astStoreNodeExtraCh(zT_498, zT_499);
    esd_children = zT_501;
    esd_children = zT_501;
    esd_children = zT_501;
    zT_503 = esd_children.len;
    zT_504 = (unsigned short)zT_503;
    zT_505 = 0;
    esd_count_box[zT_505] = zT_504;
    zT_507 = 0;
    zT_508 = (unsigned int)zT_507;
    esd_i = zT_508;
    esd_i = zT_508;
    esd_i = zT_508;
    goto z_bb_86;
    z_bb_85:
    zT_522 = env->typereg;
    zT_519 = zT_522;
    zT_523 = 0;
    zT_524 = esd_start_box[zT_523];
    zT_520 = zT_524;
    zT_525 = 0;
    zT_526 = esd_count_box[zT_525];
    zT_521 = zT_526;
    zT_527 = zF_1C9ADFFD_typeRegistryGetOrCr(zT_519, zT_520, zT_521);
    return zT_527;
    z_bb_86:
    zT_510 = esd_children.len;
    zT_511 = esd_i < zT_510;
    if (zT_511) goto z_bb_87; else goto z_bb_88;
    z_bb_87:
    zT_514 = env->typereg;
    zT_512 = zT_514;
    zT_515 = esd_children.ptr;
    zT_516 = zT_515[esd_i];
    zT_513 = zT_516;
    zF_A648B1CB_xnAppend(zT_512, zT_513);
    goto z_bb_89;
    z_bb_88:
    goto z_bb_85;
    z_bb_89:
    zT_517 = 1;
    zT_518 = esd_i + zT_517;
    esd_i = zT_518;
    esd_i = zT_518;
    goto z_bb_86;
    z_bb_90:
    zT_534 = env;
    zT_537 = node.child_1;
    zT_535 = zT_537;
    zT_538 = 1;
    zT_539 = depth + zT_538;
    zT_536 = zT_539;
    zT_540 = zF_F2107C15_resolveTypeExprFull(zT_534, zT_535, zT_536);
    eu_payload_type = zT_540;
    eu_payload_type = zT_540;
    eu_payload_type = zT_540;
    zT_541 = 18;
    zT_542 = eu_payload_type == zT_541;
    if (zT_542) goto z_bb_92; else goto z_bb_93;
    z_bb_91:
    zT_572 = node.kind;
    zT_575 = zT_8143F551_AstKind_fn_type;
    zT_576 = zT_572 == zT_575;
    if (zT_576) goto z_bb_99; else goto z_bb_100;
    z_bb_92:
    zT_543 = 18;
    return zT_543;
    z_bb_93:
    zT_546 = 0;
    zT_547 = 0;
    zT_545[zT_547] = zT_546;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        eu_es_box[_i] = zT_545[_i];
        _i++;
    }
}
    zT_548 = node.child_0;
    zT_549 = 0;
    zT_550 = zT_548 != (unsigned int)zT_549;
    if (zT_550) goto z_bb_94; else goto z_bb_96;
    z_bb_94:
    zT_552 = env;
    zT_555 = node.child_0;
    zT_553 = zT_555;
    zT_556 = 1;
    zT_557 = depth + zT_556;
    zT_554 = zT_557;
    zT_558 = zF_F2107C15_resolveTypeExprFull(zT_552, zT_553, zT_554);
    eu_resolved_es = zT_558;
    eu_resolved_es = zT_558;
    eu_resolved_es = zT_558;
    zT_559 = 18;
    zT_560 = eu_resolved_es == zT_559;
    if (zT_560) goto z_bb_97; else goto z_bb_98;
    z_bb_95:
    zT_568 = env->typereg;
    zT_565 = zT_568;
    zT_566 = eu_payload_type;
    zT_569 = 0;
    zT_570 = eu_es_box[zT_569];
    zT_567 = zT_570;
    zT_571 = zF_16D1A6EE_typeRegistryGetOrCr(zT_565, zT_566, zT_567);
    return zT_571;
    z_bb_96:
    zT_563 = 0;
    zT_564 = 0;
    eu_es_box[zT_564] = zT_563;
    goto z_bb_95;
    z_bb_97:
    zT_561 = 18;
    return zT_561;
    z_bb_98:
    zT_562 = 0;
    eu_es_box[zT_562] = eu_resolved_es;
    goto z_bb_95;
    z_bb_99:
    zT_579 = 0;
    zT_580 = 0;
    zT_578[zT_580] = zT_579;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        fnt_ret_box[_i] = zT_578[_i];
        _i++;
    }
}
    zT_581 = 1;
    zT_582 = 0;
    fnt_ret_box[zT_582] = zT_581;
    zT_583 = node.child_0;
    zT_584 = 0;
    zT_585 = zT_583 != (unsigned int)zT_584;
    if (zT_585) goto z_bb_101; else goto z_bb_102;
    z_bb_100:
    zT_793 = node.child_0;
    zT_794 = 0;
    zT_795 = zT_793 != (unsigned int)zT_794;
    if (zT_795) goto z_bb_150; else goto z_bb_151;
    z_bb_101:
    zT_586 = env;
    zT_589 = node.child_0;
    zT_587 = zT_589;
    zT_590 = 1;
    zT_591 = depth + zT_590;
    zT_588 = zT_591;
    zT_592 = zF_F2107C15_resolveTypeExprFull(zT_586, zT_587, zT_588);
    zT_593 = 0;
    fnt_ret_box[zT_593] = zT_592;
    zT_595 = "OPTVOID:fntR";
    zT_597 = 12;
    zT_596.ptr = zT_595;
    zT_596.len = zT_597;
    opm2_m = zT_596;
    opm2_m = zT_596;
    opm2_m = zT_596;
    zT_598 = opm2_m;
    zT_600 = 0;
    zT_601 = fnt_ret_box[zT_600];
    zT_599 = zT_601;
    zF_C914CB83_markerWriteInt(zT_598, zT_599);
    zT_602 = 0;
    zT_603 = fnt_ret_box[zT_602];
    zT_604 = 18;
    zT_605 = zT_603 == zT_604;
    if (zT_605) goto z_bb_103; else goto z_bb_104;
    z_bb_102:
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_608[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        fnt_ptypes[_i] = zT_608[_i];
        _i++;
    }
}
    zT_610 = 0;
    fnt_pc = zT_610;
    fnt_pc = zT_610;
    fnt_pc = zT_610;
    zT_613 = env->store;
    zT_611 = zT_613;
    zT_612 = node_idx;
    zT_614 = zF_8BA26B9E_astStoreNodePayload(zT_611, zT_612);
    zT_615 = 0;
    zT_616 = zT_614 != zT_615;
    if (zT_616) goto z_bb_105; else goto z_bb_106;
    z_bb_103:
    zT_606 = 18;
    return zT_606;
    z_bb_104:
    goto z_bb_102;
    z_bb_105:
    zT_620 = env->store;
    zT_618 = zT_620;
    zT_619 = node_idx;
    zT_621 = zF_850FDF81_astStoreNodeExtraCh(zT_618, zT_619);
    fnt_extra = zT_621;
    fnt_extra = zT_621;
    fnt_extra = zT_621;
    zT_623 = 0;
    fnt_i = zT_623;
    fnt_i = zT_623;
    fnt_i = zT_623;
    goto z_bb_107;
    z_bb_106:
    {
    unsigned int _i = 0;
    while (_i < 96) {
        zT_647[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 96) {
        fnt_nb[_i] = zT_647[_i];
        _i++;
    }
}
    zT_649 = 0;
    fnt_np = zT_649;
    fnt_np = zT_649;
    fnt_np = zT_649;
    zT_651 = "fnt_";
    zT_653 = 4;
    zT_652.ptr = zT_651;
    zT_652.len = zT_653;
    fnt_pre = zT_652;
    fnt_pre = zT_652;
    fnt_pre = zT_652;
    zT_655 = 0;
    fnt_pri = zT_655;
    fnt_pri = zT_655;
    fnt_pri = zT_655;
    goto z_bb_116;
    z_bb_107:
    zT_625 = fnt_extra.len;
    zT_626 = fnt_i < zT_625;
    if (zT_626) goto z_bb_111; else goto z_bb_112;
    z_bb_108:
    zT_631 = env;
    zT_634 = fnt_extra.ptr;
    zT_635 = zT_634[fnt_i];
    zT_632 = zT_635;
    zT_636 = 1;
    zT_637 = depth + zT_636;
    zT_633 = zT_637;
    zT_638 = zF_F2107C15_resolveTypeExprFull(zT_631, zT_632, zT_633);
    fnt_pt = zT_638;
    fnt_pt = zT_638;
    fnt_pt = zT_638;
    zT_639 = 18;
    zT_640 = fnt_pt == zT_639;
    if (zT_640) goto z_bb_114; else goto z_bb_115;
    z_bb_109:
    goto z_bb_106;
    z_bb_110:
    zT_644 = 1;
    zT_645 = fnt_i + zT_644;
    fnt_i = zT_645;
    fnt_i = zT_645;
    goto z_bb_107;
    z_bb_111:
    zT_628 = 16;
    zT_629 = fnt_pc < zT_628;
    zT_627 = zT_629;
    goto z_bb_113;
    z_bb_112:
    zT_627 = 0;
    goto z_bb_113;
    z_bb_113:
    if (zT_627) goto z_bb_108; else goto z_bb_109;
    z_bb_114:
    zT_641 = 18;
    return zT_641;
    z_bb_115:
    fnt_ptypes[fnt_pc] = fnt_pt;
    zT_642 = 1;
    zT_643 = fnt_pc + zT_642;
    fnt_pc = zT_643;
    fnt_pc = zT_643;
    goto z_bb_110;
    z_bb_116:
    zT_657 = fnt_pre.len;
    zT_658 = fnt_pri < zT_657;
    if (zT_658) goto z_bb_120; else goto z_bb_121;
    z_bb_117:
    zT_662 = fnt_pre.ptr;
    zT_663 = zT_662[fnt_pri];
    fnt_nb[fnt_np] = zT_663;
    zT_664 = 1;
    zT_665 = fnt_np + zT_664;
    fnt_np = zT_665;
    fnt_np = zT_665;
    goto z_bb_119;
    z_bb_118:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_669[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fnt_rb[_i] = zT_669[_i];
        _i++;
    }
}
    zT_673 = 0;
    zT_674 = fnt_ret_box[zT_673];
    zT_671 = zT_674;
    zT_675 = (unsigned char*)fnt_rb;
    zT_676 = 12;
    zT_677 = 0;
    zT_678 = zT_675 + zT_677;
    zT_679 = zT_676 - zT_677;
    zT_680.ptr = zT_678;
    zT_680.len = zT_679;
    zT_672 = zT_680;
    zT_681 = zF_A7504564_itoa(zT_671, zT_672);
    fnt_rl = zT_681;
    fnt_rl = zT_681;
    fnt_rl = zT_681;
    zT_683 = 11;
    zT_684 = (unsigned int)fnt_rl;
    zT_685 = zT_683 - zT_684;
    fnt_rs = zT_685;
    fnt_rs = zT_685;
    fnt_rs = zT_685;
    goto z_bb_123;
    z_bb_119:
    zT_666 = 1;
    zT_667 = fnt_pri + zT_666;
    fnt_pri = zT_667;
    fnt_pri = zT_667;
    goto z_bb_116;
    z_bb_120:
    zT_660 = 95;
    zT_661 = fnt_np < zT_660;
    zT_659 = zT_661;
    goto z_bb_122;
    z_bb_121:
    zT_659 = 0;
    goto z_bb_122;
    z_bb_122:
    if (zT_659) goto z_bb_117; else goto z_bb_118;
    z_bb_123:
    zT_686 = 11;
    zT_687 = fnt_rs < zT_686;
    if (zT_687) goto z_bb_127; else goto z_bb_128;
    z_bb_124:
    zT_691 = fnt_rb[fnt_rs];
    fnt_nb[fnt_np] = zT_691;
    zT_692 = 1;
    zT_693 = fnt_np + zT_692;
    fnt_np = zT_693;
    fnt_np = zT_693;
    goto z_bb_126;
    z_bb_125:
    zT_697 = 0;
    fnt_k = zT_697;
    fnt_k = zT_697;
    fnt_k = zT_697;
    goto z_bb_130;
    z_bb_126:
    zT_694 = 1;
    zT_695 = fnt_rs + zT_694;
    fnt_rs = zT_695;
    fnt_rs = zT_695;
    goto z_bb_123;
    z_bb_127:
    zT_689 = 95;
    zT_690 = fnt_np < zT_689;
    zT_688 = zT_690;
    goto z_bb_129;
    z_bb_128:
    zT_688 = 0;
    goto z_bb_129;
    z_bb_129:
    if (zT_688) goto z_bb_124; else goto z_bb_125;
    z_bb_130:
    zT_698 = fnt_k < fnt_pc;
    if (zT_698) goto z_bb_134; else goto z_bb_135;
    z_bb_131:
    zT_702 = 95;
    zT_703 = fnt_np < zT_702;
    if (zT_703) goto z_bb_137; else goto z_bb_138;
    z_bb_132:
    zT_739 = env->interner;
    zT_737 = zT_739;
    zT_740 = (unsigned char*)fnt_nb;
    zT_742 = 0;
    zT_743 = zT_740 + zT_742;
    zT_744 = fnt_np - zT_742;
    zT_745.ptr = zT_743;
    zT_745.len = zT_744;
    zT_738 = zT_745;
    zT_746 = zF_50C274AF_stringInternerInter(zT_737, zT_738);
    fnt_name_id = zT_746;
    fnt_name_id = zT_746;
    fnt_name_id = zT_746;
    zT_748 = env->typereg;
    zT_749 = zT_748->xt_len;
    zT_750 = (unsigned int)zT_749;
    fnt_pstart = zT_750;
    fnt_pstart = zT_750;
    fnt_pstart = zT_750;
    zT_752 = 0;
    fnt_a = zT_752;
    fnt_a = zT_752;
    fnt_a = zT_752;
    goto z_bb_146;
    z_bb_133:
    zT_734 = 1;
    zT_735 = fnt_k + zT_734;
    fnt_k = zT_735;
    fnt_k = zT_735;
    goto z_bb_130;
    z_bb_134:
    zT_700 = 95;
    zT_701 = fnt_np < zT_700;
    zT_699 = zT_701;
    goto z_bb_136;
    z_bb_135:
    zT_699 = 0;
    goto z_bb_136;
    z_bb_136:
    if (zT_699) goto z_bb_131; else goto z_bb_132;
    z_bb_137:
    zT_704 = 95;
    fnt_nb[fnt_np] = zT_704;
    zT_705 = 1;
    zT_706 = fnt_np + zT_705;
    fnt_np = zT_706;
    fnt_np = zT_706;
    goto z_bb_138;
    z_bb_138:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_708[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fnt_pb[_i] = zT_708[_i];
        _i++;
    }
}
    zT_712 = fnt_ptypes[fnt_k];
    zT_710 = zT_712;
    zT_713 = (unsigned char*)fnt_pb;
    zT_714 = 12;
    zT_715 = 0;
    zT_716 = zT_713 + zT_715;
    zT_717 = zT_714 - zT_715;
    zT_718.ptr = zT_716;
    zT_718.len = zT_717;
    zT_711 = zT_718;
    zT_719 = zF_A7504564_itoa(zT_710, zT_711);
    fnt_pl = zT_719;
    fnt_pl = zT_719;
    fnt_pl = zT_719;
    zT_721 = 11;
    zT_722 = (unsigned int)fnt_pl;
    zT_723 = zT_721 - zT_722;
    fnt_ps = zT_723;
    fnt_ps = zT_723;
    fnt_ps = zT_723;
    goto z_bb_139;
    z_bb_139:
    zT_724 = 11;
    zT_725 = fnt_ps < zT_724;
    if (zT_725) goto z_bb_143; else goto z_bb_144;
    z_bb_140:
    zT_729 = fnt_pb[fnt_ps];
    fnt_nb[fnt_np] = zT_729;
    zT_730 = 1;
    zT_731 = fnt_np + zT_730;
    fnt_np = zT_731;
    fnt_np = zT_731;
    goto z_bb_142;
    z_bb_141:
    goto z_bb_133;
    z_bb_142:
    zT_732 = 1;
    zT_733 = fnt_ps + zT_732;
    fnt_ps = zT_733;
    fnt_ps = zT_733;
    goto z_bb_139;
    z_bb_143:
    zT_727 = 95;
    zT_728 = fnt_np < zT_727;
    zT_726 = zT_728;
    goto z_bb_145;
    z_bb_144:
    zT_726 = 0;
    goto z_bb_145;
    z_bb_145:
    if (zT_726) goto z_bb_140; else goto z_bb_141;
    z_bb_146:
    zT_753 = fnt_a < fnt_pc;
    if (zT_753) goto z_bb_147; else goto z_bb_148;
    z_bb_147:
    zT_756 = env->typereg;
    zT_754 = zT_756;
    zT_757 = fnt_ptypes[fnt_a];
    zT_755 = zT_757;
    zF_4C03AE3D_xtAppend(zT_754, zT_755);
    goto z_bb_149;
    z_bb_148:
    zT_769 = env->typereg;
    zT_761 = zT_769;
    zT_762 = fnt_name_id;
    zT_770 = 0;
    zT_763 = zT_770;
    zT_771 = 0;
    zT_764 = zT_771;
    zT_772 = 0;
    zT_765 = zT_772;
    zT_773 = (unsigned int)fnt_pstart;
    zT_766 = zT_773;
    zT_774 = (unsigned short)fnt_pc;
    zT_767 = zT_774;
    zT_775 = 0;
    zT_776 = fnt_ret_box[zT_775];
    zT_768 = zT_776;
    zT_777 = zF_474336D7_typeRegistryGetOrCr(zT_761, zT_762, zT_763, zT_764, zT_765, zT_766, zT_767, zT_768);
    fnt_tid = zT_777;
    fnt_tid = zT_777;
    fnt_tid = zT_777;
    zT_779 = "OPTVOID:fntT";
    zT_781 = 12;
    zT_780.ptr = zT_779;
    zT_780.len = zT_781;
    opm3_m = zT_780;
    opm3_m = zT_780;
    opm3_m = zT_780;
    zT_782 = opm3_m;
    zT_783 = fnt_tid;
    zF_C914CB83_markerWriteInt(zT_782, zT_783);
    zT_786 = env->typereg;
    zT_784 = zT_786;
    zT_785 = fnt_tid;
    zF_263F0272_typeRegistryMarkFnP(zT_784, zT_785);
    zT_790 = env->typereg;
    zT_787 = zT_790;
    zT_788 = fnt_tid;
    zT_791 = 0;
    zT_789 = zT_791;
    zT_792 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_787, zT_788, zT_789);
    return zT_792;
    z_bb_149:
    zT_758 = 1;
    zT_759 = fnt_a + zT_758;
    fnt_a = zT_759;
    fnt_a = zT_759;
    goto z_bb_146;
    z_bb_150:
    zT_797 = env;
    zT_800 = node.child_0;
    zT_798 = zT_800;
    zT_801 = 1;
    zT_802 = depth + zT_801;
    zT_799 = zT_802;
    zT_803 = zF_F2107C15_resolveTypeExprFull(zT_797, zT_798, zT_799);
    child_type = zT_803;
    child_type = zT_803;
    child_type = zT_803;
    zT_804 = 18;
    zT_805 = child_type == zT_804;
    if (zT_805) goto z_bb_152; else goto z_bb_153;
    z_bb_151:
    zT_1328 = "UND:n";
    zT_1330 = 5;
    zT_1329.ptr = zT_1328;
    zT_1329.len = zT_1330;
    und_nm2 = zT_1329;
    und_nm2 = zT_1329;
    und_nm2 = zT_1329;
    zT_1331 = und_nm2;
    zT_1332 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1331, zT_1332);
    zT_1334 = "UND:k";
    zT_1336 = 5;
    zT_1335.ptr = zT_1334;
    zT_1335.len = zT_1336;
    und_km = zT_1335;
    und_km = zT_1335;
    und_km = zT_1335;
    zT_1337 = und_km;
    zT_1339 = node.kind;
    zT_1340 = (unsigned int)zT_1339;
    zT_1338 = zT_1340;
    zF_C914CB83_markerWriteInt(zT_1337, zT_1338);
    zT_1341 = 18;
    return zT_1341;
    z_bb_152:
    zT_806 = 18;
    return zT_806;
    z_bb_153:
    zT_807 = node.kind;
    zT_810 = zT_8143F551_AstKind_ptr_type;
    zT_811 = zT_807 == zT_810;
    if (zT_811) goto z_bb_155; else goto z_bb_154;
    z_bb_154:
    zT_813 = node.kind;
    zT_816 = zT_8143F551_AstKind_many_ptr_type;
    zT_817 = zT_813 == zT_816;
    zT_812 = zT_817;
    goto z_bb_156;
    z_bb_155:
    zT_812 = 1;
    goto z_bb_156;
    z_bb_156:
    if (zT_812) goto z_bb_157; else goto z_bb_158;
    z_bb_157:
    zT_819 = "PTR:i";
    zT_821 = 5;
    zT_820.ptr = zT_819;
    zT_820.len = zT_821;
    ptm = zT_820;
    ptm = zT_820;
    ptm = zT_820;
    zT_822 = ptm;
    zF_48AC7B3A_markerWrite(zT_822);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_824[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ptib[_i] = zT_824[_i];
        _i++;
    }
}
    zT_826 = node_idx;
    zT_828 = (unsigned char*)ptib;
    zT_829 = 10;
    zT_830 = 0;
    zT_831 = zT_828 + zT_830;
    zT_832 = zT_829 - zT_830;
    zT_833.ptr = zT_831;
    zT_833.len = zT_832;
    zT_827 = zT_833;
    zT_834 = zF_A7504564_itoa(zT_826, zT_827);
    ptil = zT_834;
    ptil = zT_834;
    ptil = zT_834;
    zT_836 = 9;
    zT_837 = (unsigned int)ptil;
    zT_838 = zT_836 - zT_837;
    ptis = zT_838;
    ptis = zT_838;
    ptis = zT_838;
    zT_840 = (unsigned char*)ptib;
    zT_842 = 9;
    zT_843 = zT_840 + ptis;
    zT_844 = zT_842 - ptis;
    zT_845.ptr = zT_843;
    zT_845.len = zT_844;
    zT_839 = zT_845;
    zF_48AC7B3A_markerWrite(zT_839);
    zT_847 = "k";
    zT_849 = 1;
    zT_848.ptr = zT_847;
    zT_848.len = zT_849;
    ptkm = zT_848;
    ptkm = zT_848;
    ptkm = zT_848;
    zT_850 = ptkm;
    zF_48AC7B3A_markerWrite(zT_850);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_852[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ptkb[_i] = zT_852[_i];
        _i++;
    }
}
    zT_856 = node.kind;
    zT_857 = (unsigned int)zT_856;
    zT_854 = zT_857;
    zT_858 = (unsigned char*)ptkb;
    zT_859 = 10;
    zT_860 = 0;
    zT_861 = zT_858 + zT_860;
    zT_862 = zT_859 - zT_860;
    zT_863.ptr = zT_861;
    zT_863.len = zT_862;
    zT_855 = zT_863;
    zT_864 = zF_A7504564_itoa(zT_854, zT_855);
    ptkl = zT_864;
    ptkl = zT_864;
    ptkl = zT_864;
    zT_866 = 9;
    zT_867 = (unsigned int)ptkl;
    zT_868 = zT_866 - zT_867;
    ptks = zT_868;
    ptks = zT_868;
    ptks = zT_868;
    zT_870 = (unsigned char*)ptkb;
    zT_872 = 9;
    zT_873 = zT_870 + ptks;
    zT_874 = zT_872 - ptks;
    zT_875.ptr = zT_873;
    zT_875.len = zT_874;
    zT_869 = zT_875;
    zF_48AC7B3A_markerWrite(zT_869);
    zT_877 = "c";
    zT_879 = 1;
    zT_878.ptr = zT_877;
    zT_878.len = zT_879;
    ptcm = zT_878;
    ptcm = zT_878;
    ptcm = zT_878;
    zT_880 = ptcm;
    zF_48AC7B3A_markerWrite(zT_880);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_882[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ptcb[_i] = zT_882[_i];
        _i++;
    }
}
    zT_884 = child_type;
    zT_886 = (unsigned char*)ptcb;
    zT_887 = 10;
    zT_888 = 0;
    zT_889 = zT_886 + zT_888;
    zT_890 = zT_887 - zT_888;
    zT_891.ptr = zT_889;
    zT_891.len = zT_890;
    zT_885 = zT_891;
    zT_892 = zF_A7504564_itoa(zT_884, zT_885);
    ptcl = zT_892;
    ptcl = zT_892;
    ptcl = zT_892;
    zT_894 = 9;
    zT_895 = (unsigned int)ptcl;
    zT_896 = zT_894 - zT_895;
    ptcs = zT_896;
    ptcs = zT_896;
    ptcs = zT_896;
    zT_898 = (unsigned char*)ptcb;
    zT_900 = 9;
    zT_901 = zT_898 + ptcs;
    zT_902 = zT_900 - ptcs;
    zT_903.ptr = zT_901;
    zT_903.len = zT_902;
    zT_897 = zT_903;
    zF_48AC7B3A_markerWrite(zT_897);
    zT_905 = node.flags;
    zT_906 = 1;
    zT_907 = zT_905 & zT_906;
    zT_908 = 0;
    zT_909 = zT_907 != zT_908;
    is_const = zT_909;
    is_const = zT_909;
    is_const = zT_909;
    zT_910 = node.kind;
    zT_913 = zT_8143F551_AstKind_ptr_type;
    zT_914 = zT_910 == zT_913;
    if (zT_914) goto z_bb_159; else goto z_bb_161;
    z_bb_158:
    zT_993 = node.kind;
    zT_996 = zT_8143F551_AstKind_slice_type;
    zT_997 = zT_993 == zT_996;
    if (zT_997) goto z_bb_162; else goto z_bb_163;
    z_bb_159:
    zT_919 = env->typereg;
    zT_916 = zT_919;
    zT_917 = child_type;
    zT_918 = is_const;
    zT_920 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_916, zT_917, zT_918);
    ptr_tid = zT_920;
    ptr_tid = zT_920;
    ptr_tid = zT_920;
    zT_922 = "P";
    zT_924 = 1;
    zT_923.ptr = zT_922;
    zT_923.len = zT_924;
    ppm = zT_923;
    ppm = zT_923;
    ppm = zT_923;
    zT_925 = ppm;
    zF_48AC7B3A_markerWrite(zT_925);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_927[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ppb[_i] = zT_927[_i];
        _i++;
    }
}
    zT_929 = ptr_tid;
    zT_931 = (unsigned char*)ppb;
    zT_932 = 10;
    zT_933 = 0;
    zT_934 = zT_931 + zT_933;
    zT_935 = zT_932 - zT_933;
    zT_936.ptr = zT_934;
    zT_936.len = zT_935;
    zT_930 = zT_936;
    zT_937 = zF_A7504564_itoa(zT_929, zT_930);
    ppl = zT_937;
    ppl = zT_937;
    ppl = zT_937;
    zT_939 = 9;
    zT_940 = (unsigned int)ppl;
    zT_941 = zT_939 - zT_940;
    pps = zT_941;
    pps = zT_941;
    pps = zT_941;
    zT_943 = (unsigned char*)ppb;
    zT_945 = 9;
    zT_946 = zT_943 + pps;
    zT_947 = zT_945 - pps;
    zT_948.ptr = zT_946;
    zT_948.len = zT_947;
    zT_942 = zT_948;
    zF_48AC7B3A_markerWrite(zT_942);
    zT_950 = "\n";
    zT_952 = 1;
    zT_951.ptr = zT_950;
    zT_951.len = zT_952;
    pnl = zT_951;
    pnl = zT_951;
    pnl = zT_951;
    zT_953 = pnl;
    zF_48AC7B3A_markerWrite(zT_953);
    return ptr_tid;
    goto z_bb_158;
    z_bb_161:
    zT_958 = env->typereg;
    zT_955 = zT_958;
    zT_956 = child_type;
    zT_957 = is_const;
    zT_959 = zF_402D622A_typeRegistryGetOrCr(zT_955, zT_956, zT_957);
    ptr_tid2 = zT_959;
    ptr_tid2 = zT_959;
    ptr_tid2 = zT_959;
    zT_961 = "M";
    zT_963 = 1;
    zT_962.ptr = zT_961;
    zT_962.len = zT_963;
    ppm2 = zT_962;
    ppm2 = zT_962;
    ppm2 = zT_962;
    zT_964 = ppm2;
    zF_48AC7B3A_markerWrite(zT_964);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_966[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        ppb2[_i] = zT_966[_i];
        _i++;
    }
}
    zT_968 = ptr_tid2;
    zT_970 = (unsigned char*)ppb2;
    zT_971 = 10;
    zT_972 = 0;
    zT_973 = zT_970 + zT_972;
    zT_974 = zT_971 - zT_972;
    zT_975.ptr = zT_973;
    zT_975.len = zT_974;
    zT_969 = zT_975;
    zT_976 = zF_A7504564_itoa(zT_968, zT_969);
    ppl2 = zT_976;
    ppl2 = zT_976;
    ppl2 = zT_976;
    zT_978 = 9;
    zT_979 = (unsigned int)ppl2;
    zT_980 = zT_978 - zT_979;
    pps2 = zT_980;
    pps2 = zT_980;
    pps2 = zT_980;
    zT_982 = (unsigned char*)ppb2;
    zT_984 = 9;
    zT_985 = zT_982 + pps2;
    zT_986 = zT_984 - pps2;
    zT_987.ptr = zT_985;
    zT_987.len = zT_986;
    zT_981 = zT_987;
    zF_48AC7B3A_markerWrite(zT_981);
    zT_989 = "\n";
    zT_991 = 1;
    zT_990.ptr = zT_989;
    zT_990.len = zT_991;
    pnl2 = zT_990;
    pnl2 = zT_990;
    pnl2 = zT_990;
    zT_992 = pnl2;
    zF_48AC7B3A_markerWrite(zT_992);
    return ptr_tid2;
    z_bb_162:
    zT_999 = node.flags;
    zT_1000 = 1;
    zT_1001 = zT_999 & zT_1000;
    zT_1002 = 0;
    zT_1003 = zT_1001 != zT_1002;
    is_const = zT_1003;
    is_const = zT_1003;
    is_const = zT_1003;
    zT_1008 = env->typereg;
    zT_1005 = zT_1008;
    zT_1006 = child_type;
    zT_1007 = is_const;
    zT_1009 = zF_8FC81A87_typeRegistryGetOrCr(zT_1005, zT_1006, zT_1007);
    sl_tid = zT_1009;
    sl_tid = zT_1009;
    sl_tid = zT_1009;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1011[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        sl_e[_i] = zT_1011[_i];
        _i++;
    }
}
    zT_1013 = child_type;
    zT_1015 = (unsigned char*)sl_e;
    zT_1016 = 20;
    zT_1017 = 0;
    zT_1018 = zT_1015 + zT_1017;
    zT_1019 = zT_1016 - zT_1017;
    zT_1020.ptr = zT_1018;
    zT_1020.len = zT_1019;
    zT_1014 = zT_1020;
    zT_1021 = zF_A7504564_itoa(zT_1013, zT_1014);
    sl_el = zT_1021;
    sl_el = zT_1021;
    sl_el = zT_1021;
    zT_1023 = 19;
    zT_1024 = (unsigned int)sl_el;
    zT_1025 = zT_1023 - zT_1024;
    sl_es = zT_1025;
    sl_es = zT_1025;
    sl_es = zT_1025;
    zT_1027 = "SL:e";
    zT_1029 = 4;
    zT_1028.ptr = zT_1027;
    zT_1028.len = zT_1029;
    sm = zT_1028;
    sm = zT_1028;
    sm = zT_1028;
    zT_1030 = sm;
    zF_48AC7B3A_markerWrite(zT_1030);
    zT_1032 = (unsigned char*)sl_e;
    zT_1034 = 19;
    zT_1035 = zT_1032 + sl_es;
    zT_1036 = zT_1034 - sl_es;
    zT_1037.ptr = zT_1035;
    zT_1037.len = zT_1036;
    zT_1031 = zT_1037;
    zF_48AC7B3A_markerWrite(zT_1031);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1039[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        sl_r[_i] = zT_1039[_i];
        _i++;
    }
}
    zT_1041 = sl_tid;
    zT_1043 = (unsigned char*)sl_r;
    zT_1044 = 20;
    zT_1045 = 0;
    zT_1046 = zT_1043 + zT_1045;
    zT_1047 = zT_1044 - zT_1045;
    zT_1048.ptr = zT_1046;
    zT_1048.len = zT_1047;
    zT_1042 = zT_1048;
    zT_1049 = zF_A7504564_itoa(zT_1041, zT_1042);
    sl_rl = zT_1049;
    sl_rl = zT_1049;
    sl_rl = zT_1049;
    zT_1051 = 19;
    zT_1052 = (unsigned int)sl_rl;
    zT_1053 = zT_1051 - zT_1052;
    sl_rs = zT_1053;
    sl_rs = zT_1053;
    sl_rs = zT_1053;
    zT_1055 = "s";
    zT_1057 = 1;
    zT_1056.ptr = zT_1055;
    zT_1056.len = zT_1057;
    s2 = zT_1056;
    s2 = zT_1056;
    s2 = zT_1056;
    zT_1058 = s2;
    zF_48AC7B3A_markerWrite(zT_1058);
    zT_1060 = (unsigned char*)sl_r;
    zT_1062 = 19;
    zT_1063 = zT_1060 + sl_rs;
    zT_1064 = zT_1062 - sl_rs;
    zT_1065.ptr = zT_1063;
    zT_1065.len = zT_1064;
    zT_1059 = zT_1065;
    zF_48AC7B3A_markerWrite(zT_1059);
    zT_1067 = "\n";
    zT_1069 = 1;
    zT_1068.ptr = zT_1067;
    zT_1068.len = zT_1069;
    s3 = zT_1068;
    s3 = zT_1068;
    s3 = zT_1068;
    zT_1070 = s3;
    zF_48AC7B3A_markerWrite(zT_1070);
    return sl_tid;
    z_bb_163:
    zT_1071 = node.kind;
    zT_1074 = zT_8143F551_AstKind_optional_type;
    zT_1075 = zT_1071 == zT_1074;
    if (zT_1075) goto z_bb_164; else goto z_bb_165;
    z_bb_164:
    zT_1077 = "OPTVOID:opt";
    zT_1079 = 11;
    zT_1078.ptr = zT_1077;
    zT_1078.len = zT_1079;
    optvd_m = zT_1078;
    optvd_m = zT_1078;
    optvd_m = zT_1078;
    zT_1080 = optvd_m;
    zT_1081 = child_type;
    zF_C914CB83_markerWriteInt(zT_1080, zT_1081);
    zT_1085 = env->typereg;
    zT_1083 = zT_1085;
    zT_1084 = child_type;
    zT_1086 = zF_74A7234F_typeRegistryGetOrCr(zT_1083, zT_1084);
    optvd_tid = zT_1086;
    optvd_tid = zT_1086;
    optvd_tid = zT_1086;
    zT_1088 = "OPTVOID:optR";
    zT_1090 = 12;
    zT_1089.ptr = zT_1088;
    zT_1089.len = zT_1090;
    optvd_rm = zT_1089;
    optvd_rm = zT_1089;
    optvd_rm = zT_1089;
    zT_1091 = optvd_rm;
    zT_1092 = optvd_tid;
    zF_C914CB83_markerWriteInt(zT_1091, zT_1092);
    return optvd_tid;
    z_bb_165:
    zT_1093 = node.kind;
    zT_1096 = zT_8143F551_AstKind_array_type;
    zT_1097 = zT_1093 == zT_1096;
    if (zT_1097) goto z_bb_166; else goto z_bb_167;
    z_bb_166:
    zT_1099 = "T0";
    zT_1101 = 2;
    zT_1100.ptr = zT_1099;
    zT_1100.len = zT_1101;
    t0m = zT_1100;
    t0m = zT_1100;
    t0m = zT_1100;
    zT_1102 = t0m;
    zF_48AC7B3A_markerWrite(zT_1102);
    zT_1104 = "T1e";
    zT_1106 = 3;
    zT_1105.ptr = zT_1104;
    zT_1105.len = zT_1106;
    t1m = zT_1105;
    t1m = zT_1105;
    t1m = zT_1105;
    zT_1107 = t1m;
    zF_48AC7B3A_markerWrite(zT_1107);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1109[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        t1b[_i] = zT_1109[_i];
        _i++;
    }
}
    zT_1111 = child_type;
    zT_1113 = (unsigned char*)t1b;
    zT_1114 = 20;
    zT_1115 = 0;
    zT_1116 = zT_1113 + zT_1115;
    zT_1117 = zT_1114 - zT_1115;
    zT_1118.ptr = zT_1116;
    zT_1118.len = zT_1117;
    zT_1112 = zT_1118;
    zT_1119 = zF_A7504564_itoa(zT_1111, zT_1112);
    t1l = zT_1119;
    t1l = zT_1119;
    t1l = zT_1119;
    zT_1121 = 19;
    zT_1122 = (unsigned int)t1l;
    zT_1123 = zT_1121 - zT_1122;
    t1s = zT_1123;
    t1s = zT_1123;
    t1s = zT_1123;
    zT_1125 = (unsigned char*)t1b;
    zT_1127 = 19;
    zT_1128 = zT_1125 + t1s;
    zT_1129 = zT_1127 - t1s;
    zT_1130.ptr = zT_1128;
    zT_1130.len = zT_1129;
    zT_1124 = zT_1130;
    zF_48AC7B3A_markerWrite(zT_1124);
    zT_1131 = node.child_1;
    zT_1132 = 0;
    zT_1133 = zT_1131 != (unsigned int)zT_1132;
    if (zT_1133) goto z_bb_168; else goto z_bb_169;
    z_bb_167:
    goto z_bb_151;
    z_bb_168:
    zT_1137 = env->store;
    zT_1135 = zT_1137;
    zT_1138 = node.child_1;
    zT_1136 = zT_1138;
    zT_1139 = zF_FCDD1D35_astStoreNodeAt(zT_1135, zT_1136);
    sz_node = zT_1139;
    sz_node = zT_1139;
    sz_node = zT_1139;
    zT_1141 = 0;
    arr_len = zT_1141;
    arr_len = zT_1141;
    arr_len = zT_1141;
    zT_1143 = 0;
    arr_resolved = zT_1143;
    arr_resolved = zT_1143;
    arr_resolved = zT_1143;
    zT_1144 = sz_node.kind;
    zT_1147 = zT_8143F551_AstKind_int_literal;
    zT_1148 = zT_1144 == zT_1147;
    if (zT_1148) goto z_bb_170; else goto z_bb_172;
    z_bb_169:
    zT_1326 = 18;
    return zT_1326;
    z_bb_170:
    zT_1151 = env->store;
    zT_1149 = zT_1151;
    zT_1152 = node.child_1;
    zT_1150 = zT_1152;
    zT_1153 = zF_678B9A72_astStoreIntValue(zT_1149, zT_1150);
    zT_1154 = __bootstrap_u32_from_u64(zT_1153);
    arr_len = zT_1154;
    arr_len = zT_1154;
    zT_1155 = 1;
    arr_resolved = zT_1155;
    arr_resolved = zT_1155;
    goto z_bb_171;
    z_bb_171:
    zT_1253 = "T2L";
    zT_1255 = 3;
    zT_1254.ptr = zT_1253;
    zT_1254.len = zT_1255;
    t2m = zT_1254;
    t2m = zT_1254;
    t2m = zT_1254;
    zT_1256 = t2m;
    zF_48AC7B3A_markerWrite(zT_1256);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1258[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        t2b[_i] = zT_1258[_i];
        _i++;
    }
}
    zT_1260 = arr_len;
    zT_1262 = (unsigned char*)t2b;
    zT_1263 = 20;
    zT_1264 = 0;
    zT_1265 = zT_1262 + zT_1264;
    zT_1266 = zT_1263 - zT_1264;
    zT_1267.ptr = zT_1265;
    zT_1267.len = zT_1266;
    zT_1261 = zT_1267;
    zT_1268 = zF_A7504564_itoa(zT_1260, zT_1261);
    t2l = zT_1268;
    t2l = zT_1268;
    t2l = zT_1268;
    zT_1270 = 19;
    zT_1271 = (unsigned int)t2l;
    zT_1272 = zT_1270 - zT_1271;
    t2s = zT_1272;
    t2s = zT_1272;
    t2s = zT_1272;
    zT_1274 = (unsigned char*)t2b;
    zT_1276 = 19;
    zT_1277 = zT_1274 + t2s;
    zT_1278 = zT_1276 - t2s;
    zT_1279.ptr = zT_1277;
    zT_1279.len = zT_1278;
    zT_1273 = zT_1279;
    zF_48AC7B3A_markerWrite(zT_1273);
    if (arr_resolved) goto z_bb_214; else goto z_bb_215;
    z_bb_172:
    zT_1156 = sz_node.kind;
    zT_1159 = zT_8143F551_AstKind_add;
    zT_1160 = zT_1156 == zT_1159;
    if (zT_1160) goto z_bb_174; else goto z_bb_173;
    z_bb_173:
    zT_1162 = sz_node.kind;
    zT_1165 = zT_8143F551_AstKind_sub;
    zT_1166 = zT_1162 == zT_1165;
    zT_1161 = zT_1166;
    goto z_bb_175;
    z_bb_174:
    zT_1161 = 1;
    goto z_bb_175;
    z_bb_175:
    if (zT_1161) goto z_bb_176; else goto z_bb_178;
    z_bb_176:
    zT_1168 = env;
    zT_1170 = sz_node.child_0;
    zT_1169 = zT_1170;
    zT_1171 = zF_6D0DD27D_evalConstU32Full(zT_1168, zT_1169);
    lhs = zT_1171;
    lhs = zT_1171;
    lhs = zT_1171;
    zT_1173 = env;
    zT_1175 = sz_node.child_1;
    zT_1174 = zT_1175;
    zT_1176 = zF_6D0DD27D_evalConstU32Full(zT_1173, zT_1174);
    rhs = zT_1176;
    rhs = zT_1176;
    rhs = zT_1176;
    zT_1177 = 4294967295u;
    zT_1178 = lhs != zT_1177;
    if (zT_1178) goto z_bb_179; else goto z_bb_180;
    z_bb_177:
    goto z_bb_171;
    z_bb_178:
    zT_1190 = sz_node.kind;
    zT_1193 = zT_8143F551_AstKind_mul;
    zT_1194 = zT_1190 == zT_1193;
    if (zT_1194) goto z_bb_188; else goto z_bb_187;
    z_bb_179:
    zT_1180 = 4294967295u;
    zT_1181 = rhs != zT_1180;
    zT_1179 = zT_1181;
    goto z_bb_181;
    z_bb_180:
    zT_1179 = 0;
    goto z_bb_181;
    z_bb_181:
    if (zT_1179) goto z_bb_182; else goto z_bb_183;
    z_bb_182:
    zT_1182 = 1;
    arr_resolved = zT_1182;
    arr_resolved = zT_1182;
    zT_1183 = sz_node.kind;
    zT_1186 = zT_8143F551_AstKind_add;
    zT_1187 = zT_1183 == zT_1186;
    if (zT_1187) goto z_bb_184; else goto z_bb_186;
    z_bb_183:
    goto z_bb_177;
    z_bb_184:
    zT_1188 = lhs + rhs;
    arr_len = zT_1188;
    arr_len = zT_1188;
    goto z_bb_185;
    z_bb_185:
    goto z_bb_183;
    z_bb_186:
    zT_1189 = lhs - rhs;
    arr_len = zT_1189;
    arr_len = zT_1189;
    goto z_bb_185;
    z_bb_187:
    zT_1196 = sz_node.kind;
    zT_1199 = zT_8143F551_AstKind_div;
    zT_1200 = zT_1196 == zT_1199;
    zT_1195 = zT_1200;
    goto z_bb_189;
    z_bb_188:
    zT_1195 = 1;
    goto z_bb_189;
    z_bb_189:
    if (zT_1195) goto z_bb_191; else goto z_bb_190;
    z_bb_190:
    zT_1202 = sz_node.kind;
    zT_1205 = zT_8143F551_AstKind_mod_op;
    zT_1206 = zT_1202 == zT_1205;
    zT_1201 = zT_1206;
    goto z_bb_192;
    z_bb_191:
    zT_1201 = 1;
    goto z_bb_192;
    z_bb_192:
    if (zT_1201) goto z_bb_193; else goto z_bb_195;
    z_bb_193:
    zT_1208 = env;
    zT_1210 = sz_node.child_0;
    zT_1209 = zT_1210;
    zT_1211 = zF_6D0DD27D_evalConstU32Full(zT_1208, zT_1209);
    lhs = zT_1211;
    lhs = zT_1211;
    lhs = zT_1211;
    zT_1213 = env;
    zT_1215 = sz_node.child_1;
    zT_1214 = zT_1215;
    zT_1216 = zF_6D0DD27D_evalConstU32Full(zT_1213, zT_1214);
    rhs = zT_1216;
    rhs = zT_1216;
    rhs = zT_1216;
    zT_1217 = 4294967295u;
    zT_1218 = lhs != zT_1217;
    if (zT_1218) goto z_bb_196; else goto z_bb_197;
    z_bb_194:
    goto z_bb_177;
    z_bb_195:
    zT_1239 = sz_node.kind;
    zT_1242 = zT_8143F551_AstKind_ident_expr;
    zT_1243 = zT_1239 == zT_1242;
    if (zT_1243) goto z_bb_210; else goto z_bb_211;
    z_bb_196:
    zT_1220 = 4294967295u;
    zT_1221 = rhs != zT_1220;
    zT_1219 = zT_1221;
    goto z_bb_198;
    z_bb_197:
    zT_1219 = 0;
    goto z_bb_198;
    z_bb_198:
    if (zT_1219) goto z_bb_199; else goto z_bb_200;
    z_bb_199:
    zT_1223 = 0;
    zT_1224 = rhs != zT_1223;
    zT_1222 = zT_1224;
    goto z_bb_201;
    z_bb_200:
    zT_1222 = 0;
    goto z_bb_201;
    z_bb_201:
    if (zT_1222) goto z_bb_202; else goto z_bb_203;
    z_bb_202:
    zT_1225 = 1;
    arr_resolved = zT_1225;
    arr_resolved = zT_1225;
    zT_1226 = sz_node.kind;
    zT_1229 = zT_8143F551_AstKind_mul;
    zT_1230 = zT_1226 == zT_1229;
    if (zT_1230) goto z_bb_204; else goto z_bb_206;
    z_bb_203:
    goto z_bb_194;
    z_bb_204:
    zT_1231 = lhs * rhs;
    arr_len = zT_1231;
    arr_len = zT_1231;
    goto z_bb_205;
    z_bb_205:
    goto z_bb_203;
    z_bb_206:
    zT_1232 = sz_node.kind;
    zT_1235 = zT_8143F551_AstKind_div;
    zT_1236 = zT_1232 == zT_1235;
    if (zT_1236) goto z_bb_207; else goto z_bb_209;
    z_bb_207:
    zT_1237 = lhs / rhs;
    arr_len = zT_1237;
    arr_len = zT_1237;
    goto z_bb_208;
    z_bb_208:
    goto z_bb_205;
    z_bb_209:
    zT_1238 = lhs % rhs;
    arr_len = zT_1238;
    arr_len = zT_1238;
    goto z_bb_208;
    z_bb_210:
    zT_1245 = env;
    zT_1247 = node.child_1;
    zT_1246 = zT_1247;
    zT_1248 = zF_6D0DD27D_evalConstU32Full(zT_1245, zT_1246);
    al = zT_1248;
    al = zT_1248;
    al = zT_1248;
    zT_1249 = 4294967295u;
    zT_1250 = al != zT_1249;
    if (zT_1250) goto z_bb_212; else goto z_bb_213;
    z_bb_211:
    goto z_bb_194;
    z_bb_212:
    arr_len = al;
    arr_len = al;
    zT_1251 = 1;
    arr_resolved = zT_1251;
    arr_resolved = zT_1251;
    goto z_bb_213;
    z_bb_213:
    goto z_bb_211;
    z_bb_214:
    zT_1284 = env->typereg;
    zT_1281 = zT_1284;
    zT_1282 = child_type;
    zT_1283 = arr_len;
    zT_1285 = zF_BA693C74_typeRegistryGetOrCr(zT_1281, zT_1282, zT_1283);
    at = zT_1285;
    at = zT_1285;
    at = zT_1285;
    zT_1287 = "T3a";
    zT_1289 = 3;
    zT_1288.ptr = zT_1287;
    zT_1288.len = zT_1289;
    t3m = zT_1288;
    t3m = zT_1288;
    t3m = zT_1288;
    zT_1290 = t3m;
    zF_48AC7B3A_markerWrite(zT_1290);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1292[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        t3b[_i] = zT_1292[_i];
        _i++;
    }
}
    zT_1294 = at;
    zT_1296 = (unsigned char*)t3b;
    zT_1297 = 20;
    zT_1298 = 0;
    zT_1299 = zT_1296 + zT_1298;
    zT_1300 = zT_1297 - zT_1298;
    zT_1301.ptr = zT_1299;
    zT_1301.len = zT_1300;
    zT_1295 = zT_1301;
    zT_1302 = zF_A7504564_itoa(zT_1294, zT_1295);
    t3l = zT_1302;
    t3l = zT_1302;
    t3l = zT_1302;
    zT_1304 = 19;
    zT_1305 = (unsigned int)t3l;
    zT_1306 = zT_1304 - zT_1305;
    t3s = zT_1306;
    t3s = zT_1306;
    t3s = zT_1306;
    zT_1308 = (unsigned char*)t3b;
    zT_1310 = 19;
    zT_1311 = zT_1308 + t3s;
    zT_1312 = zT_1310 - t3s;
    zT_1313.ptr = zT_1311;
    zT_1313.len = zT_1312;
    zT_1307 = zT_1313;
    zF_48AC7B3A_markerWrite(zT_1307);
    zT_1314 = 18;
    zT_1315 = at != zT_1314;
    if (zT_1315) goto z_bb_216; else goto z_bb_218;
    z_bb_215:
    goto z_bb_169;
    z_bb_216:
    zT_1317 = "A";
    zT_1319 = 1;
    zT_1318.ptr = zT_1317;
    zT_1318.len = zT_1319;
    am = zT_1318;
    am = zT_1318;
    am = zT_1318;
    zT_1320 = am;
    zF_48AC7B3A_markerWrite(zT_1320);
    goto z_bb_217;
    z_bb_217:
    return at;
    z_bb_218:
    zT_1322 = "a";
    zT_1324 = 1;
    zT_1323.ptr = zT_1322;
    zT_1323.len = zT_1324;
    am = zT_1323;
    am = zT_1323;
    am = zT_1323;
    zT_1325 = am;
    zF_48AC7B3A_markerWrite(zT_1325);
    goto z_bb_217;
}

/* resolveDeclAggregateFieldTypes */
void zF_F5C3193B_resolveDeclAggregat(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int mod_id, unsigned int decl_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_6B0A7D14_AstStore* zT_6;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_6B0A7D14_AstStore* zT_11;
    unsigned int zT_12;
    zT_22A7C88B_AstNode zT_13 = {0};
    zT_338B7C76_TypeRegistry* zT_15;
    zT_79FAE712_u64 zT_16;
    zT_338B7C76_TypeRegistry* zT_17;
    zT_79FAE712_u64 zT_18;
    zT_79FAE712_u64 zT_19;
    zT_79FAE712_u64 zT_20;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24 = 0;
    zT_79FAE712_u64 zT_25;
    zT_79FAE712_u64 zT_26;
    zT_BAEE192E_Opt_10 zT_27 = {0};
    unsigned char zT_28;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_D155D06D_Type* zT_32;
    unsigned int zT_33;
    zT_D155D06D_Type zT_34;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    zT_6B0A7D14_AstStore* zT_38;
    unsigned int zT_39;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_40 = {0};
    int zT_42;
    unsigned int zT_43;
    zT_33EF6BFB_TypeKind zT_44;
    zT_33EF6BFB_TypeKind zT_47;
    int zT_48;
    zT_338B7C76_TypeRegistry* zT_50;
    zT_406493CE_StructPayload* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    zT_406493CE_StructPayload zT_54;
    unsigned short zT_55;
    unsigned int zT_56;
    int zT_57;
    zT_6B0A7D14_AstStore* zT_59;
    unsigned int zT_60;
    zT_6B0A7D14_AstStore* zT_61;
    unsigned int* zT_62;
    unsigned int zT_63;
    zT_22A7C88B_AstNode zT_64 = {0};
    zT_8143F551_AstKind zT_65;
    zT_8143F551_AstKind zT_68;
    int zT_69;
    int zT_70;
    unsigned int zT_71;
    int zT_72;
    int zT_73;
    zT_ABC1EBBE_TypeResolveEnv* zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned int zT_80 = 0;
    char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    zT_4028D896_Arr_unsigned_char_2 zT_87;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    zT_6B0A7D14_AstStore* zT_93;
    unsigned int* zT_94;
    unsigned int zT_95;
    unsigned int zT_96 = 0;
    unsigned char* zT_97;
    unsigned int zT_98;
    int zT_99;
    unsigned char* zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103 = 0;
    unsigned int zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    unsigned char* zT_109;
    unsigned int zT_111;
    unsigned char* zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    char* zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    zT_4028D896_Arr_unsigned_char_2 zT_121;
    unsigned int zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    unsigned char* zT_125;
    unsigned int zT_126;
    int zT_127;
    unsigned char* zT_128;
    unsigned int zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned int zT_131 = 0;
    unsigned int zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    unsigned char* zT_137;
    unsigned int zT_139;
    unsigned char* zT_140;
    unsigned int zT_141;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_142;
    unsigned int zT_143;
    int zT_144;
    zT_338B7C76_TypeRegistry* zT_145;
    zT_2DF01B61_FieldEntry* zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    zT_2DF01B61_FieldEntry* zT_150;
    char* zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned int zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    char* zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    unsigned int zT_166;
    int zT_167;
    unsigned int zT_168;
    zT_33EF6BFB_TypeKind zT_169;
    zT_33EF6BFB_TypeKind zT_172;
    int zT_173;
    zT_338B7C76_TypeRegistry* zT_175;
    zT_54FF90FA_TaggedUnionPayload* zT_176;
    unsigned int zT_177;
    unsigned int zT_178;
    zT_54FF90FA_TaggedUnionPayload zT_179;
    char* zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    unsigned int zT_183;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_184;
    unsigned int zT_185;
    unsigned int zT_186;
    unsigned int zT_187;
    char* zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    unsigned int zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_193;
    unsigned short zT_194;
    unsigned int zT_195;
    unsigned short zT_196;
    unsigned int zT_197;
    int zT_198;
    zT_6B0A7D14_AstStore* zT_200;
    unsigned int zT_201;
    zT_6B0A7D14_AstStore* zT_202;
    unsigned int* zT_203;
    unsigned int zT_204;
    zT_22A7C88B_AstNode zT_205 = {0};
    zT_8143F551_AstKind zT_206;
    zT_8143F551_AstKind zT_209;
    int zT_210;
    int zT_211;
    unsigned int zT_212;
    int zT_213;
    int zT_214;
    zT_ABC1EBBE_TypeResolveEnv* zT_216;
    unsigned int zT_217;
    unsigned int zT_218;
    unsigned int zT_219;
    unsigned int zT_220;
    unsigned int zT_221 = 0;
    char* zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    unsigned int zT_225;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    unsigned int zT_227;
    unsigned int zT_228;
    char* zT_230;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_231;
    unsigned int zT_232;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_233;
    unsigned int zT_234;
    char* zT_236;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_237;
    unsigned int zT_238;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_239;
    zT_4028D896_Arr_unsigned_char_2 zT_241;
    unsigned int zT_243;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_244;
    zT_6B0A7D14_AstStore* zT_245;
    unsigned int zT_246;
    zT_6B0A7D14_AstStore* zT_247;
    unsigned int* zT_248;
    unsigned int zT_249;
    unsigned int zT_250 = 0;
    unsigned char* zT_251;
    unsigned int zT_252;
    int zT_253;
    unsigned char* zT_254;
    unsigned int zT_255;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_256;
    unsigned int zT_257 = 0;
    unsigned int zT_259;
    unsigned int zT_260;
    unsigned int zT_261;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_262;
    unsigned char* zT_263;
    unsigned int zT_265;
    unsigned char* zT_266;
    unsigned int zT_267;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_268;
    char* zT_270;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    unsigned int zT_272;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_273;
    zT_4028D896_Arr_unsigned_char_2 zT_275;
    unsigned int zT_277;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_278;
    unsigned char* zT_279;
    unsigned int zT_280;
    int zT_281;
    unsigned char* zT_282;
    unsigned int zT_283;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_284;
    unsigned int zT_285 = 0;
    unsigned int zT_287;
    unsigned int zT_288;
    unsigned int zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    unsigned char* zT_291;
    unsigned int zT_293;
    unsigned char* zT_294;
    unsigned int zT_295;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_296;
    char* zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    unsigned int zT_300;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_301;
    unsigned int zT_302;
    int zT_303;
    zT_338B7C76_TypeRegistry* zT_304;
    zT_2DF01B61_FieldEntry* zT_305;
    unsigned int zT_306;
    unsigned int zT_307;
    unsigned int zT_308;
    zT_2DF01B61_FieldEntry* zT_309;
    char* zT_311;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_312;
    unsigned int zT_313;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_314;
    unsigned int zT_315;
    unsigned int zT_316;
    unsigned int zT_317;
    unsigned int zT_318;
    unsigned int zT_319;
    char* zT_321;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_322;
    unsigned int zT_323;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_324;
    unsigned int zT_325;
    char* zT_327;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_328;
    unsigned int zT_329;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_330;
    int zT_331;
    unsigned int zT_332;
    zT_33EF6BFB_TypeKind zT_333;
    zT_33EF6BFB_TypeKind zT_336;
    int zT_337;
    zT_338B7C76_TypeRegistry* zT_339;
    zT_AF9231A2_UnionPayload* zT_340;
    unsigned int zT_341;
    unsigned int zT_342;
    zT_AF9231A2_UnionPayload zT_343;
    unsigned short zT_344;
    unsigned int zT_345;
    int zT_346;
    zT_6B0A7D14_AstStore* zT_348;
    unsigned int zT_349;
    zT_6B0A7D14_AstStore* zT_350;
    unsigned int* zT_351;
    unsigned int zT_352;
    zT_22A7C88B_AstNode zT_353 = {0};
    zT_8143F551_AstKind zT_354;
    zT_8143F551_AstKind zT_357;
    int zT_358;
    int zT_359;
    unsigned int zT_360;
    int zT_361;
    int zT_362;
    zT_ABC1EBBE_TypeResolveEnv* zT_364;
    unsigned int zT_365;
    unsigned int zT_366;
    unsigned int zT_367;
    unsigned int zT_368;
    unsigned int zT_369 = 0;
    unsigned int zT_370;
    int zT_371;
    zT_338B7C76_TypeRegistry* zT_372;
    zT_2DF01B61_FieldEntry* zT_373;
    unsigned int zT_374;
    unsigned int zT_375;
    unsigned int zT_376;
    zT_2DF01B61_FieldEntry* zT_377;
    int zT_378;
    unsigned int zT_379;
    zT_22A7C88B_AstNode decl;
    zT_BAEE192E_Opt_10 spid;
    unsigned int stid;
    zT_D155D06D_Type sty;
    zT_3CB0179A_Slice_zT_05F374B1_u fchildren;
    unsigned int fi2;
    zT_406493CE_StructPayload sp;
    zT_22A7C88B_AstNode fd;
    unsigned int ft;
    zT_8F083A69_Slice_zT_0B42B2F8_u b2_pn;
    zT_4028D896_Arr_unsigned_char_2 b2_pb;
    unsigned int b2_pl;
    unsigned int b2_ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u b2_tn;
    zT_4028D896_Arr_unsigned_char_2 b2_tb;
    unsigned int b2_tl;
    unsigned int b2_ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsw_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsw_tm;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_8F083A69_Slice_zT_0B42B2F8_u tui_fsm;
    zT_8F083A69_Slice_zT_0B42B2F8_u tui_fcm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dft_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dft_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dtwr_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u ftw_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ftw_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dtsk_m;
    zT_AF9231A2_UnionPayload up;
    env->module_id = mod_id;
    zT_6 = env->store;
    zT_4 = zT_6;
    zT_5 = decl_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    decl = zT_7;
    decl = zT_7;
    decl = zT_7;
    zT_11 = env->store;
    zT_9 = zT_11;
    zT_12 = decl.child_1;
    zT_10 = zT_12;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    (void)zT_13;
    zT_17 = env->typereg;
    zT_15 = zT_17;
    zT_18 = (zT_79FAE712_u64)mod_id;
    zT_19 = 32;
    zT_20 = zT_18 << zT_19;
    zT_23 = env->store;
    zT_21 = zT_23;
    zT_22 = decl_idx;
    zT_24 = zF_8BA26B9E_astStoreNodePayload(zT_21, zT_22);
    zT_25 = (zT_79FAE712_u64)zT_24;
    zT_26 = zT_20 | zT_25;
    zT_16 = zT_26;
    zT_27 = zF_0EB68360_nameCacheGet(zT_15, zT_16);
    spid = zT_27;
    spid = zT_27;
    spid = zT_27;
    zT_28 = spid.has_value;
    if (zT_28) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    stid = spid.value;
    zT_31 = env->typereg;
    zT_32 = zT_31->types_items;
    zT_33 = (unsigned int)stid;
    zT_34 = zT_32[zT_33];
    sty = zT_34;
    sty = zT_34;
    sty = zT_34;
    zT_38 = env->store;
    zT_36 = zT_38;
    zT_39 = decl.child_1;
    zT_37 = zT_39;
    zT_40 = zF_850FDF81_astStoreNodeExtraCh(zT_36, zT_37);
    fchildren = zT_40;
    fchildren = zT_40;
    fchildren = zT_40;
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    fi2 = zT_43;
    fi2 = zT_43;
    fi2 = zT_43;
    zT_44 = sty.kind;
    zT_47 = zT_33EF6BFB_TypeKind_struct_type;
    zT_48 = zT_44 == zT_47;
    if (zT_48) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    return;
    z_bb_3:
    zT_50 = env->typereg;
    zT_51 = zT_50->st_items;
    zT_52 = sty.payload_idx;
    zT_53 = (unsigned int)zT_52;
    zT_54 = zT_51[zT_53];
    sp = zT_54;
    sp = zT_54;
    sp = zT_54;
    goto z_bb_6;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_169 = sty.kind;
    zT_172 = zT_33EF6BFB_TypeKind_tagged_union_type;
    zT_173 = zT_169 == zT_172;
    if (zT_173) goto z_bb_17; else goto z_bb_19;
    z_bb_6:
    zT_55 = sp.fields_count;
    zT_56 = (unsigned int)zT_55;
    zT_57 = fi2 < zT_56;
    if (zT_57) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_61 = env->store;
    zT_59 = zT_61;
    zT_62 = fchildren.ptr;
    zT_63 = zT_62[fi2];
    zT_60 = zT_63;
    zT_64 = zF_FCDD1D35_astStoreNodeAt(zT_59, zT_60);
    fd = zT_64;
    fd = zT_64;
    fd = zT_64;
    zT_65 = fd.kind;
    zT_68 = zT_8143F551_AstKind_field_decl;
    zT_69 = zT_65 == zT_68;
    if (zT_69) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    zT_167 = 1;
    zT_168 = fi2 + zT_167;
    fi2 = zT_168;
    fi2 = zT_168;
    goto z_bb_6;
    z_bb_10:
    zT_71 = fd.child_0;
    zT_72 = 0;
    zT_73 = zT_71 != (unsigned int)zT_72;
    zT_70 = zT_73;
    goto z_bb_12;
    z_bb_11:
    zT_70 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_70) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_75 = env;
    zT_78 = fd.child_0;
    zT_76 = zT_78;
    zT_79 = 0;
    zT_77 = zT_79;
    zT_80 = zF_F2107C15_resolveTypeExprFull(zT_75, zT_76, zT_77);
    ft = zT_80;
    ft = zT_80;
    ft = zT_80;
    zT_82 = "B2:p";
    zT_84 = 4;
    zT_83.ptr = zT_82;
    zT_83.len = zT_84;
    b2_pn = zT_83;
    b2_pn = zT_83;
    b2_pn = zT_83;
    zT_85 = b2_pn;
    zF_48AC7B3A_markerWrite(zT_85);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_87[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        b2_pb[_i] = zT_87[_i];
        _i++;
    }
}
    zT_93 = env->store;
    zT_91 = zT_93;
    zT_94 = fchildren.ptr;
    zT_95 = zT_94[fi2];
    zT_92 = zT_95;
    zT_96 = zF_8BA26B9E_astStoreNodePayload(zT_91, zT_92);
    zT_89 = zT_96;
    zT_97 = (unsigned char*)b2_pb;
    zT_98 = 20;
    zT_99 = 0;
    zT_100 = zT_97 + zT_99;
    zT_101 = zT_98 - zT_99;
    zT_102.ptr = zT_100;
    zT_102.len = zT_101;
    zT_90 = zT_102;
    zT_103 = zF_A7504564_itoa(zT_89, zT_90);
    b2_pl = zT_103;
    b2_pl = zT_103;
    b2_pl = zT_103;
    zT_105 = 19;
    zT_106 = (unsigned int)b2_pl;
    zT_107 = zT_105 - zT_106;
    b2_ps = zT_107;
    b2_ps = zT_107;
    b2_ps = zT_107;
    zT_109 = (unsigned char*)b2_pb;
    zT_111 = 19;
    zT_112 = zT_109 + b2_ps;
    zT_113 = zT_111 - b2_ps;
    zT_114.ptr = zT_112;
    zT_114.len = zT_113;
    zT_108 = zT_114;
    zF_48AC7B3A_markerWrite(zT_108);
    zT_116 = "t";
    zT_118 = 1;
    zT_117.ptr = zT_116;
    zT_117.len = zT_118;
    b2_tn = zT_117;
    b2_tn = zT_117;
    b2_tn = zT_117;
    zT_119 = b2_tn;
    zF_48AC7B3A_markerWrite(zT_119);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_121[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        b2_tb[_i] = zT_121[_i];
        _i++;
    }
}
    zT_123 = ft;
    zT_125 = (unsigned char*)b2_tb;
    zT_126 = 20;
    zT_127 = 0;
    zT_128 = zT_125 + zT_127;
    zT_129 = zT_126 - zT_127;
    zT_130.ptr = zT_128;
    zT_130.len = zT_129;
    zT_124 = zT_130;
    zT_131 = zF_A7504564_itoa(zT_123, zT_124);
    b2_tl = zT_131;
    b2_tl = zT_131;
    b2_tl = zT_131;
    zT_133 = 19;
    zT_134 = (unsigned int)b2_tl;
    zT_135 = zT_133 - zT_134;
    b2_ts = zT_135;
    b2_ts = zT_135;
    b2_ts = zT_135;
    zT_137 = (unsigned char*)b2_tb;
    zT_139 = 19;
    zT_140 = zT_137 + b2_ts;
    zT_141 = zT_139 - b2_ts;
    zT_142.ptr = zT_140;
    zT_142.len = zT_141;
    zT_136 = zT_142;
    zF_48AC7B3A_markerWrite(zT_136);
    zT_143 = 18;
    zT_144 = ft != zT_143;
    if (zT_144) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_9;
    z_bb_15:
    zT_145 = env->typereg;
    zT_146 = zT_145->fe_items;
    zT_147 = sp.fields_start;
    zT_148 = (unsigned int)zT_147;
    zT_149 = zT_148 + fi2;
    zT_150 = zT_146 + zT_149;
    zT_150->type_id = ft;
    zT_152 = "FSW:n";
    zT_154 = 5;
    zT_153.ptr = zT_152;
    zT_153.len = zT_154;
    fsw_nm = zT_153;
    fsw_nm = zT_153;
    fsw_nm = zT_153;
    zT_155 = fsw_nm;
    zT_157 = sp.fields_start;
    zT_158 = (unsigned int)zT_157;
    zT_159 = zT_158 + fi2;
    zT_160 = (unsigned int)zT_159;
    zT_156 = zT_160;
    zF_C914CB83_markerWriteInt(zT_155, zT_156);
    zT_162 = "FSW:t";
    zT_164 = 5;
    zT_163.ptr = zT_162;
    zT_163.len = zT_164;
    fsw_tm = zT_163;
    fsw_tm = zT_163;
    fsw_tm = zT_163;
    zT_165 = fsw_tm;
    zT_166 = ft;
    zF_C914CB83_markerWriteInt(zT_165, zT_166);
    goto z_bb_16;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_175 = env->typereg;
    zT_176 = zT_175->tu_items;
    zT_177 = sty.payload_idx;
    zT_178 = (unsigned int)zT_177;
    zT_179 = zT_176[zT_178];
    tp = zT_179;
    tp = zT_179;
    tp = zT_179;
    zT_181 = "TUI:fs";
    zT_183 = 6;
    zT_182.ptr = zT_181;
    zT_182.len = zT_183;
    tui_fsm = zT_182;
    tui_fsm = zT_182;
    tui_fsm = zT_182;
    zT_184 = tui_fsm;
    zT_186 = tp.fields_start;
    zT_187 = (unsigned int)zT_186;
    zT_185 = zT_187;
    zF_C914CB83_markerWriteInt(zT_184, zT_185);
    zT_189 = "TUI:fc";
    zT_191 = 6;
    zT_190.ptr = zT_189;
    zT_190.len = zT_191;
    tui_fcm = zT_190;
    tui_fcm = zT_190;
    tui_fcm = zT_190;
    zT_192 = tui_fcm;
    zT_194 = tp.fields_count;
    zT_195 = (unsigned int)zT_194;
    zT_193 = zT_195;
    zF_C914CB83_markerWriteInt(zT_192, zT_193);
    goto z_bb_20;
    z_bb_18:
    goto z_bb_4;
    z_bb_19:
    zT_333 = sty.kind;
    zT_336 = zT_33EF6BFB_TypeKind_union_type;
    zT_337 = zT_333 == zT_336;
    if (zT_337) goto z_bb_32; else goto z_bb_33;
    z_bb_20:
    zT_196 = tp.fields_count;
    zT_197 = (unsigned int)zT_196;
    zT_198 = fi2 < zT_197;
    if (zT_198) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_202 = env->store;
    zT_200 = zT_202;
    zT_203 = fchildren.ptr;
    zT_204 = zT_203[fi2];
    zT_201 = zT_204;
    zT_205 = zF_FCDD1D35_astStoreNodeAt(zT_200, zT_201);
    fd = zT_205;
    fd = zT_205;
    fd = zT_205;
    zT_206 = fd.kind;
    zT_209 = zT_8143F551_AstKind_field_decl;
    zT_210 = zT_206 == zT_209;
    if (zT_210) goto z_bb_24; else goto z_bb_25;
    z_bb_22:
    goto z_bb_18;
    z_bb_23:
    zT_331 = 1;
    zT_332 = fi2 + zT_331;
    fi2 = zT_332;
    fi2 = zT_332;
    goto z_bb_20;
    z_bb_24:
    zT_212 = fd.child_0;
    zT_213 = 0;
    zT_214 = zT_212 != (unsigned int)zT_213;
    zT_211 = zT_214;
    goto z_bb_26;
    z_bb_25:
    zT_211 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_211) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_216 = env;
    zT_219 = fd.child_0;
    zT_217 = zT_219;
    zT_220 = 0;
    zT_218 = zT_220;
    zT_221 = zF_F2107C15_resolveTypeExprFull(zT_216, zT_217, zT_218);
    ft = zT_221;
    ft = zT_221;
    ft = zT_221;
    zT_223 = "DFT:n";
    zT_225 = 5;
    zT_224.ptr = zT_223;
    zT_224.len = zT_225;
    dft_nm = zT_224;
    dft_nm = zT_224;
    dft_nm = zT_224;
    zT_226 = dft_nm;
    zT_228 = (unsigned int)fi2;
    zT_227 = zT_228;
    zF_C914CB83_markerWriteInt(zT_226, zT_227);
    zT_230 = "DFT:t";
    zT_232 = 5;
    zT_231.ptr = zT_230;
    zT_231.len = zT_232;
    dft_tm = zT_231;
    dft_tm = zT_231;
    dft_tm = zT_231;
    zT_233 = dft_tm;
    zT_234 = ft;
    zF_C914CB83_markerWriteInt(zT_233, zT_234);
    zT_236 = "B2:p";
    zT_238 = 4;
    zT_237.ptr = zT_236;
    zT_237.len = zT_238;
    b2_pn = zT_237;
    b2_pn = zT_237;
    b2_pn = zT_237;
    zT_239 = b2_pn;
    zF_48AC7B3A_markerWrite(zT_239);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_241[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        b2_pb[_i] = zT_241[_i];
        _i++;
    }
}
    zT_247 = env->store;
    zT_245 = zT_247;
    zT_248 = fchildren.ptr;
    zT_249 = zT_248[fi2];
    zT_246 = zT_249;
    zT_250 = zF_8BA26B9E_astStoreNodePayload(zT_245, zT_246);
    zT_243 = zT_250;
    zT_251 = (unsigned char*)b2_pb;
    zT_252 = 20;
    zT_253 = 0;
    zT_254 = zT_251 + zT_253;
    zT_255 = zT_252 - zT_253;
    zT_256.ptr = zT_254;
    zT_256.len = zT_255;
    zT_244 = zT_256;
    zT_257 = zF_A7504564_itoa(zT_243, zT_244);
    b2_pl = zT_257;
    b2_pl = zT_257;
    b2_pl = zT_257;
    zT_259 = 19;
    zT_260 = (unsigned int)b2_pl;
    zT_261 = zT_259 - zT_260;
    b2_ps = zT_261;
    b2_ps = zT_261;
    b2_ps = zT_261;
    zT_263 = (unsigned char*)b2_pb;
    zT_265 = 19;
    zT_266 = zT_263 + b2_ps;
    zT_267 = zT_265 - b2_ps;
    zT_268.ptr = zT_266;
    zT_268.len = zT_267;
    zT_262 = zT_268;
    zF_48AC7B3A_markerWrite(zT_262);
    zT_270 = "t";
    zT_272 = 1;
    zT_271.ptr = zT_270;
    zT_271.len = zT_272;
    b2_tn = zT_271;
    b2_tn = zT_271;
    b2_tn = zT_271;
    zT_273 = b2_tn;
    zF_48AC7B3A_markerWrite(zT_273);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_275[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        b2_tb[_i] = zT_275[_i];
        _i++;
    }
}
    zT_277 = ft;
    zT_279 = (unsigned char*)b2_tb;
    zT_280 = 20;
    zT_281 = 0;
    zT_282 = zT_279 + zT_281;
    zT_283 = zT_280 - zT_281;
    zT_284.ptr = zT_282;
    zT_284.len = zT_283;
    zT_278 = zT_284;
    zT_285 = zF_A7504564_itoa(zT_277, zT_278);
    b2_tl = zT_285;
    b2_tl = zT_285;
    b2_tl = zT_285;
    zT_287 = 19;
    zT_288 = (unsigned int)b2_tl;
    zT_289 = zT_287 - zT_288;
    b2_ts = zT_289;
    b2_ts = zT_289;
    b2_ts = zT_289;
    zT_291 = (unsigned char*)b2_tb;
    zT_293 = 19;
    zT_294 = zT_291 + b2_ts;
    zT_295 = zT_293 - b2_ts;
    zT_296.ptr = zT_294;
    zT_296.len = zT_295;
    zT_290 = zT_296;
    zF_48AC7B3A_markerWrite(zT_290);
    zT_298 = "DTWR\n";
    zT_300 = 5;
    zT_299.ptr = zT_298;
    zT_299.len = zT_300;
    dtwr_m = zT_299;
    dtwr_m = zT_299;
    dtwr_m = zT_299;
    zT_301 = dtwr_m;
    zF_48AC7B3A_markerWrite(zT_301);
    zT_302 = 18;
    zT_303 = ft != zT_302;
    if (zT_303) goto z_bb_29; else goto z_bb_31;
    z_bb_28:
    goto z_bb_23;
    z_bb_29:
    zT_304 = env->typereg;
    zT_305 = zT_304->fe_items;
    zT_306 = tp.fields_start;
    zT_307 = (unsigned int)zT_306;
    zT_308 = zT_307 + fi2;
    zT_309 = zT_305 + zT_308;
    zT_309->type_id = ft;
    zT_311 = "FTW:n";
    zT_313 = 5;
    zT_312.ptr = zT_311;
    zT_312.len = zT_313;
    ftw_nm = zT_312;
    ftw_nm = zT_312;
    ftw_nm = zT_312;
    zT_314 = ftw_nm;
    zT_316 = tp.fields_start;
    zT_317 = (unsigned int)zT_316;
    zT_318 = zT_317 + fi2;
    zT_319 = (unsigned int)zT_318;
    zT_315 = zT_319;
    zF_C914CB83_markerWriteInt(zT_314, zT_315);
    zT_321 = "FTW:t";
    zT_323 = 5;
    zT_322.ptr = zT_321;
    zT_322.len = zT_323;
    ftw_tm = zT_322;
    ftw_tm = zT_322;
    ftw_tm = zT_322;
    zT_324 = ftw_tm;
    zT_325 = ft;
    zF_C914CB83_markerWriteInt(zT_324, zT_325);
    goto z_bb_30;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_327 = "DTSK\n";
    zT_329 = 5;
    zT_328.ptr = zT_327;
    zT_328.len = zT_329;
    dtsk_m = zT_328;
    dtsk_m = zT_328;
    dtsk_m = zT_328;
    zT_330 = dtsk_m;
    zF_48AC7B3A_markerWrite(zT_330);
    goto z_bb_30;
    z_bb_32:
    zT_339 = env->typereg;
    zT_340 = zT_339->un_items;
    zT_341 = sty.payload_idx;
    zT_342 = (unsigned int)zT_341;
    zT_343 = zT_340[zT_342];
    up = zT_343;
    up = zT_343;
    up = zT_343;
    goto z_bb_34;
    z_bb_33:
    goto z_bb_18;
    z_bb_34:
    zT_344 = up.fields_count;
    zT_345 = (unsigned int)zT_344;
    zT_346 = fi2 < zT_345;
    if (zT_346) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_350 = env->store;
    zT_348 = zT_350;
    zT_351 = fchildren.ptr;
    zT_352 = zT_351[fi2];
    zT_349 = zT_352;
    zT_353 = zF_FCDD1D35_astStoreNodeAt(zT_348, zT_349);
    fd = zT_353;
    fd = zT_353;
    fd = zT_353;
    zT_354 = fd.kind;
    zT_357 = zT_8143F551_AstKind_field_decl;
    zT_358 = zT_354 == zT_357;
    if (zT_358) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_33;
    z_bb_37:
    zT_378 = 1;
    zT_379 = fi2 + zT_378;
    fi2 = zT_379;
    fi2 = zT_379;
    goto z_bb_34;
    z_bb_38:
    zT_360 = fd.child_0;
    zT_361 = 0;
    zT_362 = zT_360 != (unsigned int)zT_361;
    zT_359 = zT_362;
    goto z_bb_40;
    z_bb_39:
    zT_359 = 0;
    goto z_bb_40;
    z_bb_40:
    if (zT_359) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_364 = env;
    zT_367 = fd.child_0;
    zT_365 = zT_367;
    zT_368 = 0;
    zT_366 = zT_368;
    zT_369 = zF_F2107C15_resolveTypeExprFull(zT_364, zT_365, zT_366);
    ft = zT_369;
    ft = zT_369;
    ft = zT_369;
    zT_370 = 18;
    zT_371 = ft != zT_370;
    if (zT_371) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    goto z_bb_37;
    z_bb_43:
    zT_372 = env->typereg;
    zT_373 = zT_372->fe_items;
    zT_374 = up.fields_start;
    zT_375 = (unsigned int)zT_374;
    zT_376 = zT_375 + fi2;
    zT_377 = zT_373 + zT_376;
    zT_377->type_id = ft;
    goto z_bb_44;
    z_bb_44:
    goto z_bb_42;
}

/* varDeclInitNeedsNameCache */
int zF_C7A2E0B8_varDeclInitNeedsNam(zT_8143F551_AstKind init_kind) {
    zT_8143F551_AstKind zT_3;
    int zT_4;
    int zT_5;
    zT_8143F551_AstKind zT_8;
    int zT_9;
    int zT_10;
    zT_8143F551_AstKind zT_13;
    int zT_14;
    int zT_15;
    zT_8143F551_AstKind zT_18;
    int zT_19;
    int zT_20;
    zT_8143F551_AstKind zT_23;
    int zT_24;
    int zT_25;
    zT_8143F551_AstKind zT_28;
    int zT_29;
    int zT_30;
    zT_8143F551_AstKind zT_33;
    int zT_34;
    int zT_35;
    int zT_36;
    zT_3 = zT_8143F551_AstKind_struct_decl;
    zT_4 = init_kind == zT_3;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 0;
    return zT_5;
    z_bb_2:
    zT_8 = zT_8143F551_AstKind_union_decl;
    zT_9 = init_kind == zT_8;
    if (zT_9) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_10 = 0;
    return zT_10;
    z_bb_4:
    zT_13 = zT_8143F551_AstKind_enum_decl;
    zT_14 = init_kind == zT_13;
    if (zT_14) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_15 = 0;
    return zT_15;
    z_bb_6:
    zT_18 = zT_8143F551_AstKind_error_set_decl;
    zT_19 = init_kind == zT_18;
    if (zT_19) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_20 = 0;
    return zT_20;
    z_bb_8:
    zT_23 = zT_8143F551_AstKind_ident_expr;
    zT_24 = init_kind == zT_23;
    if (zT_24) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_25 = 0;
    return zT_25;
    z_bb_10:
    zT_28 = zT_8143F551_AstKind_import_expr;
    zT_29 = init_kind == zT_28;
    if (zT_29) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_30 = 0;
    return zT_30;
    z_bb_12:
    zT_33 = zT_8143F551_AstKind_fn_decl;
    zT_34 = init_kind == zT_33;
    if (zT_34) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_35 = 0;
    return zT_35;
    z_bb_14:
    zT_36 = 1;
    return zT_36;
}

/* resolveNamedTypeExpressions */
void zF_D9A1E9B7_resolveNamedTypeExp(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    int zT_7;
    zT_6E8D187B_ModuleEntry* zT_9;
    zT_6E8D187B_ModuleEntry zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    zT_6E8D187B_ModuleEntry* zT_14;
    zT_6E8D187B_ModuleEntry zT_15;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned int zT_19;
    zT_6B0A7D14_AstStore* zT_20;
    zT_22A7C88B_AstNode zT_21 = {0};
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    zT_6B0A7D14_AstStore* zT_25;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_26 = {0};
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_31;
    int zT_32;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int zT_35;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int* zT_37;
    unsigned int zT_38;
    zT_22A7C88B_AstNode zT_39 = {0};
    zT_8143F551_AstKind zT_40;
    zT_8143F551_AstKind zT_43;
    int zT_44;
    int zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    int zT_48;
    zT_6B0A7D14_AstStore* zT_50;
    unsigned int zT_51;
    zT_6B0A7D14_AstStore* zT_52;
    unsigned int zT_53;
    zT_22A7C88B_AstNode zT_54 = {0};
    zT_8143F551_AstKind zT_55;
    zT_8143F551_AstKind zT_56;
    int zT_57 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_64 = 0;
    unsigned int zT_65;
    int zT_66;
    zT_6E8D187B_ModuleEntry* zT_68;
    zT_6E8D187B_ModuleEntry zT_69;
    unsigned int zT_70;
    zT_79FAE712_u64 zT_71;
    zT_79FAE712_u64 zT_72;
    zT_79FAE712_u64 zT_73;
    zT_6B0A7D14_AstStore* zT_74;
    unsigned int zT_75;
    zT_6B0A7D14_AstStore* zT_76;
    unsigned int* zT_77;
    unsigned int zT_78;
    unsigned int zT_79 = 0;
    zT_79FAE712_u64 zT_80;
    zT_79FAE712_u64 zT_81;
    zT_338B7C76_TypeRegistry* zT_82;
    zT_79FAE712_u64 zT_83;
    unsigned int zT_84;
    zT_338B7C76_TypeRegistry* zT_85;
    int zT_86;
    unsigned int zT_87;
    int zT_88;
    unsigned int zT_89;
    unsigned int ci;
    unsigned int cr;
    zT_3CB0179A_Slice_zT_05F374B1_u cd;
    unsigned int cdi;
    zT_22A7C88B_AstNode cdcl;
    zT_22A7C88B_AstNode cdinit;
    unsigned int cdtype;
    zT_79FAE712_u64 ck;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    ci = zT_4;
    ci = zT_4;
    ci = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = mods.len;
    zT_7 = ci < zT_6;
    if (zT_7) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = mods.ptr;
    zT_10 = zT_9[ci];
    zT_11 = zT_10.ast_root;
    cr = zT_11;
    cr = zT_11;
    cr = zT_11;
    zT_12 = 0;
    zT_13 = cr == zT_12;
    if (zT_13) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_88 = 1;
    zT_89 = ci + zT_88;
    ci = zT_89;
    ci = zT_89;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_14 = mods.ptr;
    zT_15 = zT_14[ci];
    zT_16 = zT_15.id;
    env->module_id = zT_16;
    zT_20 = env->store;
    zT_18 = zT_20;
    zT_19 = cr;
    zT_21 = zF_FCDD1D35_astStoreNodeAt(zT_18, zT_19);
    (void)zT_21;
    zT_25 = env->store;
    zT_23 = zT_25;
    zT_24 = cr;
    zT_26 = zF_850FDF81_astStoreNodeExtraCh(zT_23, zT_24);
    cd = zT_26;
    cd = zT_26;
    cd = zT_26;
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    cdi = zT_29;
    cdi = zT_29;
    cdi = zT_29;
    goto z_bb_7;
    z_bb_7:
    zT_31 = cd.len;
    zT_32 = cdi < zT_31;
    if (zT_32) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_36 = env->store;
    zT_34 = zT_36;
    zT_37 = cd.ptr;
    zT_38 = zT_37[cdi];
    zT_35 = zT_38;
    zT_39 = zF_FCDD1D35_astStoreNodeAt(zT_34, zT_35);
    cdcl = zT_39;
    cdcl = zT_39;
    cdcl = zT_39;
    zT_40 = cdcl.kind;
    zT_43 = zT_8143F551_AstKind_var_decl;
    zT_44 = zT_40 == zT_43;
    if (zT_44) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_86 = 1;
    zT_87 = cdi + zT_86;
    cdi = zT_87;
    cdi = zT_87;
    goto z_bb_7;
    z_bb_11:
    zT_46 = cdcl.child_1;
    zT_47 = 0;
    zT_48 = zT_46 != zT_47;
    zT_45 = zT_48;
    goto z_bb_13;
    z_bb_12:
    zT_45 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_45) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_52 = env->store;
    zT_50 = zT_52;
    zT_53 = cdcl.child_1;
    zT_51 = zT_53;
    zT_54 = zF_FCDD1D35_astStoreNodeAt(zT_50, zT_51);
    cdinit = zT_54;
    cdinit = zT_54;
    cdinit = zT_54;
    zT_56 = cdinit.kind;
    zT_55 = zT_56;
    zT_57 = zF_C7A2E0B8_varDeclInitNeedsNam(zT_55);
    if (zT_57) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_59 = env;
    zT_62 = cdcl.child_1;
    zT_60 = zT_62;
    zT_63 = 0;
    zT_61 = zT_63;
    zT_64 = zF_F2107C15_resolveTypeExprFull(zT_59, zT_60, zT_61);
    cdtype = zT_64;
    cdtype = zT_64;
    cdtype = zT_64;
    zT_65 = 18;
    zT_66 = cdtype != zT_65;
    if (zT_66) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_68 = mods.ptr;
    zT_69 = zT_68[ci];
    zT_70 = zT_69.id;
    zT_71 = (zT_79FAE712_u64)zT_70;
    zT_72 = 4294967296ULL;
    zT_73 = zT_71 * zT_72;
    zT_76 = env->store;
    zT_74 = zT_76;
    zT_77 = cd.ptr;
    zT_78 = zT_77[cdi];
    zT_75 = zT_78;
    zT_79 = zF_8BA26B9E_astStoreNodePayload(zT_74, zT_75);
    zT_80 = (zT_79FAE712_u64)zT_79;
    zT_81 = zT_73 + zT_80;
    ck = zT_81;
    ck = zT_81;
    ck = zT_81;
    zT_85 = env->typereg;
    zT_82 = zT_85;
    zT_83 = ck;
    zT_84 = cdtype;
    zF_5E95558D_nameCachePut(zT_82, zT_83, zT_84);
    goto z_bb_19;
    z_bb_19:
    goto z_bb_17;
}

/* resolveImportFieldAlias */
unsigned int zF_E8C2AADA_resolveImportFieldA(zT_ABC1EBBE_TypeResolveEnv* env, zT_072B53A6_ModuleRegistry* module_reg, unsigned int importer_mod_id, unsigned int target_mod_id, unsigned int field_name_id, unsigned int depth) {
    unsigned int zT_6;
    int zT_7;
    unsigned int zT_8;
    zT_3D7259E2_SymbolRegistry* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_3D7259E2_SymbolRegistry* zT_13;
    zT_E68301A1_Opt_804 zT_14 = {0};
    unsigned char zT_15;
    unsigned int zT_17;
    unsigned int zT_18;
    int zT_19;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_22A7C88B_AstNode zT_26 = {0};
    zT_8143F551_AstKind zT_27;
    zT_8143F551_AstKind zT_30;
    int zT_31;
    unsigned int zT_32;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int zT_35;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    zT_22A7C88B_AstNode zT_38 = {0};
    zT_8143F551_AstKind zT_39;
    zT_8143F551_AstKind zT_42;
    int zT_43;
    unsigned int zT_44;
    zT_6B0A7D14_AstStore* zT_46;
    unsigned int zT_47;
    zT_6B0A7D14_AstStore* zT_48;
    unsigned int zT_49;
    zT_22A7C88B_AstNode zT_50 = {0};
    zT_8143F551_AstKind zT_51;
    zT_8143F551_AstKind zT_54;
    int zT_55;
    unsigned int zT_56;
    zT_072B53A6_ModuleRegistry* zT_58;
    unsigned int zT_59;
    zT_6B0A7D14_AstStore* zT_60;
    unsigned int zT_61;
    zT_6B0A7D14_AstStore* zT_62;
    unsigned int zT_63;
    unsigned int zT_64 = 0;
    zT_BAEE192E_Opt_10 zT_65 = {0};
    unsigned char zT_66;
    zT_ABC1EBBE_TypeResolveEnv* zT_68;
    zT_072B53A6_ModuleRegistry* zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_6B0A7D14_AstStore* zT_74;
    unsigned int zT_75;
    zT_6B0A7D14_AstStore* zT_76;
    unsigned int zT_77;
    unsigned int zT_78 = 0;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned int zT_82;
    zT_E68301A1_Opt_804 fs;
    zT_3A105EF1_Symbol* fss;
    zT_22A7C88B_AstNode fd;
    zT_22A7C88B_AstNode fi;
    zT_22A7C88B_AstNode fb;
    zT_BAEE192E_Opt_10 t2;
    unsigned int m2;
    z_bb_0:
    zT_6 = 8;
    zT_7 = depth > zT_6;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = 18;
    return zT_8;
    z_bb_2:
    zT_13 = env->symbol_reg;
    zT_10 = zT_13;
    zT_11 = target_mod_id;
    zT_12 = field_name_id;
    zT_14 = zF_A398987E_symbolRegistryQuali(zT_10, zT_11, zT_12);
    fs = zT_14;
    fs = zT_14;
    fs = zT_14;
    zT_15 = fs.has_value;
    if (zT_15) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    fss = fs.value;
    zT_17 = fss->type_id;
    zT_18 = 0;
    zT_19 = zT_17 != zT_18;
    if (zT_19) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_82 = 18;
    return zT_82;
    z_bb_5:
    zT_20 = fss->type_id;
    return zT_20;
    z_bb_6:
    zT_24 = env->store;
    zT_22 = zT_24;
    zT_25 = fss->decl_node;
    zT_23 = zT_25;
    zT_26 = zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    fd = zT_26;
    fd = zT_26;
    fd = zT_26;
    zT_27 = fd.kind;
    zT_30 = zT_8143F551_AstKind_var_decl;
    zT_31 = zT_27 != zT_30;
    if (zT_31) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_32 = 18;
    return zT_32;
    z_bb_8:
    zT_36 = env->store;
    zT_34 = zT_36;
    zT_37 = fd.child_1;
    zT_35 = zT_37;
    zT_38 = zF_FCDD1D35_astStoreNodeAt(zT_34, zT_35);
    fi = zT_38;
    fi = zT_38;
    fi = zT_38;
    zT_39 = fi.kind;
    zT_42 = zT_8143F551_AstKind_field_access;
    zT_43 = zT_39 != zT_42;
    if (zT_43) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_44 = 18;
    return zT_44;
    z_bb_10:
    zT_48 = env->store;
    zT_46 = zT_48;
    zT_49 = fi.child_0;
    zT_47 = zT_49;
    zT_50 = zF_FCDD1D35_astStoreNodeAt(zT_46, zT_47);
    fb = zT_50;
    fb = zT_50;
    fb = zT_50;
    zT_51 = fb.kind;
    zT_54 = zT_8143F551_AstKind_import_expr;
    zT_55 = zT_51 != zT_54;
    if (zT_55) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_56 = 18;
    return zT_56;
    z_bb_12:
    zT_58 = module_reg;
    zT_62 = env->store;
    zT_60 = zT_62;
    zT_63 = fi.child_0;
    zT_61 = zT_63;
    zT_64 = zF_8BA26B9E_astStoreNodePayload(zT_60, zT_61);
    zT_59 = zT_64;
    zT_65 = zF_A258E183_moduleRegistryPathT(zT_58, zT_59);
    t2 = zT_65;
    t2 = zT_65;
    t2 = zT_65;
    zT_66 = t2.has_value;
    if (zT_66) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    m2 = t2.value;
    zT_68 = env;
    zT_69 = module_reg;
    zT_70 = importer_mod_id;
    zT_71 = m2;
    zT_76 = env->store;
    zT_74 = zT_76;
    zT_77 = fd.child_1;
    zT_75 = zT_77;
    zT_78 = zF_8BA26B9E_astStoreNodePayload(zT_74, zT_75);
    zT_72 = zT_78;
    zT_79 = 1;
    zT_80 = depth + zT_79;
    zT_73 = zT_80;
    env = zT_68;
    module_reg = zT_69;
    importer_mod_id = zT_70;
    target_mod_id = zT_71;
    field_name_id = zT_72;
    depth = zT_73;
    goto z_bb_0;
    z_bb_14:
    goto z_bb_4;
}

/* resolveImportFieldAliases */
void zF_1DB55B7A_resolveImportFieldA(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods, zT_072B53A6_ModuleRegistry* module_reg) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    int zT_8;
    zT_6E8D187B_ModuleEntry* zT_10;
    zT_6E8D187B_ModuleEntry zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_18;
    zT_22A7C88B_AstNode zT_19 = {0};
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    zT_6B0A7D14_AstStore* zT_23;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_24 = {0};
    int zT_26;
    unsigned int zT_27;
    unsigned int zT_29;
    int zT_30;
    zT_6B0A7D14_AstStore* zT_32;
    unsigned int zT_33;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int* zT_35;
    unsigned int zT_36;
    zT_22A7C88B_AstNode zT_37 = {0};
    zT_8143F551_AstKind zT_38;
    zT_8143F551_AstKind zT_41;
    int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    int zT_45;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_48;
    zT_6B0A7D14_AstStore* zT_49;
    unsigned int zT_50;
    zT_22A7C88B_AstNode zT_51 = {0};
    zT_8143F551_AstKind zT_52;
    zT_8143F551_AstKind zT_55;
    int zT_56;
    zT_6B0A7D14_AstStore* zT_58;
    unsigned int zT_59;
    zT_6B0A7D14_AstStore* zT_60;
    unsigned int zT_61;
    zT_22A7C88B_AstNode zT_62 = {0};
    zT_8143F551_AstKind zT_63;
    zT_8143F551_AstKind zT_66;
    int zT_67;
    zT_072B53A6_ModuleRegistry* zT_69;
    unsigned int zT_70;
    zT_6B0A7D14_AstStore* zT_71;
    unsigned int zT_72;
    zT_6B0A7D14_AstStore* zT_73;
    unsigned int zT_74;
    unsigned int zT_75 = 0;
    zT_BAEE192E_Opt_10 zT_76 = {0};
    unsigned char zT_77;
    zT_ABC1EBBE_TypeResolveEnv* zT_80;
    zT_072B53A6_ModuleRegistry* zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    zT_6E8D187B_ModuleEntry* zT_86;
    zT_6E8D187B_ModuleEntry zT_87;
    unsigned int zT_88;
    zT_6B0A7D14_AstStore* zT_89;
    unsigned int zT_90;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    unsigned int zT_93 = 0;
    unsigned int zT_94;
    unsigned int zT_95 = 0;
    unsigned int zT_96;
    int zT_97;
    zT_3D7259E2_SymbolRegistry* zT_99;
    unsigned int zT_100;
    unsigned int zT_101;
    zT_3D7259E2_SymbolRegistry* zT_102;
    zT_6E8D187B_ModuleEntry* zT_103;
    zT_6E8D187B_ModuleEntry zT_104;
    unsigned int zT_105;
    zT_6B0A7D14_AstStore* zT_106;
    unsigned int zT_107;
    zT_6B0A7D14_AstStore* zT_108;
    unsigned int* zT_109;
    unsigned int zT_110;
    unsigned int zT_111 = 0;
    zT_E68301A1_Opt_804 zT_112 = {0};
    unsigned char zT_113;
    zT_6E8D187B_ModuleEntry* zT_116;
    zT_6E8D187B_ModuleEntry zT_117;
    unsigned int zT_118;
    zT_79FAE712_u64 zT_119;
    zT_79FAE712_u64 zT_120;
    zT_79FAE712_u64 zT_121;
    zT_6B0A7D14_AstStore* zT_122;
    unsigned int zT_123;
    zT_6B0A7D14_AstStore* zT_124;
    unsigned int* zT_125;
    unsigned int zT_126;
    unsigned int zT_127 = 0;
    zT_79FAE712_u64 zT_128;
    zT_79FAE712_u64 zT_129;
    zT_338B7C76_TypeRegistry* zT_130;
    zT_79FAE712_u64 zT_131;
    unsigned int zT_132;
    zT_338B7C76_TypeRegistry* zT_133;
    int zT_134;
    unsigned int zT_135;
    int zT_136;
    unsigned int zT_137;
    unsigned int mi;
    unsigned int root;
    zT_3CB0179A_Slice_zT_05F374B1_u decls;
    unsigned int di;
    zT_22A7C88B_AstNode decl;
    zT_22A7C88B_AstNode init;
    zT_22A7C88B_AstNode base;
    zT_BAEE192E_Opt_10 target;
    unsigned int mtid;
    unsigned int resolved;
    zT_E68301A1_Opt_804 sym;
    zT_3A105EF1_Symbol* sp;
    zT_79FAE712_u64 ck;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    mi = zT_5;
    mi = zT_5;
    mi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_7 = mods.len;
    zT_8 = mi < zT_7;
    if (zT_8) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = mods.ptr;
    zT_11 = zT_10[mi];
    zT_12 = zT_11.ast_root;
    root = zT_12;
    root = zT_12;
    root = zT_12;
    zT_13 = 0;
    zT_14 = root == zT_13;
    if (zT_14) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_136 = 1;
    zT_137 = mi + zT_136;
    mi = zT_137;
    mi = zT_137;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_18 = env->store;
    zT_16 = zT_18;
    zT_17 = root;
    zT_19 = zF_FCDD1D35_astStoreNodeAt(zT_16, zT_17);
    (void)zT_19;
    zT_23 = env->store;
    zT_21 = zT_23;
    zT_22 = root;
    zT_24 = zF_850FDF81_astStoreNodeExtraCh(zT_21, zT_22);
    decls = zT_24;
    decls = zT_24;
    decls = zT_24;
    zT_26 = 0;
    zT_27 = (unsigned int)zT_26;
    di = zT_27;
    di = zT_27;
    di = zT_27;
    goto z_bb_7;
    z_bb_7:
    zT_29 = decls.len;
    zT_30 = di < zT_29;
    if (zT_30) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_34 = env->store;
    zT_32 = zT_34;
    zT_35 = decls.ptr;
    zT_36 = zT_35[di];
    zT_33 = zT_36;
    zT_37 = zF_FCDD1D35_astStoreNodeAt(zT_32, zT_33);
    decl = zT_37;
    decl = zT_37;
    decl = zT_37;
    zT_38 = decl.kind;
    zT_41 = zT_8143F551_AstKind_var_decl;
    zT_42 = zT_38 != zT_41;
    if (zT_42) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_134 = 1;
    zT_135 = di + zT_134;
    di = zT_135;
    di = zT_135;
    goto z_bb_7;
    z_bb_11:
    goto z_bb_10;
    z_bb_12:
    zT_43 = decl.child_1;
    zT_44 = 0;
    zT_45 = zT_43 == zT_44;
    if (zT_45) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    zT_49 = env->store;
    zT_47 = zT_49;
    zT_50 = decl.child_1;
    zT_48 = zT_50;
    zT_51 = zF_FCDD1D35_astStoreNodeAt(zT_47, zT_48);
    init = zT_51;
    init = zT_51;
    init = zT_51;
    zT_52 = init.kind;
    zT_55 = zT_8143F551_AstKind_field_access;
    zT_56 = zT_52 != zT_55;
    if (zT_56) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_60 = env->store;
    zT_58 = zT_60;
    zT_61 = init.child_0;
    zT_59 = zT_61;
    zT_62 = zF_FCDD1D35_astStoreNodeAt(zT_58, zT_59);
    base = zT_62;
    base = zT_62;
    base = zT_62;
    zT_63 = base.kind;
    zT_66 = zT_8143F551_AstKind_import_expr;
    zT_67 = zT_63 != zT_66;
    if (zT_67) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    goto z_bb_10;
    z_bb_18:
    zT_69 = module_reg;
    zT_73 = env->store;
    zT_71 = zT_73;
    zT_74 = init.child_0;
    zT_72 = zT_74;
    zT_75 = zF_8BA26B9E_astStoreNodePayload(zT_71, zT_72);
    zT_70 = zT_75;
    zT_76 = zF_A258E183_moduleRegistryPathT(zT_69, zT_70);
    target = zT_76;
    target = zT_76;
    target = zT_76;
    zT_77 = target.has_value;
    if (zT_77) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    mtid = target.value;
    zT_80 = env;
    zT_81 = module_reg;
    zT_86 = mods.ptr;
    zT_87 = zT_86[mi];
    zT_88 = zT_87.id;
    zT_82 = zT_88;
    zT_83 = mtid;
    zT_91 = env->store;
    zT_89 = zT_91;
    zT_92 = decl.child_1;
    zT_90 = zT_92;
    zT_93 = zF_8BA26B9E_astStoreNodePayload(zT_89, zT_90);
    zT_84 = zT_93;
    zT_94 = 0;
    zT_85 = zT_94;
    zT_95 = zF_E8C2AADA_resolveImportFieldA(zT_80, zT_81, zT_82, zT_83, zT_84, zT_85);
    resolved = zT_95;
    resolved = zT_95;
    resolved = zT_95;
    zT_96 = 18;
    zT_97 = resolved != zT_96;
    if (zT_97) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    goto z_bb_10;
    z_bb_21:
    zT_102 = env->symbol_reg;
    zT_99 = zT_102;
    zT_103 = mods.ptr;
    zT_104 = zT_103[mi];
    zT_105 = zT_104.id;
    zT_100 = zT_105;
    zT_108 = env->store;
    zT_106 = zT_108;
    zT_109 = decls.ptr;
    zT_110 = zT_109[di];
    zT_107 = zT_110;
    zT_111 = zF_8BA26B9E_astStoreNodePayload(zT_106, zT_107);
    zT_101 = zT_111;
    zT_112 = zF_A398987E_symbolRegistryQuali(zT_99, zT_100, zT_101);
    sym = zT_112;
    sym = zT_112;
    sym = zT_112;
    zT_113 = sym.has_value;
    if (zT_113) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    sp = sym.value;
    sp->type_id = resolved;
    goto z_bb_24;
    z_bb_24:
    zT_116 = mods.ptr;
    zT_117 = zT_116[mi];
    zT_118 = zT_117.id;
    zT_119 = (zT_79FAE712_u64)zT_118;
    zT_120 = 4294967296ULL;
    zT_121 = zT_119 * zT_120;
    zT_124 = env->store;
    zT_122 = zT_124;
    zT_125 = decls.ptr;
    zT_126 = zT_125[di];
    zT_123 = zT_126;
    zT_127 = zF_8BA26B9E_astStoreNodePayload(zT_122, zT_123);
    zT_128 = (zT_79FAE712_u64)zT_127;
    zT_129 = zT_121 + zT_128;
    ck = zT_129;
    ck = zT_129;
    ck = zT_129;
    zT_133 = env->typereg;
    zT_130 = zT_133;
    zT_131 = ck;
    zT_132 = resolved;
    zF_5E95558D_nameCachePut(zT_130, zT_131, zT_132);
    goto z_bb_22;
}

/* resolveAggregateFieldTypesAll */
void zF_E2882212_resolveAggregateFie(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    int zT_7;
    zT_6E8D187B_ModuleEntry* zT_9;
    zT_6E8D187B_ModuleEntry zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_17;
    zT_22A7C88B_AstNode zT_18 = {0};
    zT_6B0A7D14_AstStore* zT_20;
    unsigned int zT_21;
    zT_6B0A7D14_AstStore* zT_22;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_23 = {0};
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_28;
    int zT_29;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int* zT_34;
    unsigned int zT_35;
    zT_22A7C88B_AstNode zT_36 = {0};
    zT_8143F551_AstKind zT_37;
    zT_8143F551_AstKind zT_40;
    int zT_41;
    int zT_42;
    unsigned int zT_43;
    int zT_44;
    int zT_45;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_48;
    zT_6B0A7D14_AstStore* zT_49;
    unsigned int zT_50;
    zT_22A7C88B_AstNode zT_51 = {0};
    zT_8143F551_AstKind zT_52;
    zT_8143F551_AstKind zT_55;
    int zT_56;
    int zT_57;
    zT_8143F551_AstKind zT_58;
    zT_8143F551_AstKind zT_61;
    int zT_62;
    zT_ABC1EBBE_TypeResolveEnv* zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    zT_6E8D187B_ModuleEntry* zT_66;
    zT_6E8D187B_ModuleEntry zT_67;
    unsigned int zT_68;
    unsigned int* zT_69;
    unsigned int zT_70;
    int zT_71;
    unsigned int zT_72;
    int zT_73;
    unsigned int zT_74;
    unsigned int mi;
    unsigned int root;
    zT_3CB0179A_Slice_zT_05F374B1_u decls;
    unsigned int di;
    zT_22A7C88B_AstNode decl;
    zT_22A7C88B_AstNode init;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    mi = zT_4;
    mi = zT_4;
    mi = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = mods.len;
    zT_7 = mi < zT_6;
    if (zT_7) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = mods.ptr;
    zT_10 = zT_9[mi];
    zT_11 = zT_10.ast_root;
    root = zT_11;
    root = zT_11;
    root = zT_11;
    zT_12 = 0;
    zT_13 = root == zT_12;
    if (zT_13) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_73 = 1;
    zT_74 = mi + zT_73;
    mi = zT_74;
    mi = zT_74;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_17 = env->store;
    zT_15 = zT_17;
    zT_16 = root;
    zT_18 = zF_FCDD1D35_astStoreNodeAt(zT_15, zT_16);
    (void)zT_18;
    zT_22 = env->store;
    zT_20 = zT_22;
    zT_21 = root;
    zT_23 = zF_850FDF81_astStoreNodeExtraCh(zT_20, zT_21);
    decls = zT_23;
    decls = zT_23;
    decls = zT_23;
    zT_25 = 0;
    zT_26 = (unsigned int)zT_25;
    di = zT_26;
    di = zT_26;
    di = zT_26;
    goto z_bb_7;
    z_bb_7:
    zT_28 = decls.len;
    zT_29 = di < zT_28;
    if (zT_29) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_33 = env->store;
    zT_31 = zT_33;
    zT_34 = decls.ptr;
    zT_35 = zT_34[di];
    zT_32 = zT_35;
    zT_36 = zF_FCDD1D35_astStoreNodeAt(zT_31, zT_32);
    decl = zT_36;
    decl = zT_36;
    decl = zT_36;
    zT_37 = decl.kind;
    zT_40 = zT_8143F551_AstKind_var_decl;
    zT_41 = zT_37 == zT_40;
    if (zT_41) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_71 = 1;
    zT_72 = di + zT_71;
    di = zT_72;
    di = zT_72;
    goto z_bb_7;
    z_bb_11:
    zT_43 = decl.child_1;
    zT_44 = 0;
    zT_45 = zT_43 != (unsigned int)zT_44;
    zT_42 = zT_45;
    goto z_bb_13;
    z_bb_12:
    zT_42 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_42) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_49 = env->store;
    zT_47 = zT_49;
    zT_50 = decl.child_1;
    zT_48 = zT_50;
    zT_51 = zF_FCDD1D35_astStoreNodeAt(zT_47, zT_48);
    init = zT_51;
    init = zT_51;
    init = zT_51;
    zT_52 = init.kind;
    zT_55 = zT_8143F551_AstKind_struct_decl;
    zT_56 = zT_52 == zT_55;
    if (zT_56) goto z_bb_17; else goto z_bb_16;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_58 = init.kind;
    zT_61 = zT_8143F551_AstKind_union_decl;
    zT_62 = zT_58 == zT_61;
    zT_57 = zT_62;
    goto z_bb_18;
    z_bb_17:
    zT_57 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_57) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_63 = env;
    zT_66 = mods.ptr;
    zT_67 = zT_66[mi];
    zT_68 = zT_67.id;
    zT_64 = zT_68;
    zT_69 = decls.ptr;
    zT_70 = zT_69[di];
    zT_65 = zT_70;
    zF_F5C3193B_resolveDeclAggregat(zT_63, zT_64, zT_65);
    goto z_bb_20;
    z_bb_20:
    goto z_bb_15;
}

/* resolveFnSignatures */
void zF_29FBFC7C_resolveFnSignatures(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods, zT_8EED1867_ResolvedTypeTable* resolved_types) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    int zT_8;
    zT_6E8D187B_ModuleEntry* zT_10;
    zT_6E8D187B_ModuleEntry zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    zT_6E8D187B_ModuleEntry* zT_15;
    zT_6E8D187B_ModuleEntry zT_16;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_21;
    zT_22A7C88B_AstNode zT_22 = {0};
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_6B0A7D14_AstStore* zT_26;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_27 = {0};
    int zT_29;
    unsigned int zT_30;
    unsigned int zT_32;
    int zT_33;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    zT_6B0A7D14_AstStore* zT_37;
    unsigned int* zT_38;
    unsigned int zT_39;
    zT_22A7C88B_AstNode zT_40 = {0};
    zT_8143F551_AstKind zT_41;
    zT_8143F551_AstKind zT_44;
    int zT_45;
    zT_6B0A7D14_AstStore* zT_47;
    zT_20D47C5A_anon_161369 zT_48;
    zT_243D6A41_FnProto* zT_49;
    zT_6B0A7D14_AstStore* zT_50;
    unsigned int zT_51;
    zT_6B0A7D14_AstStore* zT_52;
    unsigned int* zT_53;
    unsigned int zT_54;
    unsigned int zT_55 = 0;
    unsigned int zT_56;
    zT_243D6A41_FnProto zT_57;
    zT_3D7259E2_SymbolRegistry* zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    zT_3D7259E2_SymbolRegistry* zT_62;
    zT_6E8D187B_ModuleEntry* zT_63;
    zT_6E8D187B_ModuleEntry zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_E68301A1_Opt_804 zT_67 = {0};
    unsigned char zT_68;
    unsigned int zT_70;
    unsigned int zT_71;
    int zT_72;
    zT_939EE900_Arr_unsigned_int_1 zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    int zT_78;
    int zT_79;
    zT_ABC1EBBE_TypeResolveEnv* zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    unsigned int zT_86 = 0;
    unsigned int zT_87;
    int zT_88;
    int zT_89;
    zT_8EED1867_ResolvedTypeTable* zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned char zT_95;
    unsigned char zT_96;
    unsigned char zT_97;
    unsigned char zT_98;
    unsigned char zT_99;
    int zT_100;
    unsigned char zT_101;
    unsigned char zT_103;
    unsigned char zT_104;
    unsigned char zT_105;
    unsigned char zT_106;
    unsigned char zT_107;
    int zT_108;
    unsigned char zT_109;
    zT_338B7C76_TypeRegistry* zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    unsigned short zT_114;
    unsigned short zT_115;
    int zT_116;
    unsigned int zT_118;
    zT_79FAE712_u64 zT_119;
    zT_79FAE712_u64 zT_120;
    zT_79FAE712_u64 zT_121;
    unsigned short zT_122;
    zT_79FAE712_u64 zT_123;
    zT_79FAE712_u64 zT_124;
    zT_6B0A7D14_AstStore* zT_126;
    zT_79FAE712_u64 zT_127;
    zT_6B0A7D14_AstStore* zT_128;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_129 = {0};
    int zT_131;
    unsigned int zT_132;
    unsigned int zT_134;
    int zT_135;
    zT_6B0A7D14_AstStore* zT_137;
    unsigned int zT_138;
    zT_6B0A7D14_AstStore* zT_139;
    unsigned int* zT_140;
    unsigned int zT_141;
    zT_22A7C88B_AstNode zT_142 = {0};
    unsigned int zT_143;
    int zT_144;
    int zT_145;
    zT_ABC1EBBE_TypeResolveEnv* zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    unsigned int zT_152 = 0;
    zT_338B7C76_TypeRegistry* zT_153;
    unsigned int zT_154;
    zT_338B7C76_TypeRegistry* zT_155;
    unsigned int zT_156;
    int zT_157;
    zT_8EED1867_ResolvedTypeTable* zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    unsigned int zT_161;
    int zT_162;
    unsigned int zT_163;
    zT_338B7C76_TypeRegistry* zT_165;
    unsigned int zT_166;
    unsigned int zT_167;
    unsigned char zT_168;
    unsigned char zT_169;
    unsigned int zT_170;
    unsigned short zT_171;
    unsigned int zT_172;
    zT_338B7C76_TypeRegistry* zT_173;
    unsigned int zT_174;
    zT_6E8D187B_ModuleEntry* zT_175;
    zT_6E8D187B_ModuleEntry zT_176;
    unsigned int zT_177;
    unsigned short zT_178;
    int zT_179;
    unsigned int zT_180;
    unsigned int zT_181 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_182;
    unsigned int zT_183;
    unsigned int zT_184;
    unsigned int* zT_185;
    unsigned int zT_186;
    zT_3D7259E2_SymbolRegistry* zT_188;
    unsigned int zT_189;
    unsigned int zT_190;
    zT_3D7259E2_SymbolRegistry* zT_191;
    zT_6E8D187B_ModuleEntry* zT_192;
    zT_6E8D187B_ModuleEntry zT_193;
    unsigned int zT_194;
    unsigned int zT_195;
    zT_E68301A1_Opt_804 zT_196 = {0};
    unsigned char zT_197;
    zT_8143F551_AstKind zT_199;
    zT_8143F551_AstKind zT_202;
    int zT_203;
    int zT_204;
    unsigned int zT_205;
    int zT_206;
    int zT_207;
    zT_ABC1EBBE_TypeResolveEnv* zT_209;
    unsigned int zT_210;
    unsigned int zT_211;
    unsigned int zT_212;
    unsigned int zT_213;
    unsigned int zT_214 = 0;
    unsigned int zT_215;
    int zT_216;
    zT_8EED1867_ResolvedTypeTable* zT_217;
    unsigned int zT_218;
    unsigned int zT_219;
    unsigned int zT_220;
    zT_8EED1867_ResolvedTypeTable* zT_221;
    unsigned int zT_222;
    unsigned int zT_223;
    unsigned int* zT_224;
    unsigned int zT_225;
    zT_3D7259E2_SymbolRegistry* zT_227;
    unsigned int zT_228;
    unsigned int zT_229;
    zT_3D7259E2_SymbolRegistry* zT_230;
    zT_6E8D187B_ModuleEntry* zT_231;
    zT_6E8D187B_ModuleEntry zT_232;
    unsigned int zT_233;
    zT_6B0A7D14_AstStore* zT_234;
    unsigned int zT_235;
    zT_6B0A7D14_AstStore* zT_236;
    unsigned int* zT_237;
    unsigned int zT_238;
    unsigned int zT_239 = 0;
    zT_E68301A1_Opt_804 zT_240 = {0};
    unsigned char zT_241;
    int zT_243;
    unsigned int zT_244;
    int zT_245;
    unsigned int zT_246;
    unsigned int mi;
    unsigned int root;
    zT_3CB0179A_Slice_zT_05F374B1_u decls;
    unsigned int di;
    zT_22A7C88B_AstNode decl;
    zT_243D6A41_FnProto proto;
    zT_E68301A1_Opt_804 sym_check;
    zT_3A105EF1_Symbol* sc;
    zT_939EE900_Arr_unsigned_int_1 rt_box;
    unsigned int rtype;
    unsigned char is_ext;
    unsigned char is_variadic;
    unsigned int fn_start;
    zT_79FAE712_u64 p_payload;
    zT_3CB0179A_Slice_zT_05F374B1_u pnodes;
    unsigned int pi;
    unsigned int tid;
    zT_E68301A1_Opt_804 sym;
    zT_22A7C88B_AstNode pnode;
    unsigned int ptype;
    zT_3A105EF1_Symbol* sp;
    unsigned int vtype;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    mi = zT_5;
    mi = zT_5;
    mi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_7 = mods.len;
    zT_8 = mi < zT_7;
    if (zT_8) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = mods.ptr;
    zT_11 = zT_10[mi];
    zT_12 = zT_11.ast_root;
    root = zT_12;
    root = zT_12;
    root = zT_12;
    zT_13 = 0;
    zT_14 = root == zT_13;
    if (zT_14) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_245 = 1;
    zT_246 = mi + zT_245;
    mi = zT_246;
    mi = zT_246;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_15 = mods.ptr;
    zT_16 = zT_15[mi];
    zT_17 = zT_16.id;
    env->module_id = zT_17;
    zT_21 = env->store;
    zT_19 = zT_21;
    zT_20 = root;
    zT_22 = zF_FCDD1D35_astStoreNodeAt(zT_19, zT_20);
    (void)zT_22;
    zT_26 = env->store;
    zT_24 = zT_26;
    zT_25 = root;
    zT_27 = zF_850FDF81_astStoreNodeExtraCh(zT_24, zT_25);
    decls = zT_27;
    decls = zT_27;
    decls = zT_27;
    zT_29 = 0;
    zT_30 = (unsigned int)zT_29;
    di = zT_30;
    di = zT_30;
    di = zT_30;
    goto z_bb_7;
    z_bb_7:
    zT_32 = decls.len;
    zT_33 = di < zT_32;
    if (zT_33) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_37 = env->store;
    zT_35 = zT_37;
    zT_38 = decls.ptr;
    zT_39 = zT_38[di];
    zT_36 = zT_39;
    zT_40 = zF_FCDD1D35_astStoreNodeAt(zT_35, zT_36);
    decl = zT_40;
    decl = zT_40;
    decl = zT_40;
    zT_41 = decl.kind;
    zT_44 = zT_8143F551_AstKind_fn_decl;
    zT_45 = zT_41 == zT_44;
    if (zT_45) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_243 = 1;
    zT_244 = di + zT_243;
    di = zT_244;
    di = zT_244;
    goto z_bb_7;
    z_bb_11:
    zT_47 = env->store;
    zT_48 = zT_47->fn_protos;
    zT_49 = zT_48.items;
    zT_52 = env->store;
    zT_50 = zT_52;
    zT_53 = decls.ptr;
    zT_54 = zT_53[di];
    zT_51 = zT_54;
    zT_55 = zF_8BA26B9E_astStoreNodePayload(zT_50, zT_51);
    zT_56 = (unsigned int)zT_55;
    zT_57 = zT_49[zT_56];
    proto = zT_57;
    proto = zT_57;
    proto = zT_57;
    zT_62 = env->symbol_reg;
    zT_59 = zT_62;
    zT_63 = mods.ptr;
    zT_64 = zT_63[mi];
    zT_65 = zT_64.id;
    zT_60 = zT_65;
    zT_66 = proto.name_id;
    zT_61 = zT_66;
    zT_67 = zF_A398987E_symbolRegistryQuali(zT_59, zT_60, zT_61);
    sym_check = zT_67;
    sym_check = zT_67;
    sym_check = zT_67;
    zT_68 = sym_check.has_value;
    if (zT_68) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_199 = decl.kind;
    zT_202 = zT_8143F551_AstKind_var_decl;
    zT_203 = zT_199 == zT_202;
    if (zT_203) goto z_bb_38; else goto z_bb_39;
    z_bb_14:
    sc = sym_check.value;
    zT_70 = sc->type_id;
    zT_71 = 0;
    zT_72 = zT_70 != zT_71;
    if (zT_72) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    zT_75 = 1;
    zT_76 = 0;
    zT_74[zT_76] = zT_75;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        rt_box[_i] = zT_74[_i];
        _i++;
    }
}
    zT_77 = proto.return_type_node;
    zT_78 = 0;
    zT_79 = zT_77 != (unsigned int)zT_78;
    if (zT_79) goto z_bb_18; else goto z_bb_19;
    z_bb_16:
    goto z_bb_10;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_81 = env;
    zT_84 = proto.return_type_node;
    zT_82 = zT_84;
    zT_85 = 0;
    zT_83 = zT_85;
    zT_86 = zF_F2107C15_resolveTypeExprFull(zT_81, zT_82, zT_83);
    rtype = zT_86;
    rtype = zT_86;
    rtype = zT_86;
    zT_87 = 18;
    zT_88 = rtype != zT_87;
    if (zT_88) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    zT_95 = 0;
    is_ext = zT_95;
    is_ext = zT_95;
    is_ext = zT_95;
    zT_96 = decl.flags;
    zT_97 = 4;
    zT_98 = zT_96 & zT_97;
    zT_99 = 0;
    zT_100 = zT_98 != zT_99;
    if (zT_100) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    zT_89 = 0;
    rt_box[zT_89] = rtype;
    zT_90 = resolved_types;
    zT_93 = proto.return_type_node;
    zT_91 = zT_93;
    zT_92 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_90, zT_91, zT_92);
    goto z_bb_21;
    z_bb_21:
    goto z_bb_19;
    z_bb_22:
    zT_101 = 1;
    is_ext = zT_101;
    is_ext = zT_101;
    goto z_bb_23;
    z_bb_23:
    zT_103 = 0;
    is_variadic = zT_103;
    is_variadic = zT_103;
    is_variadic = zT_103;
    zT_104 = decl.flags;
    zT_105 = 1;
    zT_106 = zT_104 & zT_105;
    zT_107 = 0;
    zT_108 = zT_106 != zT_107;
    if (zT_108) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_109 = 1;
    is_variadic = zT_109;
    is_variadic = zT_109;
    goto z_bb_25;
    z_bb_25:
    zT_111 = env->typereg;
    zT_112 = zT_111->xt_len;
    zT_113 = (unsigned int)zT_112;
    fn_start = zT_113;
    fn_start = zT_113;
    fn_start = zT_113;
    zT_114 = proto.params_count;
    zT_115 = 0;
    zT_116 = zT_114 > zT_115;
    if (zT_116) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_118 = proto.params_start;
    zT_119 = (zT_79FAE712_u64)zT_118;
    zT_120 = 32;
    zT_121 = zT_119 << zT_120;
    zT_122 = proto.params_count;
    zT_123 = (zT_79FAE712_u64)zT_122;
    zT_124 = zT_121 | zT_123;
    p_payload = zT_124;
    p_payload = zT_124;
    p_payload = zT_124;
    zT_128 = env->store;
    zT_126 = zT_128;
    zT_127 = p_payload;
    zT_129 = zF_3EAD7B21_astStoreGetExtraChi(zT_126, zT_127);
    pnodes = zT_129;
    pnodes = zT_129;
    pnodes = zT_129;
    zT_131 = 0;
    zT_132 = (unsigned int)zT_131;
    pi = zT_132;
    pi = zT_132;
    pi = zT_132;
    goto z_bb_28;
    z_bb_27:
    zT_173 = env->typereg;
    zT_165 = zT_173;
    zT_174 = proto.name_id;
    zT_166 = zT_174;
    zT_175 = mods.ptr;
    zT_176 = zT_175[mi];
    zT_177 = zT_176.id;
    zT_167 = zT_177;
    zT_168 = is_ext;
    zT_169 = is_variadic;
    zT_170 = fn_start;
    zT_178 = proto.params_count;
    zT_171 = zT_178;
    zT_179 = 0;
    zT_180 = rt_box[zT_179];
    zT_172 = zT_180;
    zT_181 = zF_474336D7_typeRegistryGetOrCr(zT_165, zT_166, zT_167, zT_168, zT_169, zT_170, zT_171, zT_172);
    tid = zT_181;
    tid = zT_181;
    tid = zT_181;
    zT_182 = resolved_types;
    zT_185 = decls.ptr;
    zT_186 = zT_185[di];
    zT_183 = zT_186;
    zT_184 = tid;
    zF_19B4A07D_resolvedTypeTableSe(zT_182, zT_183, zT_184);
    zT_191 = env->symbol_reg;
    zT_188 = zT_191;
    zT_192 = mods.ptr;
    zT_193 = zT_192[mi];
    zT_194 = zT_193.id;
    zT_189 = zT_194;
    zT_195 = proto.name_id;
    zT_190 = zT_195;
    zT_196 = zF_A398987E_symbolRegistryQuali(zT_188, zT_189, zT_190);
    sym = zT_196;
    sym = zT_196;
    sym = zT_196;
    zT_197 = sym.has_value;
    if (zT_197) goto z_bb_36; else goto z_bb_37;
    z_bb_28:
    zT_134 = pnodes.len;
    zT_135 = pi < zT_134;
    if (zT_135) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_139 = env->store;
    zT_137 = zT_139;
    zT_140 = pnodes.ptr;
    zT_141 = zT_140[pi];
    zT_138 = zT_141;
    zT_142 = zF_FCDD1D35_astStoreNodeAt(zT_137, zT_138);
    pnode = zT_142;
    pnode = zT_142;
    pnode = zT_142;
    zT_143 = pnode.child_0;
    zT_144 = 0;
    zT_145 = zT_143 != (unsigned int)zT_144;
    if (zT_145) goto z_bb_32; else goto z_bb_33;
    z_bb_30:
    goto z_bb_27;
    z_bb_31:
    zT_162 = 1;
    zT_163 = pi + zT_162;
    pi = zT_163;
    pi = zT_163;
    goto z_bb_28;
    z_bb_32:
    zT_147 = env;
    zT_150 = pnode.child_0;
    zT_148 = zT_150;
    zT_151 = 0;
    zT_149 = zT_151;
    zT_152 = zF_F2107C15_resolveTypeExprFull(zT_147, zT_148, zT_149);
    ptype = zT_152;
    ptype = zT_152;
    ptype = zT_152;
    zT_155 = env->typereg;
    zT_153 = zT_155;
    zT_154 = ptype;
    zF_4C03AE3D_xtAppend(zT_153, zT_154);
    zT_156 = 18;
    zT_157 = ptype != zT_156;
    if (zT_157) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    goto z_bb_31;
    z_bb_34:
    zT_158 = resolved_types;
    zT_161 = pnode.child_0;
    zT_159 = zT_161;
    zT_160 = ptype;
    zF_19B4A07D_resolvedTypeTableSe(zT_158, zT_159, zT_160);
    goto z_bb_35;
    z_bb_35:
    goto z_bb_33;
    z_bb_36:
    sp = sym.value;
    sp->type_id = tid;
    goto z_bb_37;
    z_bb_37:
    goto z_bb_12;
    z_bb_38:
    zT_205 = decl.child_0;
    zT_206 = 0;
    zT_207 = zT_205 != (unsigned int)zT_206;
    zT_204 = zT_207;
    goto z_bb_40;
    z_bb_39:
    zT_204 = 0;
    goto z_bb_40;
    z_bb_40:
    if (zT_204) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_209 = env;
    zT_212 = decl.child_0;
    zT_210 = zT_212;
    zT_213 = 0;
    zT_211 = zT_213;
    zT_214 = zF_F2107C15_resolveTypeExprFull(zT_209, zT_210, zT_211);
    vtype = zT_214;
    vtype = zT_214;
    vtype = zT_214;
    zT_215 = 18;
    zT_216 = vtype != zT_215;
    if (zT_216) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    goto z_bb_12;
    z_bb_43:
    zT_217 = resolved_types;
    zT_220 = decl.child_0;
    zT_218 = zT_220;
    zT_219 = vtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_217, zT_218, zT_219);
    zT_221 = resolved_types;
    zT_224 = decls.ptr;
    zT_225 = zT_224[di];
    zT_222 = zT_225;
    zT_223 = vtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_221, zT_222, zT_223);
    zT_230 = env->symbol_reg;
    zT_227 = zT_230;
    zT_231 = mods.ptr;
    zT_232 = zT_231[mi];
    zT_233 = zT_232.id;
    zT_228 = zT_233;
    zT_236 = env->store;
    zT_234 = zT_236;
    zT_237 = decls.ptr;
    zT_238 = zT_237[di];
    zT_235 = zT_238;
    zT_239 = zF_8BA26B9E_astStoreNodePayload(zT_234, zT_235);
    zT_229 = zT_239;
    zT_240 = zF_A398987E_symbolRegistryQuali(zT_227, zT_228, zT_229);
    sym = zT_240;
    sym = zT_240;
    sym = zT_240;
    zT_241 = sym.has_value;
    if (zT_241) goto z_bb_45; else goto z_bb_46;
    z_bb_44:
    goto z_bb_42;
    z_bb_45:
    sp = sym.value;
    sp->type_id = vtype;
    goto z_bb_46;
    z_bb_46:
    goto z_bb_44;
}

/* typeResolverResolveNames */
void zF_373A7BEF_typeResolverResolve(zT_6B0A7D14_AstStore* store, zT_338B7C76_TypeRegistry* typereg, zT_3D7259E2_SymbolRegistry* symbol_reg, zT_D3EB6303_StringInterner* interner, zT_8EED1867_ResolvedTypeTable* resolved_types, zT_072B53A6_ModuleRegistry* module_reg, zT_3E40CD83_Sand* perm_alloc) {
    zT_072B53A6_ModuleRegistry* zT_8;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_9 = {0};
    zT_ABC1EBBE_TypeResolveEnv zT_11;
    zT_ABC1EBBE_TypeResolveEnv* zT_13;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_14;
    zT_ABC1EBBE_TypeResolveEnv* zT_15;
    zT_ABC1EBBE_TypeResolveEnv* zT_16;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_17;
    zT_072B53A6_ModuleRegistry* zT_18;
    zT_ABC1EBBE_TypeResolveEnv* zT_19;
    zT_ABC1EBBE_TypeResolveEnv* zT_20;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_21;
    zT_ABC1EBBE_TypeResolveEnv* zT_22;
    zT_ABC1EBBE_TypeResolveEnv* zT_23;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_24;
    zT_8EED1867_ResolvedTypeTable* zT_25;
    zT_ABC1EBBE_TypeResolveEnv* zT_26;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    zT_ABC1EBBE_TypeResolveEnv env;
    zT_8 = module_reg;
    zT_9 = zF_3452C137_moduleRegistryGetMo(zT_8);
    mods = zT_9;
    mods = zT_9;
    mods = zT_9;
    zT_11.store = store;
    zT_11.typereg = typereg;
    zT_11.symbol_reg = symbol_reg;
    zT_11.interner = interner;
    zT_11.module_id = zG_E6DB2ACE_MODULE_ID_NONE;
    env = zT_11;
    env = zT_11;
    env = zT_11;
    (void)perm_alloc;
    zT_15 = &env;
    zT_13 = zT_15;
    zT_14 = mods;
    zF_D9A1E9B7_resolveNamedTypeExp(zT_13, zT_14);
    zT_19 = &env;
    zT_16 = zT_19;
    zT_17 = mods;
    zT_18 = module_reg;
    zF_1DB55B7A_resolveImportFieldA(zT_16, zT_17, zT_18);
    zT_22 = &env;
    zT_20 = zT_22;
    zT_21 = mods;
    zF_E2882212_resolveAggregateFie(zT_20, zT_21);
    zT_26 = &env;
    zT_23 = zT_26;
    zT_24 = mods;
    zT_25 = resolved_types;
    zF_29FBFC7C_resolveFnSignatures(zT_23, zT_24, zT_25);
    return;
}

/* __module_init */
void zF_780653D2___module_init_16(void) {
    zT_52CDA6EF_DepEdge zT_0 = {0};
    zT_D3EB6303_StringInterner zT_1 = {0};
    zT_3D7259E2_SymbolRegistry zT_2 = {0};
    unsigned int zT_3;
    zG_52CDA6EF_DepEdge = zT_0;
    zG_D3EB6303_StringInterner = zT_1;
    zG_3D7259E2_SymbolRegistry = zT_2;
    zT_3 = 4294967295u;
    zG_E6DB2ACE_MODULE_ID_NONE = zT_3;
    return;
}

/* EOF */
