#include "type_registry_8EE489B8.h"
zT_338B7C76_TypeRegistry zG_338B7C76_TypeRegistry;
zT_33EF6BFB_TypeKind zG_33EF6BFB_TypeKind;
/* typeDbOom */
void zF_9091237C_typeDbOom(unsigned int used, unsigned int new_bytes) {
    char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_5426B97B_Arr_unsigned_char_1 zT_8;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    unsigned char* zT_13;
    unsigned int zT_14;
    int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19 = 0;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned char* zT_25;
    unsigned int zT_27;
    unsigned char* zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_5426B97B_Arr_unsigned_char_1 zT_37;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    unsigned char* zT_42;
    unsigned int zT_43;
    int zT_44;
    unsigned char* zT_45;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48 = 0;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned char* zT_54;
    unsigned int zT_56;
    unsigned char* zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned char zT_65;
    unsigned char zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u p0;
    zT_5426B97B_Arr_unsigned_char_1 ubuf;
    unsigned int ulen;
    unsigned int ustart;
    zT_8F083A69_Slice_zT_0B42B2F8_u p1;
    zT_5426B97B_Arr_unsigned_char_1 nbuf;
    unsigned int nlen;
    unsigned int nstart;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2;
    zT_3 = "OOM: type_db ";
    zT_5 = 13;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    p0 = zT_4;
    p0 = zT_4;
    p0 = zT_4;
    zT_6 = p0;
    zF_E4B2EF19_stderr_write(zT_6);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_8[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        ubuf[_i] = zT_8[_i];
        _i++;
    }
}
    zT_12 = (unsigned int)used;
    zT_10 = zT_12;
    zT_13 = (unsigned char*)ubuf;
    zT_14 = 16;
    zT_15 = 0;
    zT_16 = zT_13 + zT_15;
    zT_17 = zT_14 - zT_15;
    zT_18.ptr = zT_16;
    zT_18.len = zT_17;
    zT_11 = zT_18;
    zT_19 = zF_A7504564_itoa(zT_10, zT_11);
    ulen = zT_19;
    ulen = zT_19;
    ulen = zT_19;
    zT_21 = 15;
    zT_22 = (unsigned int)ulen;
    zT_23 = zT_21 - zT_22;
    ustart = zT_23;
    ustart = zT_23;
    ustart = zT_23;
    zT_25 = (unsigned char*)ubuf;
    zT_27 = 15;
    zT_28 = zT_25 + ustart;
    zT_29 = zT_27 - ustart;
    zT_30.ptr = zT_28;
    zT_30.len = zT_29;
    zT_24 = zT_30;
    zF_E4B2EF19_stderr_write(zT_24);
    zT_32 = " -> ";
    zT_34 = 4;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    p1 = zT_33;
    p1 = zT_33;
    p1 = zT_33;
    zT_35 = p1;
    zF_E4B2EF19_stderr_write(zT_35);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_37[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        nbuf[_i] = zT_37[_i];
        _i++;
    }
}
    zT_41 = (unsigned int)new_bytes;
    zT_39 = zT_41;
    zT_42 = (unsigned char*)nbuf;
    zT_43 = 16;
    zT_44 = 0;
    zT_45 = zT_42 + zT_44;
    zT_46 = zT_43 - zT_44;
    zT_47.ptr = zT_45;
    zT_47.len = zT_46;
    zT_40 = zT_47;
    zT_48 = zF_A7504564_itoa(zT_39, zT_40);
    nlen = zT_48;
    nlen = zT_48;
    nlen = zT_48;
    zT_50 = 15;
    zT_51 = (unsigned int)nlen;
    zT_52 = zT_50 - zT_51;
    nstart = zT_52;
    nstart = zT_52;
    nstart = zT_52;
    zT_54 = (unsigned char*)nbuf;
    zT_56 = 15;
    zT_57 = zT_54 + nstart;
    zT_58 = zT_56 - nstart;
    zT_59.ptr = zT_57;
    zT_59.len = zT_58;
    zT_53 = zT_59;
    zF_E4B2EF19_stderr_write(zT_53);
    zT_61 = "\n";
    zT_63 = 1;
    zT_62.ptr = zT_61;
    zT_62.len = zT_63;
    p2 = zT_62;
    p2 = zT_62;
    p2 = zT_62;
    zT_64 = p2;
    zF_E4B2EF19_stderr_write(zT_64);
    zT_66 = 1;
    zT_65 = zT_66;
    zF_CDED1A85_exit(zT_65);
    return;
}

/* arrayGrow */
void zF_B49E7F39_arrayGrow(unsigned char** items_out, unsigned int* len_ptr, unsigned int* cap_ptr, zT_3E40CD83_Sand* alloc, unsigned int elem_size) {
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_3E40CD83_Sand* zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_A62CFBCC_EU_022 zT_20 = {0};
    unsigned char zT_21;
    unsigned char* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char* zT_28;
    unsigned char* zT_30;
    unsigned char* zT_31;
    unsigned char* zT_33;
    int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    int zT_39;
    unsigned char zT_40;
    int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int nc;
    unsigned char* raw;
    unsigned char* src;
    unsigned char* dst;
    unsigned int i;
    zT_6 = *cap_ptr;
    zT_7 = 8;
    zT_8 = zT_6 < zT_7;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = 8;
    zT_9 = zT_10;
    goto z_bb_3;
    z_bb_2:
    zT_11 = *cap_ptr;
    zT_12 = 2;
    zT_13 = zT_11 * zT_12;
    zT_9 = zT_13;
    goto z_bb_3;
    z_bb_3:
    nc = zT_9;
    nc = zT_9;
    nc = zT_9;
    zT_15 = alloc;
    zT_18 = elem_size * nc;
    zT_16 = zT_18;
    zT_19 = 4;
    zT_17 = zT_19;
    zT_20 = zF_1395EB68_sandAlloc(zT_15, zT_16, zT_17);
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_25 = *len_ptr;
    zT_26 = zT_25 * elem_size;
    zT_23 = zT_26;
    zT_27 = elem_size * nc;
    zT_24 = zT_27;
    zF_9091237C_typeDbOom(zT_23, zT_24);
    return;
    z_bb_5:
    zT_28 = zT_20.data.payload;
    zT_22 = zT_28;
    goto z_bb_6;
    z_bb_6:
    raw = zT_22;
    raw = zT_22;
    raw = zT_22;
    zT_30 = *items_out;
    zT_31 = (unsigned char*)zT_30;
    src = zT_31;
    src = zT_31;
    src = zT_31;
    zT_33 = (unsigned char*)raw;
    dst = zT_33;
    dst = zT_33;
    dst = zT_33;
    zT_35 = 0;
    zT_36 = (unsigned int)zT_35;
    i = zT_36;
    i = zT_36;
    i = zT_36;
    goto z_bb_7;
    z_bb_7:
    zT_37 = *len_ptr;
    zT_38 = zT_37 * elem_size;
    zT_39 = i < zT_38;
    if (zT_39) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_40 = src[i];
    dst[i] = zT_40;
    zT_41 = 1;
    zT_42 = (unsigned int)zT_41;
    zT_43 = i + zT_42;
    i = zT_43;
    i = zT_43;
    goto z_bb_10;
    z_bb_9:
    *items_out = raw;
    *cap_ptr = nc;
    return;
    z_bb_10:
    goto z_bb_7;
}

/* payloadEnsure */
void zF_67265B37_payloadEnsure(unsigned char** items_out, unsigned int* len_ptr, unsigned int* cap_ptr, zT_3E40CD83_Sand* alloc, unsigned int elem_size, unsigned int new_cap) {
    unsigned int zT_6;
    int zT_7;
    unsigned char** zT_8;
    unsigned int* zT_9;
    unsigned int* zT_10;
    zT_3E40CD83_Sand* zT_11;
    unsigned int zT_12;
    zT_6 = *cap_ptr;
    zT_7 = new_cap <= zT_6;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = items_out;
    zT_9 = len_ptr;
    zT_10 = cap_ptr;
    zT_11 = alloc;
    zT_12 = elem_size;
    zF_B49E7F39_arrayGrow(zT_8, zT_9, zT_10, zT_11, zT_12);
    return;
}

/* typeRegistryEnsureCapacity */
void zF_BCE30624_typeRegistryEnsureC(zT_338B7C76_TypeRegistry* self, unsigned int new_cap) {
    unsigned int zT_2;
    int zT_3;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    int zT_8;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_13;
    int zT_14;
    unsigned int zT_15;
    zT_3E40CD83_Sand* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_3E40CD83_Sand* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_A62CFBCC_EU_022 zT_24 = {0};
    unsigned char zT_25;
    unsigned char* zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned char* zT_34;
    zT_D155D06D_Type* zT_36;
    zT_D155D06D_Type* zT_37;
    unsigned int zT_38;
    int zT_39;
    zT_D155D06D_Type* zT_40;
    unsigned int zT_41;
    zT_6BDC94CF_Slice_zT_D155D06D_T zT_42;
    zT_D155D06D_Type* zT_43;
    unsigned int zT_44;
    int zT_46;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned int nc;
    unsigned char* raw;
    zT_D155D06D_Type* new_items;
    zT_D155D06D_Type item;
    unsigned int i;
    zT_2 = self->types_cap;
    zT_3 = new_cap <= zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    nc = new_cap;
    nc = new_cap;
    zT_5 = self->types_cap;
    zT_6 = 2;
    zT_7 = zT_5 * zT_6;
    zT_8 = nc < zT_7;
    if (zT_8) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->types_cap;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    nc = zT_11;
    nc = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 32;
    zT_13 = nc < (unsigned int)zT_12;
    if (zT_13) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 32;
    zT_15 = (unsigned int)zT_14;
    nc = zT_15;
    nc = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_20 = self->types_alloc;
    zT_17 = zT_20;
    zT_21 = 28;
    zT_22 = zT_21 * nc;
    zT_18 = zT_22;
    zT_23 = 4;
    zT_19 = zT_23;
    zT_24 = zF_1395EB68_sandAlloc(zT_17, zT_18, zT_19);
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_29 = self->types_len;
    zT_30 = 28;
    zT_31 = zT_29 * zT_30;
    zT_27 = zT_31;
    zT_32 = 28;
    zT_33 = zT_32 * nc;
    zT_28 = zT_33;
    zF_9091237C_typeDbOom(zT_27, zT_28);
    return;
    z_bb_8:
    zT_34 = zT_24.data.payload;
    zT_26 = zT_34;
    goto z_bb_9;
    z_bb_9:
    raw = zT_26;
    raw = zT_26;
    raw = zT_26;
    zT_36 = (zT_D155D06D_Type*)raw;
    new_items = zT_36;
    new_items = zT_36;
    new_items = zT_36;
    zT_37 = self->types_items;
    zT_38 = self->types_len;
    zT_39 = 0;
    zT_40 = zT_37 + zT_39;
    zT_41 = zT_38 - zT_39;
    zT_42.ptr = zT_40;
    zT_42.len = zT_41;
    zT_43 = zT_42.ptr;
    zT_44 = zT_42.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    zT_46 = i < zT_44;
    if (zT_46) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_43[i];
    new_items[i] = item;
    zT_48 = 1;
    zT_49 = i + zT_48;
    i = zT_49;
    goto z_bb_10;
    z_bb_12:
    self->types_items = new_items;
    self->types_cap = nc;
    return;
}

/* typeRegistryAppend */
unsigned int zF_D4993F02_typeRegistryAppend(zT_338B7C76_TypeRegistry* self, zT_D155D06D_Type t) {
    zT_338B7C76_TypeRegistry* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_4028D896_Arr_unsigned_char_2 zT_17;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    unsigned int zT_22;
    unsigned char* zT_23;
    unsigned int zT_24;
    int zT_25;
    unsigned char* zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29 = 0;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned char* zT_40;
    unsigned int zT_42;
    unsigned char* zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_4028D896_Arr_unsigned_char_2 zT_47;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    unsigned char* zT_52;
    unsigned int zT_53;
    int zT_54;
    unsigned char* zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58 = 0;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    char* zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned char* zT_69;
    unsigned int zT_71;
    unsigned char* zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    zT_4028D896_Arr_unsigned_char_2 zT_76;
    unsigned int zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned char* zT_80;
    unsigned int zT_81;
    int zT_82;
    unsigned char* zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    unsigned int zT_86 = 0;
    unsigned int zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned char* zT_97;
    unsigned int zT_99;
    unsigned char* zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    char* zT_104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    unsigned int zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    zT_33EF6BFB_TypeKind zT_108;
    zT_33EF6BFB_TypeKind zT_109;
    int zT_110;
    char* zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    unsigned int id;
    zT_4028D896_Arr_unsigned_char_2 dc_k;
    unsigned int dc_kl;
    unsigned int dc_ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u dcm;
    zT_4028D896_Arr_unsigned_char_2 dc_n;
    unsigned int dc_nl;
    unsigned int dc_ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u dcn;
    zT_4028D896_Arr_unsigned_char_2 dc_i;
    unsigned int dc_il;
    unsigned int dc_is;
    zT_8F083A69_Slice_zT_0B42B2F8_u dci;
    zT_8F083A69_Slice_zT_0B42B2F8_u dcnl;
    zT_8F083A69_Slice_zT_0B42B2F8_u xs;
    zT_2 = self;
    zT_4 = self->types_len;
    zT_5 = 1;
    zT_6 = zT_4 + zT_5;
    zT_3 = zT_6;
    zF_BCE30624_typeRegistryEnsureC(zT_2, zT_3);
    zT_8 = self->types_len;
    zT_9 = (unsigned int)zT_8;
    id = zT_9;
    id = zT_9;
    id = zT_9;
    zT_10 = self->types_items;
    zT_11 = self->types_len;
    zT_10[zT_11] = t;
    zT_12 = self->types_len;
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = zT_12 + zT_14;
    self->types_len = zT_15;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_17[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dc_k[_i] = zT_17[_i];
        _i++;
    }
}
    zT_21 = t.kind;
    zT_22 = (unsigned int)zT_21;
    zT_19 = zT_22;
    zT_23 = (unsigned char*)dc_k;
    zT_24 = 20;
    zT_25 = 0;
    zT_26 = zT_23 + zT_25;
    zT_27 = zT_24 - zT_25;
    zT_28.ptr = zT_26;
    zT_28.len = zT_27;
    zT_20 = zT_28;
    zT_29 = zF_A7504564_itoa(zT_19, zT_20);
    dc_kl = zT_29;
    dc_kl = zT_29;
    dc_kl = zT_29;
    zT_31 = 19;
    zT_32 = (unsigned int)dc_kl;
    zT_33 = zT_31 - zT_32;
    dc_ks = zT_33;
    dc_ks = zT_33;
    dc_ks = zT_33;
    zT_35 = "DC:k";
    zT_37 = 4;
    zT_36.ptr = zT_35;
    zT_36.len = zT_37;
    dcm = zT_36;
    dcm = zT_36;
    dcm = zT_36;
    zT_38 = dcm;
    zF_B5478454_measureMarkerWrite(zT_38);
    zT_40 = (unsigned char*)dc_k;
    zT_42 = 19;
    zT_43 = zT_40 + dc_ks;
    zT_44 = zT_42 - dc_ks;
    zT_45.ptr = zT_43;
    zT_45.len = zT_44;
    zT_39 = zT_45;
    zF_B5478454_measureMarkerWrite(zT_39);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_47[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dc_n[_i] = zT_47[_i];
        _i++;
    }
}
    zT_51 = t.name_id;
    zT_49 = zT_51;
    zT_52 = (unsigned char*)dc_n;
    zT_53 = 20;
    zT_54 = 0;
    zT_55 = zT_52 + zT_54;
    zT_56 = zT_53 - zT_54;
    zT_57.ptr = zT_55;
    zT_57.len = zT_56;
    zT_50 = zT_57;
    zT_58 = zF_A7504564_itoa(zT_49, zT_50);
    dc_nl = zT_58;
    dc_nl = zT_58;
    dc_nl = zT_58;
    zT_60 = 19;
    zT_61 = (unsigned int)dc_nl;
    zT_62 = zT_60 - zT_61;
    dc_ns = zT_62;
    dc_ns = zT_62;
    dc_ns = zT_62;
    zT_64 = "n";
    zT_66 = 1;
    zT_65.ptr = zT_64;
    zT_65.len = zT_66;
    dcn = zT_65;
    dcn = zT_65;
    dcn = zT_65;
    zT_67 = dcn;
    zF_B5478454_measureMarkerWrite(zT_67);
    zT_69 = (unsigned char*)dc_n;
    zT_71 = 19;
    zT_72 = zT_69 + dc_ns;
    zT_73 = zT_71 - dc_ns;
    zT_74.ptr = zT_72;
    zT_74.len = zT_73;
    zT_68 = zT_74;
    zF_B5478454_measureMarkerWrite(zT_68);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_76[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dc_i[_i] = zT_76[_i];
        _i++;
    }
}
    zT_78 = id;
    zT_80 = (unsigned char*)dc_i;
    zT_81 = 20;
    zT_82 = 0;
    zT_83 = zT_80 + zT_82;
    zT_84 = zT_81 - zT_82;
    zT_85.ptr = zT_83;
    zT_85.len = zT_84;
    zT_79 = zT_85;
    zT_86 = zF_A7504564_itoa(zT_78, zT_79);
    dc_il = zT_86;
    dc_il = zT_86;
    dc_il = zT_86;
    zT_88 = 19;
    zT_89 = (unsigned int)dc_il;
    zT_90 = zT_88 - zT_89;
    dc_is = zT_90;
    dc_is = zT_90;
    dc_is = zT_90;
    zT_92 = "t";
    zT_94 = 1;
    zT_93.ptr = zT_92;
    zT_93.len = zT_94;
    dci = zT_93;
    dci = zT_93;
    dci = zT_93;
    zT_95 = dci;
    zF_B5478454_measureMarkerWrite(zT_95);
    zT_97 = (unsigned char*)dc_i;
    zT_99 = 19;
    zT_100 = zT_97 + dc_is;
    zT_101 = zT_99 - dc_is;
    zT_102.ptr = zT_100;
    zT_102.len = zT_101;
    zT_96 = zT_102;
    zF_B5478454_measureMarkerWrite(zT_96);
    zT_104 = "\n";
    zT_106 = 1;
    zT_105.ptr = zT_104;
    zT_105.len = zT_106;
    dcnl = zT_105;
    dcnl = zT_105;
    dcnl = zT_105;
    zT_107 = dcnl;
    zF_B5478454_measureMarkerWrite(zT_107);
    zT_108 = t.kind;
    zT_109 = zT_33EF6BFB_TypeKind_struct_type;
    zT_110 = zT_108 == zT_109;
    if (zT_110) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_112 = "X:";
    zT_114 = 2;
    zT_113.ptr = zT_112;
    zT_113.len = zT_114;
    xs = zT_113;
    xs = zT_113;
    xs = zT_113;
    zT_115 = xs;
    zT_116 = id;
    zF_95B5C5CD_measureMarkerWriteI(zT_115, zT_116);
    goto z_bb_2;
    z_bb_2:
    return id;
}

/* ptrAppend */
void zF_E5939FBD_ptrAppend(zT_338B7C76_TypeRegistry* self, zT_112BF819_PtrPayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_112BF819_PtrPayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_112BF819_PtrPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->ptr_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->ptr_len;
    zT_3 = zT_10;
    zT_11 = &self->ptr_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 4;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->ptr_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->ptr_items;
    zT_19 = self->ptr_len;
    zT_18[zT_19] = v;
    zT_20 = self->ptr_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->ptr_len = zT_23;
    return;
}

/* arrayAppend */
void zF_4D5CD212_arrayAppend(zT_338B7C76_TypeRegistry* self, zT_E834303C_ArrayPayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_E834303C_ArrayPayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_E834303C_ArrayPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->array_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->array_len;
    zT_3 = zT_10;
    zT_11 = &self->array_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 8;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->array_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->array_items;
    zT_19 = self->array_len;
    zT_18[zT_19] = v;
    zT_20 = self->array_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->array_len = zT_23;
    return;
}

/* sliceAppend */
void zF_8BFD6695_sliceAppend(zT_338B7C76_TypeRegistry* self, zT_0BB2A741_SlicePayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_0BB2A741_SlicePayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_0BB2A741_SlicePayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->slice_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->slice_len;
    zT_3 = zT_10;
    zT_11 = &self->slice_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 4;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->slice_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->slice_items;
    zT_19 = self->slice_len;
    zT_18[zT_19] = v;
    zT_20 = self->slice_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->slice_len = zT_23;
    return;
}

/* optAppend */
void zF_4569340E_optAppend(zT_338B7C76_TypeRegistry* self, zT_0B10E8E9_OptionalPayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_0B10E8E9_OptionalPayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_0B10E8E9_OptionalPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->opt_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->opt_len;
    zT_3 = zT_10;
    zT_11 = &self->opt_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 4;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->opt_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->opt_items;
    zT_19 = self->opt_len;
    zT_18[zT_19] = v;
    zT_20 = self->opt_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->opt_len = zT_23;
    return;
}

/* euAppend */
void zF_ABBA52E7_euAppend(zT_338B7C76_TypeRegistry* self, zT_42C2D6BF_EUPayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_42C2D6BF_EUPayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_42C2D6BF_EUPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->eu_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->eu_len;
    zT_3 = zT_10;
    zT_11 = &self->eu_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 8;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->eu_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->eu_items;
    zT_19 = self->eu_len;
    zT_18[zT_19] = v;
    zT_20 = self->eu_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->eu_len = zT_23;
    return;
}

/* esAppend */
void zF_B86143DD_esAppend(zT_338B7C76_TypeRegistry* self, zT_0B73C507_ErrorSetPayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_0B73C507_ErrorSetPayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_0B73C507_ErrorSetPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->es_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->es_len;
    zT_3 = zT_10;
    zT_11 = &self->es_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 8;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->es_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->es_items;
    zT_19 = self->es_len;
    zT_18[zT_19] = v;
    zT_20 = self->es_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->es_len = zT_23;
    return;
}

/* fnAppend */
void zF_07DDC351_fnAppend(zT_338B7C76_TypeRegistry* self, zT_0317B1D5_FnPayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_0317B1D5_FnPayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_0317B1D5_FnPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->fn_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->fn_len;
    zT_3 = zT_10;
    zT_11 = &self->fn_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 24;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->fn_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->fn_items;
    zT_19 = self->fn_len;
    zT_18[zT_19] = v;
    zT_20 = self->fn_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->fn_len = zT_23;
    return;
}

/* stAppend */
void zF_CF849366_stAppend(zT_338B7C76_TypeRegistry* self, zT_406493CE_StructPayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_406493CE_StructPayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_406493CE_StructPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->st_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->st_len;
    zT_3 = zT_10;
    zT_11 = &self->st_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 8;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->st_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->st_items;
    zT_19 = self->st_len;
    zT_18[zT_19] = v;
    zT_20 = self->st_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->st_len = zT_23;
    return;
}

/* enAppend */
void zF_298371DE_enAppend(zT_338B7C76_TypeRegistry* self, zT_457ECFEE_EnumPayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_457ECFEE_EnumPayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_457ECFEE_EnumPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->en_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->en_len;
    zT_3 = zT_10;
    zT_11 = &self->en_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 12;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->en_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->en_items;
    zT_19 = self->en_len;
    zT_18[zT_19] = v;
    zT_20 = self->en_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->en_len = zT_23;
    return;
}

/* unAppend */
void zF_1718422E_unAppend(zT_338B7C76_TypeRegistry* self, zT_AF9231A2_UnionPayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_AF9231A2_UnionPayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_AF9231A2_UnionPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->un_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->un_len;
    zT_3 = zT_10;
    zT_11 = &self->un_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 12;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->un_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->un_items;
    zT_19 = self->un_len;
    zT_18[zT_19] = v;
    zT_20 = self->un_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->un_len = zT_23;
    return;
}

/* tuAppend */
void zF_FB6B57C6_tuAppend(zT_338B7C76_TypeRegistry* self, zT_54FF90FA_TaggedUnionPayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_54FF90FA_TaggedUnionPayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_54FF90FA_TaggedUnionPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->tu_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->tu_len;
    zT_3 = zT_10;
    zT_11 = &self->tu_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 12;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->tu_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->tu_items;
    zT_19 = self->tu_len;
    zT_18[zT_19] = v;
    zT_20 = self->tu_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->tu_len = zT_23;
    return;
}

/* tupAppend */
void zF_C94DF842_tupAppend(zT_338B7C76_TypeRegistry* self, zT_666DC2E1_TuplePayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_666DC2E1_TuplePayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_666DC2E1_TuplePayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->tup_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->tup_len;
    zT_3 = zT_10;
    zT_11 = &self->tup_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 8;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->tup_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->tup_items;
    zT_19 = self->tup_len;
    zT_18[zT_19] = v;
    zT_20 = self->tup_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->tup_len = zT_23;
    return;
}

/* unrAppend */
void zF_C4ED5700_unrAppend(zT_338B7C76_TypeRegistry* self, zT_42E798B0_UnresolvedPayload v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_42E798B0_UnresolvedPayload** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_42E798B0_UnresolvedPayload* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->unr_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->unr_len;
    zT_3 = zT_10;
    zT_11 = &self->unr_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 8;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->unr_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->unr_items;
    zT_19 = self->unr_len;
    zT_18[zT_19] = v;
    zT_20 = self->unr_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->unr_len = zT_23;
    return;
}

/* feAppend */
void zF_701DF154_feAppend(zT_338B7C76_TypeRegistry* self, zT_2DF01B61_FieldEntry v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_2DF01B61_FieldEntry** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_2DF01B61_FieldEntry* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->fe_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->fe_len;
    zT_3 = zT_10;
    zT_11 = &self->fe_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 12;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->fe_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->fe_items;
    zT_19 = self->fe_len;
    zT_18[zT_19] = v;
    zT_20 = self->fe_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->fe_len = zT_23;
    return;
}

/* emAppend */
void zF_157DA7BF_emAppend(zT_338B7C76_TypeRegistry* self, zT_D96DCDF2_EnumMember v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_D96DCDF2_EnumMember** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    zT_D96DCDF2_EnumMember* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8 = &self->em_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->em_len;
    zT_3 = zT_10;
    zT_11 = &self->em_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 16;
    zT_14 = (unsigned int)zT_13;
    zT_6 = zT_14;
    zT_15 = self->em_len;
    zT_16 = 1;
    zT_17 = zT_15 + zT_16;
    zT_7 = zT_17;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_18 = self->em_items;
    zT_19 = self->em_len;
    zT_18[zT_19] = v;
    zT_20 = self->em_len;
    zT_21 = 1;
    zT_22 = (unsigned int)zT_21;
    zT_23 = zT_20 + zT_22;
    self->em_len = zT_23;
    return;
}

/* xtAppend */
void zF_4C03AE3D_xtAppend(zT_338B7C76_TypeRegistry* self, unsigned int v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    int zT_15;
    unsigned int zT_16;
    unsigned int* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_8 = &self->xt_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->xt_len;
    zT_3 = zT_10;
    zT_11 = &self->xt_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 4;
    zT_6 = zT_13;
    zT_14 = self->xt_len;
    zT_15 = 1;
    zT_16 = zT_14 + zT_15;
    zT_7 = zT_16;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_17 = self->xt_items;
    zT_18 = self->xt_len;
    zT_17[zT_18] = v;
    zT_19 = self->xt_len;
    zT_20 = 1;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zT_19 + zT_21;
    self->xt_len = zT_22;
    return;
}

/* xnAppend */
void zF_A648B1CB_xnAppend(zT_338B7C76_TypeRegistry* self, unsigned int v) {
    unsigned char** zT_2;
    unsigned int* zT_3;
    unsigned int* zT_4;
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int** zT_8;
    unsigned char** zT_9;
    unsigned int* zT_10;
    unsigned int* zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    int zT_15;
    unsigned int zT_16;
    unsigned int* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_8 = &self->xn_items;
    zT_9 = (unsigned char**)zT_8;
    zT_2 = zT_9;
    zT_10 = &self->xn_len;
    zT_3 = zT_10;
    zT_11 = &self->xn_cap;
    zT_4 = zT_11;
    zT_12 = self->types_alloc;
    zT_5 = zT_12;
    zT_13 = 4;
    zT_6 = zT_13;
    zT_14 = self->xn_len;
    zT_15 = 1;
    zT_16 = zT_14 + zT_15;
    zT_7 = zT_16;
    zF_67265B37_payloadEnsure(zT_2, zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_17 = self->xn_items;
    zT_18 = self->xn_len;
    zT_17[zT_18] = v;
    zT_19 = self->xn_len;
    zT_20 = 1;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zT_19 + zT_21;
    self->xn_len = zT_22;
    return;
}

/* registerPrimitive */
unsigned int zF_4F84B621_registerPrimitive(zT_338B7C76_TypeRegistry* self, zT_33EF6BFB_TypeKind kind, unsigned int size, unsigned int alignment) {
    zT_338B7C76_TypeRegistry* zT_4;
    zT_D155D06D_Type zT_5;
    zT_D155D06D_Type zT_6;
    unsigned char zT_7;
    unsigned char zT_8;
    unsigned char zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_14 = 0;
    zT_4 = self;
    zT_6.kind = kind;
    zT_7 = 2;
    zT_6.state = zT_7;
    zT_8 = 0;
    zT_6.flags = zT_8;
    zT_9 = 0;
    zT_6._pad = zT_9;
    zT_6.size = size;
    zT_6.alignment = alignment;
    zT_10 = 0;
    zT_6.name_id = zT_10;
    zT_11 = 0;
    zT_6.c_name_id = zT_11;
    zT_12 = 0;
    zT_6.module_id = zT_12;
    zT_13 = 0;
    zT_6.payload_idx = zT_13;
    zT_5 = zT_6;
    zT_14 = zF_D4993F02_typeRegistryAppend(zT_4, zT_5);
    return zT_14;
}

/* alignUp */
unsigned int zF_D2BAC673_alignUp(unsigned int v, unsigned int a) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_2 = v + a;
    zT_3 = 1;
    zT_4 = zT_2 - zT_3;
    zT_5 = 1;
    zT_6 = a - zT_5;
    zT_7 = ~zT_6;
    zT_8 = zT_4 & zT_7;
    return zT_8;
}

/* initArray */
void zF_8E7EC1C8_initArray(unsigned char** items, unsigned int* len, unsigned int* cap) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_3 = 0;
    *items = (unsigned char*)zT_3;
    zT_4 = 0;
    *len = zT_4;
    zT_5 = 0;
    *cap = zT_5;
    return;
}

/* typeRegistryInit */
zT_338B7C76_TypeRegistry zF_4801746C_typeRegistryInit(zT_3E40CD83_Sand* alloc, zT_D3EB6303_StringInterner* interner) {
    zT_338B7C76_TypeRegistry zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    zT_3E40CD83_Sand* zT_58;
    zT_A4CE86B7_U64ToU32Map zT_59 = {0};
    zT_3E40CD83_Sand* zT_60;
    zT_A4CE86B7_U64ToU32Map zT_61 = {0};
    zT_3E40CD83_Sand* zT_62;
    zT_A4CE86B7_U64ToU32Map zT_63 = {0};
    zT_3E40CD83_Sand* zT_64;
    zT_21D3708C_U32ToU32Map zT_65 = {0};
    zT_3E40CD83_Sand* zT_66;
    zT_A4CE86B7_U64ToU32Map zT_67 = {0};
    zT_3E40CD83_Sand* zT_68;
    zT_A4CE86B7_U64ToU32Map zT_69 = {0};
    zT_3E40CD83_Sand* zT_70;
    zT_A4CE86B7_U64ToU32Map zT_71 = {0};
    zT_3E40CD83_Sand* zT_72;
    zT_A4CE86B7_U64ToU32Map zT_73 = {0};
    zT_338B7C76_TypeRegistry reg;
    zT_4 = 0;
    zT_3.types_items = (zT_D155D06D_Type*)zT_4;
    zT_5 = 0;
    zT_3.types_len = zT_5;
    zT_6 = 0;
    zT_3.types_cap = zT_6;
    zT_3.types_alloc = alloc;
    zT_3.interner = interner;
    zT_7 = 0;
    zT_3.ptr_items = (zT_112BF819_PtrPayload*)zT_7;
    zT_8 = 0;
    zT_3.ptr_len = zT_8;
    zT_9 = 0;
    zT_3.ptr_cap = zT_9;
    zT_10 = 0;
    zT_3.array_items = (zT_E834303C_ArrayPayload*)zT_10;
    zT_11 = 0;
    zT_3.array_len = zT_11;
    zT_12 = 0;
    zT_3.array_cap = zT_12;
    zT_13 = 0;
    zT_3.slice_items = (zT_0BB2A741_SlicePayload*)zT_13;
    zT_14 = 0;
    zT_3.slice_len = zT_14;
    zT_15 = 0;
    zT_3.slice_cap = zT_15;
    zT_16 = 0;
    zT_3.opt_items = (zT_0B10E8E9_OptionalPayload*)zT_16;
    zT_17 = 0;
    zT_3.opt_len = zT_17;
    zT_18 = 0;
    zT_3.opt_cap = zT_18;
    zT_19 = 0;
    zT_3.eu_items = (zT_42C2D6BF_EUPayload*)zT_19;
    zT_20 = 0;
    zT_3.eu_len = zT_20;
    zT_21 = 0;
    zT_3.eu_cap = zT_21;
    zT_22 = 0;
    zT_3.es_items = (zT_0B73C507_ErrorSetPayload*)zT_22;
    zT_23 = 0;
    zT_3.es_len = zT_23;
    zT_24 = 0;
    zT_3.es_cap = zT_24;
    zT_25 = 0;
    zT_3.fn_items = (zT_0317B1D5_FnPayload*)zT_25;
    zT_26 = 0;
    zT_3.fn_len = zT_26;
    zT_27 = 0;
    zT_3.fn_cap = zT_27;
    zT_28 = 0;
    zT_3.st_items = (zT_406493CE_StructPayload*)zT_28;
    zT_29 = 0;
    zT_3.st_len = zT_29;
    zT_30 = 0;
    zT_3.st_cap = zT_30;
    zT_31 = 0;
    zT_3.en_items = (zT_457ECFEE_EnumPayload*)zT_31;
    zT_32 = 0;
    zT_3.en_len = zT_32;
    zT_33 = 0;
    zT_3.en_cap = zT_33;
    zT_34 = 0;
    zT_3.un_items = (zT_AF9231A2_UnionPayload*)zT_34;
    zT_35 = 0;
    zT_3.un_len = zT_35;
    zT_36 = 0;
    zT_3.un_cap = zT_36;
    zT_37 = 0;
    zT_3.tu_items = (zT_54FF90FA_TaggedUnionPayload*)zT_37;
    zT_38 = 0;
    zT_3.tu_len = zT_38;
    zT_39 = 0;
    zT_3.tu_cap = zT_39;
    zT_40 = 0;
    zT_3.tup_items = (zT_666DC2E1_TuplePayload*)zT_40;
    zT_41 = 0;
    zT_3.tup_len = zT_41;
    zT_42 = 0;
    zT_3.tup_cap = zT_42;
    zT_43 = 0;
    zT_3.unr_items = (zT_42E798B0_UnresolvedPayload*)zT_43;
    zT_44 = 0;
    zT_3.unr_len = zT_44;
    zT_45 = 0;
    zT_3.unr_cap = zT_45;
    zT_46 = 0;
    zT_3.fe_items = (zT_2DF01B61_FieldEntry*)zT_46;
    zT_47 = 0;
    zT_3.fe_len = zT_47;
    zT_48 = 0;
    zT_3.fe_cap = zT_48;
    zT_49 = 0;
    zT_3.em_items = (zT_D96DCDF2_EnumMember*)zT_49;
    zT_50 = 0;
    zT_3.em_len = zT_50;
    zT_51 = 0;
    zT_3.em_cap = zT_51;
    zT_52 = 0;
    zT_3.xt_items = (unsigned int*)zT_52;
    zT_53 = 0;
    zT_3.xt_len = zT_53;
    zT_54 = 0;
    zT_3.xt_cap = zT_54;
    zT_55 = 0;
    zT_3.xn_items = (unsigned int*)zT_55;
    zT_56 = 0;
    zT_3.xn_len = zT_56;
    zT_57 = 0;
    zT_3.xn_cap = zT_57;
    zT_58 = alloc;
    zT_59 = zF_986226E1_u64ToU32MapInit(zT_58);
    zT_3.ptr_cache = zT_59;
    zT_60 = alloc;
    zT_61 = zF_986226E1_u64ToU32MapInit(zT_60);
    zT_3.many_ptr_cache = zT_61;
    zT_62 = alloc;
    zT_63 = zF_986226E1_u64ToU32MapInit(zT_62);
    zT_3.slice_cache = zT_63;
    zT_64 = alloc;
    zT_65 = zF_58BDA2DE_u32ToU32MapInit(zT_64);
    zT_3.optional_cache = zT_65;
    zT_66 = alloc;
    zT_67 = zF_986226E1_u64ToU32MapInit(zT_66);
    zT_3.array_cache = zT_67;
    zT_68 = alloc;
    zT_69 = zF_986226E1_u64ToU32MapInit(zT_68);
    zT_3.eu_cache = zT_69;
    zT_70 = alloc;
    zT_71 = zF_986226E1_u64ToU32MapInit(zT_70);
    zT_3.es_cache = zT_71;
    zT_72 = alloc;
    zT_73 = zF_986226E1_u64ToU32MapInit(zT_72);
    zT_3.name_cache = zT_73;
    reg = zT_3;
    reg = zT_3;
    reg = zT_3;
    return reg;
}

/* nameCacheGet */
zT_BAEE192E_Opt_10 zF_0EB68360_nameCacheGet(zT_338B7C76_TypeRegistry* self, zT_79FAE712_u64 key) {
    zT_A4CE86B7_U64ToU32Map* zT_3;
    zT_79FAE712_u64 zT_4;
    zT_A4CE86B7_U64ToU32Map* zT_5;
    zT_BAEE192E_Opt_10 zT_6 = {0};
    zT_79FAE712_u64 zT_8;
    zT_79FAE712_u64 zT_9;
    zT_79FAE712_u64 zT_10;
    int zT_11;
    char* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17;
    unsigned char zT_18;
    unsigned int zT_19;
    unsigned int zT_21;
    zT_BAEE192E_Opt_10 val;
    zT_79FAE712_u64 key_lo;
    zT_8F083A69_Slice_zT_0B42B2F8_u ngc_m;
    unsigned int v;
    zT_5 = &self->name_cache;
    zT_3 = zT_5;
    zT_4 = key;
    zT_6 = zF_A05A7BE1_u64ToU32MapGet(zT_3, zT_4);
    val = zT_6;
    val = zT_6;
    val = zT_6;
    zT_8 = 4294967295u;
    zT_9 = key & zT_8;
    key_lo = zT_9;
    key_lo = zT_9;
    key_lo = zT_9;
    zT_10 = 1;
    zT_11 = key_lo == zT_10;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = "NGC:g1";
    zT_15 = 6;
    zT_14.ptr = zT_13;
    zT_14.len = zT_15;
    ngc_m = zT_14;
    ngc_m = zT_14;
    ngc_m = zT_14;
    zT_16 = ngc_m;
    zT_18 = val.has_value;
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return val;
    z_bb_3:
    v = val.value;
    zT_19 = v;
    goto z_bb_5;
    z_bb_4:
    zT_21 = 0;
    zT_19 = zT_21;
    goto z_bb_5;
    z_bb_5:
    zT_17 = zT_19;
    zF_C914CB83_markerWriteInt(zT_16, zT_17);
    goto z_bb_2;
}

/* nameCachePut */
void zF_5E95558D_nameCachePut(zT_338B7C76_TypeRegistry* self, zT_79FAE712_u64 key, unsigned int value) {
    zT_A4CE86B7_U64ToU32Map* zT_3;
    zT_79FAE712_u64 zT_4;
    unsigned int zT_5;
    zT_A4CE86B7_U64ToU32Map* zT_6;
    zT_4028D896_Arr_unsigned_char_2 zT_8;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    zT_79FAE712_u64 zT_12;
    zT_79FAE712_u64 zT_13;
    unsigned int zT_14;
    unsigned char* zT_15;
    unsigned int zT_16;
    int zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21 = 0;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_32;
    unsigned int zT_34;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    zT_4028D896_Arr_unsigned_char_2 zT_39;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned char* zT_43;
    unsigned int zT_44;
    int zT_45;
    unsigned char* zT_46;
    unsigned int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49 = 0;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    char* zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned char* zT_60;
    unsigned int zT_62;
    unsigned char* zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    char* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    zT_4028D896_Arr_unsigned_char_2 np_k;
    unsigned int np_kl;
    unsigned int np_ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u npm;
    zT_4028D896_Arr_unsigned_char_2 np_v;
    unsigned int np_vl;
    unsigned int np_vs;
    zT_8F083A69_Slice_zT_0B42B2F8_u npv;
    zT_8F083A69_Slice_zT_0B42B2F8_u npnl;
    zT_6 = &self->name_cache;
    zT_3 = zT_6;
    zT_4 = key;
    zT_5 = value;
    zF_B6EB812C_u64ToU32MapPut(zT_3, zT_4, zT_5);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_8[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        np_k[_i] = zT_8[_i];
        _i++;
    }
}
    zT_12 = 65535;
    zT_13 = key & zT_12;
    zT_14 = __bootstrap_u32_from_u64(zT_13);
    zT_10 = zT_14;
    zT_15 = (unsigned char*)np_k;
    zT_16 = 20;
    zT_17 = 0;
    zT_18 = zT_15 + zT_17;
    zT_19 = zT_16 - zT_17;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    zT_11 = zT_20;
    zT_21 = zF_A7504564_itoa(zT_10, zT_11);
    np_kl = zT_21;
    np_kl = zT_21;
    np_kl = zT_21;
    zT_23 = 19;
    zT_24 = (unsigned int)np_kl;
    zT_25 = zT_23 - zT_24;
    np_ks = zT_25;
    np_ks = zT_25;
    np_ks = zT_25;
    zT_27 = "NP:k";
    zT_29 = 4;
    zT_28.ptr = zT_27;
    zT_28.len = zT_29;
    npm = zT_28;
    npm = zT_28;
    npm = zT_28;
    zT_30 = npm;
    zF_48AC7B3A_markerWrite(zT_30);
    zT_32 = (unsigned char*)np_k;
    zT_34 = 19;
    zT_35 = zT_32 + np_ks;
    zT_36 = zT_34 - np_ks;
    zT_37.ptr = zT_35;
    zT_37.len = zT_36;
    zT_31 = zT_37;
    zF_48AC7B3A_markerWrite(zT_31);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_39[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        np_v[_i] = zT_39[_i];
        _i++;
    }
}
    zT_41 = value;
    zT_43 = (unsigned char*)np_v;
    zT_44 = 20;
    zT_45 = 0;
    zT_46 = zT_43 + zT_45;
    zT_47 = zT_44 - zT_45;
    zT_48.ptr = zT_46;
    zT_48.len = zT_47;
    zT_42 = zT_48;
    zT_49 = zF_A7504564_itoa(zT_41, zT_42);
    np_vl = zT_49;
    np_vl = zT_49;
    np_vl = zT_49;
    zT_51 = 19;
    zT_52 = (unsigned int)np_vl;
    zT_53 = zT_51 - zT_52;
    np_vs = zT_53;
    np_vs = zT_53;
    np_vs = zT_53;
    zT_55 = "v";
    zT_57 = 1;
    zT_56.ptr = zT_55;
    zT_56.len = zT_57;
    npv = zT_56;
    npv = zT_56;
    npv = zT_56;
    zT_58 = npv;
    zF_48AC7B3A_markerWrite(zT_58);
    zT_60 = (unsigned char*)np_v;
    zT_62 = 19;
    zT_63 = zT_60 + np_vs;
    zT_64 = zT_62 - np_vs;
    zT_65.ptr = zT_63;
    zT_65.len = zT_64;
    zT_59 = zT_65;
    zF_48AC7B3A_markerWrite(zT_59);
    zT_67 = "\n";
    zT_69 = 1;
    zT_68.ptr = zT_67;
    zT_68.len = zT_69;
    npnl = zT_68;
    npnl = zT_68;
    npnl = zT_68;
    zT_70 = npnl;
    zF_48AC7B3A_markerWrite(zT_70);
    return;
}

/* typeRegistryGetOrCreatePtr */
unsigned int zF_8C0DFBC3_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, int is_const) {
    zT_79FAE712_u64 zT_4;
    zT_79FAE712_u64 zT_5;
    zT_79FAE712_u64 zT_6;
    zT_79FAE712_u64 zT_8;
    zT_79FAE712_u64 zT_9;
    zT_79FAE712_u64 zT_10;
    zT_79FAE712_u64 zT_11;
    zT_A4CE86B7_U64ToU32Map* zT_12;
    zT_79FAE712_u64 zT_13;
    zT_A4CE86B7_U64ToU32Map* zT_14;
    zT_BAEE192E_Opt_10 zT_15 = {0};
    unsigned char zT_16;
    zT_338B7C76_TypeRegistry* zT_18;
    zT_112BF819_PtrPayload zT_19;
    zT_112BF819_PtrPayload zT_20;
    zT_338B7C76_TypeRegistry* zT_22;
    zT_D155D06D_Type zT_23;
    zT_D155D06D_Type zT_24;
    zT_33EF6BFB_TypeKind zT_25;
    unsigned char zT_26;
    int zT_27;
    int zT_28;
    int zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_41 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_42;
    zT_79FAE712_u64 zT_43;
    unsigned int zT_44;
    zT_A4CE86B7_U64ToU32Map* zT_45;
    zT_79FAE712_u64 ic;
    zT_79FAE712_u64 key;
    unsigned int existing;
    unsigned int tid;
    if (is_const) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    zT_4 = zT_5;
    goto z_bb_3;
    z_bb_2:
    zT_6 = 0;
    zT_4 = zT_6;
    goto z_bb_3;
    z_bb_3:
    ic = zT_4;
    ic = zT_4;
    ic = zT_4;
    zT_8 = (zT_79FAE712_u64)base;
    zT_9 = 1;
    zT_10 = zT_8 << zT_9;
    zT_11 = zT_10 | ic;
    key = zT_11;
    key = zT_11;
    key = zT_11;
    zT_14 = &self->ptr_cache;
    zT_12 = zT_14;
    zT_13 = key;
    zT_15 = zF_A05A7BE1_u64ToU32MapGet(zT_12, zT_13);
    zT_16 = zT_15.has_value;
    if (zT_16) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    existing = zT_15.value;
    return existing;
    z_bb_5:
    zT_18 = self;
    zT_20.base = base;
    zT_19 = zT_20;
    zF_E5939FBD_ptrAppend(zT_18, zT_19);
    zT_22 = self;
    zT_25 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_24.kind = zT_25;
    zT_26 = 2;
    zT_24.state = zT_26;
    if (is_const) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_28 = 1;
    zT_27 = zT_28;
    goto z_bb_8;
    z_bb_7:
    zT_29 = 0;
    zT_27 = zT_29;
    goto z_bb_8;
    z_bb_8:
    zT_30 = (unsigned char)zT_27;
    zT_24.flags = zT_30;
    zT_31 = 0;
    zT_24._pad = zT_31;
    zT_32 = 4;
    zT_24.size = zT_32;
    zT_33 = 4;
    zT_24.alignment = zT_33;
    zT_34 = 0;
    zT_24.name_id = zT_34;
    zT_35 = 0;
    zT_24.c_name_id = zT_35;
    zT_36 = 0;
    zT_24.module_id = zT_36;
    zT_37 = self->ptr_len;
    zT_38 = 1;
    zT_39 = zT_37 - zT_38;
    zT_40 = (unsigned int)zT_39;
    zT_24.payload_idx = zT_40;
    zT_23 = zT_24;
    zT_41 = zF_D4993F02_typeRegistryAppend(zT_22, zT_23);
    tid = zT_41;
    tid = zT_41;
    tid = zT_41;
    zT_45 = &self->ptr_cache;
    zT_42 = zT_45;
    zT_43 = key;
    zT_44 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_42, zT_43, zT_44);
    return tid;
}

/* typeRegistryGetOrCreateManyPtr */
unsigned int zF_402D622A_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int base, int is_const) {
    zT_79FAE712_u64 zT_4;
    zT_79FAE712_u64 zT_5;
    zT_79FAE712_u64 zT_6;
    zT_79FAE712_u64 zT_8;
    zT_79FAE712_u64 zT_9;
    zT_79FAE712_u64 zT_10;
    zT_79FAE712_u64 zT_11;
    zT_A4CE86B7_U64ToU32Map* zT_12;
    zT_79FAE712_u64 zT_13;
    zT_A4CE86B7_U64ToU32Map* zT_14;
    zT_BAEE192E_Opt_10 zT_15 = {0};
    unsigned char zT_16;
    zT_338B7C76_TypeRegistry* zT_18;
    zT_112BF819_PtrPayload zT_19;
    zT_112BF819_PtrPayload zT_20;
    zT_338B7C76_TypeRegistry* zT_22;
    zT_D155D06D_Type zT_23;
    zT_D155D06D_Type zT_24;
    zT_33EF6BFB_TypeKind zT_25;
    unsigned char zT_26;
    int zT_27;
    int zT_28;
    int zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_41 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_42;
    zT_79FAE712_u64 zT_43;
    unsigned int zT_44;
    zT_A4CE86B7_U64ToU32Map* zT_45;
    zT_79FAE712_u64 ic;
    zT_79FAE712_u64 key;
    unsigned int existing;
    unsigned int tid;
    if (is_const) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    zT_4 = zT_5;
    goto z_bb_3;
    z_bb_2:
    zT_6 = 0;
    zT_4 = zT_6;
    goto z_bb_3;
    z_bb_3:
    ic = zT_4;
    ic = zT_4;
    ic = zT_4;
    zT_8 = (zT_79FAE712_u64)base;
    zT_9 = 1;
    zT_10 = zT_8 << zT_9;
    zT_11 = zT_10 | ic;
    key = zT_11;
    key = zT_11;
    key = zT_11;
    zT_14 = &self->many_ptr_cache;
    zT_12 = zT_14;
    zT_13 = key;
    zT_15 = zF_A05A7BE1_u64ToU32MapGet(zT_12, zT_13);
    zT_16 = zT_15.has_value;
    if (zT_16) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    existing = zT_15.value;
    return existing;
    z_bb_5:
    zT_18 = self;
    zT_20.base = base;
    zT_19 = zT_20;
    zF_E5939FBD_ptrAppend(zT_18, zT_19);
    zT_22 = self;
    zT_25 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_24.kind = zT_25;
    zT_26 = 2;
    zT_24.state = zT_26;
    if (is_const) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_28 = 1;
    zT_27 = zT_28;
    goto z_bb_8;
    z_bb_7:
    zT_29 = 0;
    zT_27 = zT_29;
    goto z_bb_8;
    z_bb_8:
    zT_30 = (unsigned char)zT_27;
    zT_24.flags = zT_30;
    zT_31 = 0;
    zT_24._pad = zT_31;
    zT_32 = 4;
    zT_24.size = zT_32;
    zT_33 = 4;
    zT_24.alignment = zT_33;
    zT_34 = 0;
    zT_24.name_id = zT_34;
    zT_35 = 0;
    zT_24.c_name_id = zT_35;
    zT_36 = 0;
    zT_24.module_id = zT_36;
    zT_37 = self->ptr_len;
    zT_38 = 1;
    zT_39 = zT_37 - zT_38;
    zT_40 = (unsigned int)zT_39;
    zT_24.payload_idx = zT_40;
    zT_23 = zT_24;
    zT_41 = zF_D4993F02_typeRegistryAppend(zT_22, zT_23);
    tid = zT_41;
    tid = zT_41;
    tid = zT_41;
    zT_45 = &self->many_ptr_cache;
    zT_42 = zT_45;
    zT_43 = key;
    zT_44 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_42, zT_43, zT_44);
    return tid;
}

/* typeRegistryGetOrCreateSlice */
unsigned int zF_8FC81A87_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int elem, int is_const) {
    zT_79FAE712_u64 zT_4;
    zT_79FAE712_u64 zT_5;
    zT_79FAE712_u64 zT_6;
    zT_79FAE712_u64 zT_8;
    zT_79FAE712_u64 zT_9;
    zT_79FAE712_u64 zT_10;
    zT_79FAE712_u64 zT_11;
    zT_A4CE86B7_U64ToU32Map* zT_12;
    zT_79FAE712_u64 zT_13;
    zT_A4CE86B7_U64ToU32Map* zT_14;
    zT_BAEE192E_Opt_10 zT_15 = {0};
    unsigned char zT_16;
    char* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    zT_4028D896_Arr_unsigned_char_2 zT_24;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned char* zT_28;
    unsigned int zT_29;
    int zT_30;
    unsigned char* zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34 = 0;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned char* zT_40;
    unsigned int zT_42;
    unsigned char* zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_4028D896_Arr_unsigned_char_2 zT_52;
    unsigned int zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned char* zT_56;
    unsigned int zT_57;
    int zT_58;
    unsigned char* zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned int zT_62 = 0;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned char* zT_68;
    unsigned int zT_70;
    unsigned char* zT_71;
    unsigned int zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    zT_4028D896_Arr_unsigned_char_2 zT_80;
    unsigned int zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    unsigned char* zT_85;
    unsigned int zT_86;
    int zT_87;
    unsigned char* zT_88;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91 = 0;
    unsigned int zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned char* zT_97;
    unsigned int zT_99;
    unsigned char* zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    zT_338B7C76_TypeRegistry* zT_103;
    zT_0BB2A741_SlicePayload zT_104;
    zT_0BB2A741_SlicePayload zT_105;
    zT_338B7C76_TypeRegistry* zT_107;
    zT_D155D06D_Type zT_108;
    zT_D155D06D_Type zT_109;
    zT_33EF6BFB_TypeKind zT_110;
    unsigned char zT_111;
    int zT_112;
    int zT_113;
    int zT_114;
    unsigned char zT_115;
    unsigned char zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned int zT_126 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_127;
    zT_79FAE712_u64 zT_128;
    unsigned int zT_129;
    zT_A4CE86B7_U64ToU32Map* zT_130;
    char* zT_132;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_133;
    unsigned int zT_134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_135;
    zT_4028D896_Arr_unsigned_char_2 zT_137;
    unsigned int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    unsigned char* zT_141;
    unsigned int zT_142;
    int zT_143;
    unsigned char* zT_144;
    unsigned int zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    unsigned int zT_147 = 0;
    unsigned int zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned char* zT_153;
    unsigned int zT_155;
    unsigned char* zT_156;
    unsigned int zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    char* zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    zT_4028D896_Arr_unsigned_char_2 zT_165;
    unsigned int zT_167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_168;
    unsigned char* zT_169;
    unsigned int zT_170;
    int zT_171;
    unsigned char* zT_172;
    unsigned int zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_174;
    unsigned int zT_175 = 0;
    unsigned int zT_177;
    unsigned int zT_178;
    unsigned int zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned char* zT_181;
    unsigned int zT_183;
    unsigned char* zT_184;
    unsigned int zT_185;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    char* zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_189;
    unsigned int zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    zT_4028D896_Arr_unsigned_char_2 zT_193;
    unsigned int zT_195;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_196;
    unsigned int zT_197;
    unsigned char* zT_198;
    unsigned int zT_199;
    int zT_200;
    unsigned char* zT_201;
    unsigned int zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    unsigned int zT_204 = 0;
    unsigned int zT_206;
    unsigned int zT_207;
    unsigned int zT_208;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_209;
    unsigned char* zT_210;
    unsigned int zT_212;
    unsigned char* zT_213;
    unsigned int zT_214;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    zT_79FAE712_u64 ic;
    zT_79FAE712_u64 key;
    unsigned int existing;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2h_m;
    zT_4028D896_Arr_unsigned_char_2 u2h_eb;
    unsigned int u2h_el;
    unsigned int u2h_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2h_rm;
    zT_4028D896_Arr_unsigned_char_2 u2h_rb;
    unsigned int u2h_rl;
    unsigned int u2h_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2h_cm;
    zT_4028D896_Arr_unsigned_char_2 u2h_cb;
    unsigned int u2h_cl;
    unsigned int u2h_cs;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2n_m;
    zT_4028D896_Arr_unsigned_char_2 u2n_eb;
    unsigned int u2n_el;
    unsigned int u2n_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2n_rm;
    zT_4028D896_Arr_unsigned_char_2 u2n_rb;
    unsigned int u2n_rl;
    unsigned int u2n_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u u2n_cm;
    zT_4028D896_Arr_unsigned_char_2 u2n_cb;
    unsigned int u2n_cl;
    unsigned int u2n_cs;
    if (is_const) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    zT_4 = zT_5;
    goto z_bb_3;
    z_bb_2:
    zT_6 = 0;
    zT_4 = zT_6;
    goto z_bb_3;
    z_bb_3:
    ic = zT_4;
    ic = zT_4;
    ic = zT_4;
    zT_8 = (zT_79FAE712_u64)elem;
    zT_9 = 1;
    zT_10 = zT_8 << zT_9;
    zT_11 = zT_10 | ic;
    key = zT_11;
    key = zT_11;
    key = zT_11;
    zT_14 = &self->slice_cache;
    zT_12 = zT_14;
    zT_13 = key;
    zT_15 = zF_A05A7BE1_u64ToU32MapGet(zT_12, zT_13);
    zT_16 = zT_15.has_value;
    if (zT_16) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    existing = zT_15.value;
    zT_19 = "U2H:e";
    zT_21 = 5;
    zT_20.ptr = zT_19;
    zT_20.len = zT_21;
    u2h_m = zT_20;
    u2h_m = zT_20;
    u2h_m = zT_20;
    zT_22 = u2h_m;
    zF_48AC7B3A_markerWrite(zT_22);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_24[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2h_eb[_i] = zT_24[_i];
        _i++;
    }
}
    zT_26 = elem;
    zT_28 = (unsigned char*)u2h_eb;
    zT_29 = 20;
    zT_30 = 0;
    zT_31 = zT_28 + zT_30;
    zT_32 = zT_29 - zT_30;
    zT_33.ptr = zT_31;
    zT_33.len = zT_32;
    zT_27 = zT_33;
    zT_34 = zF_A7504564_itoa(zT_26, zT_27);
    u2h_el = zT_34;
    u2h_el = zT_34;
    u2h_el = zT_34;
    zT_36 = 19;
    zT_37 = (unsigned int)u2h_el;
    zT_38 = zT_36 - zT_37;
    u2h_es = zT_38;
    u2h_es = zT_38;
    u2h_es = zT_38;
    zT_40 = (unsigned char*)u2h_eb;
    zT_42 = 19;
    zT_43 = zT_40 + u2h_es;
    zT_44 = zT_42 - u2h_es;
    zT_45.ptr = zT_43;
    zT_45.len = zT_44;
    zT_39 = zT_45;
    zF_48AC7B3A_markerWrite(zT_39);
    zT_47 = "r";
    zT_49 = 1;
    zT_48.ptr = zT_47;
    zT_48.len = zT_49;
    u2h_rm = zT_48;
    u2h_rm = zT_48;
    u2h_rm = zT_48;
    zT_50 = u2h_rm;
    zF_48AC7B3A_markerWrite(zT_50);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_52[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2h_rb[_i] = zT_52[_i];
        _i++;
    }
}
    zT_54 = existing;
    zT_56 = (unsigned char*)u2h_rb;
    zT_57 = 20;
    zT_58 = 0;
    zT_59 = zT_56 + zT_58;
    zT_60 = zT_57 - zT_58;
    zT_61.ptr = zT_59;
    zT_61.len = zT_60;
    zT_55 = zT_61;
    zT_62 = zF_A7504564_itoa(zT_54, zT_55);
    u2h_rl = zT_62;
    u2h_rl = zT_62;
    u2h_rl = zT_62;
    zT_64 = 19;
    zT_65 = (unsigned int)u2h_rl;
    zT_66 = zT_64 - zT_65;
    u2h_rs = zT_66;
    u2h_rs = zT_66;
    u2h_rs = zT_66;
    zT_68 = (unsigned char*)u2h_rb;
    zT_70 = 19;
    zT_71 = zT_68 + u2h_rs;
    zT_72 = zT_70 - u2h_rs;
    zT_73.ptr = zT_71;
    zT_73.len = zT_72;
    zT_67 = zT_73;
    zF_48AC7B3A_markerWrite(zT_67);
    zT_75 = "c";
    zT_77 = 1;
    zT_76.ptr = zT_75;
    zT_76.len = zT_77;
    u2h_cm = zT_76;
    u2h_cm = zT_76;
    u2h_cm = zT_76;
    zT_78 = u2h_cm;
    zF_48AC7B3A_markerWrite(zT_78);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_80[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2h_cb[_i] = zT_80[_i];
        _i++;
    }
}
    zT_84 = __bootstrap_u32_from_u64(ic);
    zT_82 = zT_84;
    zT_85 = (unsigned char*)u2h_cb;
    zT_86 = 20;
    zT_87 = 0;
    zT_88 = zT_85 + zT_87;
    zT_89 = zT_86 - zT_87;
    zT_90.ptr = zT_88;
    zT_90.len = zT_89;
    zT_83 = zT_90;
    zT_91 = zF_A7504564_itoa(zT_82, zT_83);
    u2h_cl = zT_91;
    u2h_cl = zT_91;
    u2h_cl = zT_91;
    zT_93 = 19;
    zT_94 = (unsigned int)u2h_cl;
    zT_95 = zT_93 - zT_94;
    u2h_cs = zT_95;
    u2h_cs = zT_95;
    u2h_cs = zT_95;
    zT_97 = (unsigned char*)u2h_cb;
    zT_99 = 19;
    zT_100 = zT_97 + u2h_cs;
    zT_101 = zT_99 - u2h_cs;
    zT_102.ptr = zT_100;
    zT_102.len = zT_101;
    zT_96 = zT_102;
    zF_48AC7B3A_markerWrite(zT_96);
    return existing;
    z_bb_5:
    zT_103 = self;
    zT_105.elem = elem;
    zT_104 = zT_105;
    zF_8BFD6695_sliceAppend(zT_103, zT_104);
    zT_107 = self;
    zT_110 = zT_33EF6BFB_TypeKind_slice_type;
    zT_109.kind = zT_110;
    zT_111 = 2;
    zT_109.state = zT_111;
    if (is_const) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_113 = 1;
    zT_112 = zT_113;
    goto z_bb_8;
    z_bb_7:
    zT_114 = 0;
    zT_112 = zT_114;
    goto z_bb_8;
    z_bb_8:
    zT_115 = (unsigned char)zT_112;
    zT_109.flags = zT_115;
    zT_116 = 0;
    zT_109._pad = zT_116;
    zT_117 = 8;
    zT_109.size = zT_117;
    zT_118 = 4;
    zT_109.alignment = zT_118;
    zT_119 = 0;
    zT_109.name_id = zT_119;
    zT_120 = 0;
    zT_109.c_name_id = zT_120;
    zT_121 = 0;
    zT_109.module_id = zT_121;
    zT_122 = self->slice_len;
    zT_123 = 1;
    zT_124 = zT_122 - zT_123;
    zT_125 = (unsigned int)zT_124;
    zT_109.payload_idx = zT_125;
    zT_108 = zT_109;
    zT_126 = zF_D4993F02_typeRegistryAppend(zT_107, zT_108);
    tid = zT_126;
    tid = zT_126;
    tid = zT_126;
    zT_130 = &self->slice_cache;
    zT_127 = zT_130;
    zT_128 = key;
    zT_129 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_127, zT_128, zT_129);
    zT_132 = "U2N:e";
    zT_134 = 5;
    zT_133.ptr = zT_132;
    zT_133.len = zT_134;
    u2n_m = zT_133;
    u2n_m = zT_133;
    u2n_m = zT_133;
    zT_135 = u2n_m;
    zF_48AC7B3A_markerWrite(zT_135);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_137[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2n_eb[_i] = zT_137[_i];
        _i++;
    }
}
    zT_139 = elem;
    zT_141 = (unsigned char*)u2n_eb;
    zT_142 = 20;
    zT_143 = 0;
    zT_144 = zT_141 + zT_143;
    zT_145 = zT_142 - zT_143;
    zT_146.ptr = zT_144;
    zT_146.len = zT_145;
    zT_140 = zT_146;
    zT_147 = zF_A7504564_itoa(zT_139, zT_140);
    u2n_el = zT_147;
    u2n_el = zT_147;
    u2n_el = zT_147;
    zT_149 = 19;
    zT_150 = (unsigned int)u2n_el;
    zT_151 = zT_149 - zT_150;
    u2n_es = zT_151;
    u2n_es = zT_151;
    u2n_es = zT_151;
    zT_153 = (unsigned char*)u2n_eb;
    zT_155 = 19;
    zT_156 = zT_153 + u2n_es;
    zT_157 = zT_155 - u2n_es;
    zT_158.ptr = zT_156;
    zT_158.len = zT_157;
    zT_152 = zT_158;
    zF_48AC7B3A_markerWrite(zT_152);
    zT_160 = "r";
    zT_162 = 1;
    zT_161.ptr = zT_160;
    zT_161.len = zT_162;
    u2n_rm = zT_161;
    u2n_rm = zT_161;
    u2n_rm = zT_161;
    zT_163 = u2n_rm;
    zF_48AC7B3A_markerWrite(zT_163);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_165[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2n_rb[_i] = zT_165[_i];
        _i++;
    }
}
    zT_167 = tid;
    zT_169 = (unsigned char*)u2n_rb;
    zT_170 = 20;
    zT_171 = 0;
    zT_172 = zT_169 + zT_171;
    zT_173 = zT_170 - zT_171;
    zT_174.ptr = zT_172;
    zT_174.len = zT_173;
    zT_168 = zT_174;
    zT_175 = zF_A7504564_itoa(zT_167, zT_168);
    u2n_rl = zT_175;
    u2n_rl = zT_175;
    u2n_rl = zT_175;
    zT_177 = 19;
    zT_178 = (unsigned int)u2n_rl;
    zT_179 = zT_177 - zT_178;
    u2n_rs = zT_179;
    u2n_rs = zT_179;
    u2n_rs = zT_179;
    zT_181 = (unsigned char*)u2n_rb;
    zT_183 = 19;
    zT_184 = zT_181 + u2n_rs;
    zT_185 = zT_183 - u2n_rs;
    zT_186.ptr = zT_184;
    zT_186.len = zT_185;
    zT_180 = zT_186;
    zF_48AC7B3A_markerWrite(zT_180);
    zT_188 = "c";
    zT_190 = 1;
    zT_189.ptr = zT_188;
    zT_189.len = zT_190;
    u2n_cm = zT_189;
    u2n_cm = zT_189;
    u2n_cm = zT_189;
    zT_191 = u2n_cm;
    zF_48AC7B3A_markerWrite(zT_191);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_193[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        u2n_cb[_i] = zT_193[_i];
        _i++;
    }
}
    zT_197 = __bootstrap_u32_from_u64(ic);
    zT_195 = zT_197;
    zT_198 = (unsigned char*)u2n_cb;
    zT_199 = 20;
    zT_200 = 0;
    zT_201 = zT_198 + zT_200;
    zT_202 = zT_199 - zT_200;
    zT_203.ptr = zT_201;
    zT_203.len = zT_202;
    zT_196 = zT_203;
    zT_204 = zF_A7504564_itoa(zT_195, zT_196);
    u2n_cl = zT_204;
    u2n_cl = zT_204;
    u2n_cl = zT_204;
    zT_206 = 19;
    zT_207 = (unsigned int)u2n_cl;
    zT_208 = zT_206 - zT_207;
    u2n_cs = zT_208;
    u2n_cs = zT_208;
    u2n_cs = zT_208;
    zT_210 = (unsigned char*)u2n_cb;
    zT_212 = 19;
    zT_213 = zT_210 + u2n_cs;
    zT_214 = zT_212 - u2n_cs;
    zT_215.ptr = zT_213;
    zT_215.len = zT_214;
    zT_209 = zT_215;
    zF_48AC7B3A_markerWrite(zT_209);
    return tid;
}

/* typeRegistryGetOrCreateOptional */
unsigned int zF_74A7234F_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int payload) {
    zT_21D3708C_U32ToU32Map* zT_2;
    unsigned int zT_3;
    zT_21D3708C_U32ToU32Map* zT_4;
    zT_BAEE192E_Opt_10 zT_5 = {0};
    unsigned char zT_6;
    zT_D155D06D_Type* zT_9;
    zT_D155D06D_Type zT_10;
    int zT_12;
    unsigned int zT_13;
    int zT_15;
    unsigned int zT_16;
    int zT_18;
    unsigned char zT_19;
    unsigned char zT_20;
    unsigned char zT_21;
    int zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34 = 0;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39 = 0;
    unsigned char zT_40;
    zT_338B7C76_TypeRegistry* zT_41;
    zT_0B10E8E9_OptionalPayload zT_42;
    zT_0B10E8E9_OptionalPayload zT_43;
    zT_338B7C76_TypeRegistry* zT_45;
    zT_D155D06D_Type zT_46;
    zT_D155D06D_Type zT_47;
    zT_33EF6BFB_TypeKind zT_48;
    unsigned char zT_49;
    unsigned char zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned int zT_58 = 0;
    unsigned char zT_59;
    int zT_60;
    zT_21D3708C_U32ToU32Map* zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    zT_21D3708C_U32ToU32Map* zT_64;
    unsigned int existing;
    zT_D155D06D_Type pay_type;
    unsigned int opt_size;
    unsigned int opt_align;
    unsigned char opt_state;
    unsigned int pay_align;
    unsigned int tid;
    zT_4 = &self->optional_cache;
    zT_2 = zT_4;
    zT_3 = payload;
    zT_5 = zF_F3EE5998_u32ToU32MapGet(zT_2, zT_3);
    zT_6 = zT_5.has_value;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_5.value;
    return existing;
    z_bb_2:
    zT_9 = self->types_items;
    zT_10 = zT_9[payload];
    pay_type = zT_10;
    pay_type = zT_10;
    pay_type = zT_10;
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    opt_size = zT_13;
    opt_size = zT_13;
    opt_size = zT_13;
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    opt_align = zT_16;
    opt_align = zT_16;
    opt_align = zT_16;
    zT_18 = 0;
    zT_19 = (unsigned char)zT_18;
    opt_state = zT_19;
    opt_state = zT_19;
    opt_state = zT_19;
    zT_20 = pay_type.state;
    zT_21 = 2;
    zT_22 = zT_20 == zT_21;
    if (zT_22) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_24 = pay_type.alignment;
    zT_25 = 4;
    zT_26 = zT_24 > zT_25;
    if (zT_26) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_41 = self;
    zT_43.payload = payload;
    zT_42 = zT_43;
    zF_4569340E_optAppend(zT_41, zT_42);
    zT_45 = self;
    zT_48 = zT_33EF6BFB_TypeKind_optional_type;
    zT_47.kind = zT_48;
    zT_47.state = opt_state;
    zT_49 = 0;
    zT_47.flags = zT_49;
    zT_50 = 0;
    zT_47._pad = zT_50;
    zT_47.size = opt_size;
    zT_47.alignment = opt_align;
    zT_51 = 0;
    zT_47.name_id = zT_51;
    zT_52 = 0;
    zT_47.c_name_id = zT_52;
    zT_53 = 0;
    zT_47.module_id = zT_53;
    zT_54 = self->opt_len;
    zT_55 = 1;
    zT_56 = zT_54 - zT_55;
    zT_57 = (unsigned int)zT_56;
    zT_47.payload_idx = zT_57;
    zT_46 = zT_47;
    zT_58 = zF_D4993F02_typeRegistryAppend(zT_45, zT_46);
    tid = zT_58;
    tid = zT_58;
    tid = zT_58;
    zT_59 = 2;
    zT_60 = opt_state == zT_59;
    if (zT_60) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    zT_28 = pay_type.alignment;
    zT_27 = zT_28;
    goto z_bb_7;
    z_bb_6:
    zT_29 = 4;
    zT_27 = zT_29;
    goto z_bb_7;
    z_bb_7:
    pay_align = zT_27;
    pay_align = zT_27;
    pay_align = zT_27;
    zT_32 = pay_type.size;
    zT_30 = zT_32;
    zT_33 = 4;
    zT_31 = zT_33;
    zT_34 = zF_D2BAC673_alignUp(zT_30, zT_31);
    zT_35 = 4;
    zT_36 = zT_34 + zT_35;
    opt_size = zT_36;
    opt_size = zT_36;
    zT_37 = opt_size;
    zT_38 = pay_align;
    zT_39 = zF_D2BAC673_alignUp(zT_37, zT_38);
    opt_size = zT_39;
    opt_size = zT_39;
    opt_align = pay_align;
    opt_align = pay_align;
    zT_40 = 2;
    opt_state = zT_40;
    opt_state = zT_40;
    goto z_bb_4;
    z_bb_8:
    zT_64 = &self->optional_cache;
    zT_61 = zT_64;
    zT_62 = payload;
    zT_63 = tid;
    zF_26476265_u32ToU32MapPut(zT_61, zT_62, zT_63);
    goto z_bb_9;
    z_bb_9:
    return tid;
}

/* typeRegistryGetOrCreateErrorUnion */
unsigned int zF_16D1A6EE_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int payload, unsigned int error_set) {
    zT_79FAE712_u64 zT_4;
    zT_79FAE712_u64 zT_5;
    zT_79FAE712_u64 zT_6;
    zT_79FAE712_u64 zT_7;
    zT_79FAE712_u64 zT_8;
    zT_A4CE86B7_U64ToU32Map* zT_9;
    zT_79FAE712_u64 zT_10;
    zT_A4CE86B7_U64ToU32Map* zT_11;
    zT_BAEE192E_Opt_10 zT_12 = {0};
    unsigned char zT_13;
    zT_D155D06D_Type* zT_16;
    zT_D155D06D_Type zT_17;
    int zT_19;
    unsigned int zT_20;
    int zT_22;
    unsigned int zT_23;
    int zT_25;
    unsigned char zT_26;
    unsigned char zT_27;
    unsigned char zT_28;
    int zT_29;
    unsigned int zT_31;
    unsigned int zT_32;
    int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_38;
    unsigned int zT_39;
    int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned int zT_47 = 0;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51 = 0;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56 = 0;
    unsigned char zT_57;
    zT_338B7C76_TypeRegistry* zT_58;
    zT_42C2D6BF_EUPayload zT_59;
    zT_42C2D6BF_EUPayload zT_60;
    zT_338B7C76_TypeRegistry* zT_62;
    zT_D155D06D_Type zT_63;
    zT_D155D06D_Type zT_64;
    zT_33EF6BFB_TypeKind zT_65;
    unsigned char zT_66;
    unsigned char zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    unsigned int zT_75 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_76;
    zT_79FAE712_u64 zT_77;
    unsigned int zT_78;
    zT_A4CE86B7_U64ToU32Map* zT_79;
    zT_79FAE712_u64 eu_key;
    unsigned int existing;
    zT_D155D06D_Type pay_type;
    unsigned int eu_size;
    unsigned int eu_align;
    unsigned char eu_state;
    unsigned int union_size;
    unsigned int tid;
    unsigned int union_align;
    unsigned int total;
    zT_4 = (zT_79FAE712_u64)payload;
    zT_5 = 32;
    zT_6 = zT_4 << zT_5;
    zT_7 = (zT_79FAE712_u64)error_set;
    zT_8 = zT_6 | zT_7;
    eu_key = zT_8;
    eu_key = zT_8;
    eu_key = zT_8;
    zT_11 = &self->eu_cache;
    zT_9 = zT_11;
    zT_10 = eu_key;
    zT_12 = zF_A05A7BE1_u64ToU32MapGet(zT_9, zT_10);
    zT_13 = zT_12.has_value;
    if (zT_13) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_12.value;
    return existing;
    z_bb_2:
    zT_16 = self->types_items;
    zT_17 = zT_16[payload];
    pay_type = zT_17;
    pay_type = zT_17;
    pay_type = zT_17;
    zT_19 = 0;
    zT_20 = (unsigned int)zT_19;
    eu_size = zT_20;
    eu_size = zT_20;
    eu_size = zT_20;
    zT_22 = 0;
    zT_23 = (unsigned int)zT_22;
    eu_align = zT_23;
    eu_align = zT_23;
    eu_align = zT_23;
    zT_25 = 0;
    zT_26 = (unsigned char)zT_25;
    eu_state = zT_26;
    eu_state = zT_26;
    eu_state = zT_26;
    zT_27 = pay_type.state;
    zT_28 = 2;
    zT_29 = zT_27 == zT_28;
    if (zT_29) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_31 = pay_type.size;
    zT_32 = 4;
    zT_33 = zT_31 > zT_32;
    if (zT_33) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_58 = self;
    zT_60.payload = payload;
    zT_60.error_set = error_set;
    zT_59 = zT_60;
    zF_ABBA52E7_euAppend(zT_58, zT_59);
    zT_62 = self;
    zT_65 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_64.kind = zT_65;
    zT_64.state = eu_state;
    zT_66 = 0;
    zT_64.flags = zT_66;
    zT_67 = 0;
    zT_64._pad = zT_67;
    zT_64.size = eu_size;
    zT_64.alignment = eu_align;
    zT_68 = 0;
    zT_64.name_id = zT_68;
    zT_69 = 0;
    zT_64.c_name_id = zT_69;
    zT_70 = 0;
    zT_64.module_id = zT_70;
    zT_71 = self->eu_len;
    zT_72 = 1;
    zT_73 = zT_71 - zT_72;
    zT_74 = (unsigned int)zT_73;
    zT_64.payload_idx = zT_74;
    zT_63 = zT_64;
    zT_75 = zF_D4993F02_typeRegistryAppend(zT_62, zT_63);
    tid = zT_75;
    tid = zT_75;
    tid = zT_75;
    zT_79 = &self->eu_cache;
    zT_76 = zT_79;
    zT_77 = eu_key;
    zT_78 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_76, zT_77, zT_78);
    return tid;
    z_bb_5:
    zT_35 = pay_type.size;
    zT_34 = zT_35;
    goto z_bb_7;
    z_bb_6:
    zT_36 = 4;
    zT_34 = zT_36;
    goto z_bb_7;
    z_bb_7:
    union_size = zT_34;
    union_size = zT_34;
    union_size = zT_34;
    zT_38 = pay_type.alignment;
    zT_39 = 4;
    zT_40 = zT_38 > zT_39;
    if (zT_40) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_42 = pay_type.alignment;
    zT_41 = zT_42;
    goto z_bb_10;
    z_bb_9:
    zT_43 = 4;
    zT_41 = zT_43;
    goto z_bb_10;
    z_bb_10:
    union_align = zT_41;
    union_align = zT_41;
    union_align = zT_41;
    zT_45 = union_size;
    zT_46 = union_align;
    zT_47 = zF_D2BAC673_alignUp(zT_45, zT_46);
    total = zT_47;
    total = zT_47;
    total = zT_47;
    zT_48 = total;
    zT_50 = 4;
    zT_49 = zT_50;
    zT_51 = zF_D2BAC673_alignUp(zT_48, zT_49);
    zT_52 = 4;
    zT_53 = zT_51 + zT_52;
    total = zT_53;
    total = zT_53;
    zT_54 = total;
    zT_55 = union_align;
    zT_56 = zF_D2BAC673_alignUp(zT_54, zT_55);
    eu_size = zT_56;
    eu_size = zT_56;
    eu_align = union_align;
    eu_align = union_align;
    zT_57 = 2;
    eu_state = zT_57;
    eu_state = zT_57;
    goto z_bb_4;
}

/* typeRegistryGetOrCreateArray */
unsigned int zF_BA693C74_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int elem, unsigned int length) {
    char* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_4028D896_Arr_unsigned_char_2 zT_9;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned char* zT_13;
    unsigned int zT_14;
    int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19 = 0;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned char* zT_25;
    unsigned int zT_27;
    unsigned char* zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_4028D896_Arr_unsigned_char_2 zT_37;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned char* zT_41;
    unsigned int zT_42;
    int zT_43;
    unsigned char* zT_44;
    unsigned int zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47 = 0;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned char* zT_53;
    unsigned int zT_55;
    unsigned char* zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_79FAE712_u64 zT_60;
    zT_79FAE712_u64 zT_61;
    zT_79FAE712_u64 zT_62;
    zT_79FAE712_u64 zT_63;
    zT_79FAE712_u64 zT_64;
    zT_A4CE86B7_U64ToU32Map* zT_65;
    zT_79FAE712_u64 zT_66;
    zT_A4CE86B7_U64ToU32Map* zT_67;
    zT_BAEE192E_Opt_10 zT_68 = {0};
    unsigned char zT_69;
    char* zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    unsigned int zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    zT_4028D896_Arr_unsigned_char_2 zT_77;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned char* zT_81;
    unsigned int zT_82;
    int zT_83;
    unsigned char* zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87 = 0;
    unsigned int zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned char* zT_93;
    unsigned int zT_95;
    unsigned char* zT_96;
    unsigned int zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    zT_338B7C76_TypeRegistry* zT_99;
    zT_E834303C_ArrayPayload zT_100;
    zT_E834303C_ArrayPayload zT_101;
    zT_D155D06D_Type* zT_103;
    zT_D155D06D_Type zT_104;
    int zT_106;
    unsigned int zT_107;
    int zT_109;
    unsigned int zT_110;
    int zT_112;
    unsigned char zT_113;
    unsigned char zT_114;
    unsigned char zT_115;
    int zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned char zT_120;
    zT_338B7C76_TypeRegistry* zT_122;
    zT_D155D06D_Type zT_123;
    zT_D155D06D_Type zT_124;
    zT_33EF6BFB_TypeKind zT_125;
    unsigned char zT_126;
    unsigned char zT_127;
    unsigned int zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    unsigned int zT_131;
    unsigned int zT_132;
    unsigned int zT_133;
    unsigned int zT_134;
    unsigned int zT_135 = 0;
    char* zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    unsigned int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    zT_4028D896_Arr_unsigned_char_2 zT_142;
    unsigned int zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned char* zT_146;
    unsigned int zT_147;
    int zT_148;
    unsigned char* zT_149;
    unsigned int zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned int zT_152 = 0;
    unsigned int zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    unsigned char* zT_158;
    unsigned int zT_160;
    unsigned char* zT_161;
    unsigned int zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned char zT_164;
    unsigned char zT_165;
    int zT_166;
    zT_A4CE86B7_U64ToU32Map* zT_167;
    zT_79FAE712_u64 zT_168;
    unsigned int zT_169;
    zT_A4CE86B7_U64ToU32Map* zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u o0m;
    zT_4028D896_Arr_unsigned_char_2 o0b;
    unsigned int o0l;
    unsigned int o0s;
    zT_8F083A69_Slice_zT_0B42B2F8_u o0m2;
    zT_4028D896_Arr_unsigned_char_2 o0b2;
    unsigned int o0l2;
    unsigned int o0s2;
    zT_79FAE712_u64 key;
    unsigned int existing;
    zT_8F083A69_Slice_zT_0B42B2F8_u o1m;
    zT_4028D896_Arr_unsigned_char_2 o1b;
    unsigned int o1l;
    unsigned int o1s;
    zT_D155D06D_Type elem_ty;
    unsigned int arr_size;
    unsigned int arr_align;
    unsigned char arr_state;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u o2m;
    zT_4028D896_Arr_unsigned_char_2 o2b;
    unsigned int o2l;
    unsigned int o2s;
    zT_4 = "O0e";
    zT_6 = 3;
    zT_5.ptr = zT_4;
    zT_5.len = zT_6;
    o0m = zT_5;
    o0m = zT_5;
    o0m = zT_5;
    zT_7 = o0m;
    zF_48AC7B3A_markerWrite(zT_7);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_9[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o0b[_i] = zT_9[_i];
        _i++;
    }
}
    zT_11 = elem;
    zT_13 = (unsigned char*)o0b;
    zT_14 = 20;
    zT_15 = 0;
    zT_16 = zT_13 + zT_15;
    zT_17 = zT_14 - zT_15;
    zT_18.ptr = zT_16;
    zT_18.len = zT_17;
    zT_12 = zT_18;
    zT_19 = zF_A7504564_itoa(zT_11, zT_12);
    o0l = zT_19;
    o0l = zT_19;
    o0l = zT_19;
    zT_21 = 19;
    zT_22 = (unsigned int)o0l;
    zT_23 = zT_21 - zT_22;
    o0s = zT_23;
    o0s = zT_23;
    o0s = zT_23;
    zT_25 = (unsigned char*)o0b;
    zT_27 = 19;
    zT_28 = zT_25 + o0s;
    zT_29 = zT_27 - o0s;
    zT_30.ptr = zT_28;
    zT_30.len = zT_29;
    zT_24 = zT_30;
    zF_48AC7B3A_markerWrite(zT_24);
    zT_32 = "L";
    zT_34 = 1;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    o0m2 = zT_33;
    o0m2 = zT_33;
    o0m2 = zT_33;
    zT_35 = o0m2;
    zF_48AC7B3A_markerWrite(zT_35);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_37[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o0b2[_i] = zT_37[_i];
        _i++;
    }
}
    zT_39 = length;
    zT_41 = (unsigned char*)o0b2;
    zT_42 = 20;
    zT_43 = 0;
    zT_44 = zT_41 + zT_43;
    zT_45 = zT_42 - zT_43;
    zT_46.ptr = zT_44;
    zT_46.len = zT_45;
    zT_40 = zT_46;
    zT_47 = zF_A7504564_itoa(zT_39, zT_40);
    o0l2 = zT_47;
    o0l2 = zT_47;
    o0l2 = zT_47;
    zT_49 = 19;
    zT_50 = (unsigned int)o0l2;
    zT_51 = zT_49 - zT_50;
    o0s2 = zT_51;
    o0s2 = zT_51;
    o0s2 = zT_51;
    zT_53 = (unsigned char*)o0b2;
    zT_55 = 19;
    zT_56 = zT_53 + o0s2;
    zT_57 = zT_55 - o0s2;
    zT_58.ptr = zT_56;
    zT_58.len = zT_57;
    zT_52 = zT_58;
    zF_48AC7B3A_markerWrite(zT_52);
    zT_60 = (zT_79FAE712_u64)elem;
    zT_61 = 32;
    zT_62 = zT_60 << zT_61;
    zT_63 = (zT_79FAE712_u64)length;
    zT_64 = zT_62 | zT_63;
    key = zT_64;
    key = zT_64;
    key = zT_64;
    zT_67 = &self->array_cache;
    zT_65 = zT_67;
    zT_66 = key;
    zT_68 = zF_A05A7BE1_u64ToU32MapGet(zT_65, zT_66);
    zT_69 = zT_68.has_value;
    if (zT_69) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_68.value;
    zT_72 = "O1H";
    zT_74 = 3;
    zT_73.ptr = zT_72;
    zT_73.len = zT_74;
    o1m = zT_73;
    o1m = zT_73;
    o1m = zT_73;
    zT_75 = o1m;
    zF_48AC7B3A_markerWrite(zT_75);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_77[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o1b[_i] = zT_77[_i];
        _i++;
    }
}
    zT_79 = existing;
    zT_81 = (unsigned char*)o1b;
    zT_82 = 20;
    zT_83 = 0;
    zT_84 = zT_81 + zT_83;
    zT_85 = zT_82 - zT_83;
    zT_86.ptr = zT_84;
    zT_86.len = zT_85;
    zT_80 = zT_86;
    zT_87 = zF_A7504564_itoa(zT_79, zT_80);
    o1l = zT_87;
    o1l = zT_87;
    o1l = zT_87;
    zT_89 = 19;
    zT_90 = (unsigned int)o1l;
    zT_91 = zT_89 - zT_90;
    o1s = zT_91;
    o1s = zT_91;
    o1s = zT_91;
    zT_93 = (unsigned char*)o1b;
    zT_95 = 19;
    zT_96 = zT_93 + o1s;
    zT_97 = zT_95 - o1s;
    zT_98.ptr = zT_96;
    zT_98.len = zT_97;
    zT_92 = zT_98;
    zF_48AC7B3A_markerWrite(zT_92);
    return existing;
    z_bb_2:
    zT_99 = self;
    zT_101.elem = elem;
    zT_101.length = length;
    zT_100 = zT_101;
    zF_4D5CD212_arrayAppend(zT_99, zT_100);
    zT_103 = self->types_items;
    zT_104 = zT_103[elem];
    elem_ty = zT_104;
    elem_ty = zT_104;
    elem_ty = zT_104;
    zT_106 = 0;
    zT_107 = (unsigned int)zT_106;
    arr_size = zT_107;
    arr_size = zT_107;
    arr_size = zT_107;
    zT_109 = 0;
    zT_110 = (unsigned int)zT_109;
    arr_align = zT_110;
    arr_align = zT_110;
    arr_align = zT_110;
    zT_112 = 0;
    zT_113 = (unsigned char)zT_112;
    arr_state = zT_113;
    arr_state = zT_113;
    arr_state = zT_113;
    zT_114 = elem_ty.state;
    zT_115 = 2;
    zT_116 = zT_114 == zT_115;
    if (zT_116) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_117 = elem_ty.size;
    zT_118 = zT_117 * length;
    arr_size = zT_118;
    arr_size = zT_118;
    zT_119 = elem_ty.alignment;
    arr_align = zT_119;
    arr_align = zT_119;
    zT_120 = 2;
    arr_state = zT_120;
    arr_state = zT_120;
    goto z_bb_4;
    z_bb_4:
    zT_122 = self;
    zT_125 = zT_33EF6BFB_TypeKind_array_type;
    zT_124.kind = zT_125;
    zT_124.state = arr_state;
    zT_126 = 0;
    zT_124.flags = zT_126;
    zT_127 = 0;
    zT_124._pad = zT_127;
    zT_124.size = arr_size;
    zT_124.alignment = arr_align;
    zT_128 = 0;
    zT_124.name_id = zT_128;
    zT_129 = 0;
    zT_124.c_name_id = zT_129;
    zT_130 = 0;
    zT_124.module_id = zT_130;
    zT_131 = self->array_len;
    zT_132 = 1;
    zT_133 = zT_131 - zT_132;
    zT_134 = (unsigned int)zT_133;
    zT_124.payload_idx = zT_134;
    zT_123 = zT_124;
    zT_135 = zF_D4993F02_typeRegistryAppend(zT_122, zT_123);
    tid = zT_135;
    tid = zT_135;
    tid = zT_135;
    zT_137 = "O2N";
    zT_139 = 3;
    zT_138.ptr = zT_137;
    zT_138.len = zT_139;
    o2m = zT_138;
    o2m = zT_138;
    o2m = zT_138;
    zT_140 = o2m;
    zF_48AC7B3A_markerWrite(zT_140);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_142[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        o2b[_i] = zT_142[_i];
        _i++;
    }
}
    zT_144 = tid;
    zT_146 = (unsigned char*)o2b;
    zT_147 = 20;
    zT_148 = 0;
    zT_149 = zT_146 + zT_148;
    zT_150 = zT_147 - zT_148;
    zT_151.ptr = zT_149;
    zT_151.len = zT_150;
    zT_145 = zT_151;
    zT_152 = zF_A7504564_itoa(zT_144, zT_145);
    o2l = zT_152;
    o2l = zT_152;
    o2l = zT_152;
    zT_154 = 19;
    zT_155 = (unsigned int)o2l;
    zT_156 = zT_154 - zT_155;
    o2s = zT_156;
    o2s = zT_156;
    o2s = zT_156;
    zT_158 = (unsigned char*)o2b;
    zT_160 = 19;
    zT_161 = zT_158 + o2s;
    zT_162 = zT_160 - o2s;
    zT_163.ptr = zT_161;
    zT_163.len = zT_162;
    zT_157 = zT_163;
    zF_48AC7B3A_markerWrite(zT_157);
    zT_164 = elem_ty.state;
    zT_165 = 2;
    zT_166 = zT_164 == zT_165;
    if (zT_166) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_170 = &self->array_cache;
    zT_167 = zT_170;
    zT_168 = key;
    zT_169 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_167, zT_168, zT_169);
    goto z_bb_6;
    z_bb_6:
    return tid;
}

/* typeRegistryGetOrCreateTuple */
unsigned int zF_9996320F_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int elems_start, unsigned short elems_count) {
    zT_338B7C76_TypeRegistry* zT_3;
    zT_666DC2E1_TuplePayload zT_4;
    zT_666DC2E1_TuplePayload zT_5;
    zT_338B7C76_TypeRegistry* zT_7;
    zT_D155D06D_Type zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned char zT_11;
    unsigned char zT_12;
    unsigned char zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23 = 0;
    unsigned int tid;
    zT_3 = self;
    zT_5.elems_start = elems_start;
    zT_5.elems_count = elems_count;
    zT_4 = zT_5;
    zF_C94DF842_tupAppend(zT_3, zT_4);
    zT_7 = self;
    zT_10 = zT_33EF6BFB_TypeKind_tuple_type;
    zT_9.kind = zT_10;
    zT_11 = 2;
    zT_9.state = zT_11;
    zT_12 = 0;
    zT_9.flags = zT_12;
    zT_13 = 0;
    zT_9._pad = zT_13;
    zT_14 = 0;
    zT_9.size = zT_14;
    zT_15 = 1;
    zT_9.alignment = zT_15;
    zT_16 = 0;
    zT_9.name_id = zT_16;
    zT_17 = 0;
    zT_9.c_name_id = zT_17;
    zT_18 = 0;
    zT_9.module_id = zT_18;
    zT_19 = self->tup_len;
    zT_20 = 1;
    zT_21 = zT_19 - zT_20;
    zT_22 = (unsigned int)zT_21;
    zT_9.payload_idx = zT_22;
    zT_8 = zT_9;
    zT_23 = zF_D4993F02_typeRegistryAppend(zT_7, zT_8);
    tid = zT_23;
    tid = zT_23;
    tid = zT_23;
    return tid;
}

/* typeRegistryGetOrCreateFn */
unsigned int zF_474336D7_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int name_id, unsigned int module_id, unsigned char is_extern, unsigned char is_variadic, unsigned int params_start, unsigned short params_count, unsigned int return_type) {
    char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_4028D896_Arr_unsigned_char_2 zT_14;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    int zT_20;
    unsigned char* zT_21;
    unsigned int zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24 = 0;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned char* zT_30;
    unsigned int zT_32;
    unsigned char* zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    int zT_40;
    zT_D155D06D_Type* zT_42;
    zT_D155D06D_Type zT_43;
    zT_33EF6BFB_TypeKind zT_44;
    zT_33EF6BFB_TypeKind zT_45;
    int zT_46;
    int zT_47;
    unsigned int zT_48;
    int zT_49;
    int zT_50;
    zT_0317B1D5_FnPayload* zT_51;
    zT_D155D06D_Type* zT_52;
    zT_D155D06D_Type zT_53;
    unsigned int zT_54;
    zT_0317B1D5_FnPayload zT_55;
    unsigned int zT_56;
    int zT_57;
    char* zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned int zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    int zT_64;
    unsigned int zT_65;
    zT_338B7C76_TypeRegistry* zT_66;
    zT_0317B1D5_FnPayload zT_67;
    zT_0317B1D5_FnPayload zT_68;
    zT_338B7C76_TypeRegistry* zT_70;
    zT_D155D06D_Type zT_71;
    zT_D155D06D_Type zT_72;
    zT_33EF6BFB_TypeKind zT_73;
    unsigned char zT_74;
    unsigned char zT_75;
    unsigned char zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned int zT_85 = 0;
    zT_4028D896_Arr_unsigned_char_2 zT_87;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned char* zT_91;
    unsigned int zT_92;
    int zT_93;
    unsigned char* zT_94;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned int zT_97 = 0;
    unsigned int zT_99;
    unsigned int zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned char* zT_103;
    unsigned int zT_105;
    unsigned char* zT_106;
    unsigned int zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    char* zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2m;
    zT_4028D896_Arr_unsigned_char_2 p2nb;
    unsigned int p2nl;
    unsigned int p2ns;
    unsigned int i;
    zT_D155D06D_Type it;
    unsigned int tid;
    zT_4028D896_Arr_unsigned_char_2 p2sb;
    unsigned int p2sl;
    unsigned int p2ss;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2nl2;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2hm;
    zT_9 = "P2:n";
    zT_11 = 4;
    zT_10.ptr = zT_9;
    zT_10.len = zT_11;
    p2m = zT_10;
    p2m = zT_10;
    p2m = zT_10;
    zT_12 = p2m;
    zF_48AC7B3A_markerWrite(zT_12);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_14[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        p2nb[_i] = zT_14[_i];
        _i++;
    }
}
    zT_16 = name_id;
    zT_18 = (unsigned char*)p2nb;
    zT_19 = 20;
    zT_20 = 0;
    zT_21 = zT_18 + zT_20;
    zT_22 = zT_19 - zT_20;
    zT_23.ptr = zT_21;
    zT_23.len = zT_22;
    zT_17 = zT_23;
    zT_24 = zF_A7504564_itoa(zT_16, zT_17);
    p2nl = zT_24;
    p2nl = zT_24;
    p2nl = zT_24;
    zT_26 = 19;
    zT_27 = (unsigned int)p2nl;
    zT_28 = zT_26 - zT_27;
    p2ns = zT_28;
    p2ns = zT_28;
    p2ns = zT_28;
    zT_30 = (unsigned char*)p2nb;
    zT_32 = 19;
    zT_33 = zT_30 + p2ns;
    zT_34 = zT_32 - p2ns;
    zT_35.ptr = zT_33;
    zT_35.len = zT_34;
    zT_29 = zT_35;
    zF_48AC7B3A_markerWrite(zT_29);
    zT_37 = 0;
    zT_38 = (unsigned int)zT_37;
    i = zT_38;
    i = zT_38;
    i = zT_38;
    goto z_bb_1;
    z_bb_1:
    zT_39 = self->types_len;
    zT_40 = i < zT_39;
    if (zT_40) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_42 = self->types_items;
    zT_43 = zT_42[i];
    it = zT_43;
    it = zT_43;
    it = zT_43;
    zT_44 = it.kind;
    zT_45 = zT_33EF6BFB_TypeKind_fn_type;
    zT_46 = zT_44 == zT_45;
    if (zT_46) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_66 = self;
    zT_68.name_id = name_id;
    zT_68.module_id = module_id;
    zT_68.is_extern = is_extern;
    zT_68.params_start = params_start;
    zT_68.params_count = params_count;
    zT_68.return_type = return_type;
    zT_68.flags_packed = is_variadic;
    zT_67 = zT_68;
    zF_07DDC351_fnAppend(zT_66, zT_67);
    zT_70 = self;
    zT_73 = zT_33EF6BFB_TypeKind_fn_type;
    zT_72.kind = zT_73;
    zT_74 = 2;
    zT_72.state = zT_74;
    zT_75 = 0;
    zT_72.flags = zT_75;
    zT_76 = 0;
    zT_72._pad = zT_76;
    zT_77 = 4;
    zT_72.size = zT_77;
    zT_78 = 4;
    zT_72.alignment = zT_78;
    zT_72.name_id = name_id;
    zT_79 = 0;
    zT_72.c_name_id = zT_79;
    zT_80 = 0;
    zT_72.module_id = zT_80;
    zT_81 = self->fn_len;
    zT_82 = 1;
    zT_83 = zT_81 - zT_82;
    zT_84 = (unsigned int)zT_83;
    zT_72.payload_idx = zT_84;
    zT_71 = zT_72;
    zT_85 = zF_D4993F02_typeRegistryAppend(zT_70, zT_71);
    tid = zT_85;
    tid = zT_85;
    tid = zT_85;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_87[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        p2sb[_i] = zT_87[_i];
        _i++;
    }
}
    zT_89 = tid;
    zT_91 = (unsigned char*)p2sb;
    zT_92 = 20;
    zT_93 = 0;
    zT_94 = zT_91 + zT_93;
    zT_95 = zT_92 - zT_93;
    zT_96.ptr = zT_94;
    zT_96.len = zT_95;
    zT_90 = zT_96;
    zT_97 = zF_A7504564_itoa(zT_89, zT_90);
    p2sl = zT_97;
    p2sl = zT_97;
    p2sl = zT_97;
    zT_99 = 19;
    zT_100 = (unsigned int)p2sl;
    zT_101 = zT_99 - zT_100;
    p2ss = zT_101;
    p2ss = zT_101;
    p2ss = zT_101;
    zT_103 = (unsigned char*)p2sb;
    zT_105 = 19;
    zT_106 = zT_103 + p2ss;
    zT_107 = zT_105 - p2ss;
    zT_108.ptr = zT_106;
    zT_108.len = zT_107;
    zT_102 = zT_108;
    zF_48AC7B3A_markerWrite(zT_102);
    zT_110 = "\n";
    zT_112 = 1;
    zT_111.ptr = zT_110;
    zT_111.len = zT_112;
    p2nl2 = zT_111;
    p2nl2 = zT_111;
    p2nl2 = zT_111;
    zT_113 = p2nl2;
    zF_48AC7B3A_markerWrite(zT_113);
    return tid;
    z_bb_4:
    zT_64 = 1;
    zT_65 = i + zT_64;
    i = zT_65;
    i = zT_65;
    goto z_bb_1;
    z_bb_5:
    zT_48 = it.name_id;
    zT_49 = zT_48 == name_id;
    zT_47 = zT_49;
    goto z_bb_7;
    z_bb_6:
    zT_47 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_47) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_51 = self->fn_items;
    zT_52 = self->types_items;
    zT_53 = zT_52[i];
    zT_54 = zT_53.payload_idx;
    zT_55 = zT_51[zT_54];
    zT_56 = zT_55.module_id;
    zT_57 = zT_56 == module_id;
    zT_50 = zT_57;
    goto z_bb_10;
    z_bb_9:
    zT_50 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_50) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_59 = "H";
    zT_61 = 1;
    zT_60.ptr = zT_59;
    zT_60.len = zT_61;
    p2hm = zT_60;
    p2hm = zT_60;
    p2hm = zT_60;
    zT_62 = p2hm;
    zF_48AC7B3A_markerWrite(zT_62);
    zT_63 = (unsigned int)i;
    return zT_63;
    z_bb_12:
    goto z_bb_4;
}

/* typeRegistryMarkFnPtrUsed */
void zF_263F0272_typeRegistryMarkFnP(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    unsigned int zT_3;
    zT_D155D06D_Type zT_4;
    unsigned char zT_5;
    unsigned char zT_6;
    unsigned char zT_7;
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type* zT_10;
    zT_2 = self->types_items;
    zT_3 = (unsigned int)tid;
    zT_4 = zT_2[zT_3];
    zT_5 = zT_4.flags;
    zT_6 = 1;
    zT_7 = zT_5 | zT_6;
    zT_8 = self->types_items;
    zT_9 = (unsigned int)tid;
    zT_10 = zT_8 + zT_9;
    zT_10->flags = zT_7;
    return;
}

/* typeRegistryGetOrCreateErrorSet */
unsigned int zF_1C9ADFFD_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int tags_start, unsigned short tags_count) {
    zT_79FAE712_u64 zT_4;
    int zT_6;
    unsigned short zT_7;
    int zT_8;
    unsigned int* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_79FAE712_u64 zT_15;
    zT_79FAE712_u64 zT_16;
    zT_79FAE712_u64 zT_17;
    zT_79FAE712_u64 zT_18;
    int zT_19;
    unsigned int zT_20;
    zT_A4CE86B7_U64ToU32Map* zT_21;
    zT_79FAE712_u64 zT_22;
    zT_A4CE86B7_U64ToU32Map* zT_23;
    zT_BAEE192E_Opt_10 zT_24 = {0};
    unsigned char zT_25;
    zT_338B7C76_TypeRegistry* zT_27;
    zT_0B73C507_ErrorSetPayload zT_28;
    zT_0B73C507_ErrorSetPayload zT_29;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_D155D06D_Type zT_32;
    zT_D155D06D_Type zT_33;
    zT_33EF6BFB_TypeKind zT_34;
    unsigned char zT_35;
    unsigned char zT_36;
    unsigned char zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned int zT_47 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_48;
    zT_79FAE712_u64 zT_49;
    unsigned int zT_50;
    zT_A4CE86B7_U64ToU32Map* zT_51;
    zT_79FAE712_u64 key;
    unsigned short ki;
    unsigned int tag;
    unsigned int existing;
    unsigned int tid;
    zT_4 = (zT_79FAE712_u64)tags_count;
    key = zT_4;
    key = zT_4;
    key = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned short)zT_6;
    ki = zT_7;
    ki = zT_7;
    ki = zT_7;
    goto z_bb_1;
    z_bb_1:
    zT_8 = ki < tags_count;
    if (zT_8) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = self->xn_items;
    zT_11 = (unsigned int)ki;
    zT_12 = tags_start + zT_11;
    zT_13 = (unsigned int)zT_12;
    zT_14 = zT_10[zT_13];
    tag = zT_14;
    tag = zT_14;
    tag = zT_14;
    zT_15 = (zT_79FAE712_u64)tag;
    zT_16 = key ^ zT_15;
    zT_17 = 1099511628211ULL;
    zT_18 = zT_16 * zT_17;
    key = zT_18;
    key = zT_18;
    goto z_bb_4;
    z_bb_3:
    zT_23 = &self->es_cache;
    zT_21 = zT_23;
    zT_22 = key;
    zT_24 = zF_A05A7BE1_u64ToU32MapGet(zT_21, zT_22);
    zT_25 = zT_24.has_value;
    if (zT_25) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_19 = 1;
    zT_20 = ki + zT_19;
    ki = zT_20;
    ki = zT_20;
    goto z_bb_1;
    z_bb_5:
    existing = zT_24.value;
    return existing;
    z_bb_6:
    zT_27 = self;
    zT_29.tags_start = tags_start;
    zT_29.tags_count = tags_count;
    zT_28 = zT_29;
    zF_B86143DD_esAppend(zT_27, zT_28);
    zT_31 = self;
    zT_34 = zT_33EF6BFB_TypeKind_error_set_type;
    zT_33.kind = zT_34;
    zT_35 = 2;
    zT_33.state = zT_35;
    zT_36 = 0;
    zT_33.flags = zT_36;
    zT_37 = 0;
    zT_33._pad = zT_37;
    zT_38 = 4;
    zT_33.size = zT_38;
    zT_39 = 4;
    zT_33.alignment = zT_39;
    zT_40 = 0;
    zT_33.name_id = zT_40;
    zT_41 = 0;
    zT_33.c_name_id = zT_41;
    zT_42 = 0;
    zT_33.module_id = zT_42;
    zT_43 = self->es_len;
    zT_44 = 1;
    zT_45 = zT_43 - zT_44;
    zT_46 = (unsigned int)zT_45;
    zT_33.payload_idx = zT_46;
    zT_32 = zT_33;
    zT_47 = zF_D4993F02_typeRegistryAppend(zT_31, zT_32);
    tid = zT_47;
    tid = zT_47;
    tid = zT_47;
    zT_51 = &self->es_cache;
    zT_48 = zT_51;
    zT_49 = key;
    zT_50 = tid;
    zF_B6EB812C_u64ToU32MapPut(zT_48, zT_49, zT_50);
    return tid;
}

/* typeRegistryErrorSetMemberIndex */
unsigned int zF_D2ECD176_typeRegistryErrorSe(zT_338B7C76_TypeRegistry* reg, unsigned int es_type_id, unsigned int name_id) {
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    zT_D155D06D_Type* zT_8;
    unsigned int zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    zT_33EF6BFB_TypeKind zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    int zT_18;
    unsigned int zT_19;
    zT_0B73C507_ErrorSetPayload* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_0B73C507_ErrorSetPayload zT_24;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned short zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    int zT_33;
    unsigned int zT_34;
    int zT_36;
    unsigned int zT_37;
    int zT_38;
    unsigned int* zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    int zT_42;
    unsigned int zT_43;
    int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    zT_D155D06D_Type ty;
    zT_0B73C507_ErrorSetPayload es_payload;
    unsigned int tags_start;
    unsigned int tags_count;
    unsigned int i;
    zT_3 = reg->types_len;
    zT_4 = (unsigned int)zT_3;
    zT_5 = es_type_id >= zT_4;
    if (zT_5) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = 4294967295u;
    return zT_6;
    z_bb_2:
    zT_8 = reg->types_items;
    zT_9 = (unsigned int)es_type_id;
    zT_10 = zT_8[zT_9];
    ty = zT_10;
    ty = zT_10;
    ty = zT_10;
    zT_11 = ty.kind;
    zT_12 = zT_33EF6BFB_TypeKind_error_set_type;
    zT_13 = zT_11 != zT_12;
    if (zT_13) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14 = 4294967295u;
    return zT_14;
    z_bb_4:
    zT_15 = ty.payload_idx;
    zT_16 = reg->es_len;
    zT_17 = (unsigned int)zT_16;
    zT_18 = zT_15 >= zT_17;
    if (zT_18) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_19 = 4294967295u;
    return zT_19;
    z_bb_6:
    zT_21 = reg->es_items;
    zT_22 = ty.payload_idx;
    zT_23 = (unsigned int)zT_22;
    zT_24 = zT_21[zT_23];
    es_payload = zT_24;
    es_payload = zT_24;
    es_payload = zT_24;
    zT_26 = es_payload.tags_start;
    zT_27 = (unsigned int)zT_26;
    tags_start = zT_27;
    tags_start = zT_27;
    tags_start = zT_27;
    zT_29 = es_payload.tags_count;
    zT_30 = (unsigned int)zT_29;
    tags_count = zT_30;
    tags_count = zT_30;
    tags_count = zT_30;
    zT_31 = tags_start + tags_count;
    zT_32 = reg->xn_len;
    zT_33 = zT_31 > zT_32;
    if (zT_33) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_34 = 4294967295u;
    return zT_34;
    z_bb_8:
    zT_36 = 0;
    zT_37 = (unsigned int)zT_36;
    i = zT_37;
    i = zT_37;
    i = zT_37;
    goto z_bb_9;
    z_bb_9:
    zT_38 = i < tags_count;
    if (zT_38) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_39 = reg->xn_items;
    zT_40 = tags_start + i;
    zT_41 = zT_39[zT_40];
    zT_42 = zT_41 == name_id;
    if (zT_42) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_46 = 4294967295u;
    return zT_46;
    z_bb_12:
    zT_44 = 1;
    zT_45 = i + zT_44;
    i = zT_45;
    i = zT_45;
    goto z_bb_9;
    z_bb_13:
    zT_43 = (unsigned int)i;
    return zT_43;
    z_bb_14:
    goto z_bb_12;
}

/* typeRegistryGetOrCreateModule */
unsigned int zF_2ECA9F93_typeRegistryGetOrCr(zT_338B7C76_TypeRegistry* self, unsigned int module_id) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    int zT_6;
    zT_D155D06D_Type* zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    int zT_12;
    int zT_13;
    unsigned int zT_14;
    int zT_15;
    unsigned int zT_16;
    int zT_17;
    unsigned int zT_18;
    zT_D155D06D_Type zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    unsigned char zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    zT_338B7C76_TypeRegistry* zT_36;
    zT_D155D06D_Type zT_37;
    unsigned int zT_38 = 0;
    unsigned int i;
    zT_D155D06D_Type it;
    zT_D155D06D_Type t;
    zT_8F083A69_Slice_zT_0B42B2F8_u mc;
    unsigned int mcid;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    i = zT_4;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->types_len;
    zT_6 = i < zT_5;
    if (zT_6) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = self->types_items;
    zT_9 = zT_8[i];
    it = zT_9;
    it = zT_9;
    it = zT_9;
    zT_10 = it.kind;
    zT_11 = zT_33EF6BFB_TypeKind_module_type;
    zT_12 = zT_10 == zT_11;
    if (zT_12) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_21 = zT_33EF6BFB_TypeKind_module_type;
    zT_20.kind = zT_21;
    zT_22 = 0;
    zT_20.state = zT_22;
    zT_23 = 0;
    zT_20.flags = zT_23;
    zT_24 = 0;
    zT_20._pad = zT_24;
    zT_25 = 0;
    zT_20.size = zT_25;
    zT_26 = 0;
    zT_20.alignment = zT_26;
    zT_27 = 0;
    zT_20.name_id = zT_27;
    zT_28 = 0;
    zT_20.c_name_id = zT_28;
    zT_20.module_id = module_id;
    zT_29 = 0;
    zT_20.payload_idx = zT_29;
    t = zT_20;
    t = zT_20;
    t = zT_20;
    zT_31 = "MC";
    zT_33 = 2;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    mc = zT_32;
    mc = zT_32;
    mc = zT_32;
    zT_34 = mc;
    zF_48AC7B3A_markerWrite(zT_34);
    zT_36 = self;
    zT_37 = t;
    zT_38 = zF_D4993F02_typeRegistryAppend(zT_36, zT_37);
    mcid = zT_38;
    mcid = zT_38;
    mcid = zT_38;
    return mcid;
    z_bb_4:
    zT_17 = 1;
    zT_18 = i + zT_17;
    i = zT_18;
    i = zT_18;
    goto z_bb_1;
    z_bb_5:
    zT_14 = it.module_id;
    zT_15 = zT_14 == module_id;
    zT_13 = zT_15;
    goto z_bb_7;
    z_bb_6:
    zT_13 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_13) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_16 = (unsigned int)i;
    return zT_16;
    z_bb_9:
    goto z_bb_4;
}

/* typeRegistryRegisterPrimitives */
void zF_541737A5_typeRegistryRegiste(zT_338B7C76_TypeRegistry* self) {
    zT_338B7C76_TypeRegistry* zT_1;
    zT_33EF6BFB_TypeKind zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_338B7C76_TypeRegistry* zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_338B7C76_TypeRegistry* zT_17;
    zT_33EF6BFB_TypeKind zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_338B7C76_TypeRegistry* zT_25;
    zT_33EF6BFB_TypeKind zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    zT_33EF6BFB_TypeKind zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    zT_338B7C76_TypeRegistry* zT_33;
    zT_33EF6BFB_TypeKind zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    zT_33EF6BFB_TypeKind zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_338B7C76_TypeRegistry* zT_41;
    zT_33EF6BFB_TypeKind zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    zT_33EF6BFB_TypeKind zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    zT_338B7C76_TypeRegistry* zT_49;
    zT_33EF6BFB_TypeKind zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    zT_33EF6BFB_TypeKind zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    zT_338B7C76_TypeRegistry* zT_57;
    zT_33EF6BFB_TypeKind zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    zT_33EF6BFB_TypeKind zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    zT_338B7C76_TypeRegistry* zT_65;
    zT_33EF6BFB_TypeKind zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    zT_33EF6BFB_TypeKind zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    zT_338B7C76_TypeRegistry* zT_73;
    zT_33EF6BFB_TypeKind zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    zT_33EF6BFB_TypeKind zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    zT_338B7C76_TypeRegistry* zT_81;
    zT_33EF6BFB_TypeKind zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_33EF6BFB_TypeKind zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    zT_338B7C76_TypeRegistry* zT_89;
    zT_33EF6BFB_TypeKind zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    zT_33EF6BFB_TypeKind zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    zT_338B7C76_TypeRegistry* zT_97;
    zT_33EF6BFB_TypeKind zT_98;
    unsigned int zT_99;
    unsigned int zT_100;
    zT_33EF6BFB_TypeKind zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    zT_338B7C76_TypeRegistry* zT_105;
    zT_33EF6BFB_TypeKind zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    zT_33EF6BFB_TypeKind zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    zT_338B7C76_TypeRegistry* zT_113;
    zT_33EF6BFB_TypeKind zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    zT_33EF6BFB_TypeKind zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    zT_338B7C76_TypeRegistry* zT_121;
    zT_33EF6BFB_TypeKind zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    zT_33EF6BFB_TypeKind zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    zT_338B7C76_TypeRegistry* zT_129;
    zT_33EF6BFB_TypeKind zT_130;
    unsigned int zT_131;
    unsigned int zT_132;
    zT_33EF6BFB_TypeKind zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    zT_338B7C76_TypeRegistry* zT_137;
    zT_33EF6BFB_TypeKind zT_138;
    unsigned int zT_139;
    unsigned int zT_140;
    zT_33EF6BFB_TypeKind zT_141;
    unsigned int zT_142;
    unsigned int zT_143;
    zT_338B7C76_TypeRegistry* zT_145;
    zT_33EF6BFB_TypeKind zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    zT_33EF6BFB_TypeKind zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    zT_338B7C76_TypeRegistry* zT_153;
    zT_33EF6BFB_TypeKind zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    zT_33EF6BFB_TypeKind zT_157;
    unsigned int zT_158;
    unsigned int zT_159;
    zT_338B7C76_TypeRegistry* zT_161;
    zT_33EF6BFB_TypeKind zT_162;
    unsigned int zT_163;
    unsigned int zT_164;
    zT_33EF6BFB_TypeKind zT_165;
    unsigned int zT_166;
    unsigned int zT_167;
    zT_338B7C76_TypeRegistry* zT_169;
    zT_33EF6BFB_TypeKind zT_170;
    unsigned int zT_171;
    unsigned int zT_172;
    zT_33EF6BFB_TypeKind zT_173;
    unsigned int zT_174;
    unsigned int zT_175;
    char* zT_178;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_179;
    unsigned int zT_180;
    zT_338B7C76_TypeRegistry* zT_181;
    unsigned int zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_184;
    char* zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned int zT_188;
    zT_338B7C76_TypeRegistry* zT_189;
    unsigned int zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    unsigned int zT_192;
    char* zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned int zT_196;
    zT_338B7C76_TypeRegistry* zT_197;
    unsigned int zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    unsigned int zT_200;
    char* zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    unsigned int zT_204;
    zT_338B7C76_TypeRegistry* zT_205;
    unsigned int zT_206;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_207;
    unsigned int zT_208;
    char* zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned int zT_212;
    zT_338B7C76_TypeRegistry* zT_213;
    unsigned int zT_214;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned int zT_216;
    char* zT_218;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_219;
    unsigned int zT_220;
    zT_338B7C76_TypeRegistry* zT_221;
    unsigned int zT_222;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    unsigned int zT_224;
    char* zT_226;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_227;
    unsigned int zT_228;
    zT_338B7C76_TypeRegistry* zT_229;
    unsigned int zT_230;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_231;
    unsigned int zT_232;
    char* zT_234;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_235;
    unsigned int zT_236;
    zT_338B7C76_TypeRegistry* zT_237;
    unsigned int zT_238;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_239;
    unsigned int zT_240;
    char* zT_242;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    unsigned int zT_244;
    zT_338B7C76_TypeRegistry* zT_245;
    unsigned int zT_246;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_247;
    unsigned int zT_248;
    char* zT_250;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_251;
    unsigned int zT_252;
    zT_338B7C76_TypeRegistry* zT_253;
    unsigned int zT_254;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_255;
    unsigned int zT_256;
    char* zT_258;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_259;
    unsigned int zT_260;
    zT_338B7C76_TypeRegistry* zT_261;
    unsigned int zT_262;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_263;
    unsigned int zT_264;
    char* zT_266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_267;
    unsigned int zT_268;
    zT_338B7C76_TypeRegistry* zT_269;
    unsigned int zT_270;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    unsigned int zT_272;
    char* zT_274;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_275;
    unsigned int zT_276;
    zT_338B7C76_TypeRegistry* zT_277;
    unsigned int zT_278;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    unsigned int zT_280;
    char* zT_282;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_283;
    unsigned int zT_284;
    zT_338B7C76_TypeRegistry* zT_285;
    unsigned int zT_286;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    unsigned int zT_288;
    char* zT_290;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_291;
    unsigned int zT_292;
    zT_338B7C76_TypeRegistry* zT_293;
    unsigned int zT_294;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_295;
    unsigned int zT_296;
    char* zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    unsigned int zT_300;
    zT_338B7C76_TypeRegistry* zT_301;
    unsigned int zT_302;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_303;
    unsigned int zT_304;
    char* zT_306;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_307;
    unsigned int zT_308;
    zT_338B7C76_TypeRegistry* zT_309;
    unsigned int zT_310;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_311;
    unsigned int zT_312;
    char* zT_314;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_315;
    unsigned int zT_316;
    zT_338B7C76_TypeRegistry* zT_317;
    unsigned int zT_318;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_319;
    unsigned int zT_320;
    char* zT_322;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_323;
    unsigned int zT_324;
    zT_338B7C76_TypeRegistry* zT_325;
    unsigned int zT_326;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_327;
    unsigned int zT_328;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_bool;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i8;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i16;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i32;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_i64;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u8;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u16;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u32;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_u64;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_isize;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_usize;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_c_char;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_f32;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_f64;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_null;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_undefined;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_va_list;
    zT_1 = self;
    zT_5 = zT_33EF6BFB_TypeKind_none_sentinel;
    zT_2 = zT_5;
    zT_6 = 0;
    zT_3 = zT_6;
    zT_7 = 0;
    zT_4 = zT_7;
    (void)zF_4F84B621_registerPrimitive(zT_1, zT_2, zT_3, zT_4);
    zT_9 = self;
    zT_13 = zT_33EF6BFB_TypeKind_void_type;
    zT_10 = zT_13;
    zT_14 = 0;
    zT_11 = zT_14;
    zT_15 = 0;
    zT_12 = zT_15;
    (void)zF_4F84B621_registerPrimitive(zT_9, zT_10, zT_11, zT_12);
    zT_17 = self;
    zT_21 = zT_33EF6BFB_TypeKind_bool_type;
    zT_18 = zT_21;
    zT_22 = 4;
    zT_19 = zT_22;
    zT_23 = 4;
    zT_20 = zT_23;
    (void)zF_4F84B621_registerPrimitive(zT_17, zT_18, zT_19, zT_20);
    zT_25 = self;
    zT_29 = zT_33EF6BFB_TypeKind_noreturn_type;
    zT_26 = zT_29;
    zT_30 = 0;
    zT_27 = zT_30;
    zT_31 = 0;
    zT_28 = zT_31;
    (void)zF_4F84B621_registerPrimitive(zT_25, zT_26, zT_27, zT_28);
    zT_33 = self;
    zT_37 = zT_33EF6BFB_TypeKind_i8_type;
    zT_34 = zT_37;
    zT_38 = 1;
    zT_35 = zT_38;
    zT_39 = 1;
    zT_36 = zT_39;
    (void)zF_4F84B621_registerPrimitive(zT_33, zT_34, zT_35, zT_36);
    zT_41 = self;
    zT_45 = zT_33EF6BFB_TypeKind_i16_type;
    zT_42 = zT_45;
    zT_46 = 2;
    zT_43 = zT_46;
    zT_47 = 2;
    zT_44 = zT_47;
    (void)zF_4F84B621_registerPrimitive(zT_41, zT_42, zT_43, zT_44);
    zT_49 = self;
    zT_53 = zT_33EF6BFB_TypeKind_i32_type;
    zT_50 = zT_53;
    zT_54 = 4;
    zT_51 = zT_54;
    zT_55 = 4;
    zT_52 = zT_55;
    (void)zF_4F84B621_registerPrimitive(zT_49, zT_50, zT_51, zT_52);
    zT_57 = self;
    zT_61 = zT_33EF6BFB_TypeKind_i64_type;
    zT_58 = zT_61;
    zT_62 = 8;
    zT_59 = zT_62;
    zT_63 = 8;
    zT_60 = zT_63;
    (void)zF_4F84B621_registerPrimitive(zT_57, zT_58, zT_59, zT_60);
    zT_65 = self;
    zT_69 = zT_33EF6BFB_TypeKind_u8_type;
    zT_66 = zT_69;
    zT_70 = 1;
    zT_67 = zT_70;
    zT_71 = 1;
    zT_68 = zT_71;
    (void)zF_4F84B621_registerPrimitive(zT_65, zT_66, zT_67, zT_68);
    zT_73 = self;
    zT_77 = zT_33EF6BFB_TypeKind_u16_type;
    zT_74 = zT_77;
    zT_78 = 2;
    zT_75 = zT_78;
    zT_79 = 2;
    zT_76 = zT_79;
    (void)zF_4F84B621_registerPrimitive(zT_73, zT_74, zT_75, zT_76);
    zT_81 = self;
    zT_85 = zT_33EF6BFB_TypeKind_u32_type;
    zT_82 = zT_85;
    zT_86 = 4;
    zT_83 = zT_86;
    zT_87 = 4;
    zT_84 = zT_87;
    (void)zF_4F84B621_registerPrimitive(zT_81, zT_82, zT_83, zT_84);
    zT_89 = self;
    zT_93 = zT_33EF6BFB_TypeKind_u64_type;
    zT_90 = zT_93;
    zT_94 = 8;
    zT_91 = zT_94;
    zT_95 = 8;
    zT_92 = zT_95;
    (void)zF_4F84B621_registerPrimitive(zT_89, zT_90, zT_91, zT_92);
    zT_97 = self;
    zT_101 = zT_33EF6BFB_TypeKind_isize_type;
    zT_98 = zT_101;
    zT_102 = 4;
    zT_99 = zT_102;
    zT_103 = 4;
    zT_100 = zT_103;
    (void)zF_4F84B621_registerPrimitive(zT_97, zT_98, zT_99, zT_100);
    zT_105 = self;
    zT_109 = zT_33EF6BFB_TypeKind_usize_type;
    zT_106 = zT_109;
    zT_110 = 4;
    zT_107 = zT_110;
    zT_111 = 4;
    zT_108 = zT_111;
    (void)zF_4F84B621_registerPrimitive(zT_105, zT_106, zT_107, zT_108);
    zT_113 = self;
    zT_117 = zT_33EF6BFB_TypeKind_c_char_type;
    zT_114 = zT_117;
    zT_118 = 1;
    zT_115 = zT_118;
    zT_119 = 1;
    zT_116 = zT_119;
    (void)zF_4F84B621_registerPrimitive(zT_113, zT_114, zT_115, zT_116);
    zT_121 = self;
    zT_125 = zT_33EF6BFB_TypeKind_f32_type;
    zT_122 = zT_125;
    zT_126 = 4;
    zT_123 = zT_126;
    zT_127 = 4;
    zT_124 = zT_127;
    (void)zF_4F84B621_registerPrimitive(zT_121, zT_122, zT_123, zT_124);
    zT_129 = self;
    zT_133 = zT_33EF6BFB_TypeKind_f64_type;
    zT_130 = zT_133;
    zT_134 = 8;
    zT_131 = zT_134;
    zT_135 = 8;
    zT_132 = zT_135;
    (void)zF_4F84B621_registerPrimitive(zT_129, zT_130, zT_131, zT_132);
    zT_137 = self;
    zT_141 = zT_33EF6BFB_TypeKind_null_type;
    zT_138 = zT_141;
    zT_142 = 0;
    zT_139 = zT_142;
    zT_143 = 0;
    zT_140 = zT_143;
    (void)zF_4F84B621_registerPrimitive(zT_137, zT_138, zT_139, zT_140);
    zT_145 = self;
    zT_149 = zT_33EF6BFB_TypeKind_undefined_type;
    zT_146 = zT_149;
    zT_150 = 0;
    zT_147 = zT_150;
    zT_151 = 0;
    zT_148 = zT_151;
    (void)zF_4F84B621_registerPrimitive(zT_145, zT_146, zT_147, zT_148);
    zT_153 = self;
    zT_157 = zT_33EF6BFB_TypeKind_integer_literal_type;
    zT_154 = zT_157;
    zT_158 = 0;
    zT_155 = zT_158;
    zT_159 = 0;
    zT_156 = zT_159;
    (void)zF_4F84B621_registerPrimitive(zT_153, zT_154, zT_155, zT_156);
    zT_161 = self;
    zT_165 = zT_33EF6BFB_TypeKind_type_type;
    zT_162 = zT_165;
    zT_166 = 0;
    zT_163 = zT_166;
    zT_167 = 0;
    zT_164 = zT_167;
    (void)zF_4F84B621_registerPrimitive(zT_161, zT_162, zT_163, zT_164);
    zT_169 = self;
    zT_173 = zT_33EF6BFB_TypeKind_va_list_type;
    zT_170 = zT_173;
    zT_174 = 4;
    zT_171 = zT_174;
    zT_175 = 4;
    zT_172 = zT_175;
    (void)zF_4F84B621_registerPrimitive(zT_169, zT_170, zT_171, zT_172);
    zT_178 = "void";
    zT_180 = 4;
    zT_179.ptr = zT_178;
    zT_179.len = zT_180;
    pn = zT_179;
    pn = zT_179;
    pn = zT_179;
    zT_181 = self;
    zT_184 = 1;
    zT_182 = zT_184;
    zT_183 = pn;
    zF_BA76727A_registerPrimitiveNa(zT_181, zT_182, zT_183);
    zT_186 = "bool";
    zT_188 = 4;
    zT_187.ptr = zT_186;
    zT_187.len = zT_188;
    pn_bool = zT_187;
    pn_bool = zT_187;
    pn_bool = zT_187;
    zT_189 = self;
    zT_192 = 2;
    zT_190 = zT_192;
    zT_191 = pn_bool;
    zF_BA76727A_registerPrimitiveNa(zT_189, zT_190, zT_191);
    zT_194 = "i8";
    zT_196 = 2;
    zT_195.ptr = zT_194;
    zT_195.len = zT_196;
    pn_i8 = zT_195;
    pn_i8 = zT_195;
    pn_i8 = zT_195;
    zT_197 = self;
    zT_200 = 4;
    zT_198 = zT_200;
    zT_199 = pn_i8;
    zF_BA76727A_registerPrimitiveNa(zT_197, zT_198, zT_199);
    zT_202 = "i16";
    zT_204 = 3;
    zT_203.ptr = zT_202;
    zT_203.len = zT_204;
    pn_i16 = zT_203;
    pn_i16 = zT_203;
    pn_i16 = zT_203;
    zT_205 = self;
    zT_208 = 5;
    zT_206 = zT_208;
    zT_207 = pn_i16;
    zF_BA76727A_registerPrimitiveNa(zT_205, zT_206, zT_207);
    zT_210 = "i32";
    zT_212 = 3;
    zT_211.ptr = zT_210;
    zT_211.len = zT_212;
    pn_i32 = zT_211;
    pn_i32 = zT_211;
    pn_i32 = zT_211;
    zT_213 = self;
    zT_216 = 6;
    zT_214 = zT_216;
    zT_215 = pn_i32;
    zF_BA76727A_registerPrimitiveNa(zT_213, zT_214, zT_215);
    zT_218 = "i64";
    zT_220 = 3;
    zT_219.ptr = zT_218;
    zT_219.len = zT_220;
    pn_i64 = zT_219;
    pn_i64 = zT_219;
    pn_i64 = zT_219;
    zT_221 = self;
    zT_224 = 7;
    zT_222 = zT_224;
    zT_223 = pn_i64;
    zF_BA76727A_registerPrimitiveNa(zT_221, zT_222, zT_223);
    zT_226 = "u8";
    zT_228 = 2;
    zT_227.ptr = zT_226;
    zT_227.len = zT_228;
    pn_u8 = zT_227;
    pn_u8 = zT_227;
    pn_u8 = zT_227;
    zT_229 = self;
    zT_232 = 8;
    zT_230 = zT_232;
    zT_231 = pn_u8;
    zF_BA76727A_registerPrimitiveNa(zT_229, zT_230, zT_231);
    zT_234 = "u16";
    zT_236 = 3;
    zT_235.ptr = zT_234;
    zT_235.len = zT_236;
    pn_u16 = zT_235;
    pn_u16 = zT_235;
    pn_u16 = zT_235;
    zT_237 = self;
    zT_240 = 9;
    zT_238 = zT_240;
    zT_239 = pn_u16;
    zF_BA76727A_registerPrimitiveNa(zT_237, zT_238, zT_239);
    zT_242 = "u32";
    zT_244 = 3;
    zT_243.ptr = zT_242;
    zT_243.len = zT_244;
    pn_u32 = zT_243;
    pn_u32 = zT_243;
    pn_u32 = zT_243;
    zT_245 = self;
    zT_248 = 10;
    zT_246 = zT_248;
    zT_247 = pn_u32;
    zF_BA76727A_registerPrimitiveNa(zT_245, zT_246, zT_247);
    zT_250 = "u64";
    zT_252 = 3;
    zT_251.ptr = zT_250;
    zT_251.len = zT_252;
    pn_u64 = zT_251;
    pn_u64 = zT_251;
    pn_u64 = zT_251;
    zT_253 = self;
    zT_256 = 11;
    zT_254 = zT_256;
    zT_255 = pn_u64;
    zF_BA76727A_registerPrimitiveNa(zT_253, zT_254, zT_255);
    zT_258 = "isize";
    zT_260 = 5;
    zT_259.ptr = zT_258;
    zT_259.len = zT_260;
    pn_isize = zT_259;
    pn_isize = zT_259;
    pn_isize = zT_259;
    zT_261 = self;
    zT_264 = 12;
    zT_262 = zT_264;
    zT_263 = pn_isize;
    zF_BA76727A_registerPrimitiveNa(zT_261, zT_262, zT_263);
    zT_266 = "usize";
    zT_268 = 5;
    zT_267.ptr = zT_266;
    zT_267.len = zT_268;
    pn_usize = zT_267;
    pn_usize = zT_267;
    pn_usize = zT_267;
    zT_269 = self;
    zT_272 = 13;
    zT_270 = zT_272;
    zT_271 = pn_usize;
    zF_BA76727A_registerPrimitiveNa(zT_269, zT_270, zT_271);
    zT_274 = "c_char";
    zT_276 = 6;
    zT_275.ptr = zT_274;
    zT_275.len = zT_276;
    pn_c_char = zT_275;
    pn_c_char = zT_275;
    pn_c_char = zT_275;
    zT_277 = self;
    zT_280 = 14;
    zT_278 = zT_280;
    zT_279 = pn_c_char;
    zF_BA76727A_registerPrimitiveNa(zT_277, zT_278, zT_279);
    zT_282 = "f32";
    zT_284 = 3;
    zT_283.ptr = zT_282;
    zT_283.len = zT_284;
    pn_f32 = zT_283;
    pn_f32 = zT_283;
    pn_f32 = zT_283;
    zT_285 = self;
    zT_288 = 15;
    zT_286 = zT_288;
    zT_287 = pn_f32;
    zF_BA76727A_registerPrimitiveNa(zT_285, zT_286, zT_287);
    zT_290 = "f64";
    zT_292 = 3;
    zT_291.ptr = zT_290;
    zT_291.len = zT_292;
    pn_f64 = zT_291;
    pn_f64 = zT_291;
    pn_f64 = zT_291;
    zT_293 = self;
    zT_296 = 16;
    zT_294 = zT_296;
    zT_295 = pn_f64;
    zF_BA76727A_registerPrimitiveNa(zT_293, zT_294, zT_295);
    zT_298 = "null";
    zT_300 = 4;
    zT_299.ptr = zT_298;
    zT_299.len = zT_300;
    pn_null = zT_299;
    pn_null = zT_299;
    pn_null = zT_299;
    zT_301 = self;
    zT_304 = 17;
    zT_302 = zT_304;
    zT_303 = pn_null;
    zF_BA76727A_registerPrimitiveNa(zT_301, zT_302, zT_303);
    zT_306 = "undefined";
    zT_308 = 9;
    zT_307.ptr = zT_306;
    zT_307.len = zT_308;
    pn_undefined = zT_307;
    pn_undefined = zT_307;
    pn_undefined = zT_307;
    zT_309 = self;
    zT_312 = 18;
    zT_310 = zT_312;
    zT_311 = pn_undefined;
    zF_BA76727A_registerPrimitiveNa(zT_309, zT_310, zT_311);
    zT_314 = "type";
    zT_316 = 4;
    zT_315.ptr = zT_314;
    zT_315.len = zT_316;
    pn_type = zT_315;
    pn_type = zT_315;
    pn_type = zT_315;
    zT_317 = self;
    zT_320 = 20;
    zT_318 = zT_320;
    zT_319 = pn_type;
    zF_BA76727A_registerPrimitiveNa(zT_317, zT_318, zT_319);
    zT_322 = "va_list";
    zT_324 = 7;
    zT_323.ptr = zT_322;
    zT_323.len = zT_324;
    pn_va_list = zT_323;
    pn_va_list = zT_323;
    pn_va_list = zT_323;
    zT_325 = self;
    zT_328 = 21;
    zT_326 = zT_328;
    zT_327 = pn_va_list;
    zF_BA76727A_registerPrimitiveNa(zT_325, zT_326, zT_327);
    return;
}

/* registerPrimitiveName */
void zF_BA76727A_registerPrimitiveNa(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_8F083A69_Slice_zT_0B42B2F8_u name) {
    zT_D3EB6303_StringInterner* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_D3EB6303_StringInterner* zT_6;
    unsigned int zT_7 = 0;
    zT_D155D06D_Type* zT_9;
    unsigned int zT_10;
    zT_D155D06D_Type zT_11;
    zT_D155D06D_Type* zT_12;
    unsigned int zT_13;
    zT_338B7C76_TypeRegistry* zT_14;
    zT_79FAE712_u64 zT_15;
    unsigned int zT_16;
    zT_79FAE712_u64 zT_17;
    unsigned int nid;
    zT_D155D06D_Type ty;
    zT_6 = self->interner;
    zT_4 = zT_6;
    zT_5 = name;
    zT_7 = zF_50C274AF_stringInternerInter(zT_4, zT_5);
    nid = zT_7;
    nid = zT_7;
    nid = zT_7;
    zT_9 = self->types_items;
    zT_10 = (unsigned int)tid;
    zT_11 = zT_9[zT_10];
    ty = zT_11;
    ty = zT_11;
    ty = zT_11;
    ty.name_id = nid;
    zT_12 = self->types_items;
    zT_13 = (unsigned int)tid;
    zT_12[zT_13] = ty;
    zT_14 = self;
    zT_17 = (zT_79FAE712_u64)nid;
    zT_15 = zT_17;
    zT_16 = tid;
    zF_5E95558D_nameCachePut(zT_14, zT_15, zT_16);
    return;
}

/* typeRegistryRegisterNamedType */
unsigned int zF_3A64E2E0_typeRegistryRegiste(zT_338B7C76_TypeRegistry* self, unsigned int module_id, unsigned int name_id, zT_33EF6BFB_TypeKind kind) {
    zT_79FAE712_u64 zT_5;
    zT_79FAE712_u64 zT_6;
    zT_79FAE712_u64 zT_7;
    zT_79FAE712_u64 zT_8;
    zT_79FAE712_u64 zT_9;
    zT_338B7C76_TypeRegistry* zT_10;
    zT_79FAE712_u64 zT_11;
    zT_BAEE192E_Opt_10 zT_12 = {0};
    unsigned char zT_13;
    zT_338B7C76_TypeRegistry* zT_16;
    zT_D155D06D_Type zT_17;
    zT_D155D06D_Type zT_18;
    unsigned char zT_19;
    unsigned char zT_20;
    unsigned char zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned int zT_26 = 0;
    zT_338B7C76_TypeRegistry* zT_27;
    zT_79FAE712_u64 zT_28;
    unsigned int zT_29;
    zT_4028D896_Arr_unsigned_char_2 zT_31;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned char* zT_35;
    unsigned int zT_36;
    int zT_37;
    unsigned char* zT_38;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41 = 0;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned char* zT_52;
    unsigned int zT_54;
    unsigned char* zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    zT_4028D896_Arr_unsigned_char_2 zT_59;
    unsigned int zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned char* zT_63;
    unsigned int zT_64;
    int zT_65;
    unsigned char* zT_66;
    unsigned int zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69 = 0;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned char* zT_80;
    unsigned int zT_82;
    unsigned char* zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    zT_4028D896_Arr_unsigned_char_2 zT_87;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91;
    unsigned char* zT_92;
    unsigned int zT_93;
    int zT_94;
    unsigned char* zT_95;
    unsigned int zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_98 = 0;
    unsigned int zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    char* zT_104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    unsigned int zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    unsigned char* zT_109;
    unsigned int zT_111;
    unsigned char* zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    zT_4028D896_Arr_unsigned_char_2 zT_116;
    unsigned int zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned char* zT_120;
    unsigned int zT_121;
    int zT_122;
    unsigned char* zT_123;
    unsigned int zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_125;
    unsigned int zT_126 = 0;
    unsigned int zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    char* zT_132;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_133;
    unsigned int zT_134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    unsigned char* zT_137;
    unsigned int zT_139;
    unsigned char* zT_140;
    unsigned int zT_141;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_142;
    char* zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned int zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    zT_79FAE712_u64 key;
    unsigned int existing;
    unsigned int tid;
    zT_4028D896_Arr_unsigned_char_2 rn_m;
    unsigned int rn_ml;
    unsigned int rn_ms;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnm;
    zT_4028D896_Arr_unsigned_char_2 rn_n;
    unsigned int rn_nl;
    unsigned int rn_ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnn;
    zT_4028D896_Arr_unsigned_char_2 rn_k;
    unsigned int rn_kl;
    unsigned int rn_ks;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnk;
    zT_4028D896_Arr_unsigned_char_2 rn_t;
    unsigned int rn_tl;
    unsigned int rn_ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnt;
    zT_8F083A69_Slice_zT_0B42B2F8_u rnnl;
    zT_5 = (zT_79FAE712_u64)module_id;
    zT_6 = 4294967296ULL;
    zT_7 = zT_5 * zT_6;
    zT_8 = (zT_79FAE712_u64)name_id;
    zT_9 = zT_7 + zT_8;
    key = zT_9;
    key = zT_9;
    key = zT_9;
    zT_10 = self;
    zT_11 = key;
    zT_12 = zF_0EB68360_nameCacheGet(zT_10, zT_11);
    zT_13 = zT_12.has_value;
    if (zT_13) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    existing = zT_12.value;
    return existing;
    z_bb_2:
    zT_16 = self;
    zT_18.kind = kind;
    zT_19 = 0;
    zT_18.state = zT_19;
    zT_20 = 0;
    zT_18.flags = zT_20;
    zT_21 = 0;
    zT_18._pad = zT_21;
    zT_22 = 0;
    zT_18.size = zT_22;
    zT_23 = 0;
    zT_18.alignment = zT_23;
    zT_18.name_id = name_id;
    zT_24 = 0;
    zT_18.c_name_id = zT_24;
    zT_18.module_id = module_id;
    zT_25 = 0;
    zT_18.payload_idx = zT_25;
    zT_17 = zT_18;
    zT_26 = zF_D4993F02_typeRegistryAppend(zT_16, zT_17);
    tid = zT_26;
    tid = zT_26;
    tid = zT_26;
    zT_27 = self;
    zT_28 = key;
    zT_29 = tid;
    zF_5E95558D_nameCachePut(zT_27, zT_28, zT_29);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_31[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_m[_i] = zT_31[_i];
        _i++;
    }
}
    zT_33 = module_id;
    zT_35 = (unsigned char*)rn_m;
    zT_36 = 20;
    zT_37 = 0;
    zT_38 = zT_35 + zT_37;
    zT_39 = zT_36 - zT_37;
    zT_40.ptr = zT_38;
    zT_40.len = zT_39;
    zT_34 = zT_40;
    zT_41 = zF_A7504564_itoa(zT_33, zT_34);
    rn_ml = zT_41;
    rn_ml = zT_41;
    rn_ml = zT_41;
    zT_43 = 19;
    zT_44 = (unsigned int)rn_ml;
    zT_45 = zT_43 - zT_44;
    rn_ms = zT_45;
    rn_ms = zT_45;
    rn_ms = zT_45;
    zT_47 = "RN:m";
    zT_49 = 4;
    zT_48.ptr = zT_47;
    zT_48.len = zT_49;
    rnm = zT_48;
    rnm = zT_48;
    rnm = zT_48;
    zT_50 = rnm;
    zF_48AC7B3A_markerWrite(zT_50);
    zT_52 = (unsigned char*)rn_m;
    zT_54 = 19;
    zT_55 = zT_52 + rn_ms;
    zT_56 = zT_54 - rn_ms;
    zT_57.ptr = zT_55;
    zT_57.len = zT_56;
    zT_51 = zT_57;
    zF_48AC7B3A_markerWrite(zT_51);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_59[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_n[_i] = zT_59[_i];
        _i++;
    }
}
    zT_61 = name_id;
    zT_63 = (unsigned char*)rn_n;
    zT_64 = 20;
    zT_65 = 0;
    zT_66 = zT_63 + zT_65;
    zT_67 = zT_64 - zT_65;
    zT_68.ptr = zT_66;
    zT_68.len = zT_67;
    zT_62 = zT_68;
    zT_69 = zF_A7504564_itoa(zT_61, zT_62);
    rn_nl = zT_69;
    rn_nl = zT_69;
    rn_nl = zT_69;
    zT_71 = 19;
    zT_72 = (unsigned int)rn_nl;
    zT_73 = zT_71 - zT_72;
    rn_ns = zT_73;
    rn_ns = zT_73;
    rn_ns = zT_73;
    zT_75 = "n";
    zT_77 = 1;
    zT_76.ptr = zT_75;
    zT_76.len = zT_77;
    rnn = zT_76;
    rnn = zT_76;
    rnn = zT_76;
    zT_78 = rnn;
    zF_48AC7B3A_markerWrite(zT_78);
    zT_80 = (unsigned char*)rn_n;
    zT_82 = 19;
    zT_83 = zT_80 + rn_ns;
    zT_84 = zT_82 - rn_ns;
    zT_85.ptr = zT_83;
    zT_85.len = zT_84;
    zT_79 = zT_85;
    zF_48AC7B3A_markerWrite(zT_79);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_87[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_k[_i] = zT_87[_i];
        _i++;
    }
}
    zT_91 = (unsigned int)kind;
    zT_89 = zT_91;
    zT_92 = (unsigned char*)rn_k;
    zT_93 = 20;
    zT_94 = 0;
    zT_95 = zT_92 + zT_94;
    zT_96 = zT_93 - zT_94;
    zT_97.ptr = zT_95;
    zT_97.len = zT_96;
    zT_90 = zT_97;
    zT_98 = zF_A7504564_itoa(zT_89, zT_90);
    rn_kl = zT_98;
    rn_kl = zT_98;
    rn_kl = zT_98;
    zT_100 = 19;
    zT_101 = (unsigned int)rn_kl;
    zT_102 = zT_100 - zT_101;
    rn_ks = zT_102;
    rn_ks = zT_102;
    rn_ks = zT_102;
    zT_104 = "k";
    zT_106 = 1;
    zT_105.ptr = zT_104;
    zT_105.len = zT_106;
    rnk = zT_105;
    rnk = zT_105;
    rnk = zT_105;
    zT_107 = rnk;
    zF_48AC7B3A_markerWrite(zT_107);
    zT_109 = (unsigned char*)rn_k;
    zT_111 = 19;
    zT_112 = zT_109 + rn_ks;
    zT_113 = zT_111 - rn_ks;
    zT_114.ptr = zT_112;
    zT_114.len = zT_113;
    zT_108 = zT_114;
    zF_48AC7B3A_markerWrite(zT_108);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_116[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rn_t[_i] = zT_116[_i];
        _i++;
    }
}
    zT_118 = tid;
    zT_120 = (unsigned char*)rn_t;
    zT_121 = 20;
    zT_122 = 0;
    zT_123 = zT_120 + zT_122;
    zT_124 = zT_121 - zT_122;
    zT_125.ptr = zT_123;
    zT_125.len = zT_124;
    zT_119 = zT_125;
    zT_126 = zF_A7504564_itoa(zT_118, zT_119);
    rn_tl = zT_126;
    rn_tl = zT_126;
    rn_tl = zT_126;
    zT_128 = 19;
    zT_129 = (unsigned int)rn_tl;
    zT_130 = zT_128 - zT_129;
    rn_ts = zT_130;
    rn_ts = zT_130;
    rn_ts = zT_130;
    zT_132 = "t";
    zT_134 = 1;
    zT_133.ptr = zT_132;
    zT_133.len = zT_134;
    rnt = zT_133;
    rnt = zT_133;
    rnt = zT_133;
    zT_135 = rnt;
    zF_48AC7B3A_markerWrite(zT_135);
    zT_137 = (unsigned char*)rn_t;
    zT_139 = 19;
    zT_140 = zT_137 + rn_ts;
    zT_141 = zT_139 - rn_ts;
    zT_142.ptr = zT_140;
    zT_142.len = zT_141;
    zT_136 = zT_142;
    zF_48AC7B3A_markerWrite(zT_136);
    zT_144 = "\n";
    zT_146 = 1;
    zT_145.ptr = zT_144;
    zT_145.len = zT_146;
    rnnl = zT_145;
    rnnl = zT_145;
    rnnl = zT_145;
    zT_147 = rnnl;
    zF_48AC7B3A_markerWrite(zT_147);
    return tid;
}

/* isValueDependency */
int zF_2FA4221F_isValueDependency(zT_33EF6BFB_TypeKind kind) {
    zT_33EF6BFB_TypeKind zT_1;
    int zT_2;
    int zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    int zT_5;
    int zT_6;
    zT_33EF6BFB_TypeKind zT_7;
    int zT_8;
    int zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    int zT_11;
    int zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    int zT_14;
    int zT_15;
    zT_33EF6BFB_TypeKind zT_16;
    int zT_17;
    int zT_18;
    zT_33EF6BFB_TypeKind zT_19;
    int zT_20;
    int zT_21;
    zT_33EF6BFB_TypeKind zT_22;
    int zT_23;
    int zT_24;
    int zT_25;
    zT_1 = zT_33EF6BFB_TypeKind_struct_type;
    zT_2 = kind == zT_1;
    if (zT_2) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_3 = 1;
    return zT_3;
    z_bb_2:
    zT_4 = zT_33EF6BFB_TypeKind_union_type;
    zT_5 = kind == zT_4;
    if (zT_5) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_6 = 1;
    return zT_6;
    z_bb_4:
    zT_7 = zT_33EF6BFB_TypeKind_tagged_union_type;
    zT_8 = kind == zT_7;
    if (zT_8) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_9 = 1;
    return zT_9;
    z_bb_6:
    zT_10 = zT_33EF6BFB_TypeKind_array_type;
    zT_11 = kind == zT_10;
    if (zT_11) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_12 = 1;
    return zT_12;
    z_bb_8:
    zT_13 = zT_33EF6BFB_TypeKind_optional_type;
    zT_14 = kind == zT_13;
    if (zT_14) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_15 = 1;
    return zT_15;
    z_bb_10:
    zT_16 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_17 = kind == zT_16;
    if (zT_17) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_18 = 1;
    return zT_18;
    z_bb_12:
    zT_19 = zT_33EF6BFB_TypeKind_tuple_type;
    zT_20 = kind == zT_19;
    if (zT_20) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_21 = 1;
    return zT_21;
    z_bb_14:
    zT_22 = zT_33EF6BFB_TypeKind_unresolved_name;
    zT_23 = kind == zT_22;
    if (zT_23) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_24 = 1;
    return zT_24;
    z_bb_16:
    zT_25 = 0;
    return zT_25;
}

/* typeRegistryGetTypeState */
unsigned char zF_742DAE47_typeRegistryGetType(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    unsigned char zT_4;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.state;
    return zT_4;
}

/* typeRegistryIsNumeric */
int zF_3087E0A5_typeRegistryIsNumer(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind zT_6;
    int zT_7;
    int zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    int zT_10;
    int zT_11;
    zT_33EF6BFB_TypeKind zT_12;
    int zT_13;
    int zT_14;
    zT_33EF6BFB_TypeKind zT_15;
    int zT_16;
    int zT_17;
    zT_33EF6BFB_TypeKind zT_18;
    int zT_19;
    int zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    int zT_22;
    int zT_23;
    zT_33EF6BFB_TypeKind zT_24;
    int zT_25;
    int zT_26;
    zT_33EF6BFB_TypeKind zT_27;
    int zT_28;
    int zT_29;
    zT_33EF6BFB_TypeKind zT_30;
    int zT_31;
    int zT_32;
    zT_33EF6BFB_TypeKind zT_33;
    int zT_34;
    int zT_35;
    zT_33EF6BFB_TypeKind zT_36;
    int zT_37;
    int zT_38;
    zT_33EF6BFB_TypeKind zT_39;
    int zT_40;
    int zT_41;
    zT_33EF6BFB_TypeKind zT_42;
    int zT_43;
    int zT_44;
    int zT_45;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    kind = zT_5;
    kind = zT_5;
    zT_6 = zT_33EF6BFB_TypeKind_i8_type;
    zT_7 = kind == zT_6;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = 1;
    return zT_8;
    z_bb_2:
    zT_9 = zT_33EF6BFB_TypeKind_i16_type;
    zT_10 = kind == zT_9;
    if (zT_10) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_11 = 1;
    return zT_11;
    z_bb_4:
    zT_12 = zT_33EF6BFB_TypeKind_i32_type;
    zT_13 = kind == zT_12;
    if (zT_13) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 1;
    return zT_14;
    z_bb_6:
    zT_15 = zT_33EF6BFB_TypeKind_i64_type;
    zT_16 = kind == zT_15;
    if (zT_16) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_17 = 1;
    return zT_17;
    z_bb_8:
    zT_18 = zT_33EF6BFB_TypeKind_u8_type;
    zT_19 = kind == zT_18;
    if (zT_19) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_20 = 1;
    return zT_20;
    z_bb_10:
    zT_21 = zT_33EF6BFB_TypeKind_u16_type;
    zT_22 = kind == zT_21;
    if (zT_22) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_23 = 1;
    return zT_23;
    z_bb_12:
    zT_24 = zT_33EF6BFB_TypeKind_u32_type;
    zT_25 = kind == zT_24;
    if (zT_25) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_26 = 1;
    return zT_26;
    z_bb_14:
    zT_27 = zT_33EF6BFB_TypeKind_u64_type;
    zT_28 = kind == zT_27;
    if (zT_28) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_29 = 1;
    return zT_29;
    z_bb_16:
    zT_30 = zT_33EF6BFB_TypeKind_isize_type;
    zT_31 = kind == zT_30;
    if (zT_31) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_32 = 1;
    return zT_32;
    z_bb_18:
    zT_33 = zT_33EF6BFB_TypeKind_usize_type;
    zT_34 = kind == zT_33;
    if (zT_34) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_35 = 1;
    return zT_35;
    z_bb_20:
    zT_36 = zT_33EF6BFB_TypeKind_f32_type;
    zT_37 = kind == zT_36;
    if (zT_37) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_38 = 1;
    return zT_38;
    z_bb_22:
    zT_39 = zT_33EF6BFB_TypeKind_f64_type;
    zT_40 = kind == zT_39;
    if (zT_40) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_41 = 1;
    return zT_41;
    z_bb_24:
    zT_42 = zT_33EF6BFB_TypeKind_integer_literal_type;
    zT_43 = kind == zT_42;
    if (zT_43) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_44 = 1;
    return zT_44;
    z_bb_26:
    zT_45 = 0;
    return zT_45;
}

/* typeRegistryIsInteger */
int zF_3290E9C4_typeRegistryIsInteg(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind zT_6;
    int zT_7;
    int zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    int zT_10;
    int zT_11;
    zT_33EF6BFB_TypeKind zT_12;
    int zT_13;
    int zT_14;
    zT_33EF6BFB_TypeKind zT_15;
    int zT_16;
    int zT_17;
    zT_33EF6BFB_TypeKind zT_18;
    int zT_19;
    int zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    int zT_22;
    int zT_23;
    zT_33EF6BFB_TypeKind zT_24;
    int zT_25;
    int zT_26;
    zT_33EF6BFB_TypeKind zT_27;
    int zT_28;
    int zT_29;
    zT_33EF6BFB_TypeKind zT_30;
    int zT_31;
    int zT_32;
    zT_33EF6BFB_TypeKind zT_33;
    int zT_34;
    int zT_35;
    zT_33EF6BFB_TypeKind zT_36;
    int zT_37;
    int zT_38;
    int zT_39;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    kind = zT_5;
    kind = zT_5;
    zT_6 = zT_33EF6BFB_TypeKind_i8_type;
    zT_7 = kind == zT_6;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = 1;
    return zT_8;
    z_bb_2:
    zT_9 = zT_33EF6BFB_TypeKind_i16_type;
    zT_10 = kind == zT_9;
    if (zT_10) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_11 = 1;
    return zT_11;
    z_bb_4:
    zT_12 = zT_33EF6BFB_TypeKind_i32_type;
    zT_13 = kind == zT_12;
    if (zT_13) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 1;
    return zT_14;
    z_bb_6:
    zT_15 = zT_33EF6BFB_TypeKind_i64_type;
    zT_16 = kind == zT_15;
    if (zT_16) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_17 = 1;
    return zT_17;
    z_bb_8:
    zT_18 = zT_33EF6BFB_TypeKind_u8_type;
    zT_19 = kind == zT_18;
    if (zT_19) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_20 = 1;
    return zT_20;
    z_bb_10:
    zT_21 = zT_33EF6BFB_TypeKind_u16_type;
    zT_22 = kind == zT_21;
    if (zT_22) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_23 = 1;
    return zT_23;
    z_bb_12:
    zT_24 = zT_33EF6BFB_TypeKind_u32_type;
    zT_25 = kind == zT_24;
    if (zT_25) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_26 = 1;
    return zT_26;
    z_bb_14:
    zT_27 = zT_33EF6BFB_TypeKind_u64_type;
    zT_28 = kind == zT_27;
    if (zT_28) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_29 = 1;
    return zT_29;
    z_bb_16:
    zT_30 = zT_33EF6BFB_TypeKind_isize_type;
    zT_31 = kind == zT_30;
    if (zT_31) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_32 = 1;
    return zT_32;
    z_bb_18:
    zT_33 = zT_33EF6BFB_TypeKind_usize_type;
    zT_34 = kind == zT_33;
    if (zT_34) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_35 = 1;
    return zT_35;
    z_bb_20:
    zT_36 = zT_33EF6BFB_TypeKind_integer_literal_type;
    zT_37 = kind == zT_36;
    if (zT_37) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_38 = 1;
    return zT_38;
    z_bb_22:
    zT_39 = 0;
    return zT_39;
}

/* typeRegistryIsUnsigned */
int zF_B664AC19_typeRegistryIsUnsig(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind zT_6;
    int zT_7;
    int zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    int zT_10;
    int zT_11;
    zT_33EF6BFB_TypeKind zT_12;
    int zT_13;
    int zT_14;
    zT_33EF6BFB_TypeKind zT_15;
    int zT_16;
    int zT_17;
    zT_33EF6BFB_TypeKind zT_18;
    int zT_19;
    int zT_20;
    int zT_21;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    kind = zT_5;
    kind = zT_5;
    zT_6 = zT_33EF6BFB_TypeKind_u8_type;
    zT_7 = kind == zT_6;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = 1;
    return zT_8;
    z_bb_2:
    zT_9 = zT_33EF6BFB_TypeKind_u16_type;
    zT_10 = kind == zT_9;
    if (zT_10) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_11 = 1;
    return zT_11;
    z_bb_4:
    zT_12 = zT_33EF6BFB_TypeKind_u32_type;
    zT_13 = kind == zT_12;
    if (zT_13) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 1;
    return zT_14;
    z_bb_6:
    zT_15 = zT_33EF6BFB_TypeKind_u64_type;
    zT_16 = kind == zT_15;
    if (zT_16) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_17 = 1;
    return zT_17;
    z_bb_8:
    zT_18 = zT_33EF6BFB_TypeKind_usize_type;
    zT_19 = kind == zT_18;
    if (zT_19) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_20 = 1;
    return zT_20;
    z_bb_10:
    zT_21 = 0;
    return zT_21;
}

/* typeRegistryIsPointer */
int zF_AD61DB1B_typeRegistryIsPoint(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind zT_6;
    int zT_7;
    int zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    int zT_10;
    zT_33EF6BFB_TypeKind kind;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    zT_5 = zT_4.kind;
    kind = zT_5;
    kind = zT_5;
    kind = zT_5;
    zT_6 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_7 = kind == zT_6;
    if (zT_7) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_9 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_10 = kind == zT_9;
    zT_8 = zT_10;
    goto z_bb_3;
    z_bb_2:
    zT_8 = 1;
    goto z_bb_3;
    z_bb_3:
    return zT_8;
}

/* typeRegistryIsSlice */
int zF_0F4CC580_typeRegistryIsSlice(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    int zT_6;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.kind;
    zT_5 = zT_33EF6BFB_TypeKind_slice_type;
    zT_6 = zT_4 == zT_5;
    return zT_6;
}

/* typeRegistryGetPointeeType */
zT_BAEE192E_Opt_10 zF_740D2592_typeRegistryGetPoin(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind zT_6;
    int zT_7;
    int zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    int zT_11;
    zT_BAEE192E_Opt_10 zT_12 = {0};
    zT_112BF819_PtrPayload* zT_13;
    unsigned int zT_14;
    zT_112BF819_PtrPayload zT_15;
    unsigned int zT_16;
    zT_BAEE192E_Opt_10 zT_17;
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    ty = zT_4;
    ty = zT_4;
    ty = zT_4;
    zT_5 = ty.kind;
    zT_6 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_7 = zT_5 != zT_6;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = ty.kind;
    zT_10 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_11 = zT_9 != zT_10;
    zT_8 = zT_11;
    goto z_bb_3;
    z_bb_2:
    zT_8 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_8) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_12.has_value = 0;
    return zT_12;
    z_bb_5:
    zT_13 = self->ptr_items;
    zT_14 = ty.payload_idx;
    zT_15 = zT_13[zT_14];
    zT_16 = zT_15.base;
    zT_17.has_value = 1;
    zT_17.value = zT_16;
    return zT_17;
}

/* typeRegistryGetSliceElem */
zT_BAEE192E_Opt_10 zF_676C3AD3_typeRegistryGetSlic(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_3;
    zT_D155D06D_Type zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    zT_33EF6BFB_TypeKind zT_6;
    int zT_7;
    zT_BAEE192E_Opt_10 zT_8 = {0};
    zT_0BB2A741_SlicePayload* zT_9;
    unsigned int zT_10;
    zT_0BB2A741_SlicePayload zT_11;
    unsigned int zT_12;
    zT_BAEE192E_Opt_10 zT_13;
    zT_D155D06D_Type ty;
    zT_3 = self->types_items;
    zT_4 = zT_3[tid];
    ty = zT_4;
    ty = zT_4;
    ty = zT_4;
    zT_5 = ty.kind;
    zT_6 = zT_33EF6BFB_TypeKind_slice_type;
    zT_7 = zT_5 != zT_6;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8.has_value = 0;
    return zT_8;
    z_bb_2:
    zT_9 = self->slice_items;
    zT_10 = ty.payload_idx;
    zT_11 = zT_9[zT_10];
    zT_12 = zT_11.elem;
    zT_13.has_value = 1;
    zT_13.value = zT_12;
    return zT_13;
}

/* typeRegistryIndexedElemType */
unsigned int zF_E02A7BC0_typeRegistryIndexed(zT_338B7C76_TypeRegistry* self, unsigned int base_tid) {
    zT_D155D06D_Type* zT_3;
    unsigned int zT_4;
    zT_D155D06D_Type zT_5;
    zT_33EF6BFB_TypeKind zT_6;
    zT_33EF6BFB_TypeKind zT_7;
    int zT_8;
    zT_E834303C_ArrayPayload* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_E834303C_ArrayPayload zT_12;
    unsigned int zT_13;
    zT_33EF6BFB_TypeKind zT_14;
    zT_33EF6BFB_TypeKind zT_15;
    int zT_16;
    zT_0BB2A741_SlicePayload* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_0BB2A741_SlicePayload zT_20;
    unsigned int zT_21;
    zT_33EF6BFB_TypeKind zT_22;
    zT_33EF6BFB_TypeKind zT_23;
    int zT_24;
    int zT_25;
    zT_33EF6BFB_TypeKind zT_26;
    zT_33EF6BFB_TypeKind zT_27;
    int zT_28;
    zT_112BF819_PtrPayload* zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_112BF819_PtrPayload zT_33;
    unsigned int zT_34;
    zT_D155D06D_Type* zT_36;
    unsigned int zT_37;
    zT_D155D06D_Type zT_38;
    zT_33EF6BFB_TypeKind zT_39;
    zT_33EF6BFB_TypeKind zT_40;
    int zT_41;
    zT_E834303C_ArrayPayload* zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    zT_E834303C_ArrayPayload zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    zT_D155D06D_Type ty;
    unsigned int pointee;
    zT_D155D06D_Type pointee_ty;
    zT_3 = self->types_items;
    zT_4 = (unsigned int)base_tid;
    zT_5 = zT_3[zT_4];
    ty = zT_5;
    ty = zT_5;
    ty = zT_5;
    zT_6 = ty.kind;
    zT_7 = zT_33EF6BFB_TypeKind_array_type;
    zT_8 = zT_6 == zT_7;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = self->array_items;
    zT_10 = ty.payload_idx;
    zT_11 = (unsigned int)zT_10;
    zT_12 = zT_9[zT_11];
    zT_13 = zT_12.elem;
    return zT_13;
    z_bb_2:
    zT_14 = ty.kind;
    zT_15 = zT_33EF6BFB_TypeKind_slice_type;
    zT_16 = zT_14 == zT_15;
    if (zT_16) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = self->slice_items;
    zT_18 = ty.payload_idx;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zT_17[zT_19];
    zT_21 = zT_20.elem;
    return zT_21;
    z_bb_4:
    zT_22 = ty.kind;
    zT_23 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_24 = zT_22 == zT_23;
    if (zT_24) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_26 = ty.kind;
    zT_27 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_28 = zT_26 == zT_27;
    zT_25 = zT_28;
    goto z_bb_7;
    z_bb_6:
    zT_25 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_25) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_30 = self->ptr_items;
    zT_31 = ty.payload_idx;
    zT_32 = (unsigned int)zT_31;
    zT_33 = zT_30[zT_32];
    zT_34 = zT_33.base;
    pointee = zT_34;
    pointee = zT_34;
    pointee = zT_34;
    zT_36 = self->types_items;
    zT_37 = (unsigned int)pointee;
    zT_38 = zT_36[zT_37];
    pointee_ty = zT_38;
    pointee_ty = zT_38;
    pointee_ty = zT_38;
    zT_39 = pointee_ty.kind;
    zT_40 = zT_33EF6BFB_TypeKind_array_type;
    zT_41 = zT_39 == zT_40;
    if (zT_41) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    zT_47 = 18;
    return zT_47;
    z_bb_10:
    zT_42 = self->array_items;
    zT_43 = pointee_ty.payload_idx;
    zT_44 = (unsigned int)zT_43;
    zT_45 = zT_42[zT_44];
    zT_46 = zT_45.elem;
    return zT_46;
    z_bb_11:
    return pointee;
}

/* typeRegistryIsOptional */
int zF_DA6AF452_typeRegistryIsOptio(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    int zT_6;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.kind;
    zT_5 = zT_33EF6BFB_TypeKind_optional_type;
    zT_6 = zT_4 == zT_5;
    return zT_6;
}

/* typeRegistryIsErrorSet */
int zF_B8767394_typeRegistryIsError(zT_338B7C76_TypeRegistry* self, unsigned int tid) {
    zT_D155D06D_Type* zT_2;
    zT_D155D06D_Type zT_3;
    zT_33EF6BFB_TypeKind zT_4;
    zT_33EF6BFB_TypeKind zT_5;
    int zT_6;
    zT_2 = self->types_items;
    zT_3 = zT_2[tid];
    zT_4 = zT_3.kind;
    zT_5 = zT_33EF6BFB_TypeKind_error_set_type;
    zT_6 = zT_4 == zT_5;
    return zT_6;
}

/* typeRegistryGetStructFields */
void zF_5A40A2EE_typeRegistryGetStru(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BF2E90D8_Slice_zT_2DF01B61_F* out) {
    zT_D155D06D_Type* zT_4;
    zT_D155D06D_Type zT_5;
    zT_406493CE_StructPayload* zT_7;
    unsigned int zT_8;
    zT_406493CE_StructPayload zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned short zT_14;
    unsigned int zT_15;
    zT_2DF01B61_FieldEntry* zT_16;
    unsigned int zT_17;
    zT_2DF01B61_FieldEntry* zT_18;
    unsigned int zT_19;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_20;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload sp;
    unsigned int fstart;
    unsigned int fcount;
    zT_4 = self->types_items;
    zT_5 = zT_4[tid];
    ty = zT_5;
    ty = zT_5;
    ty = zT_5;
    zT_7 = self->st_items;
    zT_8 = ty.payload_idx;
    zT_9 = zT_7[zT_8];
    sp = zT_9;
    sp = zT_9;
    sp = zT_9;
    zT_11 = sp.fields_start;
    zT_12 = (unsigned int)zT_11;
    fstart = zT_12;
    fstart = zT_12;
    fstart = zT_12;
    zT_14 = sp.fields_count;
    zT_15 = (unsigned int)zT_14;
    fcount = zT_15;
    fcount = zT_15;
    fcount = zT_15;
    zT_16 = self->fe_items;
    zT_17 = fstart + fcount;
    zT_18 = zT_16 + fstart;
    zT_19 = zT_17 - fstart;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    *out = zT_20;
    return;
}

/* typeRegistryGetUnionFields */
void zF_15BD2D98_typeRegistryGetUnio(zT_338B7C76_TypeRegistry* self, unsigned int tid, zT_BF2E90D8_Slice_zT_2DF01B61_F* out) {
    zT_D155D06D_Type* zT_4;
    zT_D155D06D_Type zT_5;
    zT_AF9231A2_UnionPayload* zT_7;
    unsigned int zT_8;
    zT_AF9231A2_UnionPayload zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned short zT_14;
    unsigned int zT_15;
    zT_2DF01B61_FieldEntry* zT_16;
    unsigned int zT_17;
    zT_2DF01B61_FieldEntry* zT_18;
    unsigned int zT_19;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_20;
    zT_D155D06D_Type ty;
    zT_AF9231A2_UnionPayload up;
    unsigned int fstart;
    unsigned int fcount;
    zT_4 = self->types_items;
    zT_5 = zT_4[tid];
    ty = zT_5;
    ty = zT_5;
    ty = zT_5;
    zT_7 = self->un_items;
    zT_8 = ty.payload_idx;
    zT_9 = zT_7[zT_8];
    up = zT_9;
    up = zT_9;
    up = zT_9;
    zT_11 = up.fields_start;
    zT_12 = (unsigned int)zT_11;
    fstart = zT_12;
    fstart = zT_12;
    fstart = zT_12;
    zT_14 = up.fields_count;
    zT_15 = (unsigned int)zT_14;
    fcount = zT_15;
    fcount = zT_15;
    fcount = zT_15;
    zT_16 = self->fe_items;
    zT_17 = fstart + fcount;
    zT_18 = zT_16 + fstart;
    zT_19 = zT_17 - fstart;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    *out = zT_20;
    return;
}

/* typeRegistryIsAssignable */
int zF_683AEB7F_typeRegistryIsAssig(zT_338B7C76_TypeRegistry* self, unsigned int source, unsigned int target) {
    int zT_3;
    int zT_4;
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    zT_D155D06D_Type zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    zT_33EF6BFB_TypeKind zT_14;
    int zT_15;
    int zT_16;
    zT_338B7C76_TypeRegistry* zT_17;
    unsigned int zT_18;
    int zT_19 = 0;
    int zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    zT_33EF6BFB_TypeKind zT_22;
    int zT_23;
    int zT_24;
    unsigned int zT_25;
    int zT_26;
    int zT_27;
    zT_338B7C76_TypeRegistry* zT_28;
    unsigned int zT_29;
    int zT_30 = 0;
    int zT_31;
    zT_338B7C76_TypeRegistry* zT_32;
    unsigned int zT_33;
    int zT_34 = 0;
    int zT_35;
    unsigned int zT_36;
    int zT_37;
    zT_338B7C76_TypeRegistry* zT_38;
    unsigned int zT_39;
    int zT_40 = 0;
    zT_338B7C76_TypeRegistry* zT_41;
    unsigned int zT_42;
    int zT_43 = 0;
    int zT_44;
    int zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    int zT_48;
    int zT_49;
    unsigned int zT_50;
    int zT_51;
    int zT_52;
    unsigned int zT_53;
    int zT_54;
    int zT_55;
    zT_33EF6BFB_TypeKind zT_56;
    zT_33EF6BFB_TypeKind zT_57;
    int zT_58;
    zT_338B7C76_TypeRegistry* zT_59;
    unsigned int zT_60;
    int zT_61 = 0;
    int zT_62;
    zT_33EF6BFB_TypeKind zT_63;
    zT_33EF6BFB_TypeKind zT_64;
    int zT_65;
    int zT_66;
    zT_33EF6BFB_TypeKind zT_67;
    zT_33EF6BFB_TypeKind zT_68;
    int zT_69;
    int zT_70;
    zT_33EF6BFB_TypeKind zT_71;
    zT_33EF6BFB_TypeKind zT_72;
    int zT_73;
    int zT_74;
    zT_33EF6BFB_TypeKind zT_75;
    zT_33EF6BFB_TypeKind zT_76;
    int zT_77;
    zT_112BF819_PtrPayload* zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    zT_112BF819_PtrPayload zT_82;
    zT_D155D06D_Type* zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    zT_D155D06D_Type zT_87;
    zT_33EF6BFB_TypeKind zT_88;
    zT_33EF6BFB_TypeKind zT_89;
    int zT_90;
    zT_0317B1D5_FnPayload* zT_92;
    unsigned int zT_93;
    unsigned int zT_94;
    zT_0317B1D5_FnPayload zT_95;
    zT_0317B1D5_FnPayload* zT_97;
    unsigned int zT_98;
    unsigned int zT_99;
    zT_0317B1D5_FnPayload zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    int zT_103;
    int zT_104;
    unsigned short zT_105;
    unsigned short zT_106;
    int zT_107;
    int zT_108;
    unsigned char zT_109;
    unsigned char zT_110;
    int zT_111;
    int zT_112;
    unsigned char zT_113;
    unsigned char zT_114;
    unsigned char zT_115;
    unsigned char zT_116;
    unsigned char zT_117;
    unsigned char zT_118;
    int zT_119;
    int zT_121;
    int zT_123;
    unsigned short zT_124;
    unsigned short zT_125;
    int zT_126;
    unsigned int* zT_127;
    unsigned int zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    unsigned int zT_131;
    unsigned int zT_132;
    unsigned int* zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    unsigned int zT_138;
    int zT_139;
    int zT_140;
    int zT_141;
    unsigned int zT_142;
    int zT_143;
    zT_33EF6BFB_TypeKind zT_144;
    zT_33EF6BFB_TypeKind zT_145;
    int zT_146;
    zT_0B10E8E9_OptionalPayload* zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    zT_0B10E8E9_OptionalPayload zT_151;
    zT_338B7C76_TypeRegistry* zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    int zT_156 = 0;
    int zT_157;
    zT_33EF6BFB_TypeKind zT_158;
    zT_33EF6BFB_TypeKind zT_159;
    int zT_160;
    int zT_161;
    zT_33EF6BFB_TypeKind zT_162;
    zT_33EF6BFB_TypeKind zT_163;
    int zT_164;
    int zT_165;
    zT_33EF6BFB_TypeKind zT_166;
    zT_33EF6BFB_TypeKind zT_167;
    int zT_168;
    zT_42C2D6BF_EUPayload* zT_170;
    unsigned int zT_171;
    unsigned int zT_172;
    zT_42C2D6BF_EUPayload zT_173;
    zT_42C2D6BF_EUPayload* zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    zT_42C2D6BF_EUPayload zT_178;
    unsigned int zT_179;
    unsigned int zT_180;
    int zT_181;
    zT_338B7C76_TypeRegistry* zT_182;
    unsigned int zT_183;
    unsigned int zT_184;
    unsigned int zT_185;
    unsigned int zT_186;
    zT_33EF6BFB_TypeKind zT_188;
    zT_33EF6BFB_TypeKind zT_189;
    int zT_190;
    zT_42C2D6BF_EUPayload* zT_192;
    unsigned int zT_193;
    unsigned int zT_194;
    zT_42C2D6BF_EUPayload zT_195;
    zT_338B7C76_TypeRegistry* zT_196;
    unsigned int zT_197;
    unsigned int zT_198;
    unsigned int zT_199;
    int zT_200 = 0;
    int zT_201;
    zT_33EF6BFB_TypeKind zT_202;
    zT_33EF6BFB_TypeKind zT_203;
    int zT_204;
    int zT_205;
    zT_33EF6BFB_TypeKind zT_206;
    zT_33EF6BFB_TypeKind zT_207;
    int zT_208;
    int zT_209;
    zT_33EF6BFB_TypeKind zT_210;
    zT_33EF6BFB_TypeKind zT_211;
    int zT_212;
    int zT_213;
    zT_33EF6BFB_TypeKind zT_214;
    zT_33EF6BFB_TypeKind zT_215;
    int zT_216;
    zT_112BF819_PtrPayload* zT_218;
    unsigned int zT_219;
    unsigned int zT_220;
    zT_112BF819_PtrPayload zT_221;
    zT_112BF819_PtrPayload* zT_223;
    unsigned int zT_224;
    unsigned int zT_225;
    zT_112BF819_PtrPayload zT_226;
    unsigned int zT_227;
    unsigned int zT_228;
    int zT_229;
    int zT_230;
    unsigned int zT_231;
    unsigned int zT_232;
    int zT_233;
    int zT_234;
    unsigned char zT_235;
    unsigned char zT_236;
    unsigned char zT_237;
    unsigned char zT_238;
    int zT_239;
    int zT_240;
    unsigned char zT_241;
    unsigned char zT_242;
    unsigned char zT_243;
    unsigned char zT_244;
    int zT_245;
    unsigned int zT_246;
    unsigned int zT_247;
    int zT_248;
    int zT_249;
    zT_33EF6BFB_TypeKind zT_250;
    zT_33EF6BFB_TypeKind zT_251;
    int zT_252;
    int zT_253;
    zT_33EF6BFB_TypeKind zT_254;
    zT_33EF6BFB_TypeKind zT_255;
    int zT_256;
    unsigned char zT_257;
    unsigned char zT_258;
    unsigned char zT_259;
    unsigned char zT_260;
    int zT_261;
    int zT_262;
    unsigned char zT_263;
    unsigned char zT_264;
    unsigned char zT_265;
    unsigned char zT_266;
    int zT_267;
    zT_0BB2A741_SlicePayload* zT_269;
    unsigned int zT_270;
    unsigned int zT_271;
    zT_0BB2A741_SlicePayload zT_272;
    zT_0BB2A741_SlicePayload* zT_274;
    unsigned int zT_275;
    unsigned int zT_276;
    zT_0BB2A741_SlicePayload zT_277;
    unsigned int zT_278;
    unsigned int zT_279;
    int zT_280;
    int zT_281;
    zT_33EF6BFB_TypeKind zT_282;
    zT_33EF6BFB_TypeKind zT_283;
    int zT_284;
    int zT_285;
    zT_33EF6BFB_TypeKind zT_286;
    zT_33EF6BFB_TypeKind zT_287;
    int zT_288;
    zT_112BF819_PtrPayload* zT_290;
    unsigned int zT_291;
    unsigned int zT_292;
    zT_112BF819_PtrPayload zT_293;
    zT_0BB2A741_SlicePayload* zT_295;
    unsigned int zT_296;
    unsigned int zT_297;
    zT_0BB2A741_SlicePayload zT_298;
    zT_D155D06D_Type* zT_300;
    unsigned int zT_301;
    unsigned int zT_302;
    zT_D155D06D_Type zT_303;
    zT_33EF6BFB_TypeKind zT_304;
    zT_33EF6BFB_TypeKind zT_305;
    int zT_306;
    zT_E834303C_ArrayPayload* zT_308;
    unsigned int zT_309;
    unsigned int zT_310;
    zT_E834303C_ArrayPayload zT_311;
    unsigned int zT_312;
    unsigned int zT_313;
    int zT_314;
    int zT_315;
    unsigned int zT_316;
    unsigned int zT_317;
    int zT_318;
    int zT_319;
    unsigned int zT_320;
    unsigned int zT_321;
    int zT_322;
    int zT_323;
    unsigned int zT_324;
    unsigned int zT_325;
    int zT_326;
    int zT_327;
    unsigned int zT_328;
    unsigned int zT_329;
    int zT_330;
    int zT_331;
    unsigned int zT_332;
    unsigned int zT_333;
    int zT_334;
    int zT_335;
    zT_33EF6BFB_TypeKind zT_336;
    zT_33EF6BFB_TypeKind zT_337;
    int zT_338;
    int zT_339;
    zT_33EF6BFB_TypeKind zT_340;
    zT_33EF6BFB_TypeKind zT_341;
    int zT_342;
    unsigned char zT_343;
    unsigned char zT_344;
    unsigned char zT_345;
    unsigned char zT_346;
    int zT_347;
    int zT_348;
    unsigned char zT_349;
    unsigned char zT_350;
    unsigned char zT_351;
    unsigned char zT_352;
    int zT_353;
    zT_112BF819_PtrPayload* zT_355;
    unsigned int zT_356;
    unsigned int zT_357;
    zT_112BF819_PtrPayload zT_358;
    zT_112BF819_PtrPayload* zT_360;
    unsigned int zT_361;
    unsigned int zT_362;
    zT_112BF819_PtrPayload zT_363;
    unsigned int zT_364;
    unsigned int zT_365;
    int zT_366;
    int zT_367;
    zT_33EF6BFB_TypeKind zT_368;
    zT_33EF6BFB_TypeKind zT_369;
    int zT_370;
    int zT_371;
    zT_33EF6BFB_TypeKind zT_372;
    zT_33EF6BFB_TypeKind zT_373;
    int zT_374;
    zT_112BF819_PtrPayload* zT_376;
    unsigned int zT_377;
    unsigned int zT_378;
    zT_112BF819_PtrPayload zT_379;
    zT_0BB2A741_SlicePayload* zT_381;
    unsigned int zT_382;
    unsigned int zT_383;
    zT_0BB2A741_SlicePayload zT_384;
    unsigned int zT_385;
    unsigned int zT_386;
    int zT_387;
    int zT_388;
    unsigned int zT_389;
    unsigned int zT_390;
    int zT_391;
    int zT_392;
    unsigned int zT_393;
    unsigned int zT_394;
    int zT_395;
    int zT_396;
    unsigned int zT_397;
    unsigned int zT_398;
    int zT_399;
    int zT_400;
    unsigned int zT_401;
    unsigned int zT_402;
    int zT_403;
    int zT_404;
    zT_33EF6BFB_TypeKind zT_405;
    zT_33EF6BFB_TypeKind zT_406;
    int zT_407;
    int zT_408;
    zT_33EF6BFB_TypeKind zT_409;
    zT_33EF6BFB_TypeKind zT_410;
    int zT_411;
    zT_E834303C_ArrayPayload* zT_413;
    unsigned int zT_414;
    unsigned int zT_415;
    zT_E834303C_ArrayPayload zT_416;
    zT_0BB2A741_SlicePayload* zT_418;
    unsigned int zT_419;
    unsigned int zT_420;
    zT_0BB2A741_SlicePayload zT_421;
    unsigned int zT_422;
    unsigned int zT_423;
    int zT_424;
    int zT_425;
    unsigned char zT_426;
    unsigned char zT_427;
    unsigned char zT_428;
    unsigned char zT_429;
    int zT_430;
    int zT_431;
    unsigned int zT_432;
    unsigned int zT_433;
    int zT_434;
    int zT_435;
    zT_33EF6BFB_TypeKind zT_436;
    zT_33EF6BFB_TypeKind zT_437;
    int zT_438;
    int zT_439;
    zT_33EF6BFB_TypeKind zT_440;
    zT_33EF6BFB_TypeKind zT_441;
    int zT_442;
    zT_E834303C_ArrayPayload* zT_444;
    unsigned int zT_445;
    unsigned int zT_446;
    zT_E834303C_ArrayPayload zT_447;
    zT_112BF819_PtrPayload* zT_449;
    unsigned int zT_450;
    unsigned int zT_451;
    zT_112BF819_PtrPayload zT_452;
    unsigned int zT_453;
    unsigned int zT_454;
    int zT_455;
    int zT_456;
    zT_33EF6BFB_TypeKind zT_457;
    zT_33EF6BFB_TypeKind zT_458;
    int zT_459;
    int zT_460;
    zT_33EF6BFB_TypeKind zT_461;
    zT_33EF6BFB_TypeKind zT_462;
    int zT_463;
    zT_0BB2A741_SlicePayload* zT_465;
    unsigned int zT_466;
    unsigned int zT_467;
    zT_0BB2A741_SlicePayload zT_468;
    zT_112BF819_PtrPayload* zT_470;
    unsigned int zT_471;
    unsigned int zT_472;
    zT_112BF819_PtrPayload zT_473;
    unsigned int zT_474;
    unsigned int zT_475;
    int zT_476;
    int zT_477;
    zT_33EF6BFB_TypeKind zT_478;
    zT_33EF6BFB_TypeKind zT_479;
    int zT_480;
    int zT_481;
    zT_33EF6BFB_TypeKind zT_482;
    zT_33EF6BFB_TypeKind zT_483;
    int zT_484;
    zT_0B10E8E9_OptionalPayload* zT_486;
    unsigned int zT_487;
    unsigned int zT_488;
    zT_0B10E8E9_OptionalPayload zT_489;
    zT_D155D06D_Type* zT_491;
    unsigned int zT_492;
    unsigned int zT_493;
    zT_D155D06D_Type zT_494;
    zT_33EF6BFB_TypeKind zT_495;
    zT_33EF6BFB_TypeKind zT_496;
    int zT_497;
    zT_338B7C76_TypeRegistry* zT_498;
    unsigned int zT_499;
    unsigned int zT_500;
    unsigned int zT_501;
    unsigned int zT_503;
    int zT_504;
    int zT_505;
    unsigned int zT_506;
    int zT_507;
    int zT_508;
    unsigned int zT_509;
    int zT_510;
    int zT_511;
    unsigned int zT_512;
    int zT_513;
    int zT_514;
    int zT_515;
    zT_D155D06D_Type src;
    zT_D155D06D_Type tgt;
    zT_112BF819_PtrPayload tpp;
    zT_D155D06D_Type bt;
    zT_0317B1D5_FnPayload src_f;
    zT_0317B1D5_FnPayload tgt_f;
    int ok;
    unsigned short fi;
    zT_0B10E8E9_OptionalPayload opt;
    zT_42C2D6BF_EUPayload eu_src;
    zT_42C2D6BF_EUPayload eu_tgt;
    zT_42C2D6BF_EUPayload eu;
    zT_112BF819_PtrPayload tgt_pp;
    zT_112BF819_PtrPayload src_pp;
    zT_0BB2A741_SlicePayload s_sl;
    zT_0BB2A741_SlicePayload t_sl;
    zT_0BB2A741_SlicePayload sl;
    zT_D155D06D_Type src_pointee;
    zT_E834303C_ArrayPayload arr;
    zT_112BF819_PtrPayload s_pp;
    zT_112BF819_PtrPayload t_pp;
    zT_112BF819_PtrPayload sp2;
    zT_0BB2A741_SlicePayload ts2;
    zT_112BF819_PtrPayload pp;
    zT_D155D06D_Type opt_ty;
    z_bb_0:
    zT_3 = source == target;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = 1;
    return zT_4;
    z_bb_2:
    zT_6 = self->types_items;
    zT_7 = (unsigned int)source;
    zT_8 = zT_6[zT_7];
    src = zT_8;
    src = zT_8;
    src = zT_8;
    zT_10 = self->types_items;
    zT_11 = (unsigned int)target;
    zT_12 = zT_10[zT_11];
    tgt = zT_12;
    tgt = zT_12;
    tgt = zT_12;
    zT_13 = src.kind;
    zT_14 = zT_33EF6BFB_TypeKind_integer_literal_type;
    zT_15 = zT_13 == zT_14;
    if (zT_15) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = self;
    zT_18 = target;
    zT_19 = zF_3087E0A5_typeRegistryIsNumer(zT_17, zT_18);
    zT_16 = zT_19;
    goto z_bb_5;
    z_bb_4:
    zT_16 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_16) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_20 = 1;
    return zT_20;
    z_bb_7:
    zT_21 = src.kind;
    zT_22 = zT_33EF6BFB_TypeKind_integer_literal_type;
    zT_23 = zT_21 == zT_22;
    if (zT_23) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_25 = 14;
    zT_26 = target == zT_25;
    zT_24 = zT_26;
    goto z_bb_10;
    z_bb_9:
    zT_24 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_24) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_27 = 1;
    return zT_27;
    z_bb_12:
    zT_28 = self;
    zT_29 = source;
    zT_30 = zF_3290E9C4_typeRegistryIsInteg(zT_28, zT_29);
    if (zT_30) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_32 = self;
    zT_33 = target;
    zT_34 = zF_3290E9C4_typeRegistryIsInteg(zT_32, zT_33);
    zT_31 = zT_34;
    goto z_bb_15;
    z_bb_14:
    zT_31 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_31) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_36 = 19;
    zT_37 = source != zT_36;
    zT_35 = zT_37;
    goto z_bb_18;
    z_bb_17:
    zT_35 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_35) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_38 = self;
    zT_39 = source;
    zT_40 = zF_B664AC19_typeRegistryIsUnsig(zT_38, zT_39);
    zT_41 = self;
    zT_42 = target;
    zT_43 = zF_B664AC19_typeRegistryIsUnsig(zT_41, zT_42);
    zT_44 = zT_40 == zT_43;
    if (zT_44) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_50 = 15;
    zT_51 = source == zT_50;
    if (zT_51) goto z_bb_26; else goto z_bb_27;
    z_bb_21:
    zT_46 = src.size;
    zT_47 = tgt.size;
    zT_48 = zT_46 < zT_47;
    zT_45 = zT_48;
    goto z_bb_23;
    z_bb_22:
    zT_45 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_45) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_49 = 1;
    return zT_49;
    z_bb_25:
    goto z_bb_20;
    z_bb_26:
    zT_53 = 16;
    zT_54 = target == zT_53;
    zT_52 = zT_54;
    goto z_bb_28;
    z_bb_27:
    zT_52 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_52) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_55 = 1;
    return zT_55;
    z_bb_30:
    zT_56 = src.kind;
    zT_57 = zT_33EF6BFB_TypeKind_null_type;
    zT_58 = zT_56 == zT_57;
    if (zT_58) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_59 = self;
    zT_60 = target;
    zT_61 = zF_AD61DB1B_typeRegistryIsPoint(zT_59, zT_60);
    if (zT_61) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    zT_71 = src.kind;
    zT_72 = zT_33EF6BFB_TypeKind_fn_type;
    zT_73 = zT_71 == zT_72;
    if (zT_73) goto z_bb_39; else goto z_bb_40;
    z_bb_33:
    zT_62 = 1;
    return zT_62;
    z_bb_34:
    zT_63 = tgt.kind;
    zT_64 = zT_33EF6BFB_TypeKind_optional_type;
    zT_65 = zT_63 == zT_64;
    if (zT_65) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_66 = 1;
    return zT_66;
    z_bb_36:
    zT_67 = tgt.kind;
    zT_68 = zT_33EF6BFB_TypeKind_fn_type;
    zT_69 = zT_67 == zT_68;
    if (zT_69) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_70 = 1;
    return zT_70;
    z_bb_38:
    goto z_bb_32;
    z_bb_39:
    zT_75 = tgt.kind;
    zT_76 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_77 = zT_75 == zT_76;
    zT_74 = zT_77;
    goto z_bb_41;
    z_bb_40:
    zT_74 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_74) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_79 = self->ptr_items;
    zT_80 = tgt.payload_idx;
    zT_81 = (unsigned int)zT_80;
    zT_82 = zT_79[zT_81];
    tpp = zT_82;
    tpp = zT_82;
    tpp = zT_82;
    zT_84 = self->types_items;
    zT_85 = tpp.base;
    zT_86 = (unsigned int)zT_85;
    zT_87 = zT_84[zT_86];
    bt = zT_87;
    bt = zT_87;
    bt = zT_87;
    zT_88 = bt.kind;
    zT_89 = zT_33EF6BFB_TypeKind_fn_type;
    zT_90 = zT_88 == zT_89;
    if (zT_90) goto z_bb_44; else goto z_bb_45;
    z_bb_43:
    zT_144 = tgt.kind;
    zT_145 = zT_33EF6BFB_TypeKind_optional_type;
    zT_146 = zT_144 == zT_145;
    if (zT_146) goto z_bb_65; else goto z_bb_66;
    z_bb_44:
    zT_92 = self->fn_items;
    zT_93 = src.payload_idx;
    zT_94 = (unsigned int)zT_93;
    zT_95 = zT_92[zT_94];
    src_f = zT_95;
    src_f = zT_95;
    src_f = zT_95;
    zT_97 = self->fn_items;
    zT_98 = bt.payload_idx;
    zT_99 = (unsigned int)zT_98;
    zT_100 = zT_97[zT_99];
    tgt_f = zT_100;
    tgt_f = zT_100;
    tgt_f = zT_100;
    zT_101 = src_f.return_type;
    zT_102 = tgt_f.return_type;
    zT_103 = zT_101 == zT_102;
    if (zT_103) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    goto z_bb_43;
    z_bb_46:
    zT_105 = src_f.params_count;
    zT_106 = tgt_f.params_count;
    zT_107 = zT_105 == zT_106;
    zT_104 = zT_107;
    goto z_bb_48;
    z_bb_47:
    zT_104 = 0;
    goto z_bb_48;
    z_bb_48:
    if (zT_104) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_109 = src_f.is_extern;
    zT_110 = tgt_f.is_extern;
    zT_111 = zT_109 == zT_110;
    zT_108 = zT_111;
    goto z_bb_51;
    z_bb_50:
    zT_108 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_108) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_113 = src_f.flags_packed;
    zT_114 = 1;
    zT_115 = zT_113 & zT_114;
    zT_116 = tgt_f.flags_packed;
    zT_117 = 1;
    zT_118 = zT_116 & zT_117;
    zT_119 = zT_115 == zT_118;
    zT_112 = zT_119;
    goto z_bb_54;
    z_bb_53:
    zT_112 = 0;
    goto z_bb_54;
    z_bb_54:
    if (zT_112) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_121 = 1;
    ok = zT_121;
    ok = zT_121;
    ok = zT_121;
    zT_123 = 0;
    zT_124 = (unsigned short)zT_123;
    fi = zT_124;
    fi = zT_124;
    fi = zT_124;
    goto z_bb_57;
    z_bb_56:
    goto z_bb_45;
    z_bb_57:
    zT_125 = src_f.params_count;
    zT_126 = fi < zT_125;
    if (zT_126) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_127 = self->xt_items;
    zT_128 = src_f.params_start;
    zT_129 = (unsigned int)fi;
    zT_130 = zT_128 + zT_129;
    zT_131 = (unsigned int)zT_130;
    zT_132 = zT_127[zT_131];
    zT_133 = self->xt_items;
    zT_134 = tgt_f.params_start;
    zT_135 = (unsigned int)fi;
    zT_136 = zT_134 + zT_135;
    zT_137 = (unsigned int)zT_136;
    zT_138 = zT_133[zT_137];
    zT_139 = zT_132 != zT_138;
    if (zT_139) goto z_bb_61; else goto z_bb_62;
    z_bb_59:
    if (ok) goto z_bb_63; else goto z_bb_64;
    z_bb_60:
    zT_141 = 1;
    zT_142 = fi + zT_141;
    fi = zT_142;
    fi = zT_142;
    goto z_bb_57;
    z_bb_61:
    zT_140 = 0;
    ok = zT_140;
    ok = zT_140;
    goto z_bb_59;
    z_bb_62:
    goto z_bb_60;
    z_bb_63:
    zT_143 = 1;
    return zT_143;
    z_bb_64:
    goto z_bb_56;
    z_bb_65:
    zT_148 = self->opt_items;
    zT_149 = tgt.payload_idx;
    zT_150 = (unsigned int)zT_149;
    zT_151 = zT_148[zT_150];
    opt = zT_151;
    opt = zT_151;
    opt = zT_151;
    zT_152 = self;
    zT_153 = source;
    zT_155 = opt.payload;
    zT_154 = zT_155;
    zT_156 = zF_683AEB7F_typeRegistryIsAssig(zT_152, zT_153, zT_154);
    if (zT_156) goto z_bb_67; else goto z_bb_68;
    z_bb_66:
    zT_162 = src.kind;
    zT_163 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_164 = zT_162 == zT_163;
    if (zT_164) goto z_bb_71; else goto z_bb_72;
    z_bb_67:
    zT_157 = 1;
    return zT_157;
    z_bb_68:
    zT_158 = src.kind;
    zT_159 = zT_33EF6BFB_TypeKind_null_type;
    zT_160 = zT_158 == zT_159;
    if (zT_160) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    zT_161 = 1;
    return zT_161;
    z_bb_70:
    goto z_bb_66;
    z_bb_71:
    zT_166 = tgt.kind;
    zT_167 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_168 = zT_166 == zT_167;
    zT_165 = zT_168;
    goto z_bb_73;
    z_bb_72:
    zT_165 = 0;
    goto z_bb_73;
    z_bb_73:
    if (zT_165) goto z_bb_74; else goto z_bb_75;
    z_bb_74:
    zT_170 = self->eu_items;
    zT_171 = src.payload_idx;
    zT_172 = (unsigned int)zT_171;
    zT_173 = zT_170[zT_172];
    eu_src = zT_173;
    eu_src = zT_173;
    eu_src = zT_173;
    zT_175 = self->eu_items;
    zT_176 = tgt.payload_idx;
    zT_177 = (unsigned int)zT_176;
    zT_178 = zT_175[zT_177];
    eu_tgt = zT_178;
    eu_tgt = zT_178;
    eu_tgt = zT_178;
    zT_179 = eu_src.error_set;
    zT_180 = eu_tgt.error_set;
    zT_181 = zT_179 == zT_180;
    if (zT_181) goto z_bb_76; else goto z_bb_77;
    z_bb_75:
    zT_188 = tgt.kind;
    zT_189 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_190 = zT_188 == zT_189;
    if (zT_190) goto z_bb_78; else goto z_bb_79;
    z_bb_76:
    zT_182 = self;
    zT_185 = eu_src.payload;
    zT_183 = zT_185;
    zT_186 = eu_tgt.payload;
    zT_184 = zT_186;
    self = zT_182;
    source = zT_183;
    target = zT_184;
    goto z_bb_0;
    z_bb_77:
    goto z_bb_75;
    z_bb_78:
    zT_192 = self->eu_items;
    zT_193 = tgt.payload_idx;
    zT_194 = (unsigned int)zT_193;
    zT_195 = zT_192[zT_194];
    eu = zT_195;
    eu = zT_195;
    eu = zT_195;
    zT_196 = self;
    zT_197 = source;
    zT_199 = eu.payload;
    zT_198 = zT_199;
    zT_200 = zF_683AEB7F_typeRegistryIsAssig(zT_196, zT_197, zT_198);
    if (zT_200) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    zT_202 = src.kind;
    zT_203 = zT_33EF6BFB_TypeKind_error_set_type;
    zT_204 = zT_202 == zT_203;
    if (zT_204) goto z_bb_82; else goto z_bb_83;
    z_bb_80:
    zT_201 = 1;
    return zT_201;
    z_bb_81:
    goto z_bb_79;
    z_bb_82:
    zT_206 = tgt.kind;
    zT_207 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_208 = zT_206 == zT_207;
    zT_205 = zT_208;
    goto z_bb_84;
    z_bb_83:
    zT_205 = 0;
    goto z_bb_84;
    z_bb_84:
    if (zT_205) goto z_bb_85; else goto z_bb_86;
    z_bb_85:
    zT_209 = 1;
    return zT_209;
    z_bb_86:
    zT_210 = src.kind;
    zT_211 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_212 = zT_210 == zT_211;
    if (zT_212) goto z_bb_87; else goto z_bb_88;
    z_bb_87:
    zT_214 = tgt.kind;
    zT_215 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_216 = zT_214 == zT_215;
    zT_213 = zT_216;
    goto z_bb_89;
    z_bb_88:
    zT_213 = 0;
    goto z_bb_89;
    z_bb_89:
    if (zT_213) goto z_bb_90; else goto z_bb_91;
    z_bb_90:
    zT_218 = self->ptr_items;
    zT_219 = tgt.payload_idx;
    zT_220 = (unsigned int)zT_219;
    zT_221 = zT_218[zT_220];
    tgt_pp = zT_221;
    tgt_pp = zT_221;
    tgt_pp = zT_221;
    zT_223 = self->ptr_items;
    zT_224 = src.payload_idx;
    zT_225 = (unsigned int)zT_224;
    zT_226 = zT_223[zT_225];
    src_pp = zT_226;
    src_pp = zT_226;
    src_pp = zT_226;
    zT_227 = tgt_pp.base;
    zT_228 = 1;
    zT_229 = zT_227 == zT_228;
    if (zT_229) goto z_bb_92; else goto z_bb_93;
    z_bb_91:
    zT_250 = tgt.kind;
    zT_251 = zT_33EF6BFB_TypeKind_slice_type;
    zT_252 = zT_250 == zT_251;
    if (zT_252) goto z_bb_103; else goto z_bb_104;
    z_bb_92:
    zT_230 = 1;
    return zT_230;
    z_bb_93:
    zT_231 = src_pp.base;
    zT_232 = 1;
    zT_233 = zT_231 == zT_232;
    if (zT_233) goto z_bb_94; else goto z_bb_95;
    z_bb_94:
    zT_234 = 1;
    return zT_234;
    z_bb_95:
    zT_235 = tgt.flags;
    zT_236 = 1;
    zT_237 = zT_235 & zT_236;
    zT_238 = 0;
    zT_239 = zT_237 != zT_238;
    if (zT_239) goto z_bb_96; else goto z_bb_97;
    z_bb_96:
    zT_241 = src.flags;
    zT_242 = 1;
    zT_243 = zT_241 & zT_242;
    zT_244 = 0;
    zT_245 = zT_243 == zT_244;
    zT_240 = zT_245;
    goto z_bb_98;
    z_bb_97:
    zT_240 = 0;
    goto z_bb_98;
    z_bb_98:
    if (zT_240) goto z_bb_99; else goto z_bb_100;
    z_bb_99:
    zT_246 = src_pp.base;
    zT_247 = tgt_pp.base;
    zT_248 = zT_246 == zT_247;
    if (zT_248) goto z_bb_101; else goto z_bb_102;
    z_bb_100:
    goto z_bb_91;
    z_bb_101:
    zT_249 = 1;
    return zT_249;
    z_bb_102:
    goto z_bb_100;
    z_bb_103:
    zT_254 = src.kind;
    zT_255 = zT_33EF6BFB_TypeKind_slice_type;
    zT_256 = zT_254 == zT_255;
    zT_253 = zT_256;
    goto z_bb_105;
    z_bb_104:
    zT_253 = 0;
    goto z_bb_105;
    z_bb_105:
    if (zT_253) goto z_bb_106; else goto z_bb_107;
    z_bb_106:
    zT_257 = tgt.flags;
    zT_258 = 1;
    zT_259 = zT_257 & zT_258;
    zT_260 = 0;
    zT_261 = zT_259 != zT_260;
    if (zT_261) goto z_bb_108; else goto z_bb_109;
    z_bb_107:
    zT_282 = tgt.kind;
    zT_283 = zT_33EF6BFB_TypeKind_slice_type;
    zT_284 = zT_282 == zT_283;
    if (zT_284) goto z_bb_115; else goto z_bb_116;
    z_bb_108:
    zT_263 = src.flags;
    zT_264 = 1;
    zT_265 = zT_263 & zT_264;
    zT_266 = 0;
    zT_267 = zT_265 == zT_266;
    zT_262 = zT_267;
    goto z_bb_110;
    z_bb_109:
    zT_262 = 0;
    goto z_bb_110;
    z_bb_110:
    if (zT_262) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_269 = self->slice_items;
    zT_270 = src.payload_idx;
    zT_271 = (unsigned int)zT_270;
    zT_272 = zT_269[zT_271];
    s_sl = zT_272;
    s_sl = zT_272;
    s_sl = zT_272;
    zT_274 = self->slice_items;
    zT_275 = tgt.payload_idx;
    zT_276 = (unsigned int)zT_275;
    zT_277 = zT_274[zT_276];
    t_sl = zT_277;
    t_sl = zT_277;
    t_sl = zT_277;
    zT_278 = s_sl.elem;
    zT_279 = t_sl.elem;
    zT_280 = zT_278 == zT_279;
    if (zT_280) goto z_bb_113; else goto z_bb_114;
    z_bb_112:
    goto z_bb_107;
    z_bb_113:
    zT_281 = 1;
    return zT_281;
    z_bb_114:
    goto z_bb_112;
    z_bb_115:
    zT_286 = src.kind;
    zT_287 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_288 = zT_286 == zT_287;
    zT_285 = zT_288;
    goto z_bb_117;
    z_bb_116:
    zT_285 = 0;
    goto z_bb_117;
    z_bb_117:
    if (zT_285) goto z_bb_118; else goto z_bb_119;
    z_bb_118:
    zT_290 = self->ptr_items;
    zT_291 = src.payload_idx;
    zT_292 = (unsigned int)zT_291;
    zT_293 = zT_290[zT_292];
    src_pp = zT_293;
    src_pp = zT_293;
    src_pp = zT_293;
    zT_295 = self->slice_items;
    zT_296 = tgt.payload_idx;
    zT_297 = (unsigned int)zT_296;
    zT_298 = zT_295[zT_297];
    sl = zT_298;
    sl = zT_298;
    sl = zT_298;
    zT_300 = self->types_items;
    zT_301 = src_pp.base;
    zT_302 = (unsigned int)zT_301;
    zT_303 = zT_300[zT_302];
    src_pointee = zT_303;
    src_pointee = zT_303;
    src_pointee = zT_303;
    zT_304 = src_pointee.kind;
    zT_305 = zT_33EF6BFB_TypeKind_array_type;
    zT_306 = zT_304 == zT_305;
    if (zT_306) goto z_bb_120; else goto z_bb_121;
    z_bb_119:
    zT_336 = tgt.kind;
    zT_337 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_338 = zT_336 == zT_337;
    if (zT_338) goto z_bb_136; else goto z_bb_137;
    z_bb_120:
    zT_308 = self->array_items;
    zT_309 = src_pointee.payload_idx;
    zT_310 = (unsigned int)zT_309;
    zT_311 = zT_308[zT_310];
    arr = zT_311;
    arr = zT_311;
    arr = zT_311;
    zT_312 = arr.elem;
    zT_313 = sl.elem;
    zT_314 = zT_312 == zT_313;
    if (zT_314) goto z_bb_122; else goto z_bb_123;
    z_bb_121:
    zT_316 = src_pp.base;
    zT_317 = sl.elem;
    zT_318 = zT_316 == zT_317;
    if (zT_318) goto z_bb_124; else goto z_bb_125;
    z_bb_122:
    zT_315 = 1;
    return zT_315;
    z_bb_123:
    goto z_bb_121;
    z_bb_124:
    zT_319 = 1;
    return zT_319;
    z_bb_125:
    zT_320 = src_pp.base;
    zT_321 = 14;
    zT_322 = zT_320 == zT_321;
    if (zT_322) goto z_bb_126; else goto z_bb_127;
    z_bb_126:
    zT_324 = sl.elem;
    zT_325 = 8;
    zT_326 = zT_324 == zT_325;
    zT_323 = zT_326;
    goto z_bb_128;
    z_bb_127:
    zT_323 = 0;
    goto z_bb_128;
    z_bb_128:
    if (zT_323) goto z_bb_129; else goto z_bb_130;
    z_bb_129:
    zT_327 = 1;
    return zT_327;
    z_bb_130:
    zT_328 = src_pp.base;
    zT_329 = 8;
    zT_330 = zT_328 == zT_329;
    if (zT_330) goto z_bb_131; else goto z_bb_132;
    z_bb_131:
    zT_332 = sl.elem;
    zT_333 = 14;
    zT_334 = zT_332 == zT_333;
    zT_331 = zT_334;
    goto z_bb_133;
    z_bb_132:
    zT_331 = 0;
    goto z_bb_133;
    z_bb_133:
    if (zT_331) goto z_bb_134; else goto z_bb_135;
    z_bb_134:
    zT_335 = 1;
    return zT_335;
    z_bb_135:
    goto z_bb_119;
    z_bb_136:
    zT_340 = src.kind;
    zT_341 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_342 = zT_340 == zT_341;
    zT_339 = zT_342;
    goto z_bb_138;
    z_bb_137:
    zT_339 = 0;
    goto z_bb_138;
    z_bb_138:
    if (zT_339) goto z_bb_139; else goto z_bb_140;
    z_bb_139:
    zT_343 = tgt.flags;
    zT_344 = 1;
    zT_345 = zT_343 & zT_344;
    zT_346 = 0;
    zT_347 = zT_345 != zT_346;
    if (zT_347) goto z_bb_141; else goto z_bb_142;
    z_bb_140:
    zT_368 = src.kind;
    zT_369 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_370 = zT_368 == zT_369;
    if (zT_370) goto z_bb_148; else goto z_bb_149;
    z_bb_141:
    zT_349 = src.flags;
    zT_350 = 1;
    zT_351 = zT_349 & zT_350;
    zT_352 = 0;
    zT_353 = zT_351 == zT_352;
    zT_348 = zT_353;
    goto z_bb_143;
    z_bb_142:
    zT_348 = 0;
    goto z_bb_143;
    z_bb_143:
    if (zT_348) goto z_bb_144; else goto z_bb_145;
    z_bb_144:
    zT_355 = self->ptr_items;
    zT_356 = src.payload_idx;
    zT_357 = (unsigned int)zT_356;
    zT_358 = zT_355[zT_357];
    s_pp = zT_358;
    s_pp = zT_358;
    s_pp = zT_358;
    zT_360 = self->ptr_items;
    zT_361 = tgt.payload_idx;
    zT_362 = (unsigned int)zT_361;
    zT_363 = zT_360[zT_362];
    t_pp = zT_363;
    t_pp = zT_363;
    t_pp = zT_363;
    zT_364 = s_pp.base;
    zT_365 = t_pp.base;
    zT_366 = zT_364 == zT_365;
    if (zT_366) goto z_bb_146; else goto z_bb_147;
    z_bb_145:
    goto z_bb_140;
    z_bb_146:
    zT_367 = 1;
    return zT_367;
    z_bb_147:
    goto z_bb_145;
    z_bb_148:
    zT_372 = tgt.kind;
    zT_373 = zT_33EF6BFB_TypeKind_slice_type;
    zT_374 = zT_372 == zT_373;
    zT_371 = zT_374;
    goto z_bb_150;
    z_bb_149:
    zT_371 = 0;
    goto z_bb_150;
    z_bb_150:
    if (zT_371) goto z_bb_151; else goto z_bb_152;
    z_bb_151:
    zT_376 = self->ptr_items;
    zT_377 = src.payload_idx;
    zT_378 = (unsigned int)zT_377;
    zT_379 = zT_376[zT_378];
    sp2 = zT_379;
    sp2 = zT_379;
    sp2 = zT_379;
    zT_381 = self->slice_items;
    zT_382 = tgt.payload_idx;
    zT_383 = (unsigned int)zT_382;
    zT_384 = zT_381[zT_383];
    ts2 = zT_384;
    ts2 = zT_384;
    ts2 = zT_384;
    zT_385 = sp2.base;
    zT_386 = ts2.elem;
    zT_387 = zT_385 == zT_386;
    if (zT_387) goto z_bb_153; else goto z_bb_154;
    z_bb_152:
    zT_405 = src.kind;
    zT_406 = zT_33EF6BFB_TypeKind_array_type;
    zT_407 = zT_405 == zT_406;
    if (zT_407) goto z_bb_166; else goto z_bb_167;
    z_bb_153:
    zT_388 = 1;
    return zT_388;
    z_bb_154:
    zT_389 = sp2.base;
    zT_390 = 14;
    zT_391 = zT_389 == zT_390;
    if (zT_391) goto z_bb_155; else goto z_bb_156;
    z_bb_155:
    zT_393 = ts2.elem;
    zT_394 = 8;
    zT_395 = zT_393 == zT_394;
    zT_392 = zT_395;
    goto z_bb_157;
    z_bb_156:
    zT_392 = 0;
    goto z_bb_157;
    z_bb_157:
    if (zT_392) goto z_bb_159; else goto z_bb_158;
    z_bb_158:
    zT_397 = sp2.base;
    zT_398 = 8;
    zT_399 = zT_397 == zT_398;
    if (zT_399) goto z_bb_161; else goto z_bb_162;
    z_bb_159:
    zT_396 = 1;
    goto z_bb_160;
    z_bb_160:
    if (zT_396) goto z_bb_164; else goto z_bb_165;
    z_bb_161:
    zT_401 = ts2.elem;
    zT_402 = 14;
    zT_403 = zT_401 == zT_402;
    zT_400 = zT_403;
    goto z_bb_163;
    z_bb_162:
    zT_400 = 0;
    goto z_bb_163;
    z_bb_163:
    zT_396 = zT_400;
    goto z_bb_160;
    z_bb_164:
    zT_404 = 1;
    return zT_404;
    z_bb_165:
    goto z_bb_152;
    z_bb_166:
    zT_409 = tgt.kind;
    zT_410 = zT_33EF6BFB_TypeKind_slice_type;
    zT_411 = zT_409 == zT_410;
    zT_408 = zT_411;
    goto z_bb_168;
    z_bb_167:
    zT_408 = 0;
    goto z_bb_168;
    z_bb_168:
    if (zT_408) goto z_bb_169; else goto z_bb_170;
    z_bb_169:
    zT_413 = self->array_items;
    zT_414 = src.payload_idx;
    zT_415 = (unsigned int)zT_414;
    zT_416 = zT_413[zT_415];
    arr = zT_416;
    arr = zT_416;
    arr = zT_416;
    zT_418 = self->slice_items;
    zT_419 = tgt.payload_idx;
    zT_420 = (unsigned int)zT_419;
    zT_421 = zT_418[zT_420];
    sl = zT_421;
    sl = zT_421;
    sl = zT_421;
    zT_422 = arr.elem;
    zT_423 = sl.elem;
    zT_424 = zT_422 == zT_423;
    if (zT_424) goto z_bb_171; else goto z_bb_172;
    z_bb_170:
    zT_436 = src.kind;
    zT_437 = zT_33EF6BFB_TypeKind_array_type;
    zT_438 = zT_436 == zT_437;
    if (zT_438) goto z_bb_178; else goto z_bb_179;
    z_bb_171:
    zT_425 = 1;
    return zT_425;
    z_bb_172:
    zT_426 = tgt.flags;
    zT_427 = 1;
    zT_428 = zT_426 & zT_427;
    zT_429 = 0;
    zT_430 = zT_428 != zT_429;
    if (zT_430) goto z_bb_173; else goto z_bb_174;
    z_bb_173:
    zT_432 = arr.elem;
    zT_433 = sl.elem;
    zT_434 = zT_432 == zT_433;
    zT_431 = zT_434;
    goto z_bb_175;
    z_bb_174:
    zT_431 = 0;
    goto z_bb_175;
    z_bb_175:
    if (zT_431) goto z_bb_176; else goto z_bb_177;
    z_bb_176:
    zT_435 = 1;
    return zT_435;
    z_bb_177:
    goto z_bb_170;
    z_bb_178:
    zT_440 = tgt.kind;
    zT_441 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_442 = zT_440 == zT_441;
    zT_439 = zT_442;
    goto z_bb_180;
    z_bb_179:
    zT_439 = 0;
    goto z_bb_180;
    z_bb_180:
    if (zT_439) goto z_bb_181; else goto z_bb_182;
    z_bb_181:
    zT_444 = self->array_items;
    zT_445 = src.payload_idx;
    zT_446 = (unsigned int)zT_445;
    zT_447 = zT_444[zT_446];
    arr = zT_447;
    arr = zT_447;
    arr = zT_447;
    zT_449 = self->ptr_items;
    zT_450 = tgt.payload_idx;
    zT_451 = (unsigned int)zT_450;
    zT_452 = zT_449[zT_451];
    pp = zT_452;
    pp = zT_452;
    pp = zT_452;
    zT_453 = arr.elem;
    zT_454 = pp.base;
    zT_455 = zT_453 == zT_454;
    if (zT_455) goto z_bb_183; else goto z_bb_184;
    z_bb_182:
    zT_457 = src.kind;
    zT_458 = zT_33EF6BFB_TypeKind_slice_type;
    zT_459 = zT_457 == zT_458;
    if (zT_459) goto z_bb_185; else goto z_bb_186;
    z_bb_183:
    zT_456 = 1;
    return zT_456;
    z_bb_184:
    goto z_bb_182;
    z_bb_185:
    zT_461 = tgt.kind;
    zT_462 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_463 = zT_461 == zT_462;
    zT_460 = zT_463;
    goto z_bb_187;
    z_bb_186:
    zT_460 = 0;
    goto z_bb_187;
    z_bb_187:
    if (zT_460) goto z_bb_188; else goto z_bb_189;
    z_bb_188:
    zT_465 = self->slice_items;
    zT_466 = src.payload_idx;
    zT_467 = (unsigned int)zT_466;
    zT_468 = zT_465[zT_467];
    sl = zT_468;
    sl = zT_468;
    sl = zT_468;
    zT_470 = self->ptr_items;
    zT_471 = tgt.payload_idx;
    zT_472 = (unsigned int)zT_471;
    zT_473 = zT_470[zT_472];
    pp = zT_473;
    pp = zT_473;
    pp = zT_473;
    zT_474 = sl.elem;
    zT_475 = pp.base;
    zT_476 = zT_474 == zT_475;
    if (zT_476) goto z_bb_190; else goto z_bb_191;
    z_bb_189:
    zT_478 = src.kind;
    zT_479 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_480 = zT_478 == zT_479;
    if (zT_480) goto z_bb_192; else goto z_bb_193;
    z_bb_190:
    zT_477 = 1;
    return zT_477;
    z_bb_191:
    goto z_bb_189;
    z_bb_192:
    zT_482 = tgt.kind;
    zT_483 = zT_33EF6BFB_TypeKind_optional_type;
    zT_484 = zT_482 == zT_483;
    zT_481 = zT_484;
    goto z_bb_194;
    z_bb_193:
    zT_481 = 0;
    goto z_bb_194;
    z_bb_194:
    if (zT_481) goto z_bb_195; else goto z_bb_196;
    z_bb_195:
    zT_486 = self->opt_items;
    zT_487 = tgt.payload_idx;
    zT_488 = (unsigned int)zT_487;
    zT_489 = zT_486[zT_488];
    opt = zT_489;
    opt = zT_489;
    opt = zT_489;
    zT_491 = self->types_items;
    zT_492 = opt.payload;
    zT_493 = (unsigned int)zT_492;
    zT_494 = zT_491[zT_493];
    opt_ty = zT_494;
    opt_ty = zT_494;
    opt_ty = zT_494;
    zT_495 = opt_ty.kind;
    zT_496 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_497 = zT_495 == zT_496;
    if (zT_497) goto z_bb_197; else goto z_bb_198;
    z_bb_196:
    zT_503 = 8;
    zT_504 = source == zT_503;
    if (zT_504) goto z_bb_199; else goto z_bb_200;
    z_bb_197:
    zT_498 = self;
    zT_499 = source;
    zT_501 = opt.payload;
    zT_500 = zT_501;
    self = zT_498;
    source = zT_499;
    target = zT_500;
    goto z_bb_0;
    z_bb_198:
    goto z_bb_196;
    z_bb_199:
    zT_506 = 14;
    zT_507 = target == zT_506;
    zT_505 = zT_507;
    goto z_bb_201;
    z_bb_200:
    zT_505 = 0;
    goto z_bb_201;
    z_bb_201:
    if (zT_505) goto z_bb_203; else goto z_bb_202;
    z_bb_202:
    zT_509 = 14;
    zT_510 = source == zT_509;
    if (zT_510) goto z_bb_205; else goto z_bb_206;
    z_bb_203:
    zT_508 = 1;
    goto z_bb_204;
    z_bb_204:
    if (zT_508) goto z_bb_208; else goto z_bb_209;
    z_bb_205:
    zT_512 = 8;
    zT_513 = target == zT_512;
    zT_511 = zT_513;
    goto z_bb_207;
    z_bb_206:
    zT_511 = 0;
    goto z_bb_207;
    z_bb_207:
    zT_508 = zT_511;
    goto z_bb_204;
    z_bb_208:
    zT_514 = 1;
    return zT_514;
    z_bb_209:
    zT_515 = 0;
    return zT_515;
}

/* canLiteralFitInType */
int zF_C67E36D0_canLiteralFitInType(zT_C69B2266_i64 value, unsigned int target) {
    unsigned int zT_2;
    int zT_3;
    zT_C69B2266_i64 zT_4;
    int zT_5;
    int zT_6;
    zT_C69B2266_i64 zT_7;
    int zT_8;
    unsigned int zT_9;
    int zT_10;
    zT_C69B2266_i64 zT_11;
    int zT_12;
    int zT_13;
    zT_C69B2266_i64 zT_14;
    int zT_15;
    unsigned int zT_16;
    int zT_17;
    zT_C69B2266_i64 zT_18;
    zT_C69B2266_i64 zT_19;
    zT_C69B2266_i64 zT_20;
    int zT_21;
    int zT_22;
    zT_C69B2266_i64 zT_23;
    int zT_24;
    unsigned int zT_25;
    int zT_26;
    int zT_27;
    unsigned int zT_28;
    int zT_29;
    zT_C69B2266_i64 zT_30;
    int zT_31;
    int zT_32;
    zT_C69B2266_i64 zT_33;
    int zT_34;
    unsigned int zT_35;
    int zT_36;
    zT_C69B2266_i64 zT_37;
    int zT_38;
    int zT_39;
    zT_C69B2266_i64 zT_40;
    int zT_41;
    unsigned int zT_42;
    int zT_43;
    zT_C69B2266_i64 zT_44;
    int zT_45;
    int zT_46;
    zT_C69B2266_i64 zT_47;
    int zT_48;
    unsigned int zT_49;
    int zT_50;
    zT_C69B2266_i64 zT_51;
    int zT_52;
    unsigned int zT_53;
    int zT_54;
    zT_C69B2266_i64 zT_55;
    zT_C69B2266_i64 zT_56;
    zT_C69B2266_i64 zT_57;
    int zT_58;
    int zT_59;
    zT_C69B2266_i64 zT_60;
    int zT_61;
    unsigned int zT_62;
    int zT_63;
    zT_C69B2266_i64 zT_64;
    int zT_65;
    int zT_66;
    zT_C69B2266_i64 zT_67;
    int zT_68;
    unsigned int zT_69;
    int zT_70;
    int zT_71;
    unsigned int zT_72;
    int zT_73;
    int zT_74;
    int zT_75;
    zT_2 = 4;
    zT_3 = target == zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = (zT_C69B2266_i64)-128;
    zT_5 = value >= zT_4;
    if (zT_5) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_9 = 5;
    zT_10 = target == zT_9;
    if (zT_10) goto z_bb_6; else goto z_bb_7;
    z_bb_3:
    zT_7 = 127;
    zT_8 = value <= zT_7;
    zT_6 = zT_8;
    goto z_bb_5;
    z_bb_4:
    zT_6 = 0;
    goto z_bb_5;
    z_bb_5:
    return zT_6;
    z_bb_6:
    zT_11 = (zT_C69B2266_i64)-32768;
    zT_12 = value >= zT_11;
    if (zT_12) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_16 = 6;
    zT_17 = target == zT_16;
    if (zT_17) goto z_bb_11; else goto z_bb_12;
    z_bb_8:
    zT_14 = 32767;
    zT_15 = value <= zT_14;
    zT_13 = zT_15;
    goto z_bb_10;
    z_bb_9:
    zT_13 = 0;
    goto z_bb_10;
    z_bb_10:
    return zT_13;
    z_bb_11:
    zT_18 = (zT_C69B2266_i64)-2147483647;
    zT_19 = 1;
    zT_20 = zT_18 - zT_19;
    zT_21 = value >= zT_20;
    if (zT_21) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_25 = 7;
    zT_26 = target == zT_25;
    if (zT_26) goto z_bb_16; else goto z_bb_17;
    z_bb_13:
    zT_23 = 2147483647;
    zT_24 = value <= zT_23;
    zT_22 = zT_24;
    goto z_bb_15;
    z_bb_14:
    zT_22 = 0;
    goto z_bb_15;
    z_bb_15:
    return zT_22;
    z_bb_16:
    zT_27 = 1;
    return zT_27;
    z_bb_17:
    zT_28 = 8;
    zT_29 = target == zT_28;
    if (zT_29) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_30 = 0;
    zT_31 = value >= zT_30;
    if (zT_31) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    zT_35 = 9;
    zT_36 = target == zT_35;
    if (zT_36) goto z_bb_23; else goto z_bb_24;
    z_bb_20:
    zT_33 = 255;
    zT_34 = value <= zT_33;
    zT_32 = zT_34;
    goto z_bb_22;
    z_bb_21:
    zT_32 = 0;
    goto z_bb_22;
    z_bb_22:
    return zT_32;
    z_bb_23:
    zT_37 = 0;
    zT_38 = value >= zT_37;
    if (zT_38) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    zT_42 = 10;
    zT_43 = target == zT_42;
    if (zT_43) goto z_bb_28; else goto z_bb_29;
    z_bb_25:
    zT_40 = 65535;
    zT_41 = value <= zT_40;
    zT_39 = zT_41;
    goto z_bb_27;
    z_bb_26:
    zT_39 = 0;
    goto z_bb_27;
    z_bb_27:
    return zT_39;
    z_bb_28:
    zT_44 = 0;
    zT_45 = value >= zT_44;
    if (zT_45) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    zT_49 = 11;
    zT_50 = target == zT_49;
    if (zT_50) goto z_bb_33; else goto z_bb_34;
    z_bb_30:
    zT_47 = 4294967295u;
    zT_48 = value <= zT_47;
    zT_46 = zT_48;
    goto z_bb_32;
    z_bb_31:
    zT_46 = 0;
    goto z_bb_32;
    z_bb_32:
    return zT_46;
    z_bb_33:
    zT_51 = 0;
    zT_52 = value >= zT_51;
    return zT_52;
    z_bb_34:
    zT_53 = 12;
    zT_54 = target == zT_53;
    if (zT_54) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_55 = (zT_C69B2266_i64)-2147483647;
    zT_56 = 1;
    zT_57 = zT_55 - zT_56;
    zT_58 = value >= zT_57;
    if (zT_58) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_62 = 13;
    zT_63 = target == zT_62;
    if (zT_63) goto z_bb_40; else goto z_bb_41;
    z_bb_37:
    zT_60 = 2147483647;
    zT_61 = value <= zT_60;
    zT_59 = zT_61;
    goto z_bb_39;
    z_bb_38:
    zT_59 = 0;
    goto z_bb_39;
    z_bb_39:
    return zT_59;
    z_bb_40:
    zT_64 = 0;
    zT_65 = value >= zT_64;
    if (zT_65) goto z_bb_42; else goto z_bb_43;
    z_bb_41:
    zT_69 = 15;
    zT_70 = target == zT_69;
    if (zT_70) goto z_bb_46; else goto z_bb_45;
    z_bb_42:
    zT_67 = 4294967295u;
    zT_68 = value <= zT_67;
    zT_66 = zT_68;
    goto z_bb_44;
    z_bb_43:
    zT_66 = 0;
    goto z_bb_44;
    z_bb_44:
    return zT_66;
    z_bb_45:
    zT_72 = 16;
    zT_73 = target == zT_72;
    zT_71 = zT_73;
    goto z_bb_47;
    z_bb_46:
    zT_71 = 1;
    goto z_bb_47;
    z_bb_47:
    if (zT_71) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_74 = 1;
    return zT_74;
    z_bb_49:
    zT_75 = 0;
    return zT_75;
}

/* EOF */
