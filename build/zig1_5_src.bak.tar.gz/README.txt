zig1_5 self-emitted source backup (emergency)
============================================

What this is
------------
A complete, gcc-compilable copy of the self-hosted zig1 compiler (zig1_5) as
plain C89. It was produced by running the working reference compiler:

    /tmp/fx_subfolder/zig1 --dump-c89 --output-dir <gen> sf/src/main.zig

at git HEAD ff5e3633 ("docs: spill backend config plan GATE + reconciliation",
branch zig1_start). This is the FULL self-hosted compiler source, emitted to C,
so it can be rebuilt with gcc alone — no Zig compiler (zig0 or zig1) is required.

Why it exists
-------------
The zig0 -> zig1 bootstrap chain is currently broken (zig0 cannot type-check the
modern sf/src; see the spill-config GATE report). Until that is fixed, this
emitted-C bundle + the committed compiler binaries (build/*.bak) are the only
guaranteed way to reproduce a working compiler from nothing but gcc.

Contents
--------
  gen/       42 .c + 43 .h emitted modules (the entire compiler)
  include/   hand-written runtime/compat: zig_runtime.{c,h}, zig_pal.c,
             zig_compat.h, zig_special_types.h, net_runtime.{c,h}, optstar_repro.h
  c_exit.c   exit-shim linked into the binary
  build.sh   one-command rebuild

Rebuild
-------
  bash build.sh
  # -> ./zig1_5_clean  (32-bit ELF, C89, -O0)

This reproduces the clean (non-ASan) compiler binary.
